package com.tgou.data.stanford.streaming.rec.metrics

import com.alibaba.fastjson.{JSON, JSONObject}
import com.tgou.data.stanford.streaming.core.{KafkaSource, StreamingBootstrap}
import com.tgou.traceInfo.OriginGenerator
import org.apache.spark.sql.{SaveMode, SparkSession}
import org.apache.spark.streaming.StreamingContext

object Application {

  val CHECKPOINT = "/recommend/check_point/metrics_v1"
  val KAFKA_ADDR = "hnode9:9092,hnode10:9092"
  val TOPIC = "scp-topic"
  val PROPERTIES = new java.util.Properties()

  def main(args: Array[String]): Unit = {
    PROPERTIES.setProperty("user","xinhailong")
    PROPERTIES.setProperty("password","test!@3$xhl")
    PROPERTIES.setProperty("batchsize","500")
    new StreamingBootstrap(args, CHECKPOINT).bootstrap(execute)
//    new StreamingBootstrap(Array("test-recommend-metrics","60")/*, CHECKPOINT*/).bootstrap(execute)
  }

  def execute(ssc: StreamingContext, appName: String): Unit = {

    val kafkaParams = Map[String, String]("metadata.broker.list" -> KAFKA_ADDR)

    //点击
    val clicked = KafkaSource.createJSONKafkaDStreams(ssc, appName, "scp-topic")
      .map(t2 => JSON.parseObject(t2.value()))
      .filter(json =>
        json.getString("bk").startsWith("item-")
          //&& !"".equals(json.getString("mi"))
          && !"".equals(json.getString("traceId"))
      )
      .map(parse)
      .reduceByKey(_ + _ )
      .map(t2 => {
        val arr = t2._1.split("\\|")
        Metrics(arr(0),arr(1),arr(2),t2._2,"click")
      })

    clicked.print()
    clicked.foreachRDD( rdd => {

        val spark = SparkSession.builder.config(rdd.sparkContext.getConf).getOrCreate()

        spark.createDataFrame(rdd)
          .write
          .mode(SaveMode.Append)
          .jdbc("jdbc:mysql://10.10.5.11:3306/recommend","metrics",PROPERTIES)
      })

    //曝光
    val exposes = KafkaSource.createJSONKafkaDStreams(ssc, appName, "expose-topic")
      .map(t2 => JSON.parseObject(t2.value()))
      .filter(json =>
        json.getString("bk").startsWith("item-")
          //&& !"".equals(json.getString("mi"))
          && !"".equals(json.getString("traceId"))
      )
      .map(parse)
      .reduceByKey(_ + _ )
      .map(t2 => {
        val arr = t2._1.split("\\|")
        Metrics(arr(0),arr(1),arr(2),t2._2,"expose")
      })

    exposes.print()
    exposes.foreachRDD( rdd => {

        val spark = SparkSession.builder.config(rdd.sparkContext.getConf).getOrCreate()

        spark.createDataFrame(rdd)
          .write
          .mode(SaveMode.Append)
          .jdbc("jdbc:mysql://10.10.5.11:3306/recommend","metrics",PROPERTIES)
      })
  }

  def parse(json:JSONObject): (String,Int) = {
    //仅取前三位
    var scp = json.getString("scp").split("\\.").take(2).mkString(".")

    val global = json.getString("global")

    val traceId = json.getString("traceId")
    val traceJson = OriginGenerator.getOriginJsonObject(traceId)

    var model = traceJson.getString("model")
    if(model == null){
      model = traceJson.getString("model_type")
    }

    (s"$scp|$global|$model",1)
  }
}
case class Metrics(scp:String,global:String, model:String, count:Int, event:String)