package com.tgou.data.stanford.streaming.core

import com.tgou.data.stanford.streaming.core.conf.Conf
import redis.clients.jedis.Jedis

/**
  * Created by 李震 on 2018/5/7.
  */
object RedisSource {

  def getJedis(): Jedis = {
    val conf = Conf.getCacheConf
    val jedis = new Jedis(conf.host, conf.port)
    jedis.auth(conf.password)
    jedis
  }

}
