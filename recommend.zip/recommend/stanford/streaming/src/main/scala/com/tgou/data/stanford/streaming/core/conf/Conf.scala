package com.tgou.data.stanford.streaming.core.conf

import com.alibaba.fastjson.JSON
import org.apache.commons.io.IOUtils
import com.google.common.base.Preconditions._
import org.apache.hadoop.conf.Configuration
import org.apache.hadoop.fs.{FileSystem, Path}


/**
  * Created by 李震 on 2018/4/24.
  */
object Conf {

  private val DATABASE_CONF_DIR = "hdfs://hnode1:8020/app/tgods/conf/db"

  private val CACHE_CONF_DIR = "hdfs://hnode1:8020/app/tgods/conf/cache"

  case class DBConf(url: String, username: String, password: String)

  case class CacheConf(host: String, port: Int, password: String)

  /**
    * 获取数据库连接配置
    *
    * @param dbName 数据库名
    *
    * */
  def getDBConf(dbName: String): DBConf = {
    val path = new Path(s"${DATABASE_CONF_DIR}/${dbName.toLowerCase}.json")
    val fs = FileSystem.get(path.toUri, new Configuration())

    checkState(fs.exists(path), "请检查 %s/%s.json 配置文件是否存在", DATABASE_CONF_DIR, dbName.toLowerCase)

    val in = fs.open(path)
    val jo = JSON.parseObject(IOUtils.toString(in))
    in.close()

    DBConf(jo.getString("url"), jo.getString("username"), jo.getString("password"))
  }

  /**
    * 获取缓存连接配置
    *
    * */
  def getCacheConf: CacheConf = {
    val path = new Path(s"${CACHE_CONF_DIR}/redis.json")
    val fs = FileSystem.get(path.toUri, new Configuration())

    checkState(fs.exists(path), "请检查 %s/redis.json 配置文件是否存在", CACHE_CONF_DIR)

    val in = fs.open(path)
    val jo = JSON.parseObject(IOUtils.toString(in))
    in.close()

    CacheConf(jo.getString("host"), jo.getIntValue("port"), jo.getString("password"))
  }

}
