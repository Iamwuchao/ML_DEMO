package com.tgou.data.stanford.streaming.core.avro

import java.sql.DriverManager
import java.util

import com.tgou.data.stanford.streaming.canal.CanalConstants
import com.tgou.data.stanford.streaming.core.conf.Conf
import org.apache.avro.{Schema, SchemaBuilder}

import scala.collection.JavaConversions._

/**
  * Created by 李震 on 2018/4/10.
  */
object AvroSchema {

  /**
    * 解析 Schema JSON 为 Schema 对象
    *
    * @param json Schema JSON 字符串
    *
    * */
  def parseSchemaJSON(json: String): Schema = {
    new Schema.Parser().parse(json)
  }

  /**
    * 获取 Avro Schema 对象
    *
    * @param tableName 完整的表名
    *
    * */
  def getAvroSchema(tableName: String): Schema = {
    if (tableName.contains(".")) throw new IllegalArgumentException("请输入完整的表名：数据库名.表名")

    val a = tableName.split("\\.")
    getAvroSchema(a(0), a(1))
  }

  /**
    * 获取 Avro Schema 对象
    *
    * @param dbName 数据库名
    * @param tableName 表名
    *
    * */
  def getAvroSchema(dbName: String, tableName: String): Schema = {
    /*
     * 1. 读取数据库配置
     * */
    val dbConf = Conf.getDBConf(dbName)

    /*
     * 2. 查询数据库表 Schema
     * */
    Class.forName("com.mysql.jdbc.Driver")
    val conn = DriverManager.getConnection(dbConf.url, dbConf.username, dbConf.password)
    val rs = conn.getMetaData.getColumns(dbName, null, tableName, "%")


    /*
     * 3. MySQL 类型与 Avro 类型映射
     * */
    var fields = SchemaBuilder
      .record(tableName)
      .namespace(CanalConstants.NAMESPACE)
      .fields()

    // 使用 TreeMap 根据字段所在位置进行排序
    val columnMap = new util.TreeMap[Int, (String, String)]()
    while (rs.next()) {
      val columnName = rs.getString("COLUMN_NAME")
      val typeName = rs.getString("TYPE_NAME")
      val position = rs.getInt("ORDINAL_POSITION")

      columnMap.put(position, (columnName, typeName))
    }
    for (key <- columnMap.keySet().toList) {
      val columnName = columnMap.get(key)._1
      val typeName = columnMap.get(key)._2

      if ("""^(?i)(tinyint)|(smallint)|(mediumint)\(?\d*\)?$""".r.findFirstIn(typeName).isDefined) {
        // INT
        fields = fields.name(columnName).`type`().nullable().intType().noDefault()
      } else if ("""^(?i)(int)|(bigint)\(?\d*\)?$""".r.findFirstIn(typeName).isDefined) {
        // LONG
        fields = fields.name(columnName).`type`().nullable().longType().noDefault()
      } else if ("""^(?i)float$""".r.findFirstIn(typeName).isDefined) {
        // FLOAT
        fields = fields.name(columnName).`type`().nullable().floatType().noDefault()
      } else if ("""^(?i)(double)|(decimal\(?[^\)]*\)?)$""".r.findFirstIn(typeName).isDefined) {
        // DOUBLE
        fields = fields.name(columnName).`type`().nullable().doubleType().noDefault()
      } else if ("""^(?i)(char)|(varchar)\(?\d*\)?$""".r.findFirstIn(typeName).isDefined) {
        // STRING
        fields = fields.name(columnName).`type`().nullable().stringType().noDefault()
      } else if ("timestamp".equalsIgnoreCase(typeName) || "datetime".equalsIgnoreCase(typeName)) {
        // LONG
        fields = fields.name(columnName).`type`().nullable().longType().noDefault()
      }
    }

    val schema = fields.endRecord()

    /*
     * 4. 清理
     * */
    rs.close()
    conn.close()

    schema
  }

}
