package com.tgou.data.stanford.streaming.delivery

import java.util.Date

import com.alibaba.fastjson.{JSON, JSONObject}
import com.datastax.driver.core.Session
import com.google.inject.name.Named
import com.google.inject.{Guice, Inject}
import com.tgou.data.stanford.streaming.core.{CassandraSink, KafkaSource, StreamingBootstrap}
import com.tgou.data.stanford.streaming.delivery.source.DeliverySource
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.streaming.StreamingContext
import org.apache.spark.streaming.kafka010.{CanCommitOffsets, HasOffsetRanges}

import scala.collection.JavaConversions._

/**
  * Created by 李震 on 2018/1/9.
  */
object Application {

  def main(args: Array[String]): Unit = {
    new StreamingBootstrap(args).bootstrap(execute)
  }

  def execute(ssc: StreamingContext, appName: String): Unit = {
    val injector = Guice.createInjector(new ApplicationModule(ssc, appName))
    injector.getInstance(classOf[Application]).run()
  }

  /**
    * 获取最新一条追踪信息
    *
    * @return
    *
    * tracing_time 追踪信息时间戳
    * tracing_msg 追踪信息
    *
    * */
  private def getLatestTracingInfo(comment: String): (Date, String) = {
    var tracing_time: Date = null
    var tracing_msg: String = null

    // 非空判断
    if (comment == null || comment.trim.size == 0) return (tracing_time, tracing_msg)

    try {
      val ja = JSON.parseArray(comment)
      var latestDate: Option[Date] = None // 最近的追踪信息日期
      for(i <- ja) {
        // 获取最新的一条追踪信息
        try {
          if (i.isInstanceOf[JSONObject]) {
            val jo = i.asInstanceOf[JSONObject]

            latestDate match {
              case None => {
                latestDate = Some(jo.getDate("excuteTime"))

                tracing_time = jo.getDate("excuteTime")
                tracing_msg = jo.getString("description")
              }
              case Some(d) => {
                if (d.compareTo(jo.getDate("excuteTime")) < 0) {
                  latestDate = Some(jo.getDate("excuteTime"))

                  tracing_time = jo.getDate("excuteTime")
                  tracing_msg = jo.getString("description")
                }
              }
            }
          }
        } catch {
          case e: Exception => e.printStackTrace()
        }
      }
    } catch {
      case e: Exception => e.printStackTrace()
    }

    (tracing_time, tracing_msg)
  }

  /**
    * 处理 tgou_package 表数据
    *
    * @param context 执行上下文
    *
    * */
  private def processTgouPackage(context: Map[String, Any]): Unit = {
    val jo = JSON.parseObject(context("json").asInstanceOf[String])
    val session = context("cassandra").asInstanceOf[Session]
    val deliveryVendorName = if (jo.getLong("fk_delivery_vendor_id") == null) ""
      else context("broadcast").asInstanceOf[Broadcast[Map[Long, String]]].value(jo.getLong("fk_delivery_vendor_id"))

    // 仅仅处理发货状态的数据
    if (jo.getString("state").equals("Shipped")) {
      // 查询该订单ID + 物流单号是否存在
      val rs = session.execute(
        """
          |select
          |    order_id,
          |    tracking_no,
          |    store_id,
          |    store_name,
          |    yt,
          |    area_id,
          |    area_name,
          |    pay_date,
          |    pay_time
          |from market.tgou_delivery
          |where order_id = ?
        """.stripMargin,
        jo.getLong("fk_tgou_order_id")
      )

      for (row <- rs) {
        if (row.getString("tracking_no").trim.size == 0) {
          // 刚发货
          val payDate = row.getTimestamp("pay_date")

          // 先删
          session.execute(
            """
              |delete
              |from market.tgou_delivery
              |where pay_date = ?
              |and order_id = ?
              |and tracking_no = ''
            """.stripMargin,
            payDate,
            jo.getLong("fk_tgou_order_id")
          )

          // 后插
          session.execute(
            """
              |insert into market.tgou_delivery
              |(
              |    order_id,
              |    tracking_no,
              |    store_id,
              |    store_name,
              |    yt,
              |    area_id,
              |    area_name,
              |    pay_date,
              |    pay_time,
              |    delivery_name,
              |    ship_time
              |)
              |values
              |(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """.stripMargin,
            long2Long(row.getLong("order_id")),
            jo.getString("tracking_no"),
            long2Long(row.getLong("store_id")),
            row.getString("store_name"),
            int2Integer(row.getInt("yt")),
            long2Long(row.getLong("area_id")),
            row.getString("area_name"),
            payDate,
            row.getTimestamp("pay_time"),
            deliveryVendorName,
            jo.getDate("ship_time")
          )
        } else {
          // 已发货
        }
      }
    }
  }

  /**
    * 处理 third_delivery_info_record 表数据
    *
    * @param context 执行上下文
    *
    * */
  private def processThirdDeliveryInfoRecord(context: Map[String, Any]): Unit = {
    val jo = JSON.parseObject(context("json").asInstanceOf[String])
    val session = context("cassandra").asInstanceOf[Session]

    // 获取物流单号获取订单ID、发货时间
    val row = session.execute(
      """
        |select
        |    order_id,
        |    pay_date
        |from market.tgou_delivery
        |where tracking_no=?
      """.stripMargin,
      jo.getString("tracking_no")
    ).one()

    if (row != null) {
      val orderId = row.getLong("order_id")
      val payDate = row.getTimestamp("pay_date")

      // 更新物流状态
      val (tracingTime, tracingMsg) = Application.getLatestTracingInfo(jo.getString("comment"))

      session.execute(
        """
          |update market.tgou_delivery
          |set state = ?, tracing_time = ?, tracing_msg = ?
          |where pay_date = ?
          |and order_id = ?
          |and tracking_no = ?
          |if exists
        """.stripMargin,
        jo.getString("state"),
        tracingTime,
        tracingMsg,
        payDate,
        long2Long(orderId),
        jo.getString("tracking_no")
      )
    }
  }

  /**
    * 处理 third_delivery_info_record_log 表数据
    *
    * @param context 执行上下文
    *
    * */
  private def processThirdDeliveryInfoRecordLog(context: Map[String, Any]): Unit = {
    val jo = JSON.parseObject(context("json").asInstanceOf[String])
    val session = context("cassandra").asInstanceOf[Session]

    // 获取物流单号获取订单ID、发货时间
    val row = session.execute(
      """
        |select
        |    order_id,
        |    pay_date,
        |    way_time
        |from market.tgou_delivery
        |where tracking_no=?
      """.stripMargin,
      jo.getString("tracking_no")
    ).one()

    // 更新揽货时间、发货时间、收货时间
    if (row != null) {
      val orderId = row.getLong("order_id")
      val payDate = row.getTimestamp("pay_date");
      val wayTime = row.getTimestamp("way_time")

      val state = jo.getString("state")
      if ("1".equals(state)) {
        // 揽收
        session.execute(
          """
            |update market.tgou_delivery
            |set accept_time = ?
            |where pay_date = ?
            |and order_id = ?
            |and tracking_no = ?
          """.stripMargin,
          jo.getTimestamp("create_time"),
          payDate,
          long2Long(orderId),
          jo.getString("tracking_no")
        )
      } else if (state.startsWith("2") && wayTime == null) {
        // 在途中
        session.execute(
          """
            |update market.tgou_delivery
            |set way_time = ?
            |where pay_date = ?
            |and order_id = ?
            |and tracking_no = ?
          """.stripMargin,
          jo.getTimestamp("way_time"),
          payDate,
          long2Long(orderId),
          jo.getString("tracking_no")
        )
      } else if ("3".equals(state)) {
        // 收货
        session.execute(
          """
            |update market.tgou_delivery
            |set receive_time = ?
            |where pay_date = ?
            |and order_id = ?
            |and tracking_no = ?
          """.stripMargin,
          jo.getTimestamp("receive_time"),
          payDate,
          long2Long(orderId),
          jo.getString("tracking_no")
        )
      }
    }
  }
}

class Application @Inject()(ssc: StreamingContext, @Named("appName")appName: String) {

  @Inject
  var deliverySource: DeliverySource = _

  def run(): Unit = {
    val dStream = KafkaSource.createJSONKafkaDStreams(ssc, appName, DeliveryConstants.TOPIC)

    dStream.foreachRDD(rdd => {
      val offsetRanges = rdd.asInstanceOf[HasOffsetRanges].offsetRanges // 获取 offset

      val bc = deliverySource.getDeliveryVendorBroadcast(rdd.sparkContext)

      rdd.foreachPartition(is => {
        val cluster = CassandraSink.createCassandraCluster()
        val session = cluster.connect()

        for (i <- is) {
          if (Set(
            DeliveryConstants.TABLE_TGOU_PACKAGE,
            DeliveryConstants.TABLE_THIRD_DELIVERY_INFO_RECORD,
            DeliveryConstants.TABLE_THIRD_DELIVERY_INFO_RECORD_LOG
          ).contains(i.key())) {
            val context = Map(
              "table_name" -> i.key(),
              "json" -> i.value(),
              "cassandra" -> session,
              "broadcast" -> bc
            )

            i.key() match {
              case DeliveryConstants.TABLE_TGOU_PACKAGE => {
                Application.processTgouPackage(context)
              }
              case DeliveryConstants.TABLE_THIRD_DELIVERY_INFO_RECORD => {
                Application.processThirdDeliveryInfoRecord(context)
              }
              case DeliveryConstants.TABLE_THIRD_DELIVERY_INFO_RECORD_LOG => {
                Application.processThirdDeliveryInfoRecordLog(context)
              }
            }
          }
        }

        session.close()
        cluster.close()
      })

      if (!appName.startsWith("test") && !appName.endsWith("test")) dStream.asInstanceOf[CanCommitOffsets].commitAsync(offsetRanges) // 线上部署时提交 offset
    })

  }

}