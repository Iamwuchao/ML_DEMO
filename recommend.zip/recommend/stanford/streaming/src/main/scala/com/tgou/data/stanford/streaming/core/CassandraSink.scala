package com.tgou.data.stanford.streaming.core

import com.datastax.driver.core.Cluster

/**
  * Created by 李震 on 2018/2/8.
  */
object CassandraSink {

  def createCassandraCluster(): Cluster = {
    Cluster.builder()
      .addContactPoint("172.16.3.9")
      .addContactPoint("172.16.3.10")
      .addContactPoint("172.16.3.11")
      .withCredentials("tiangou", "K09Kccrx]")
      .build()
  }

}
