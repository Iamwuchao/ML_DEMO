package com.tgou.data.stanford.streaming.utils

import com.alibaba.fastjson.JSON
import com.tgou.data.stanford.streaming.utils.SaveType.SaveType
import org.apache.spark.sql.execution.datasources.hbase.HBaseTableCatalog
import org.apache.spark.sql.{DataFrame, SaveMode, SparkSession}
import org.apache.spark.storage.StorageLevel

/**
  * 推荐系统数据持久化工具类
  */
object PersistUtils {

  val PARQUET_PATH  = "/recommend/parquet"
  val SQOOP_PATH    = "/recommend/sqoop"

  /**
    * 读取保存的内容
    *
    * @param spark        sparksession
    * @param model_name   模型名字
    * @param online       是否线上环境
    * @return
    */
  def read(spark:SparkSession, model_name:String, online:Boolean = false): DataFrame ={
    val namespace = getNamespace(online)
    spark.read.parquet(s"$PARQUET_PATH/$namespace/$model_name")
  }

  /**
    * 推荐内容保存
    *
    * @param df         推荐结果dataframe
    * @param model_name 推荐算法模型简称
    * @param save_type  保存类型
    * @param online     是否上线，注意！不要直接以上线模式部署!!
    */
  def save(spark:SparkSession, df: DataFrame, model_name: String, save_type:SaveType = SaveType.OTHER, online:Boolean = false ):Unit = {
    df.persist(StorageLevel.MEMORY_AND_DISK_SER)

    import spark.implicits._

    spark.udf.register("merge", new SortedMergeUDAF())

    // 校验参数
    assert(df, SaveType.getAssertList(save_type))

    // 格式化前缀，如果是测试环境，所有的表
    val namespace = getNamespace(online)

    // 统一保存
    df.write.mode(SaveMode.Overwrite).parquet(s"$PARQUET_PATH/$namespace/$model_name")


    if(save_type == SaveType.SQOOP_REC){// sqoop

      df.write.mode(SaveMode.Overwrite).option("sep","^").csv(s"$SQOOP_PATH/$namespace/$model_name")

    }else if(save_type != SaveType.OTHER){//hbase

      val rowkey = SaveType.getRowkey(save_type)
      val recCol = SaveType.getRecCol(save_type)

      // 格式化数据

      val tempDF = df.toJSON
        .map(j => {
          val json = JSON.parseObject(j)
          (json.getString(rowkey),json.getInteger("index"),json.getString(recCol)+"^"+j)
        })
        .toDF(rowkey,"index",model_name)

      tempDF.createOrReplaceTempView("temp")

      val mergedDF = spark.sql(s"select $rowkey, merge(index, $model_name) as $model_name from temp group by $rowkey")

      saveToHbase(mergedDF, namespace, save_type.toString, rowkey, model_name)
    }

    df.unpersist()
  }

  /**
    * 判断DataFrame格式是否合法
    *
    * @param df     dataFrame
    * @param fields 必要的列
    */
  private def assert(df:DataFrame, fields:Seq[String]): Unit ={
    df.schema
    fields.foreach(field => {

      var flag = false
      df.schema.foreach(sf => {
        if(sf.name.equals(field)){
          flag = true
        }
      })

      if(!flag){
        val df_schema = df.schema.mkString(",")
        val needs = fields.mkString(",")
        throw new RecommendException(s"DF don't have the column: $field, please check your dataframe. Current dataframe's schema: [$df_schema], but needs: [$needs]")
      }
    })
  }

  /**
    * 保存到Hbase
    *
    * @param df         dataFrame
    * @param namespace  命名空间
    * @param table      表名
    * @param rowkey     rowkey
    * @param column     列名
    */
  private def saveToHbase(df: DataFrame, namespace:String, table:String, rowkey:String, column:String): Unit = {

    def catalog = s"""{
                     |"table":{"namespace":"$namespace", "name":"$table"},
                     |"rowkey":"$rowkey",
                     |"columns":{
                     |  "$rowkey":{"cf":"rowkey", "col":"$rowkey", "type":"string"},
                     |  "$column":{"cf":"t",      "col":"$column", "type":"string"}
                     |}
                     |}""".stripMargin

    df.write
      .mode(SaveMode.Overwrite)
      .options(Map(HBaseTableCatalog.tableCatalog -> catalog))
      .format("org.apache.spark.sql.execution.datasources.hbase")
      .save()
  }

  /**
    * 根据是否线上，判断命名空间
    *
    * @param online 是否线上
    * @return
    */
  private def getNamespace(online:Boolean):String = {
    if(online) "rec" else "test_rec"
  }
}
