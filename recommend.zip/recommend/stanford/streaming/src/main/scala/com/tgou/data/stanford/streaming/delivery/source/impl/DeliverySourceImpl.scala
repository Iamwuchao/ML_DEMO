package com.tgou.data.stanford.streaming.delivery.source.impl

import java.sql.DriverManager

import com.tgou.data.stanford.streaming.delivery.source.DeliverySource
import org.apache.spark.SparkContext
import org.apache.spark.broadcast.Broadcast

import scala.collection.mutable

/**
  * Created by 李震 on 2018/2/8.
  */
class DeliverySourceImpl extends DeliverySource {

  @volatile private var deliveryVendorBroadcast: Broadcast[Map[Long, String]] = null

  override def getDeliveryVendorBroadcast(sc: SparkContext): Broadcast[Map[Long, String]] = {
    if (deliveryVendorBroadcast == null) {
      synchronized {
        if (deliveryVendorBroadcast == null) {
          val deliveryVendorMap = new mutable.HashMap[Long, String]()

          Class.forName("com.mysql.jdbc.Driver").newInstance()
          val conn = DriverManager.getConnection("jdbc:mysql://172.16.3.102:3306/tgouorder", "bitest", "tg!@3$bitest")
          val s = conn.createStatement()
          val rs = s.executeQuery("select id, name from tgouorder.delivery_vendor")
          while (rs.next()) {
            val id = rs.getLong("id")
            val name = rs.getString("name")
            deliveryVendorMap += id -> name
          }

          deliveryVendorBroadcast = sc.broadcast[Map[Long, String]](deliveryVendorMap.toMap)
        }
      }
    }
    deliveryVendorBroadcast
  }

}
