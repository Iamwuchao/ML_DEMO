package com.tgou.data.stanford.streaming.core

import java.util.Properties

import org.apache.kafka.clients.consumer.ConsumerRecord
import org.apache.kafka.clients.producer.KafkaProducer
import org.apache.kafka.common.serialization.{ByteArrayDeserializer, StringDeserializer}
import org.apache.spark.streaming.StreamingContext
import org.apache.spark.streaming.dstream.InputDStream
import org.apache.spark.streaming.kafka010._
import org.apache.spark.streaming.kafka010.LocationStrategies.PreferConsistent
import org.apache.spark.streaming.kafka010.ConsumerStrategies.Subscribe

/**
  * Created by 李震 on 2018/1/9.
  */
object KafkaSource {

  val KAFKA_SERVERS = "hnode9:9092,hnode10:9092"

  def createJSONKafkaDStreams(ssc: StreamingContext, appName: String, topic: String): InputDStream[ConsumerRecord[String, String]] = {
    KafkaUtils.createDirectStream[String, String](
      ssc,
      PreferConsistent,
      Subscribe[String, String](Array(topic), Map[String, Object](
        "bootstrap.servers" -> KAFKA_SERVERS,
        "key.deserializer" -> classOf[StringDeserializer],
        "value.deserializer" -> classOf[StringDeserializer],
        "group.id" -> appName,
        "auto.offset.reset" -> "latest", // 如果没找到之前的 offset 从最新的 offset 开始读
        "enable.auto.commit" -> (false: java.lang.Boolean) // 禁止 Kafka 自动提交 offset，代码中手动提交
      ))
    )
  }

  def createAvroKafkaDStreams(ssc: StreamingContext, appName: String, topic: String): InputDStream[ConsumerRecord[String, Array[Byte]]] = {
    KafkaUtils.createDirectStream[String, Array[Byte]](
      ssc,
      PreferConsistent,
      Subscribe[String, Array[Byte]](Array(topic), Map[String, Object](
        "bootstrap.servers" -> KAFKA_SERVERS,
        "key.deserializer" -> classOf[StringDeserializer],
        "value.deserializer" -> classOf[ByteArrayDeserializer],
        "group.id" -> appName,
        "auto.offset.reset" -> "latest", // 如果没找到之前的 offset 从最新的 offset 开始读
        "enable.auto.commit" -> (false: java.lang.Boolean) // 禁止 Kafka 自动提交 offset，代码中手动提交
      ))
    )
  }

  def createAvroKafkaProducer(): KafkaProducer[String, Array[Byte]] = {
    val properties = new Properties()

    properties.put("bootstrap.servers", KAFKA_SERVERS)
    properties.put("key.serializer", "org.apache.kafka.common.serialization.StringSerializer")
    properties.put("value.serializer", "org.apache.kafka.common.serialization.ByteArraySerializer")

    new KafkaProducer[String, Array[Byte]](properties)
  }

}
