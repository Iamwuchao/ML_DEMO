package com.tgou.data.stanford.streaming.order.source

import org.apache.kafka.clients.consumer.ConsumerRecord
import org.apache.spark.SparkContext
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.streaming.dstream.DStream

/**
  * Created by 李震 on 2018/4/10.
  */
trait OrderSource {

  /**
    * 获取订单品表 tgouorder.order_item 流数据
    * */
  def getOrderItemDStream(): DStream[ConsumerRecord[String, Array[Byte]]]

  /**
    * 获取订单表 tgouorder.tgou_order 流数据
    * */
  def getTgouOrderDStream(): DStream[ConsumerRecord[String, Array[Byte]]]

  /**
    * 获取订单金额表 tgouorder.order_amount 流数据
    * */
  def getOrderAmountDStream(): DStream[ConsumerRecord[String, Array[Byte]]]

  /**
    * 获取订单退款表 tgouorder.return_request 流数据
    * */
  def getReturnRequestDStream(): DStream[ConsumerRecord[String, Array[Byte]]]

  /**
    * 获取订单有限状态机日志表 tgouorder.tgou_order_fsm_log 流数据
    * */
  def getTgouOrderFSMLogDStream(): DStream[ConsumerRecord[String, Array[Byte]]]

  /**
    * 获取订单品表 tgouorder.order_item Avro Schema 广播变量
    * */
  def getOrderItemSchemaBroadcast(sc: SparkContext): Broadcast[String]

  /**
    * 获取订单表 tgouorder.tgou_order Avro Schema 广播变量
    * */
  def getTgouOrderSchemaBroadcast(sc: SparkContext): Broadcast[String]

  /**
    * 获取订单金额表 tgouorder.order_amount Avro Schema 广播变量
    * */
  def getOrderAmountSchemaBroadcast(sc: SparkContext): Broadcast[String]

  /**
    * 获取订单退款表 tgouorder.return_request Avro Schema 广播变量
    * */
  def getReturnRequestSchemaBroadcast(sc: SparkContext): Broadcast[String]

  /**
    * 获取订单有限状态机日志表 tgouorder.tgou_order_fsm_log Avro Schema 广播变量
    * */
  def getTgouOrderFSMLogSchemaBroadcast(sc: SparkContext): Broadcast[String]

}
