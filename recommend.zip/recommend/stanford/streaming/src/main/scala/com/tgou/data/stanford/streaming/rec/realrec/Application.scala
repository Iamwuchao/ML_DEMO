package com.tgou.data.stanford.streaming.rec.realrec

import com.alibaba.fastjson.JSON
import com.tgou.data.stanford.streaming.core.KafkaSource
import org.apache.spark.SparkConf
import org.apache.spark.sql.SparkSession
import org.apache.spark.streaming.{Seconds, StreamingContext}

/**
  * 算法思路：
  * 1 取用户最新浏览的数据，保存到Redis
  * 2 读取Redis数据注册成表，关联相似品
  * 3 重合之后写入到HBase,跟其他的表放入不同的column family中
  */
object Application {
val CHECKPOINT_PATH = "/recommend/check_point/user_view_history_v4"

  val KAFKA_ADDR = "hnode9:9092,hnode10:9092"
  val TOPIC = "tgs-topic"
  val MAX_TIME_STAMP = 9999999999999L
  val REFRESH_TIME:Long = 1000*60*60*24// *30 // 每半个小时刷新一次

  def main(args: Array[String]): Unit = {
    System.setProperty("hive.metastore.uris", "thrift://hnode1:9083")
    val ssc = StreamingContext.getOrCreate(CHECKPOINT_PATH,() => createContext(args))
    ssc.start()
    ssc.awaitTermination()
  }

  def createContext(args:Array[String]): StreamingContext = {

    // 1. 创建StreamingContext，并完成注册的监控
    val conf = new SparkConf().setAppName("user-view-rec-v4").setMaster("local")
    val ssc = new StreamingContext(conf,Seconds(10))
    ssc.sparkContext.setLogLevel("warn")
    val isOnline = "online".equals(args(0))

    //由于 Kafka Direct方式不依赖于ZK获取offset信息，所以直接连 Kafka broker集群即可
    val kafkaParams = Map[String, String]("metadata.broker.list" -> KAFKA_ADDR)
    val topics = Set[String](TOPIC)
    val messages = KafkaSource.createJSONKafkaDStreams(ssc, "user-view-rec-v4", TOPIC)

    // 2. 过滤单品详情页的tgs

    val rdds = messages
      .map(t2 =>
        try{
          JSON.parseObject(t2.value())
        }catch {
          case ex: Exception => null
        }
      )
      // 过滤json为null，非商品浏览，非member_id的数据
      .filter(json => json!=null && json.getString("page").startsWith("10.pd.item-") && !"".equals(json.getString("member_id")))
      .map(json => {
        val member_id = json.getString("member_id")
        val item_id = json.getString("page").split("-")(1)
        val date = json.getString("time")
        (member_id,item_id,date)
      })

    val spark = SparkSession.builder.config(conf).getOrCreate()

    ssc
  }
}
