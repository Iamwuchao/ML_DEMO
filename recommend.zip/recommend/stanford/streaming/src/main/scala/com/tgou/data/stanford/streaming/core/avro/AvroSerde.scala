package com.tgou.data.stanford.streaming.core.avro

import com.twitter.bijection.avro.GenericAvroCodecs
import org.apache.avro.Schema
import org.apache.avro.generic.GenericRecord

/**
  * Avro 序列化和反序列化
  *
  * Created by 李震 on 2018/4/10.
  */
object AvroSerde {

  def serialize(record: GenericRecord, schema: Schema): Array[Byte] = {
    val codecs = GenericAvroCodecs.toBinary[GenericRecord](schema)
    codecs.apply(record)
  }

  def deserialize(data: Array[Byte], schema: Schema): GenericRecord = {
    val codecs = GenericAvroCodecs.toBinary[GenericRecord](schema)
    codecs.invert(data).get
  }

}
