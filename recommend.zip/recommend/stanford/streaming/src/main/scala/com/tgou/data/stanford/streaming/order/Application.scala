package com.tgou.data.stanford.streaming.order

import java.util.Date
import scala.collection.JavaConverters._

import com.datastax.driver.core.{Row, Session}
import com.google.inject.{Guice, Inject}
import com.tgou.data.stanford.streaming.core.avro.{AvroSchema, AvroSerde}
import com.tgou.data.stanford.streaming.core.{CassandraSink, StreamingBootstrap}
import com.tgou.data.stanford.streaming.order.source.{BaseSource, OrderSource}
import org.apache.avro.util.Utf8
import org.apache.spark.internal.Logging
import org.apache.spark.streaming.StreamingContext

/**
  * 实现步骤：
  *
  * 1. 第一步，更新事实表
  *
  *  [order_item @ kafak] -> [order_item_fact @ cassandra]
  *  [tgou_order @ kafka] -> [order_fact @ cassandra]
  *  [order_amount @ kafka] -> [order_fact @ cassandra]
  *  [order_return_request @ kafka] -> [order_fact @ cassandra]
  *  [tgou_order_fsm_log @kafka] -> [order_fact @ cassandra]
  *
  * 2. 第二步，同步到宽表
  *
  *  [order_item_fact @ cassandra] -> [order_item_wide_column @ cassandra]
  *  [order_fact @ cassandra] -> [order_item_wide_column @ cassandra]
  *  [store_dim @ cassandra] -> [order_item_wide_column @ cassandra]
  *  [sku_dim @ cassandra] -> [order_item_wide_column @ cassandra]
  *  [member_dim @ cassandra] -> [order_item_wide_column @ cassandra]
  *
  * Created by 李震 on 2018/4/10.
  */
object Application {

  def main(args: Array[String]): Unit = {
    new StreamingBootstrap(args).bootstrap(execute)
  }

  def execute(ssc: StreamingContext, appName: String): Unit = {
    val injector = Guice.createInjector(new ApplicationModule(ssc, appName))
    injector.getInstance(classOf[Application]).run()
  }

  /**
    * 将原始 category_code 转化为一级二级三级四级分类
    *
    * @param originCategoryCode 原始 category_code
    *
    * */
  private def transformCategoryCode(originCategoryCode: Utf8): (String, String, String, String) = {
    if (originCategoryCode == null) return (null, null, null, null)
    val category = originCategoryCode.toString

    if (originCategoryCode.length >= 2 && originCategoryCode.length < 4) {
      // 只有一级分类
      val l1 = category.substring(0, 2)
      (l1, l1, l1, l1)
    } else if (originCategoryCode.length >= 4 && originCategoryCode.length < 6) {
      // 有一级分类和二级分类
      val l1 = category.substring(0, 2)
      val l2 = category.substring(2, 4)
      (l1, l2, l2, l2)
    } else if (originCategoryCode.length >= 6 && originCategoryCode.length < 8) {
      // 有一级分类、二级分类和三级分类
      val l1 = category.substring(0, 2)
      val l2 = category.substring(2, 4)
      val l3 = category.substring(4, 6)
      (l1, l2, l3, l3)
    } else if (originCategoryCode.length >= 8) {
      // 有一级分类、二级分类、三级分类和四级分类
      val l1 = category.substring(0, 2)
      val l2 = category.substring(2, 4)
      val l3 = category.substring(4, 6)
      val l4 = category.substring(6, 8)
      (l1, l2, l3, l4)
    } else {
      // 其它
      (null, null, null, null)
    }
  }

  /**
    * 将原始 fixed_tags 转化为订单类型
    *
    * @param originFixedTags 原始 fixed_tags
    *
    * */
  private def transformOrderType(originFixedTags: Utf8): String = {
    if (originFixedTags == null || originFixedTags.length == 0) return null
    if (originFixedTags.toString.substring(0, 1).equals("0")) "PRODUCT" else "COUPON"
  }

  /**
    * 将原始 pay_method 转化为支付方法
    *
    * @param originPayMethod 原始 pay_method
    *
    * */
  private def transformPayMethod(originPayMethod: Utf8): String = {
    if (originPayMethod == null || originPayMethod.length < 3) return null
    val payMethod = originPayMethod.toString

    val payMethodPrefix = payMethod.substring(0, 1)
    if (payMethod.substring(0, 2).equals("00")) "OFFLINE"
    else if (payMethod.equals("010")) "NOT_PAY"
    else if (payMethodPrefix.equals("1")) "DASHANG_CARD"
    else if (payMethodPrefix.equals("2")) "POS"
    else if (payMethodPrefix.equals("3")) "WECHAT"
    else if (payMethodPrefix.equals("5")) "APPLE"
    else if (payMethodPrefix.equals("6")) "ALIPAY"
    else if (payMethodPrefix.equals("9")) "TIANGOU"
    else "OTHER"
  }

  /**
    * 将原始 receive_type 转化为物流方法
    *
    * @param originReceiveType 原始 receive_type
    *
    * */
  private def transformDeliveryMethod(originReceiveType: Utf8): String = {
    if (originReceiveType == null) return null
    val receiveType = originReceiveType.toString

    receiveType match {
      case "00" | "01" | "02" => "SELF_PICKUP"
      case "10" => "LOGISTICS"
      case "99" => "VIRTUAL"
      case _ => "OTHER"
    }
  }

  /**
    * 将秒转为日期
    *
    * @param seconds 秒
    *
    * */
  private def transformSecond2Date(seconds: Long): Date = {
    new Date(seconds * 1000)
  }

  /**
    * 订单品事实表同步到宽表
    *
    * @param session Cassandra Session
    * @param skuId
    * @param orderId
    *
    * */
  private def orderItemFact2WideColumn(session: Session, skuId: Long, orderId: Long): Unit = {
    val orderItemFact = session.execute(
      """
        |select
        | *
        |from market.order_item_fact
        |where sku_id=?
        |and order_id=?
      """.stripMargin,
      long2Long(skuId),
      long2Long(orderId)
    ).one()

    if (orderItemFact != null) {
      session.execute(
        """
          |update market.order_item_wide_column
          |set
          |  brand_id=?,
          |  level_one_category_code=?,
          |  level_two_category_code=?,
          |  level_three_category_code=?,
          |  level_four_category_code=?,
          |  price=?,
          |  quantity=?
          |where sku_id=?
          |and order_id=?
        """.stripMargin,
        long2Long(orderItemFact.getLong("brand_id")),
        orderItemFact.getString("level_one_category_code"),
        orderItemFact.getString("level_two_category_code"),
        orderItemFact.getString("level_three_category_code"),
        orderItemFact.getString("level_four_category_code"),
        orderItemFact.getDecimal("price"),
        int2Integer(orderItemFact.getLong("quantity").toInt),
        long2Long(skuId),
        long2Long(orderId)
      )
    }
  }

  /**
    * 订单事实表同步到宽表
    *
    * @param session Cassandra Session
    * @param orderId
    *
    * */
  private def orderFact2WideColumn(session: Session, orderId: Long): Unit = {
    // 获取 sku_id 和 order_id
    val rs = session.execute(
      """
        |select
        |  sku_id,
        |  order_id
        |from market.order_item_wide_column
        |where order_id=?
      """.stripMargin, long2Long(orderId))

    for (row <- rs.asScala) {
      val skuId = row.getLong("sku_id")
      val orderId = row.getLong("order_id")

      val orderFact = session.execute(
        """
          |select
          |  *
          |from market.order_fact
          |where order_id=?
        """.stripMargin, long2Long(orderId)).one()

      if (orderFact != null) {
        session.execute(
          """
            |update market.order_item_wide_column
            |set
            |  member_id=?,
            |  store_id=?,
            |  source=?,
            |  order_pay_method=?,
            |  order_delivery_method=?,
            |  order_create_time=?,
            |  order_pay_time=?,
            |  order_cancel_time=?,
            |  order_ship_time=?,
            |  order_return_time=?,
            |  order_finish_time=?,
            |  order_amount=?,
            |  order_return_amount=?,
            |  order_coupon_amount=?,
            |  order_activity_amount=?,
            |  order_tax=?,
            |  order_shipping_costs=?,
            |  order_net_sales_amount=?,
            |  order_actual_sales_amount=?
            |where sku_id=?
            |and order_id=?
          """.stripMargin,
          long2Long(orderFact.getLong("member_id")),
          long2Long(orderFact.getLong("store_id")),
          orderFact.getString("source"),
          orderFact.getString("order_pay_method"),
          orderFact.getString("order_delivery_method"),
          orderFact.getTimestamp("order_create_time"),
          orderFact.getTimestamp("order_pay_time"),
          orderFact.getTimestamp("order_cancel_time"),
          orderFact.getTimestamp("order_ship_time"),
          orderFact.getTimestamp("order_return_time"),
          orderFact.getTimestamp("order_finish_time"),
          orderFact.getDecimal("order_amount"),
          orderFact.getDecimal("order_return_amount"),
          orderFact.getDecimal("order_coupon_amount"),
          orderFact.getDecimal("order_activity_amount"),
          orderFact.getDecimal("order_tax"),
          orderFact.getDecimal("order_shipping_costs"),
          orderFact.getDecimal("order_net_sales_amount"),
          Option(orderFact.getDecimal("order_net_sales_amount")).getOrElse(java.math.BigDecimal.ZERO)
            .add(Option(orderFact.getDecimal("order_tax")).getOrElse(java.math.BigDecimal.ZERO))
            .add(Option(orderFact.getDecimal("order_tax")).getOrElse(java.math.BigDecimal.ZERO)),
          long2Long(skuId),
          long2Long(orderId)
        )
      }
    }

  }

  /**
    * SKU 维度表同步到宽表
    *
    * @param session Cassandra Session
    * @param skuId
    * @param orderId
    *
    * */
  def skuDim2WideColumn(session: Session, skuId: Long, orderId: Long): Unit = {
    val row = session.execute(
      """
        |select
        |  item_is_selected
        |from market.sku_dim
        |where sku_id=?
      """.stripMargin, long2Long(skuId)).one()
    val itemIsSelected = if (row != null) row.getInt("item_is_selected") else 0

    session.execute(
      """
        |update market.order_item_wide_column
        |set
        |  item_is_selected=?
        |where sku_id=?
        |and order_id=?
      """.stripMargin,
      int2Integer(itemIsSelected),
      long2Long(skuId),
      long2Long(orderId)
    )
  }

  /**
    * SKU 维度表同步到宽表
    *
    * @param session Cassandra Session
    * @param orderId
    *
    * */
  def storeDim2WideColumn(session: Session, orderId: Long): Unit = {
    val rs = session.execute(
      """
        |select
        |  sku_id,
        |  order_id,
        |  store_id
        |from market.order_item_wide_column
        |where order_id=?
      """.stripMargin, long2Long(orderId))

    for (row <- rs.asScala) {
      val skuId = row.getLong("sku_id")
      val orderId = row.getLong("order_id")
      val storeId = row.getLong("store_id")

      if (storeId != null) {
        val storeDim = session.execute(
          """
            |select
            |  *
            |from market.store_dim
            |where store_id=?
          """.stripMargin, long2Long(storeId)).one()

        if (storeDim != null) {
          session.execute(
            """
              |update market.order_item_wide_column
              |set
              |  area_name=?,
              |  city_name=?,
              |  source_name=?,
              |  store_name=?
              |where sku_id=?
              |and order_id=?
            """.stripMargin,
            storeDim.getString("area_name"),
            storeDim.getString("city_name"),
            storeDim.getString("source_name"),
            storeDim.getString("store_name"),
            long2Long(skuId),
            long2Long(orderId)
          )
        }
      }
    }
  }

  /**
    * 会员维度表同步到宽表
    *
    * @param session Cassandra Session
    * @param orderId
    *
    * */
  def memberDim2WideColumn(session: Session, orderId: Long): Unit = {
    val rs = session.execute(
      """
        |select
        |  sku_id,
        |  order_id,
        |  member_id
        |from market.order_item_wide_column
        |where order_id=?
      """.stripMargin, long2Long(orderId))

    for (row: Row <- rs.asScala) {
      val skuId = row.getLong("sku_id")
      val orderId = row.getLong("order_id")
      val memberId = row.getLong("member_id")

      if (memberId != null) {
        val memberDim = session.execute(
          """
            |select
            |  *
            |from market.member_dim
            |where member_id=?
          """.stripMargin, long2Long(memberId)).one()

        if (memberDim != null) {
          session.execute(
            """
              |update market.order_item_wide_column
              |set
              |  first_shopping_time=?,
              |  first_market_shopping_time=?,
              |  first_mall_shopping_time=?,
              |  first_supplier_shopping_time=?,
              |  first_oversea_shopping_time=?
              |where sku_id=?
              |and order_id=?
            """.stripMargin,
            memberDim.getTimestamp("first_shopping_time"),
            memberDim.getTimestamp("first_market_shopping_time"),
            memberDim.getTimestamp("first_mall_shopping_time"),
            memberDim.getTimestamp("first_supplier_shopping_time"),
            memberDim.getTimestamp("first_oversea_shopping_time"),
            long2Long(skuId),
            long2Long(orderId)
          )
        }
      }
    }
  }

}

class Application extends Logging with Runnable {

  @Inject
  var orderSource: OrderSource = _

  @Inject
  var baseSource: BaseSource = _

  override def run(): Unit = {
    /*
     * 处理 tgouorder.order_item 流数据
     * */
    orderSource.getOrderItemDStream().foreachRDD(rdd => {
      val orderItemSchemaBroadcast = orderSource.getOrderItemSchemaBroadcast(rdd.sparkContext)

      rdd.foreachPartition(partition => {
        val cassandraCluster = CassandraSink.createCassandraCluster()
        cassandraCluster.connect()
        val session = cassandraCluster.newSession()

        for (i <- partition) {
          val data = i.value()
          val schema = AvroSchema.parseSchemaJSON(orderItemSchemaBroadcast.value)
          val record = AvroSerde.deserialize(data, schema)

          val categoryCode = Application.transformCategoryCode((record.get("category_code").asInstanceOf[Utf8]))

          val row = session.execute(
            """
              |select
              |  brand_id
              |from market.product
              |where product_id=?
            """.stripMargin,
            record.get("product_id")
          ).one()
          val brandId = if (row != null) row.getLong("brand_id") else 0l

          // 更新订单品实时表 order_item_fact
          val orderId = record.get("fk_tgou_order_id").asInstanceOf[Long]
          val skuId = record.get("sku_id").asInstanceOf[Long]

          session.execute(
            """
              |update market.order_item_fact
              |set
              |  brand_id=?,
              |  level_one_category_code=?,
              |  level_two_category_code=?,
              |  level_three_category_code=?,
              |  level_four_category_code=?,
              |  price=?,
              |  quantity=?
              |where order_id=?
              |and sku_id=?
            """.stripMargin,
            long2Long(brandId),
            categoryCode._1,
            categoryCode._2,
            categoryCode._3,
            categoryCode._4,
            BigDecimal(record.get("price").asInstanceOf[Double]).bigDecimal,
            record.get("quantity"),
            long2Long(orderId),
            long2Long(skuId)
          )

          // 同步到宽表
          Application.orderItemFact2WideColumn(session, skuId, orderId)
          Application.skuDim2WideColumn(session, skuId, orderId)
        }

        session.close()
        cassandraCluster.close()
      })
    })

    /*
     * 处理 tgouorder.tgou_order 流数据
     * */
    orderSource.getTgouOrderDStream().foreachRDD(rdd => {
      val tgouOrderSchemaBroadcast = orderSource.getTgouOrderSchemaBroadcast(rdd.sparkContext)
      val storeSourceBroadcast = baseSource.getStoreSourceBroadcast(rdd.sparkContext)

      rdd.foreachPartition(partition => {
        val cassandraCluster = CassandraSink.createCassandraCluster()
        cassandraCluster.connect()
        val session = cassandraCluster.newSession()

        for (i <- partition) {
          val data = i.value()
          val schema = AvroSchema.parseSchemaJSON(tgouOrderSchemaBroadcast.value)
          val record = AvroSerde.deserialize(data, schema)

          // 更新订单事实表 order_fact
          val orderId = record.get("id").asInstanceOf[Long]
          session.execute(
            """
              |update market.order_fact
              |set
              |  order_type=?,
              |  order_pay_method=?,
              |  order_delivery_method=?,
              |  store_id=?,
              |  source=?,
              |  member_id=?,
              |  order_create_time=?,
              |  order_ship_time=?,
              |  order_net_sales_amount=?
              |where order_id=?
            """.stripMargin,
            Application.transformOrderType(record.get("fixed_tags").asInstanceOf[Utf8]),
            Application.transformPayMethod(record.get("pay_method").asInstanceOf[Utf8]),
            Application.transformDeliveryMethod(record.get("receive_type").asInstanceOf[Utf8]),
            record.get("store_id"),
            storeSourceBroadcast.value(record.get("store_id").asInstanceOf[Long]),
            record.get("fk_member_id"),
            Application.transformSecond2Date(record.get("create_time").asInstanceOf[Long]),
            Application.transformSecond2Date(record.get("ship_time").asInstanceOf[Long]),
            BigDecimal(record.get("total_amount").asInstanceOf[Double]).bigDecimal,
            long2Long(orderId)
          )

          // 同步到宽表
          Application.orderFact2WideColumn(session, orderId)
          Application.storeDim2WideColumn(session, orderId)
          Application.memberDim2WideColumn(session, orderId)
        }

        session.close()
        cassandraCluster.close()
      })

    })

    /*
     * 处理 tgouorder.order_amount 流数据
     * */
    orderSource.getOrderAmountDStream().foreachRDD(rdd => {
      val orderAmountSchemaBroadcast = orderSource.getOrderAmountSchemaBroadcast(rdd.sparkContext)

      rdd.foreachPartition(partition => {
        val cassandraCluster = CassandraSink.createCassandraCluster()
        cassandraCluster.connect()
        val session = cassandraCluster.newSession()

        for (i <- partition) {
          val data = i.value()
          val schema = AvroSchema.parseSchemaJSON(orderAmountSchemaBroadcast.value)
          val record = AvroSerde.deserialize(data, schema)

          // 更新订单事实表 order_fact
          val amountType = record.get("type").asInstanceOf[Long]
          val orderId = record.get("fk_tgou_order_id").asInstanceOf[Long]
          if (amountType == 6l) {
            // 商品金额
            session.execute(
              """
                |update market.order_fact
                |set
                |  order_amount=?
                |where order_id=?
              """.stripMargin,
              BigDecimal(record.get("amount").asInstanceOf[Double]).bigDecimal,
              long2Long(orderId)
            )
          } else if (amountType == 4l) {
            // 税
            session.execute(
              """
                |update market.order_fact
                |set
                |  order_tax=?
                |where order_id=?
              """.stripMargin,
              BigDecimal(record.get("amount").asInstanceOf[Double]).bigDecimal,
              long2Long(orderId)
            )
          } else if (amountType == 5l) {
            // 运费
            session.execute(
              """
                |update market.order_fact
                |set
                |  order_shipping_costs=?
                |where order_id=?
              """.stripMargin,
              BigDecimal(record.get("amount").asInstanceOf[Double]).bigDecimal,
              long2Long(orderId)
            )
          } else if (amountType == 2l) {
            // 券优惠金额
            session.execute(
              """
                |update market.order_fact
                |set
                |  order_coupon_amount=?
                |where order_id=?
              """.stripMargin,
              BigDecimal(record.get("amount").asInstanceOf[Double]).bigDecimal,
              long2Long(orderId)
            )
          } else if (amountType == 3l) {
            // 活动优惠金额
            session.execute(
              """
                |update market.order_fact
                |set
                |  order_activity_amount=?
                |where order_id=?
              """.stripMargin,
              BigDecimal(record.get("amount").asInstanceOf[Double]).bigDecimal,
              long2Long(orderId)
            )
          }

          // 同步到宽表
          Application.orderFact2WideColumn(session, orderId)
        }

        session.close()
        cassandraCluster.close()
      })
    })

    /*
     * 处理 tgouorder.order_return_request 流数据
     * */
    if (false) orderSource.getReturnRequestDStream().foreachRDD(rdd => {
      val orderReturnRequestSchemaBroadcast = orderSource.getReturnRequestSchemaBroadcast(rdd.sparkContext)

      rdd.foreachPartition(partition => {
        val cassandraCluster = CassandraSink.createCassandraCluster()
        cassandraCluster.connect()
        val session = cassandraCluster.newSession()

        for (i <- partition) {
          val data = i.value()
          val schema = AvroSchema.parseSchemaJSON(orderReturnRequestSchemaBroadcast.value)
          val record = AvroSerde.deserialize(data, schema)

          // TODO: 无法计算退货金额
        }

        session.close()
        cassandraCluster.close()
      })

    })

    /*
     * 处理 tgou_order_fsm_log 流数据
     * */
    orderSource.getTgouOrderFSMLogDStream().foreachRDD(rdd => {
      val tgouOrderFsmLogSchemaBroadcast = orderSource.getTgouOrderFSMLogSchemaBroadcast(rdd.sparkContext)

      rdd.foreachPartition(partition => {
        val cassandraCluster = CassandraSink.createCassandraCluster()
        cassandraCluster.connect()
        val session = cassandraCluster.newSession()

        for (i <- partition) {
          val data = i.value()
          val schema = AvroSchema.parseSchemaJSON(tgouOrderFsmLogSchemaBroadcast.value)
          val record = AvroSerde.deserialize(data, schema)

          if (record.get("object_id") != null) {
            val orderId = record.get("object_id").asInstanceOf[Long]
            val event = if (record.get("event") != null) record.get("event").toString else ""
            val stateTo = if (record.get("state_to") != null) record.get("state_to").toString else ""

            if (stateTo.equals("Canceled")) {
              // 取消时间
              session.execute(
                """
                  |update market.order_fact
                  |set
                  |  order_cancel_time=?
                  |where order_id=?
                """.stripMargin,
                Application.transformSecond2Date(record.get("enter_time").asInstanceOf[Long]),
                long2Long(orderId)
              )
            } else if (event.equals("Pay")) {
              // 支付时间
              session.execute(
                """
                  |update market.order_fact
                  |set
                  |  order_pay_time=?
                  |where order_id=?
                """.stripMargin,
                Application.transformSecond2Date(record.get("enter_time").asInstanceOf[Long]),
                long2Long(orderId)
              )
            } else if (stateTo.equals("Returned")) {
              // 退货时间
              session.execute(
                """
                  |update market.order_fact
                  |set
                  |  order_return_time=?
                  |where order_id=?
                """.stripMargin,
                Application.transformSecond2Date(record.get("enter_time").asInstanceOf[Long]),
                long2Long(orderId)
              )
            } else if (stateTo.equals("End")) {
              // 完成时间
              session.execute(
                """
                  |update market.order_fact
                  |set
                  |  order_finish_time=?
                  |where order_id=?
                """.stripMargin,
                Application.transformSecond2Date(record.get("enter_time").asInstanceOf[Long]),
                long2Long(orderId)
              )
            }

            // 同步到宽表
            Application.orderFact2WideColumn(session, orderId)
          }
        }

        session.close()
        cassandraCluster.close()
      })

    })
  }

}