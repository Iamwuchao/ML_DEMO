package com.tgou.data.stanford.streaming.rec.userview

import java.sql.Timestamp
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter

import com.alibaba.fastjson.JSON
import com.tgou.data.stanford.streaming.core.KafkaSource
import com.tgou.standford.core.hbase.HbaseServer
import com.tgou.standford.core.hbase.plugins.SimplePutter
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.sql.SparkSession
import org.apache.spark.storage.StorageLevel
import org.apache.spark.streaming.{Seconds, StreamingContext}
import org.apache.spark.{SparkConf, SparkContext}

object UserViewHistory {

  val CHECKPOINT_PATH = "/recommend/check_point/user_view_history_v3"
  val KAFKA_ADDR = "hnode9:9092,hnode10:9092"
  val TOPIC = "tgs-topic"
  val MAX_TIME_STAMP = 9999999999999L
  val REFRESH_TIME:Long = 1000*60*60*24// *30 // 每半个小时刷新一次

  def main(args: Array[String]): Unit = {
    System.setProperty("hive.metastore.uris", "thrift://hnode1:9083")
    val ssc = StreamingContext.getOrCreate(CHECKPOINT_PATH,() => createContext(args))
    ssc.start()
    ssc.awaitTermination()
  }

  def createContext(args:Array[String]): StreamingContext = {

    // 1. 创建StreamingContext，并完成注册的监控
    val conf = new SparkConf().setAppName("UserViewHistory").setMaster("yarn")
    val ssc = new StreamingContext(conf,Seconds(7))
    ssc.sparkContext.setLogLevel("warn")

    //由于 Kafka Direct方式不依赖于ZK获取offset信息，所以直接连 Kafka broker集群即可
    val kafkaParams = Map[String, String]("metadata.broker.list" -> KAFKA_ADDR)
    val topics = Set[String](TOPIC)
    val messages = KafkaSource.createJSONKafkaDStreams(ssc, "UserViewHistory", TOPIC)

    // 2. 过滤单品详情页的tgs

    val cached = messages
      .map(t2 => try{
        JSON.parseObject(t2.value())
      }catch {
        case ex: Exception => null
      })
      .filter(json => json!=null && json.getString("page").startsWith("10.pd.item-"))
      .persist(StorageLevel.MEMORY_AND_DISK_SER_2)

    // 3. 处理带有memberId的数据，拼接生成rowkey

    // 消费有member_id的数据，生成member_id拼反向时间戳的rowkey
    val withMemberLines = cached
      //过滤memberId为空的
      .filter(json => !"".equals(json.getString("member_id")))
      .map(json => {
        val member_id = json.getString("member_id")
        val item_id = json.getString("page").split("-")(1)
        val date = json.getString("time")

        // memberid拼接时间戳
        val rowkey = member_id+ (MAX_TIME_STAMP - getTimestamp(date))
        (rowkey,member_id,item_id)
      })

    // 4. 存储到HBase

    // 保存到hbase
    withMemberLines.foreachRDD { rdd =>
      // 过滤source=1且非入围或者下架的
      if(SelectedIds.getFlag != Timestamp.valueOf(LocalDateTime.now()).getTime/REFRESH_TIME){
        SelectedIds.setNull()
      }

      val selected = SelectedIds.getInstance(rdd.sparkContext)
      val selectedRdd = rdd.filter(t3 => selected.value.contains(t3._3))

      selectedRdd.foreachPartition { partitionOfRecords =>

        val userServer:HbaseServer = new HbaseServer("rec:userview")
        val userPutter: SimplePutter = new SimplePutter(userServer)

        while(partitionOfRecords.hasNext){
          val row = partitionOfRecords.next()
          userPutter.add(row._1.toString,"t","member_id",row._2)
          userPutter.add(row._1.toString,"t","item_id",row._3)
          userPutter.putAndClearIfMorethan(100)
        }

        userPutter.putAndClearIfMorethan(0)
        userPutter.close()
        userServer.close()
      }
    }

    // 之前发现streaming运行一段时间就不往hbase里面写了，这里记录一下，是否是streaming没有捕获对应的内容
    //withMemberLines.print()

    //*******************************************************************************************
    //todo 处理没有memberId的
    //*******************************************************************************************

    // 没有member_id的保存到...
//    val withoutMemberLines = cached
//      .filter(json => "".equals(json.getString("member_id")))

    ssc
  }

  /**
    * 读取是否入围品数据，每隔一段时间刷新一次
    */
  object SelectedIds extends Serializable{

    @volatile private var flag: Long = 0
    @volatile private var instance: Broadcast[Seq[String]] = null

    // double check
    def getInstance(sc: SparkContext): Broadcast[Seq[String]] = {
      if (instance == null) {
        synchronized {
          if (instance == null) {

            val spark = SparkSession.builder
              .config(sc.getConf)
              .enableHiveSupport()
              .getOrCreate()

            import spark.implicits._
            spark.sql(s"refresh table persona.listing")
            val ids = spark.sql(
              s"""
                 |select
                 |  listing_id
                 |from persona.listing
                 |where (( source = 1 and is_selected = 1) or source = 4 )
                 |  and listing_state='onshelf'
               """.stripMargin).map(row => row.getLong(0).toString).collect()

            instance = sc.broadcast(ids)
            flag = Timestamp.valueOf(LocalDateTime.now()).getTime / REFRESH_TIME
            println("时间："+LocalDateTime.now()+", flag:"+flag)
          }
        }
      }
      println("个数"+instance.value.size)
      instance
    }

    def getFlag: Long = {
      flag
    }

    def setNull(): Unit = {
      synchronized{
        if(instance != null){
          instance = null
        }
      }
    }
  }

  /**
    * 根据time字段，获得对应的时间戳
    * @param date 时间字段，格式为2017-12-01 09:59:58
    * @return
    */
  def getTimestamp(date:String): Long ={
    val time = LocalDateTime.parse(date,DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"))
    Timestamp.valueOf(time).getTime
  }

}
