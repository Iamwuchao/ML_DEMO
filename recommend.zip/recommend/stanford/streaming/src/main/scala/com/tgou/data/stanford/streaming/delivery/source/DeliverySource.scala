package com.tgou.data.stanford.streaming.delivery.source

import org.apache.spark.SparkContext
import org.apache.spark.broadcast.Broadcast

/**
  * Created by 李震 on 2018/2/8.
  */
trait DeliverySource {

  def getDeliveryVendorBroadcast(sc: SparkContext): Broadcast[Map[Long, String]]

}
