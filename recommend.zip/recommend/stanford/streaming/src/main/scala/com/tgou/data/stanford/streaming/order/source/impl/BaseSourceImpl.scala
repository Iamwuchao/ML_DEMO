package com.tgou.data.stanford.streaming.order.source.impl

import java.sql.{DriverManager, ResultSet}

import com.tgou.data.stanford.streaming.core.conf.Conf
import com.tgou.data.stanford.streaming.order.source.BaseSource
import org.apache.commons.dbutils.{QueryRunner, ResultSetHandler}
import org.apache.spark.SparkContext
import org.apache.spark.broadcast.Broadcast

import scala.collection.mutable

/**
  * Created by 李震 on 2018/4/24.
  */
class BaseSourceImpl extends BaseSource {

  @volatile
  private var storeSourceBroadcast: Broadcast[Map[Long, String]] = null

  /**
    * 获取店铺业态广播变量
    **/
  override def getStoreSourceBroadcast(sc: SparkContext): Broadcast[Map[Long, String]] = {
    if (storeSourceBroadcast == null) {
      synchronized {
        if (storeSourceBroadcast == null) {
          val dbConf = Conf.getDBConf("base")
          Class.forName("com.mysql.jdbc.Driver")
          val conn = DriverManager.getConnection(dbConf.url, dbConf.username, dbConf.password)

          val queryRunner = new QueryRunner()
          val value = queryRunner.query[Map[Long, String]](conn, "select id, type, is_international from base.store", new ResultSetHandler[Map[Long, String]] {

            override def handle(rs: ResultSet): Map[Long, String] = {
              val r = new mutable.HashMap[Long, String]()

              while (rs.next()) {
                val key = rs.getInt("id")
                val yt = rs.getInt("type") // 业态
                val isInternational = rs.getInt("is_international") // 国际 or 国内

                val value = if (yt == 1) "MALL"
                else if (yt == 2) "MARKET"
                else if (yt == 3) "OVERSEA"
                else if (yt == 4 && isInternational == 1) "OVERSEA"
                else if (yt == 4 && isInternational == 0) "SUPPLIER"
                else "UNKNOW"

                r += ((key.toLong, value))
              }

              r.toMap
            }
          })

          storeSourceBroadcast = sc.broadcast(value)

          conn.close()
        }
      }
    }
    storeSourceBroadcast
  }

}
