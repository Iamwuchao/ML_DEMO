package com.tgou.data.stanford.streaming.canal

import com.alibaba.fastjson.{JSON, JSONObject}
import com.tgou.data.stanford.streaming.core.avro.{AvroSchema, AvroSerde}
import com.tgou.data.stanford.streaming.core.{KafkaSource, RedisSource, StreamingBootstrap}
import org.apache.avro.Schema
import org.apache.avro.generic.{GenericData, GenericRecord}
import org.apache.kafka.clients.producer.ProducerRecord
import org.apache.spark.streaming.StreamingContext
import org.apache.spark.streaming.kafka010.{CanCommitOffsets, HasOffsetRanges}
import org.joda.time.format.DateTimeFormat
import org.joda.time.{DateTimeZone, LocalDateTime}

import scala.collection.JavaConversions._

/**
  * 用于分发 Canal 主题数据的流应用
  *
  * Created by 李震 on 2018/4/8.
  */
object Application {

  def main(args: Array[String]): Unit = {
    new StreamingBootstrap(args).bootstrap(execute)
  }

  /**
    * 获取 Avro Schema
    *
    * @param jo Canal 主题的 JSONObject 对象
    *
    * @return Avro Schema 对象
    * */
  private def getAvroSchema(jo: JSONObject): Schema = {
    AvroSchema.getAvroSchema("tgouorder", jo.getString("_TABLENAME"))
  }

  /**
    * 获取 Avro Record
    *
    * @param jo Canal 主题的 JSONObject 对象
    * @param schema Avro Schema 对象
    *
    * @return Avro Record 对象
    * */
  private def getAvroRecord(jo: JSONObject, schema: Schema): GenericRecord = {
    val record = new GenericData.Record(schema)

    for (field: Schema.Field <- schema.getFields) {
      val key = field.name()
      for (subType <- field.schema().getTypes) { //WARN: 原始类型为 UNION 类型，需要移除其中的 NULL 类型
        if (subType.getType != Schema.Type.NULL) {
          subType.getType match {
            case Schema.Type.INT => {
              val value = jo.getString(key)
              if (value != null && value.trim.size > 0) {
                record.put(key, value.toInt)
              }
            }
            case Schema.Type.LONG => {
              val value = jo.getString(key)
              if (value != null && value.trim.size > 0) {
                if ("""^[0-9]{4}\-[0-9]{2}\-[0-9]{2}\s*[0-9]{2}:[0-9]{2}:[0-9]{2}$""".r.findFirstIn(value).isDefined) {
                  // 如果是日期格式，转为自 970-01-01 00:00:00 的秒数
                  val time = LocalDateTime.parse(value, DateTimeFormat.forPattern("yyyy-MM-dd HH:mm:ss")).toDateTime(DateTimeZone.forOffsetHours(8)).getMillis / 1000
                  record.put(key, time)
                } else {
                  record.put(key, value.toLong)
                }
              }
            }
            case Schema.Type.FLOAT => {
              val value = jo.getString(key)
              if (value != null && value.trim.size > 0) {
                record.put(key, value.toFloat)
              }
            }
            case Schema.Type.DOUBLE => {
              val value = jo.getString(key)
              if (value != null && value.trim.size > 0) {
                record.put(key, value.toDouble)
              }
            }
            case Schema.Type.STRING => {
              val value = jo.getString(key)
              if (value != null && value.trim.size > 0) {
                record.put(key, value)
              }
            }
            case _ => {}
          }
        }
      }
    }

    record
  }

  /**
    * 将 JSON 格式数据转为 Avro 格式数据
    *
    * @param json Canal 主题 JSON 格式数据
    *
    * @return Avro 序列化二进制数据
    * */
  private def convertJson2Avro(json: String): Array[Byte] = {
    val jo = JSON.parseObject(json)
    val schema = getAvroSchema(jo)
    val record = getAvroRecord(jo, schema)

    AvroSerde.serialize(record, schema)
  }

  def execute(ssc: StreamingContext, appName: String): Unit = {
    val in = KafkaSource.createJSONKafkaDStreams(ssc, appName, CanalConstants.SOURCE_TOPIC)
    in.foreachRDD(rdd => {
      val offsetRanges = rdd.asInstanceOf[HasOffsetRanges].offsetRanges // 获取 offset

      rdd.foreachPartition(data => {
        val producer = KafkaSource.createAvroKafkaProducer()
        val jedis = RedisSource.getJedis()

        for (i <- data) {
          val topic = i.key()

          if (jedis.lrange(appName, 0, jedis.llen(appName) - 1).toSet.contains(topic)) {
            val value = convertJson2Avro(i.value())
            val record = new ProducerRecord[String, Array[Byte]](topic, value)
            producer.send(record)
          }
        }

        jedis.close()
        producer.close()
      })

      if (!appName.startsWith("test") && !appName.endsWith("test")) in.asInstanceOf[CanCommitOffsets].commitAsync(offsetRanges) // 线上部署时提交 offset
    })
  }

}