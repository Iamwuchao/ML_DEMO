package com.tgou.data.stanford.streaming.order

import com.google.inject.AbstractModule
import com.google.inject.name.Names
import com.tgou.data.stanford.streaming.order.source.{BaseSource, OrderSource}
import com.tgou.data.stanford.streaming.order.source.impl.{BaseSourceImpl, OrderSourceImpl}
import org.apache.spark.streaming.StreamingContext

/**
  * Created by 李震 on 2018/4/10.
  */
class ApplicationModule(ssc: StreamingContext, appName: String) extends AbstractModule {

  override def configure(): Unit = {
    bind(classOf[StreamingContext]).toInstance(ssc)
    bind(classOf[String]).annotatedWith(Names.named("appName")).toInstance(appName)
    bind(classOf[OrderSource]).to(classOf[OrderSourceImpl])
    bind(classOf[BaseSource]).to(classOf[BaseSourceImpl])
  }

}
