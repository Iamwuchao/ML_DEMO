package com.tgou.data.stanford.streaming.order.source.impl

import com.google.inject.Inject
import com.google.inject.name.Named
import com.tgou.data.stanford.streaming.core.KafkaSource
import com.tgou.data.stanford.streaming.core.avro.AvroSchema
import com.tgou.data.stanford.streaming.order.source.OrderSource
import org.apache.kafka.clients.consumer.ConsumerRecord
import org.apache.spark.SparkContext
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.streaming.StreamingContext
import org.apache.spark.streaming.dstream.DStream

/**
  * Created by 李震 on 2018/4/10.
  */
class OrderSourceImpl extends OrderSource {

  @Inject
  var ssc: StreamingContext = _

  @Inject
  @Named("appName")
  var appName: String = _

  @volatile
  private var orderItemSchemaBroadcast: Broadcast[String] = null

  @volatile
  private var tgouOrderSchemaBroadcast: Broadcast[String] = null

  @volatile
  private var orderAmountSchemaBroadcast: Broadcast[String] = null

  @volatile
  private var returnRequestSchemaBroadcast: Broadcast[String] = null

  @volatile
  private var tgouOrderFsmLogSchemaBroadcast: Broadcast[String] = null

  /**
    * 获取订单品表 tgouorder.order_item 流数据
    **/
  override def getOrderItemDStream(): DStream[ConsumerRecord[String, Array[Byte]]] = {
    KafkaSource.createAvroKafkaDStreams(ssc, appName, "order_item")
  }

  /**
    * 获取订单表 tgouorder.tgou_order 流数据
    * */
  override def getTgouOrderDStream(): DStream[ConsumerRecord[String, Array[Byte]]] = {
    KafkaSource.createAvroKafkaDStreams(ssc, appName, "tgou_order")
  }

  /**
    * 获取订单金额表 tgouorder.order_amount 流数据
    * */
  override def getOrderAmountDStream(): DStream[ConsumerRecord[String, Array[Byte]]] = {
    KafkaSource.createAvroKafkaDStreams(ssc, appName, "order_amount")
  }

  /**
    * 获取订单退款表 tgouorder.return_request 流数据
    **/
  override def getReturnRequestDStream(): DStream[ConsumerRecord[String, Array[Byte]]] = {
    KafkaSource.createAvroKafkaDStreams(ssc, appName, "return_request")
  }

  /**
    * 获取订单有限状态机日志表 tgouorder.tgou_order_fsm_log 流数据
    **/
  override def getTgouOrderFSMLogDStream(): DStream[ConsumerRecord[String, Array[Byte]]] = {
    KafkaSource.createAvroKafkaDStreams(ssc, appName, "tgou_order_fsm_log")
  }

  /**
    * 获取订单品表 tgouorder.order_item Avro Schema 广播变量
    **/
  override def getOrderItemSchemaBroadcast(sc: SparkContext): Broadcast[String] = {
    if (orderItemSchemaBroadcast == null) {
      synchronized {
        if (orderItemSchemaBroadcast == null) {
          val json = AvroSchema.getAvroSchema("tgouorder", "order_item").toString
          orderItemSchemaBroadcast = sc.broadcast(json)
        }
      }
    }
    orderItemSchemaBroadcast
  }

  /**
    * 获取订单表 tgouorder.tgou_order Avro Schema 广播变量
    * */
  override def getTgouOrderSchemaBroadcast(sc: SparkContext): Broadcast[String] = {
    if (tgouOrderSchemaBroadcast == null) {
      synchronized {
        if (tgouOrderSchemaBroadcast == null) {
          val json = AvroSchema.getAvroSchema("tgouorder", "tgou_order").toString
          tgouOrderSchemaBroadcast = sc.broadcast(json)
        }
      }
    }
    tgouOrderSchemaBroadcast
  }

  /**
    * 获取订单金额表 tgouorder.order_amount Avro Schema 广播变量
    * */
  override def getOrderAmountSchemaBroadcast(sc: SparkContext): Broadcast[String] = {
    if (orderAmountSchemaBroadcast == null) {
      synchronized {
        if (orderAmountSchemaBroadcast == null) {
          val json = AvroSchema.getAvroSchema("tgouorder", "order_amount").toString
          orderAmountSchemaBroadcast = sc.broadcast(json)
        }
      }
    }
    orderAmountSchemaBroadcast
  }

  /**
    * 获取订单退款表 tgouorder.return_request Avro Schema 广播变量
    **/
  override def getReturnRequestSchemaBroadcast(sc: SparkContext): Broadcast[String] = {
    if (returnRequestSchemaBroadcast == null) {
      synchronized {
        if (returnRequestSchemaBroadcast == null) {
          val json = AvroSchema.getAvroSchema("tgouorder", "return_request").toString
          returnRequestSchemaBroadcast = sc.broadcast(json)
        }
      }
    }
    returnRequestSchemaBroadcast
  }

  /**
    * 获取订单有限状态机日志表 tgouorder.tgou_order_fsm_log Avro Schema 广播变量
    **/
  override def getTgouOrderFSMLogSchemaBroadcast(sc: SparkContext): Broadcast[String] = {
    if (tgouOrderFsmLogSchemaBroadcast == null) {
      synchronized {
        if (tgouOrderFsmLogSchemaBroadcast == null) {
          val json = AvroSchema.getAvroSchema("tgouorder", "tgou_order_fsm_log").toString
          tgouOrderFsmLogSchemaBroadcast = sc.broadcast(json)
        }
      }
    }
    tgouOrderFsmLogSchemaBroadcast
  }
}
