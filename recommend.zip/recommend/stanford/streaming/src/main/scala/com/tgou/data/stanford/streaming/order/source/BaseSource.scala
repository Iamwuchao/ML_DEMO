package com.tgou.data.stanford.streaming.order.source

import org.apache.spark.SparkContext
import org.apache.spark.broadcast.Broadcast

/**
  * Created by 李震 on 2018/4/24.
  */
trait BaseSource {

  /**
    * 获取店铺业态广播变量
    * */
  def getStoreSourceBroadcast(sc: SparkContext): Broadcast[Map[Long, String]]

}
