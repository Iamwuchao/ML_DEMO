package com.tgou.data.stanford.streaming.utils

object SaveType extends Enumeration{
  type SaveType = Value

  val USER_PRODUCT_REC  = Value("user_product_rec")
  val PRODUCT_REC       = Value("product_rec")
  val USER_BRAND_REC    = Value("user_brand_rec")
  val BRAND_REC         = Value("brand_rec")
  val SQOOP_REC         = Value("sqoop_rec")
  val OTHER             = Value("other")

  private val default = Seq("none","none")

  private val checks:Map[SaveType,Seq[String]] = Map(
    USER_PRODUCT_REC  -> Seq("member_id","listing_id","index"),
    PRODUCT_REC       -> Seq("listing_id","rec_listing_id","index"),
    USER_BRAND_REC    -> Seq("member_id","brand_id","index"),
    BRAND_REC         -> Seq("brand_id","rec_brand_id","index"),
    SQOOP_REC         -> Seq("index","rec_id","info"),
    OTHER             -> Seq()
  )

  /**
    * 获取检查列表
    *
    * @param saveType 保存类型
    * @return
    */
  def getAssertList(saveType: SaveType):Seq[String] = {
    checks.getOrElse(saveType, default)
  }

  /**
    * 获取保存时的rowkey
    *
    * @param saveType 保存类型
    * @return
    */
  def getRowkey(saveType: SaveType):String = {
    checks.getOrElse(saveType, default).head
  }

  /**
    * 获取保存时的推荐col
    *
    * @param saveType 保存类型
    * @return
    */
  def getRecCol(saveType: SaveType):String = {
    checks.getOrElse(saveType, default)(1)
  }
}
