package com.tgou.data.stanford.streaming.core

import org.apache.spark.SparkConf
import org.apache.spark.streaming.{Seconds, StreamingContext}

/**
  * Created by 李震 on 2018/1/9.
  */
class StreamingBootstrap(args : Array[String], checkpoint: String) {

  val appName = args(0)
  val duration = if (args.length > 1) args(1).toInt else 10 // 默认 10 秒

  def this(args : Array[String]){
    this(args, null)
  }

  def bootstrap(execute: (StreamingContext, String) => Unit): Unit = {
    val ssc = if (appName.startsWith("test") || appName.endsWith("test")) {
      // 测试
      System.setProperty("hive.metastore.uris", "thrift://hnode1:9083")

      val conf = new SparkConf().setMaster("local[2]").setAppName(appName)
      val ssc = new StreamingContext(conf, Seconds(duration))

      ssc.sparkContext.setLogLevel("DEBUG")

      ssc
    } else {
      // 线上
      System.setProperty("hive.metastore.uris", "thrift://hnode1:9083")

      val conf = new SparkConf().setMaster("yarn").setAppName(appName)
      val ssc = new StreamingContext(conf, Seconds(duration))

      ssc.sparkContext.setLogLevel("warn")

      ssc
    }

    execute(ssc, appName) // 执行

    ssc.start()
    ssc.awaitTermination()
  }

}