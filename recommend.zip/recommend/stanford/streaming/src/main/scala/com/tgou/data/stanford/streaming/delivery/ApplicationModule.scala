package com.tgou.data.stanford.streaming.delivery

import com.google.inject.AbstractModule
import com.google.inject.name.Names
import com.tgou.data.stanford.streaming.delivery.source.DeliverySource
import com.tgou.data.stanford.streaming.delivery.source.impl.DeliverySourceImpl
import org.apache.spark.streaming.StreamingContext

/**
  * Created by 李震 on 2018/2/8.
  */
class ApplicationModule(ssc: StreamingContext, appName: String) extends AbstractModule {

  override def configure(): Unit = {
    bind(classOf[StreamingContext]).toInstance(ssc)
    bind(classOf[String]).annotatedWith(Names.named("appName")).toInstance(appName)
    bind(classOf[DeliverySource]).to(classOf[DeliverySourceImpl])
  }

}
