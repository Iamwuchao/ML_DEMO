package com.tgou.data.stanford.streaming.delivery;

/**
 * Created by 李震 on 2018/2/8.
 */
public interface DeliveryConstants {

    String TABLE_TGOU_PACKAGE = "tgou_package";
    String TABLE_THIRD_DELIVERY_INFO_RECORD = "third_delievry_info_record";
    String TABLE_THIRD_DELIVERY_INFO_RECORD_LOG = "third_delievry_info_record_log";

    String TOPIC = "canal";

}
