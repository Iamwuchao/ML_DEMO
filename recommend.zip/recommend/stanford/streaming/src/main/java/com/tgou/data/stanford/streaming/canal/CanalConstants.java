package com.tgou.data.stanford.streaming.canal;

/**
 * Created by 李震 on 2018/4/8.
 */
public interface CanalConstants {

    String SOURCE_TOPIC = "canal";

    String NAMESPACE = "com.tgou.data.stanford.streaming.canal";

}
