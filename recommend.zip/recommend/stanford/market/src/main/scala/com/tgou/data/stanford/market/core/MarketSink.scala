package com.tgou.data.stanford.market.core

import org.apache.spark.sql.{Column, DataFrame, SaveMode}
import org.apache.spark.sql.functions._
import org.joda.time.{LocalDate, LocalTime}

/**
  * Created by 李震 on 2017/11/21.
  */
object MarketSink {

  /**
    * 保存为 CSV
    *
    * @param df
    * @param primaryKey 构成主键的字段
    * @param timestamp 时间戳
    * @param path 路径
    *
    * */
  def saveAsCSV(df: DataFrame, primaryKey: Seq[Column], timestamp: LocalDate, path: String): Unit = {
    val marketTime = lit(timestamp.toDateTime(new LocalTime(0, 0, 0, 0)).toString("yyyy-MM-dd HH:mm:ss"))
    val salt = rand()
    val id = md5(concat((primaryKey :+ marketTime :+ salt): _*))
    val columns = id +: df.columns.map(c => col(c)) :+ marketTime

    df.select(columns: _*).coalesce(1).write
      .mode(SaveMode.Overwrite)
      .option("delimiter", "^")
      .option("quote", "")
      .option("nullValue", "\\N")
      .option("dateFormat", "yyyy-MM-dd HH:mm:ss")
      .csv(s"${path}/${timestamp.toString("yyyy/MM/dd")}")
  }

}
