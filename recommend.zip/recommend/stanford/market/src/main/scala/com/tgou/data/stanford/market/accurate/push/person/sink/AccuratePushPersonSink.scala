package com.tgou.data.stanford.market.accurate.push.person.sink

import org.apache.spark.sql.DataFrame

/**
  * Created by 李震 on 2017/11/20.
  */
trait AccuratePushPersonSink {

  /**
    * 保存精准推送人员信息
    *
    * @param df
    *
    * */
  def persistAccuratePushPersonDF(df: DataFrame): Unit

  /**
    * 保存精准推送人员深度信息
    *
    * @param df
    *
    * */
  def persistAccuratePushPersonDensityDF(df: DataFrame): Unit

}
