package com.tgou.data.stanford.market.accurate.push

import com.alibaba.fastjson.JSON
import com.tgou.data.stanford.market.accurate.push.bean.{ActivityODS, CouponODS}
import com.tgou.data.stanford.market.core.MarketSource
import com.tgou.data.stanford.market.core.utils.BeanUtils
import org.apache.spark.sql.catalyst.encoders.RowEncoder
import org.apache.spark.sql.{DataFrame, Row, SparkSession}
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types._
import org.apache.spark.storage.StorageLevel
import org.joda.time.format.DateTimeFormat
import org.joda.time.{LocalDate, LocalDateTime, LocalTime}

import scala.collection.mutable

/**
  * Created by 李震 on 2017/11/6.
  */
class PushSource (spark: SparkSession, date: LocalDate) {

  /**
    * 精准推送
    *
    * 字段：
    *
    * - push_task_id  推送ID
    * - push_time  推送时间
    * - start_time  精准活动开始时间
    * - end_time  精准活动结束时间
    * - subject_code  推送内容编码 502 券 503 活动
    * - object_id 推送内容ID
    * - object_type 推送内容类型
    *
    * */
  lazy val pushDF: DataFrame = initPushDF()

  private def initPushDF(): DataFrame = {
    val pushDF = spark.sql(
      s"""
        |select
        |    p.push_task_id,
        |    p.push_time,
        |    p.subject_code,
        |    p.object_id
        |from dw.push p
        |where p.his_time = '${date.toString("yyyy-MM-dd")}'
        |and p.push_time >= '${date.minusDays(Constants.STATICS_DURATION - 1).toDateTime(new LocalTime(0, 0, 0, 0)).toString("yyyy-MM-dd HH:mm:ss")}'
        |and p.type in ('1', '2')
        |and p.state = '6'
      """.stripMargin)

      val couponPushDF = pushDF.filter(col("subject_code") === "502")
      val activityPushDF = pushDF.filter(col("subject_code") === "503")

      if (couponPushDF.count() > 0) {
        if (activityPushDF.count() > 0) {
          // 推送券
          val pushCouponDF = getPushCouponDF(couponPushDF)

          // 推送活动
          val pushActivityDF = getPushActivityDF(activityPushDF)

          // 合并
          pushCouponDF.union(pushActivityDF)
        } else {
          // 推送券
          getPushCouponDF(couponPushDF)
        }
      } else {
        // 推送活动
        getPushActivityDF(activityPushDF)
      }
  }


  /**
    * 精准推送人
    *
    * 字段：
    *
    * - push_task_id  推送ID
    * - push_time  推送时间
    * - start_time  精准活动开始时间
    * - end_time  精准活动结束时间
    * - subject_code  推送内容编码 502 券 503 活动
    * - object_id 推送内容ID
    * - object_type 推送内容类型
    * - phone  手机号码
    * - is_received  是否接收成功
    *
    * */
  lazy val pushPersonDF: DataFrame = initPushPersonDF()

  private def initPushPersonDF(): DataFrame = {
    this.pushDF.createOrReplaceTempView("push")

    spark.sql(
      s"""
        |select
        |    p.push_task_id,
        |    p.push_time,
        |    p.start_time,
        |    p.end_time,
        |    p.subject_code,
        |    p.object_id,
        |    p.object_type,
        |    p2p.phone,
        |    if(p2p.push_send_flag = '1' or p2p.sms_send_flag = '1', true, false) as is_received
        |from push p
        |join dw.push_to_person p2p
        |on p2p.fk_push_task_id = p.push_task_id
        |and p2p.his_time = '${date.toString("yyyy-MM-dd")}'
      """.stripMargin)
  }


  /**
    * 处理推送会员
    *
    * 字段：
    *
    * - push_task_id  推送 ID
    * - push_time  推送时间
    * - start_time  精准活动开始时间
    * - end_time  精准活动结束时间
    * - subject_code  推送内容编码 502 券 503 活动
    * - object_id  推送内容ID
    * - object_type  推送内容类型
    * - member_id  会员 ID
    * - register_time  注册时间
    *
    * */
  lazy val pushMemberDF: DataFrame = initPushMemberDF()

  private def initPushMemberDF(): DataFrame = {
    this.pushPersonDF.createOrReplaceTempView("push_person")

    spark.sql(
      s"""
         |select
         |    pp.push_task_id,
         |    pp.push_time,
         |    pp.start_time,
         |    pp.end_time,
         |    pp.subject_code,
         |    pp.object_id,
         |    pp.object_type,
         |    m.member_id,
         |    m.register_time
         |from dw.member m
         |join push_person pp
         |on m.cell_phone = pp.phone
         |and m.his_time = '${date.toString("yyyy-MM-dd")}'
         |and pp.is_received = true
      """.stripMargin).persist(StorageLevel.MEMORY_AND_DISK)
  }


  /**
    * 推送券
    *
    * 字段：
    *
    * - push_task_id  推送ID
    * - push_time  推送时间
    * - start_time  精准活动开始时间
    * - end_time  精准活动结束时间
    * - subject_code  推送内容编码 502 券 503 活动
    * - object_id 推送内容ID
    * - object_type 推送内容类型
    *
    * */
  private def getPushCouponDF(pushDF: DataFrame): DataFrame = {
    /*
     * 推送券
     * */
    val pushCouponDF = getOriginalPushCoupon(pushDF)
    pushCouponDF.persist(StorageLevel.MEMORY_AND_DISK)
    pushCouponDF.createOrReplaceTempView("push_coupon")

    val earlyestDate = LocalDateTime.parse(
      pushCouponDF.agg(min(col("create_time"))).collect()(0).getString(0),
      DateTimeFormat.forPattern("yyyy-MM-dd HH:mm:ss")
    ).toLocalDate // 所有活动最早的创建日期

    val couponODSDF = getCouponODSDF(earlyestDate)
    couponODSDF.createOrReplaceTempView("coupon_ods")

    val flatPushCouponDF = spark.sql(
      """
        |select
        |    pc.push_task_id,
        |    pc.push_time,
        |    pc.start_time,
        |    pc.end_time,
        |    pc.publish_time,
        |    pc.off_time,
        |    pc.is_fixed,
        |    pc.subject_code,
        |    pc.object_id,
        |    pc.object_type,
        |    co.state,
        |    co.promotion_rule
        |from push_coupon pc
        |left join coupon_ods co
        |on pc.object_id = co.id
      """.stripMargin)

    val formatDate = date.toString("yyyy-MM-dd")
    val schema = StructType(
      StructField("push_task_id", LongType, false) ::
      StructField("push_time", StringType, false) ::
      StructField("start_time", StringType, false) ::
      StructField("end_time", StringType, false) ::
      StructField("subject_code", LongType, false) ::
      StructField("object_id", LongType, false) ::
      StructField("object_type", StringType, false) :: Nil
    )
    flatPushCouponDF
      .mapPartitions(rs => {
        val date = LocalDateTime.parse(formatDate, DateTimeFormat.forPattern("yyyy-MM-dd"))

        var b = new mutable.ListBuffer[Row]

        for (r <- rs) {
          if ("processing".equals(r.getString(10))) {
            if (r.getBoolean(6)) {
              // 定长
              val fixedLength = JSON.parseObject(r.getString(11)).getInteger("fixedLength")
              val startTime = LocalDateTime.parse(r.getString(4), DateTimeFormat.forPattern("yyyy-MM-dd HH:mm:ss"))
              val endTime = LocalDateTime.parse(r.getString(5), DateTimeFormat.forPattern("yyyy-MM-dd HH:mm:ss")).plusDays(fixedLength)

              if (endTime.compareTo(date) >= 0) {
                b += Row(r.get(0), r.get(1), startTime.toString("yyyy-MM-dd HH:mm:ss"), endTime.toString("yyyy-MM-dd HH:mm:ss"), r.get(7), r.get(8), r.get(9))
              }
            } else {
              // 非定长
              val endTime = LocalDateTime.parse(r.getString(3), DateTimeFormat.forPattern("yyyy-MM-dd HH:mm:ss"))

              if (endTime.compareTo(date) >= 0) {
                b += Row(r.get(0), r.get(1), r.get(2), r.get(3), r.get(7), r.get(8), r.get(9))
              }
            }
          }
        }

        b.toIterator
      })(RowEncoder(schema))
  }


  private def getOriginalPushCoupon(pushDF: DataFrame): DataFrame = {
    val couponDF = spark.sql(
      s"""
         |select
         |    c.coupon_id,
         |    c.type,
         |    c.create_time,
         |    c.verify_start_time,
         |    c.verify_end_time,
         |    c.start_time,
         |    c.end_time,
         |    if((isnull(verify_start_time) and isnull(verify_end_time)), true, false) as is_fixed
         |from dw.coupon c
         |where c.his_time = '${date.toString("yyyy-MM-dd")}'
         |and c.type in ('1', '2', '3', '4')
      """.stripMargin)

    couponDF.join(broadcast(pushDF), couponDF.col("coupon_id") === pushDF.col("object_id"))
      .select(
        col("push_task_id"),
        col("push_time"),
        col("create_time"),
        col("verify_start_time") as "start_time",
        col("verify_end_time") as "end_time",
        col("start_time") as "publish_time",
        col("end_time") as "off_time",
        col("is_fixed"),
        col("subject_code"),
        col("object_id"),
        col("type") as "object_type"
      )
  }


  /**
    * 推送活动
    *
    * 字段：
    *
    * - push_task_id  推送ID
    * - push_time  推送时间
    * - start_time  精准活动开始时间
    * - end_time  精准活动结束时间
    * - subject_code  推送内容编码 502 券 503 活动
    * - object_id 推送内容ID
    * - object_type 推送内容类型
    *
    * */
  private def getPushActivityDF(pushDF: DataFrame): DataFrame = {
    /*
     * 推送活动
     * */
    val pushActivity = getOriginalPushActivity(pushDF)
    pushActivity.persist(StorageLevel.MEMORY_AND_DISK)
    pushActivity.createOrReplaceTempView("push_activity")

    /*
     * 只保留状态审核通过的活动
     * */
    val earlyestDate = LocalDateTime.parse(
      pushActivity.agg(min(col("create_time"))).collect()(0).getString(0),
      DateTimeFormat.forPattern("yyyy-MM-dd HH:mm:ss")
    ).toLocalDate // 所有活动最早的创建日期

    val activityODSDF = getActivityODSDF(earlyestDate)
    activityODSDF.createOrReplaceTempView("activity_ods")

    spark.sql(
      s"""
        |select
        |    pa.push_task_id,
        |    pa.push_time,
        |    pa.start_time,
        |    pa.end_time,
        |    pa.subject_code,
        |    pa.object_id,
        |    pa.object_type
        |from push_activity pa
        |left join activity_ods ao
        |on pa.object_id = ao.id
        |where ao.state = 'processing'
        |and pa.end_time >= '${date.toDateTime(new LocalTime(0, 0, 0, 0)).toString("yyyy-MM-dd HH:mm:ss")}'
      """.stripMargin)
  }


  private def getOriginalPushActivity(pushDF: DataFrame): DataFrame = {
    val activityDF = spark.sql(
      s"""
         |select
         |    a.activity_id,
         |    a.type,
         |    a.create_time,
         |    a.start_time,
         |    a.stop_time
         |from dw.activity a
         |where a.his_time = '${date.toString("yyyy-MM-dd")}'
         |and a.type in ('3', '4', '6', '7')
      """.stripMargin)

    activityDF.join(broadcast(pushDF), activityDF.col("activity_id") === pushDF.col("object_id"))
      .select(
        col("push_task_id"),
        col("push_time"),
        col("create_time"),
        col("start_time"),
        col("stop_time") as "end_time",
        col("subject_code"),
        col("object_id"),
        col("type") as "object_type"
      )
  }


  /**
    * 获取 ODS 层活动数据
    *
    * @param fromDate
    *
    * @return
    *
    * 字段：
    *
    * - id 活动 ID
    * - state 活动状态
    *
    * */
  private def getActivityODSDF(fromDate: LocalDate): DataFrame = {
    val df = MarketSource.getDurationDF(
      spark,
      "/tiangou/tgou/activity",
      fromDate,
      date,
      BeanUtils.getSchemaFromBean[ActivityODS]
    )
    MarketSource.getNewestDF(df, Seq("id"), "modify_time")
  }


  /**
    * 获取 ODS 层券数据
    *
    * @param fromDate
    *
    * @return
    *
    * 字段：
    *
    * - id 券 ID
    * - state 券状态
    * - promotion_rule 规则
    *
    * */
  private def getCouponODSDF(fromDate: LocalDate): DataFrame = {
    val df = MarketSource.getDurationDF(
      spark,
      "/tiangou/tgou/coupon",
      fromDate,
      date,
      BeanUtils.getSchemaFromBean[CouponODS]
    )
    MarketSource.getNewestDF(df, Seq("id"), "modify_time")
  }

}

object PushSource {

  def apply(spark: SparkSession, date: LocalDate): PushSource = new PushSource(spark, date)

}
