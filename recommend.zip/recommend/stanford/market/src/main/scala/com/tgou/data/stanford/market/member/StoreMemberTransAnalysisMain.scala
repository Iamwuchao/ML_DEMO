package com.tgou.data.stanford.market.member

import java.time.LocalDate
import java.util.Properties

import com.tgou.data.stanford.market.member.service.{MemberAnalysisCalculators, StoreMembersCalculators}
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.execution.datasources.jdbc.{JDBCOptions, JdbcUtils}
import org.apache.spark.storage.StorageLevel

/**
  * 统计平台活跃&新增
  */
object StoreMemberTransAnalysisMain {
  def main(args: Array[String]): Unit = {
    JdbcBootstrap(args).bootstrap(execute)
  }
  def execute(spark: SparkSession,appName: String, date: LocalDate, jdbcConfig: Properties): Unit = {
    val table = "tgou_store_member_trans"//表名
    jdbcConfig.setProperty("table", table)
    var jdbcConfigMap = Map[String,String]()
    jdbcConfigMap+=("driver"->jdbcConfig.getProperty("driver"))
    jdbcConfigMap+=("url"->jdbcConfig.getProperty("url"))
    jdbcConfigMap+=("user"->jdbcConfig.getProperty("user"))
    jdbcConfigMap+=("password"->jdbcConfig.getProperty("password"))
    jdbcConfigMap+=("dbtable"->table)
    println(jdbcConfigMap)
    val conn = JdbcUtils.createConnectionFactory(new JDBCOptions(jdbcConfigMap)).apply
    try {
      conn.prepareStatement(
        s"""
           |delete from $table where date = '$date'
        """.stripMargin).executeUpdate
    }finally conn.close()

    val overviewResult = StoreMembersCalculators.calOnlineTranslate(spark, date).select("storecode","storename","total_count","active_cid_count","no_trans_count","date")
    overviewResult.write.mode("append").jdbc(jdbcConfig.getProperty("url"), table, jdbcConfig)
  }

}
