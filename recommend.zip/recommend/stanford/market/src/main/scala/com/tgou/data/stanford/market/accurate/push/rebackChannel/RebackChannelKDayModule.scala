package com.tgou.data.stanford.market.accurate.push.rebackChannel

import com.tgou.data.stanford.market.accurate.push.{Constants, OrderSource}
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.storage.StorageLevel
import org.joda.time.LocalDate

/**
  * Created by 张少锐 on 2017/11/10.
  * 精准推送回访渠道分析-跨天表
  */
object RebackChannelKDayModule {

  def getRebackChannelKDay(spark: SparkSession, date: LocalDate): DataFrame ={

    val yesterday = date.toString("yyyy-MM-dd")
    val minus31 = date.minusDays(Constants.STATICS_DURATION - 1).toString("yyyy-MM-dd")
    val rebackChannel = RebackChannelProcessor(spark, date)
    val rebackChannelKDay = RebackChannelKDayProcessor(spark, date)
    val onlineOrder = OrderSource(spark,date).onlineOrderDF.persist(StorageLevel.MEMORY_AND_DISK_SER)
    val onlineOrderProduct = OrderSource(spark,date).onlineOrderProductDF

    // 获取跨天的uba_page信息表
    rebackChannel.ubaPage31DF.createOrReplaceTempView("uba_page_kday")

    // 获取跨天的uba_scp信息表
    spark.sql(
      s"""
         |select id,member_id,a_b_c,time
         |from dw.uba_scp us
         |where us.his_time >= '$minus31'
         |and us.his_time <= '$yesterday'
         |and us.member_id != ''
       """.stripMargin).createOrReplaceTempView("uba_scp_kday")

    // 获取去除掉电子小票-创建的订单
    onlineOrder.filter(s"create_time is not null").createOrReplaceTempView("create_order")

    // 获取去除掉电子小票-支付的订单
    onlineOrder.filter(s"pay_time is not null and pay_method != '010'").createOrReplaceTempView("pay_order")

    // 获取订单商品去除掉电子小票-支付的订单
    onlineOrderProduct.filter(s"pay_time is not null and pay_method != '010'").createOrReplaceTempView("pay_order_product")

    // 获取线上订单优惠记录流水表
    OrderSource(spark,date).onlineOrderPreferentialDF.createOrReplaceTempView("order_preferential")

    // 获取收藏表shop_cart_log
    rebackChannelKDay.getShopCartLogODSDF().createOrReplaceTempView("shop_cart_log")

    // 获取卷活动信息表coupon_to_activity
    rebackChannelKDay.getCouponToActivityDF().select("fk_activity_id","fk_coupon_id","total_qty").createOrReplaceTempView("coupon_to_activity")

    // 获取券信息表coupon_information
    spark.sql(
      s"""
         |select id,coupon_id,type
         |from dw.coupon c
         |where c.his_time = '$yesterday'
       """.stripMargin).createOrReplaceTempView("coupon_information")

    // 获取劵核销信息表coupon_code
    spark.sql(
      s"""
         |select id,coupon_code_id,member_id,create_time,use_time,use_tag,fk_activity_id,fk_coupon_id
         |from dw.coupon_code cc
         |where cc.his_time = '$yesterday'
         |and cc.member_id is not null
       """.stripMargin).createOrReplaceTempView("coupon_code")

    // 统计所有的数据
    val allRebackCountDF = rebackChannelKDay.processTradingCount(rebackChannel.allPerson).
      join(rebackChannelKDay.processCouponFlowCount(rebackChannel.allPerson),Seq("push_task_id"),"full").
      selectExpr(
        "push_task_id",
        "reback_count",
        "order_count",
        "order_sum",
        "pay_count",
        "pay_sum",
        "kdj",
        "null as platform_pv",
        "null as platform_uv",
        "null as add_cart_count",
        "null as jz_jyrs_count",
        "null as jz_jybs_count",
        "null as jz_jyje_sum",
        "null as ld_jyrs_count",
        "null as ld_jybs_count",
        "null as ld_jyje_sum",
        "coupon_type",
        "coupon_id",
        "coupon_total_sum",
        "coupon_receive_count",
        "coupon_user_count",
        "coupon_ship_count",
        "coupon_ship_sum",
        "'所有' as reback_channel"
      )

    // 统计APP的数据
    val appRebackCountDF = rebackChannelKDay.processTradingCount(rebackChannel.appPerson).
      join(rebackChannelKDay.processFlowCount(rebackChannel.appPerson),Seq("push_task_id"),"full").
      join(rebackChannelKDay.processCouponFlowCount(rebackChannel.appPerson),Seq("push_task_id"),"full").
      selectExpr("*", "'APP' as reback_channel")

    // 统计微信的数据
    val wechatRebackCountDF = rebackChannelKDay.processTradingCount(rebackChannel.wechatPerson).
      join(rebackChannelKDay.processFlowCount(rebackChannel.wechatPerson),Seq("push_task_id"),"full").
      join(rebackChannelKDay.processCouponFlowCount(rebackChannel.wechatPerson),Seq("push_task_id"),"full").
      selectExpr("*","'微信' as reback_channel")

    // 统计WEB的数据
    val webRebackCountDF = rebackChannelKDay.processTradingCount(rebackChannel.webPerson).
      join(rebackChannelKDay.processFlowCount(rebackChannel.webPerson),Seq("push_task_id"),"full").
      join(rebackChannelKDay.processCouponFlowCount(rebackChannel.webPerson),Seq("push_task_id"),"full").
      selectExpr("*","'WEB' as reback_channel")

    // 各渠道汇总的数据
    val allCountDF = allRebackCountDF.union(appRebackCountDF).union(wechatRebackCountDF).union(webRebackCountDF)
    val fields = Map("reback_count"->0,"order_count"->0,"order_sum"->0.0,"pay_count"->0,"pay_sum"->0.0,"kdj"->0.0,
                    "platform_pv"->0,"platform_uv"->0,"add_cart_count"->0,"jz_jyrs_count"->0,"jz_jybs_count"->0,
                    "jz_jyje_sum"->0.0,"ld_jyrs_count"->0,"ld_jybs_count"->0,"ld_jyje_sum"->0.0,"coupon_total_sum"->0,
                    "coupon_receive_count"->0,"coupon_user_count"->0,"coupon_ship_count"->0,"coupon_ship_sum"->0.0)

    spark.udf.register("getCouponType", (i:Integer)=>{if(i == 1){"现金券"}else if(i == 2){"折扣券"}else if(i == 3){"满减券"}else if(i == 4){"满送券"}else{null}})

    rebackChannel.pushPerson.select("push_task_id","start_time","end_time").distinct().
      join(allCountDF,"push_task_id").selectExpr(
      "push_task_id as push_id",
      "start_time",
      "end_time",
      "reback_channel",
      "reback_count",
      "order_count",
      "order_sum",
      "pay_count",
      "pay_sum",
      "kdj",
      "platform_pv",
      "platform_uv",
      "add_cart_count",
      "jz_jyrs_count",
      "jz_jybs_count",
      "jz_jyje_sum",
      "ld_jyrs_count",
      "ld_jybs_count",
      "ld_jyje_sum",
      "getCouponType(coupon_type) as coupon_type",
      "coupon_id",
      "coupon_total_sum",
      "coupon_receive_count",
      "coupon_user_count",
      "coupon_ship_count",
      "coupon_ship_sum"
    ).na.fill(fields)
  }
}
