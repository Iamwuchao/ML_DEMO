package com.tgou.data.stanford.market.member.service

import java.time.LocalDate

import org.apache.spark.sql.{DataFrame, SparkSession}

object StoreMembersCalculators {

  def calOnlineTranslate(spark: SparkSession, date: LocalDate): DataFrame = {
    val oneYear = date.plusDays(-365)
    val transMemberSql =
      s"""
        |SELECT count(1) as active_cid_count,sum(no_trans_members) as no_trans_count,storecode FROM(
        |   SELECT substring(t1.cid,0,4) as storecode,CASE WHEN t2.cid is null THEN 1 ELSE 0 END as no_trans_members from
        |     (SELECT distinct cid FROM dw.pos_zz where his_time > '$oneYear' and his_time <= '$date' and jyje>0) t1
        |   LEFT JOIN
        |     (SELECT distinct cid FROM dw.card_bind where his_time = '$date') t2
        |   ON t1.cid = t2.cid
        |   ) t group by storecode
      """.stripMargin

    val totalMemberSql =
      s"""
        | SELECT COUNT(1) as total_count,
        | storecode
        | FROM dw.mmc_card
        | WHERE his_time = '$date'
        | and status = 1
        | GROUP BY storecode
      """.stripMargin

    var sqlText =
      s"""
        | SELECT t1.storecode,
        |  t3.storename,
        |  t1.total_count,
        |  nvl(t2.active_cid_count,0) as active_cid_count,
        |  nvl(t2.no_trans_count,0) as no_trans_count,
        |  '$date' as date
        |  FROM ($totalMemberSql) t1
        |  INNER JOIN
        |  (SELECT store_code as storecode,store_name as storename FROM dw.store where his_time = '$date') t3
        |  ON t1.storecode = t3.storecode
        |  LEFT JOIN
        |  ($transMemberSql) t2
        |  ON t1.storecode = t2.storecode
      """.stripMargin
    spark.sql(sqlText)
  }
}
