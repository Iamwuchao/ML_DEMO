package com.tgou.data.stanford.market.page.code.analysis.util

import org.apache.spark.sql.{DataFrame, SparkSession}

/**
  * create by: CaoBuZheng 2018-04-03
  * 目的是补全类scp表的 Member_id。
  * 生成1个新字段，m_id。表示新的补充后的member_id。源member_id不变。
  */
object FullMemberIdHelper {

  def fullMemberIdWithUuid(spark: SparkSession, originDF: DataFrame): DataFrame = {
    //select("uuid","member_id","time") 这三个是必须的。
    originDF.createOrReplaceTempView("tmp_view")
    var sqlText =
      """
        | select a.uuid,a.time,min(b.time) as b_time from
        | (select member_id,uuid,time from tmp_view)a
        |   left join
        | (select member_id,uuid,time from tmp_view )b
        | on b.uuid = a.uuid
        | and a.member_id = ''
        | and b.member_id != ''
        | WHERE a.time <= b.time
        | group by a.uuid,a.time
      """.stripMargin
    val tmpDF = spark.sql(sqlText)
    tmpDF.createOrReplaceTempView("b_view")
    sqlText =
      """
        | select t1.*,CASE WHEN t1.member_id != '' THEN t1.member_id ELSE t2.member_id END  as m_id from tmp_view t1
        | left join
        | (
        |  SELECT DISTINCT b.uuid,b.time,a.member_id FROM tmp_view a
        |  INNER JOIN b_view b
        |  ON a.uuid = b.uuid
        |  AND a.time = b.b_time
        | )t2
        | ON t1.uuid = t2.uuid
        | AND t1.time = t2.time
      """.stripMargin
    val resultDf =spark.sql(sqlText)
    resultDf
  }

}
