package com.tgou.data.stanford.market.page.util.udf
import org.apache.spark.sql.Row
import org.apache.spark.sql.expressions.{MutableAggregationBuffer, UserDefinedAggregateFunction}
import org.apache.spark.sql.types._


/**
  * 代表一个Pv
  * @param deep
  * @param page
  */
case class PageView(
                   deep: Int,
                   page: String
                   ){}
/**
  * pages是有序的序列。
  * @param pages
  */
class HardcoreFunnelUDAF(pages: List[String]) extends UserDefinedAggregateFunction{
  // 此处的page 只能用 = ，如果是要用like，再想办法吧
  // funnel_page 是由','逗号隔开的page，带先后顺序
  override def inputSchema: StructType = StructType(Seq(StructField("deep", IntegerType),StructField("page",StringType)))

  // 直接不处理？全部交给evaluate来处理？？？
  override def bufferSchema: StructType = StructType(StructField("values", MapType(IntegerType, StringType))::Nil)

  // 如果满足第一层漏斗的，是1，第二层的是2，依次递增
  override def dataType: DataType = IntegerType

  override def deterministic: Boolean = true

  override def initialize(buffer: MutableAggregationBuffer): Unit = {
    buffer(0) = Map[String,Seq[Map[Int, String]]]()
  }

  override def update(buffer: MutableAggregationBuffer, input: Row): Unit = {
    var map = buffer.getAs[Map[Int, String]](0)
    map = map + (input.getInt(0) -> input.getString(1))
    buffer(0) = map
  }

  override def merge(buffer1: MutableAggregationBuffer, buffer2: Row): Unit = {
    if(buffer2(0) != null){
      var map1 = buffer1.getAs[Map[Int, String]](0)
      val map2 = buffer2.getAs[Map[Int, String]](0)
      for(kv <- map2){
        map1 = map1 + kv
      }
      buffer1(0) = map1
    }
  }

  override def evaluate(buffer: Row): Any = {
    if(buffer(0) != null){
      val map = buffer.getAs[Map[Int, String]](0)
      val list = map.toList.map(kv => PageView(kv._1,kv._2))
      toFunnelCount(list)
    }else{
      1
    }
  }

  def toFunnelCount(list: List[PageView]): Int = {
    val sortList = list.sortWith((v1, v2) => v1.deep<v2.deep)
    var p = 0
    var q = 0
    while (q < sortList.size && p < pages.size){
      // 到达D了，本次漏斗结束--1层的漏斗也OK

      if(sortList(q).page.startsWith(pages.last) && p + 1 == pages.size){
        return p + 1
      }
      // 发现不连续了，直接跳出。
      if(q > 0 && sortList(q).deep != sortList(q - 1).deep + 1 ){
        return p + 1
      }
      // 在列表内如果下个页面不是page列表游标的。游标加1
      if(q+1 < sortList.size && sortList(q).page.startsWith(pages(p)) && !sortList(q+1).page.startsWith(pages(p))){
        p = p + 1
        // 也不是page游标的下一个游标，则漏斗结束
        if(!sortList(q+1).page.startsWith(pages(p))) {
          return p
        }
      }
      q = q + 1
    }
    p + 1
  }
}