package com.tgou.data.stanford.market.accurate.push.person.bean.agg

/**
  * Created by 李震 on 2017/11/20.
  */
case class OrderItemAgg (
                          push_task_id: Long,
                          member_id: Long,
                          order_id: Long,
                          total_amount: Double,
                          create_time: String,
                          pay_time: String,
                          pay_method: String,
                          is_shopping_cart: Boolean
                        )
