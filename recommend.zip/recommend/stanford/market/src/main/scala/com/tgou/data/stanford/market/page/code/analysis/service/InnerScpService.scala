package com.tgou.data.stanford.market.page.code.analysis.service

import java.time.LocalDate

import org.apache.spark.broadcast.Broadcast
import org.apache.spark.sql.{DataFrame, SparkSession}

object InnerScpService {



  def getMapBroadcast(spark: SparkSession) : Broadcast[Map[Int, (Long, Long)]] = {
    @volatile var mapBroadcast: Broadcast[Map[Int, (Long, Long)]] = null
    val pvSql =
      s"""
         | SELECT * FROM
         | (
         |   SELECT count(1) as pv, count(distinct m_ud) as uv,global FROM day_page_code_member group by global
         |   )UNION
         |  (
         |   SELECT count(1) as pv,count(distinct m_ud) as uv , 0 as global FROM day_page_code_member
         |  )
         |  UNION
         |  (
         |   SELECT count(1) as pv,count(distinct m_ud) as uv , 3 as global FROM day_page_code_member where yt = 1
         |  )
      """.stripMargin
    val tmpDf = spark.sql(pvSql)
    tmpDf.cache()
    val map = tmpDf.collect().map(row=>row.getInt(2)->(row.getLong(0),row.getLong(1))).toMap
    mapBroadcast = spark.sparkContext.broadcast[Map[Int, (Long, Long)]](map)
    mapBroadcast
  }

  def getScpInfo(spark: SparkSession, date: LocalDate, map:Map[Int, (Long, Long)]): DataFrame = {
    val innerTableSqlText =
      s"""
         | SELECT * FROM
         | (SELECT m_id as member_id,uuid,
         |  CASE 
         |    WHEN scp like '05.code.idCardSelect%' THEN '切换门店'
         |    WHEN scp like '05.code.idCardConpon%' or scp like '05.code.barcode.btn1%' THEN '我的优惠券'
         |    WHEN scp like '05.code.slider%' THEN '轮播'
         |    WHEN scp like '05.code.counters%' THEN '专柜推荐'
         |    WHEN scp like '05.code.ylike%' THEN '商品推荐'
         |    WHEN scp like '05.code.idCardDownload%' THEN '下载APP'
         |    WHEN scp like '05.code.barcode.btn2%' THEN '支付宝'
         |    WHEN scp like '05.code.barcode.btn3%' THEN '微信支付'
         |    ELSE '其他'
         |  END AS scp_type
         | FROM fm_scp where scp like '05.code.%'
         | ) WHERE scp_type != '其他'
       """.stripMargin
    val innerTableDf = spark.sql(innerTableSqlText)
    innerTableDf.cache()
    innerTableDf.createOrReplaceTempView("inner_table")

    val resultSql =
      s"""
        |  SELECT * FROM
        |   (
        |   SELECT c_pv,c_uv,scp_type,
        |   CASE WHEN scp_type in ('支付宝','微信支付')  THEN ${map(1)._1}
        |    WHEN scp_type = '下载APP' THEN ${map(2)._1}
        |    WHEN scp_type = '专柜推荐' THEN ${map(3)._1}
        |     ELSE ${map(0)._1} END as pv,
        |    CASE WHEN scp_type in ('支付宝','微信支付')  THEN ${map(1)._2}
        |    WHEN scp_type = '下载APP' THEN ${map(2)._2}
        |    WHEN scp_type = '专柜推荐' THEN ${map(3)._2}
        |     ELSE ${map(0)._2} END as uv,
        |     date FROM (
        |     SELECT count(1) as c_pv,count(distinct m_ud) as c_uv,scp_type,
        |       '$date' as date FROM
        |     (SELECT t2.m_ud,t1.scp_type
        |       FROM
        |         inner_table t1
        |       INNER JOIN day_member t2
        |       ON (t1.member_id = t2.m_ud or t1.uuid = t2.m_ud)
        |     )
        |     group by scp_type
        |     )
        |  )
        | UNION
        | (SELECT 0 as c_pv,count(distinct m_ud) as c_uv,'合计' as scp_type,${map(0)._1} as pv,${map(0)._2} as uv,'$date' as date FROM
        |  (SELECT t2.m_ud,t1.scp_type
        |       FROM
        |         inner_table t1
        |       INNER JOIN day_member t2
        |       ON (t1.member_id = t2.m_ud or t1.uuid = t2.m_ud)
        |     )
        |  )
      """.stripMargin
    spark.sql(resultSql)
  }
}
