package com.tgou.data.stanford.market.page.funnel.analysis

import org.joda.time.LocalDate
import com.google.inject.{Guice, Inject}
import com.tgou.data.stanford.market.core.MarketBootstrap
import com.tgou.data.stanford.market.page.funnel.analysis.service.FunnelService
import com.tgou.data.stanford.market.page.funnel.analysis.source.FunnelSource
import org.apache.spark.sql.{DataFrame, SparkSession}

object ApplicationV1 {
  def main(args: Array[String]): Unit = {
    MarketBootstrap(args).bootstrap(execute)
  }

  def execute(spark: SparkSession, appName: String, date: LocalDate): Unit = {
    val injector = Guice.createInjector(ApplicationModule(spark, appName, date))
    injector.getInstance(classOf[ApplicationV1]).run
  }
}
class ApplicationV1 @Inject()(spark: SparkSession, date: LocalDate) {
  @Inject
  var source: FunnelSource = _
  @Inject
  var service: FunnelService = _

  val path = "/data/market/funnel/"

  def run: Unit = {
    // step1.处理商品业态。
    val listingWithYtDf =  source.getListingWithYtDf
    listingWithYtDf.cache()
    listingWithYtDf.createOrReplaceTempView("listing_t")

    // step1.5 处理组合品的问题。
    val mallActivityProductToGroupDF = source.getMallActivityProductToGroupDF
    mallActivityProductToGroupDF.cache()
    mallActivityProductToGroupDF.createOrReplaceTempView("zuhe_t")

    // step2.商品详情页格式化BK，加业态。
    val ubaPageWithYtDf = source.getUbaPageWithYtDf
    ubaPageWithYtDf.cache()
    ubaPageWithYtDf.createOrReplaceTempView("listing_page_t")

    // step3.当日uba_page。
    val toDayUbaPageDf = source.getTodayUbaPageDf
    toDayUbaPageDf.cache()
    toDayUbaPageDf.createOrReplaceTempView("today_page_t")

    // funnel 1
    val funnelDf_1 = service.getFunnel_1
    saveJson(funnelDf_1,path+"funnel_1",date)
    // funnel 2
    val funnelDf_2 = service.getFunnel_2
    saveJson(funnelDf_2,path+"funnel_2",date)
    // funner 3
    val funnelDf_3 = service.getFunnel_3
    saveJson(funnelDf_3,path+"funnel_3",date)
  }
  def saveJson(dataFrame:DataFrame, path: String,date: LocalDate): Unit = {
    dataFrame.show(true)
    dataFrame.write.mode("overwrite").json(path+"/"+date.toString().replace("-","/"))
  }
}