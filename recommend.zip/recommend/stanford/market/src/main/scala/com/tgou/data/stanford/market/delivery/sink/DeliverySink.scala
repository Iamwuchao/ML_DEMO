package com.tgou.data.stanford.market.delivery.sink

import org.apache.spark.sql.DataFrame

/**
  * Created by 李震 on 2018/1/4.
  */
trait DeliverySink {

  def saveToCassandra(df: DataFrame): Unit

}
