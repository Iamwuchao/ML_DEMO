package com.tgou.data.stanford.market.cyclebuying.udf

import java.time.LocalDate

import com.tgou.data.stanford.market.cyclebuying.bean.ListingBrought
import com.tgou.data.stanford.market.cyclebuying.util.CyclingBuyUtil
import org.apache.spark.sql.Row
import org.apache.spark.sql.expressions.{MutableAggregationBuffer, UserDefinedAggregateFunction}
import org.apache.spark.sql.types._

/**
  * 面膜的回购周期。返回第一个购买的面膜的
  */

class FaceMaskCycle2UDAF(date: LocalDate) extends UserDefinedAggregateFunction{

  override def inputSchema: StructType = StructType(List(StructField("quantity", IntegerType),StructField("pay_time",DateType)))

  override def bufferSchema: StructType = StructType(StructField("values", MapType(StringType,IntegerType))::Nil)

  override def dataType: DataType = StringType

  override def deterministic: Boolean = true

  override def initialize(buffer: MutableAggregationBuffer): Unit = {
    buffer(0) = Map[String,Seq[Map[String,Int]]]()
  }

  override def update(buffer: MutableAggregationBuffer, input: Row): Unit = {
    var map = buffer.getAs[Map[String/*pay_time，同一天，算一次。不同天，算多次*/,Int/*量*/]](0)
    val key = input.getDate(1).toLocalDate.toString
    val newQuantity = map.getOrElse(key,0) + input.getInt(0)
    map = map + (key -> newQuantity)
    buffer(0) = map
  }

  override def merge(buffer1: MutableAggregationBuffer, buffer2: Row): Unit = {
    if(buffer2(0) != null){
      var map1 = buffer1.getAs[Map[String, Int]](0)
      val map2 = buffer2.getAs[Map[String, Int]](0)
      for(kv <- map2){
        val map1NewVal = kv._2 + map1.getOrElse(kv._1,0)
        map1 = map1 + (kv._1 -> map1NewVal)
      }
      buffer1(0) = map1
    }
  }

  override def evaluate(buffer: Row): Any = {
    if(buffer(0) != null){
      val map = buffer.getAs[Map[String, Int]](0)
      var isTrigger = false
      val list = map.map(kv => ListingBrought(LocalDate.parse(kv._1), kv._2)).toList
      val  mayTriggerDate = CyclingBuyUtil.getFaceMaskCyclingTrigger(list, date)
      mayTriggerDate.toString
    }else{
      ""
    }
  }

  def toMaybeInt(s:String):Int = {
    scala.util.Try(s.toInt).get
  }
}
