package com.tgou.data.stanford.market.cyclebuying.util

import java.time.LocalDate
import java.time.temporal.ChronoField.EPOCH_DAY

import com.tgou.data.stanford.market.cyclebuying.bean.ListingBrought

import scala.collection.mutable.ArrayBuffer

object CyclingBuyUtil {
  //暂时只有面膜。以后换了别的品类。
  val X = 5
  val Y = 6

  def getP(tDate: LocalDate): Double = {
    if(tDate.getMonthValue>11 || tDate.getMonthValue<6){
      3.5D
    }else{
      2.5D
    }
  }

  /**
    *
    * @param tDate 触发的日期
    * @param date 触发日期的Begin
    * @return
    */
  def dateBingo(tDate: LocalDate, date: LocalDate): Boolean = {
    if(tDate != null && tDate.isAfter(date.plusDays(1)) && tDate.isBefore(date.plusDays(9))){
      true
    }else{
      false
    }
  }

  def getFaceMaskCyclingTrigger(listingBroughtList: List[ListingBrought], date: LocalDate): LocalDate = {
    //如果是不合理的日期，则用返回一年后的时间
    //数量全用bigDecimal进行处理
    val longAfter = LocalDate.now().plusYears(1)
    if(listingBroughtList.isEmpty){
      longAfter
    }else if(listingBroughtList.size == 1){
      val listingBrought = listingBroughtList.head
      //第一次触发时间

      val normalTriggerDate = listingBrought.pay_time.plusDays((BigDecimal(listingBrought.quantity)/BigDecimal(6)*BigDecimal(getP(listingBrought.pay_time))).toInt).plusDays(-3)
      //第二次触发时间
      val nextTriggerDate = normalTriggerDate.plusDays((BigDecimal(listingBrought.quantity) / BigDecimal(6) * BigDecimal(getP(listingBrought.pay_time)) / BigDecimal(2)).toInt)
      if(dateBingo(normalTriggerDate, date)){
        normalTriggerDate
      }else if(dateBingo(nextTriggerDate, date)){
        nextTriggerDate
      }else{
        longAfter
      }
    }else if(listingBroughtList.size >= 2){
      var abWithoutError = new ArrayBuffer[BigDecimal]()
      //根据时间进行个排序
      val sortList = listingBroughtList.sortWith((l1,l2)=>l2.pay_time.isAfter(l1.pay_time))
      for(t<-1 until(sortList.size)){
        val diffDay = sortList(t).pay_time.getLong(EPOCH_DAY) - sortList(t-1).pay_time.getLong(EPOCH_DAY)
        val Pn = BigDecimal(diffDay * 6) / BigDecimal(sortList(t-1).quantity)
        if(Pn<= BigDecimal(X) * BigDecimal(getP(sortList(t).pay_time)) && Pn >= BigDecimal(getP(sortList(t).pay_time))/ BigDecimal(Y) ){
          abWithoutError+=(Pn)
        }
      }
      val lastListingBrought = sortList.last
      if(abWithoutError.isEmpty){
        lastListingBrought.pay_time.plusDays((BigDecimal(lastListingBrought.quantity) / 6 * getP(lastListingBrought.pay_time)).toInt).plusDays(-3)
      }else{
        // double 丢精度的问题。全部改bigInt？
        lastListingBrought.pay_time.plusDays((BigDecimal(lastListingBrought.quantity) *  abWithoutError.toList.sum / (abWithoutError.size * 6)).toInt).plusDays(-3)
      }
    }else {
      longAfter
    }
  }


  def main(args: Array[String]): Unit = {
    val listingBroughtList = List(
      ListingBrought(LocalDate.parse("2018-01-25"),360),
      ListingBrought(LocalDate.parse("2017-12-07"),180)
//      ListingBrought(LocalDate.parse("2017-11-16"),60)
//      ListingBrought(LocalDate.parse("2017-11-24"),120),
    )
    println(getFaceMaskCyclingTrigger(listingBroughtList,LocalDate.now()))
  }
}
