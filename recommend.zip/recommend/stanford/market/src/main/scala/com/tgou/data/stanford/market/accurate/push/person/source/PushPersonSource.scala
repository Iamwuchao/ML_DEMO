package com.tgou.data.stanford.market.accurate.push.person.source

import org.apache.spark.sql.DataFrame

/**
  * Created by 李震 on 2017/11/20.
  */
trait PushPersonSource {

  /**
    * 推送人员信息
    *
    * @return
    *
    * 字段：
    *
    * - push_task_id  推送ID
    * - push_time  推送时间
    * - start_time  精准活动开始时间
    * - end_time  精准活动结束时间
    * - subject_code  推送内容编码 502 券 503 活动
    * - object_id 推送内容ID
    * - object_type 推送内容类型
    * - phone  手机号码
    * - is_received  是否接收成功
    *
    * */
  def pushPersonDF: DataFrame


  /**
    * 推送会员信息
    *
    * @return
    *
    * 字段：
    *
    * - push_task_id  推送 ID
    * - push_time  推送时间
    * - start_time  精准活动开始时间
    * - end_time  精准活动结束时间
    * - subject_code  推送内容编码 502 券 503 活动
    * - object_id  推送内容ID
    * - object_type  推送内容类型
    * - member_id  会员 ID
    * - register_time  注册时间
    *
    * */
  def pushMemberDF: DataFrame


  /**
    * 处理人群
    *
    * @return
    *
    * 字段：
    *
    * - push_task_id  推送 ID
    * - push_time  推送时间
    * - start_time  精准活动开始时间
    * - end_time  精准活动结束时间
    * - subject_code  推送内容编码 502 券 503 活动
    * - object_id  推送内容ID
    * - object_type  推送内容类型
    * - group  客户群 new 新客户 old 老客户
    * - is_first_online  是否第一次线上交易 0 否 1 是
    *
    * */
  def pushGroupMemberDF: DataFrame

}
