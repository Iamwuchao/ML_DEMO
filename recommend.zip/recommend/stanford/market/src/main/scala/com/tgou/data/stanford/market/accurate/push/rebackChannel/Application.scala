package com.tgou.data.stanford.market.accurate.push.rebackChannel

import com.tgou.data.stanford.market.core.{MarketBootstrap, MarketSink}
import org.apache.spark.sql.functions.col
import org.apache.spark.sql.SparkSession
import org.joda.time.LocalDate

/**
  * Created by 张少锐 on 2017/11/10.
  */
object Application {
  def main(args: Array[String]): Unit = {
    MarketBootstrap(args).bootstrap(execute)
  }

  def execute(spark: SparkSession, appName: String, date: LocalDate): Unit = {

    // 保存到hdfs上
    val persistDay = RebackChannelDayModule.getRebackChannelDay(spark,date)
    MarketSink.saveAsCSV(persistDay,Seq(col("push_id"),col("reback_channel")),date,"/data/market/accurate_push_reback_channel_d_t")

    val persistKDay = RebackChannelKDayModule.getRebackChannelKDay(spark,date)
    MarketSink.saveAsCSV(persistKDay,Seq(col("push_id"),col("reback_channel")),date,"/data/market/accurate_push_reback_channel_k_t")
  }
}
