package com.tgou.data.stanford.market.accurate.push.person.source

import com.google.inject.Inject
import com.tgou.data.stanford.market.accurate.push.{Constants, OrderSource}
import com.tgou.data.stanford.market.accurate.push.bean.ShopCartLogODS
import com.tgou.data.stanford.market.core.MarketSource
import com.tgou.data.stanford.market.core.utils.BeanUtils
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.joda.time.LocalDate

/**
  * Created by 李震 on 2017/11/20.
  */
class TgOrderSourceImpl @Inject()(spark: SparkSession, date: LocalDate) extends TgOrderSource {

  private val orderSource: OrderSource = OrderSource(spark, date)

  val orderDF = orderSource.onlineOrderDF

  val orderProductDF = orderSource.onlineOrderProductDF

  val orderPreferentialDF = orderSource.onlineOrderPreferentialDF

  lazy val shoppingCartLogDF: DataFrame = {
    MarketSource.getDurationDF(
      spark, "/tiangou/tgouorder/shop_cart_log",
      date.minusDays(Constants.STATICS_DURATION - 1),
      date,
      BeanUtils.getSchemaFromBean[ShopCartLogODS]
    )
  }

}
