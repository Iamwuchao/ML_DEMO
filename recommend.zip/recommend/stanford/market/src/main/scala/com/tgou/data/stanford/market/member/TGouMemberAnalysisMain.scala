package com.tgou.data.stanford.market.member

import java.time.LocalDate
import java.util.Properties

import com.tgou.data.stanford.market.member.service.{MemberAnalysisCalculators, MemberRetentionCalculator, MemberTransCalculator}
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.sql.execution.datasources.jdbc.{JDBCOptions, JdbcUtils}
import org.apache.spark.storage.StorageLevel

/**
  * 统计平台活跃&新增
  */
object TGouMemberAnalysisMain {
  def main(args: Array[String]): Unit = {
    JdbcBootstrap(args).bootstrap(execute)
  }

  def execute(spark: SparkSession,appName: String, date: LocalDate, jdbcConfig: Properties): Unit = {
    val overview_t = "tgou_member_overview"
    val origin_t = "tgou_member_origin"
    val global_t = "tgou_member_global"
    val goal_t = "tgou_member_goal"
    val life_cycle_t = "tgou_member_life_cycle"
    val retention_t = "tgou_member_retention"
    val rfModel_t = "tgou_member_rf"
    //step 1。初始化tempView
    MemberAnalysisCalculators.init(spark, date)
    val overviewResult = MemberAnalysisCalculators.calOverview(spark, date)
    println(overviewResult)
    //建立个jdbc client。
    var jdbcConfigMap = Map[String,String]()
    jdbcConfigMap+=("driver"->jdbcConfig.getProperty("driver"))
    jdbcConfigMap+=("url"->jdbcConfig.getProperty("url"))
    jdbcConfigMap+=("user"->jdbcConfig.getProperty("user"))
    jdbcConfigMap+=("password"->jdbcConfig.getProperty("password"))
    jdbcConfigMap+=("dbtable"->overview_t)
    println(jdbcConfigMap)
    val conn = JdbcUtils.createConnectionFactory(new JDBCOptions(jdbcConfigMap)).apply
    try{
      //clear olds
      val list = Seq(overview_t,origin_t,global_t,goal_t,life_cycle_t,retention_t,rfModel_t)
      for(t <- list){
        conn.prepareStatement(
          s"""
             |delete from $t where date = '$date'
        """.stripMargin).executeUpdate
      }
      //insert overview
      conn.prepareStatement(
        s"""
          | INSERT INTO `standford`.`$overview_t`
          |  (`total_members_count`,`day_active`,`day_new_register`,`day_guest`,`day_brought`,`day_trans`,`week_active`,
          |       `week_guest`,`week_brought`,`week_trans`,`month_active`,`month_guest`,`month_brought`,`month_trans`,`date`)
          |  VALUES
          |   (
          |   ${overviewResult.total_members_count},
          |   ${overviewResult.day_active},
          |   ${overviewResult.day_new_register},
          |   ${overviewResult.day_guest},
          |   ${overviewResult.day_brought},
          |   ${overviewResult.day_trans},
          |   ${if(overviewResult.week_active == 0) null else overviewResult.week_active},
          |   ${if(overviewResult.week_guest == 0) null else overviewResult.week_guest},
          |   ${if(overviewResult.week_brought == 0) null else overviewResult.week_brought},
          |   ${if(overviewResult.week_trans == 0) null else overviewResult.week_trans},
          |   ${if(overviewResult.month_active == 0) null else overviewResult.month_active},
          |   ${if(overviewResult.month_guest == 0) null else overviewResult.month_guest},
          |   ${if(overviewResult.month_brought == 0) null else overviewResult.month_brought},
          |   ${if(overviewResult.month_trans == 0) null else overviewResult.month_trans},
          |   '${overviewResult.date}'
          |   )
        """.stripMargin).executeUpdate
      //delete
    }finally conn.close()
    //客户端
    val globalDF = MemberAnalysisCalculators.calGlobalDetails(spark, date).select("global","global_count","new_register","date")
    save(globalDF,jdbcConfig,global_t)
    //来源
    val originDF = MemberAnalysisCalculators.calOriginDetails(spark, date).select("jr","origin_count","new_register","date")
    save(originDF,jdbcConfig,origin_t)
    //目的
    val goalDF = MemberAnalysisCalculators.calGoalDetails(spark, date).select("do_ele_ticket","do_sao_ma","do_oversea","do_sign_in","do_search","do_store","do_market","do_item","do_park","do_wifi","do_others","new_register","date")
    save(goalDF,jdbcConfig,goal_t)
    //生命周期
    val lifeCycleDF = MemberTransCalculator.calLifeCycle(spark, date).select("life_cycle","life_cycle_count","date")
    save(lifeCycleDF,jdbcConfig,life_cycle_t)
    //retention...
    val retentionResult = MemberRetentionCalculator.calRetention(spark, date).select("date","member_count","retention_type","retention_count")
    save(retentionResult,jdbcConfig,retention_t)
    //rf 模型
    val rfModelResult = MemberTransCalculator.calRfModel(spark, date).select("rf","rf_count","rf_amount","date")
    save(rfModelResult,jdbcConfig,rfModel_t)
  }

  def save(df: DataFrame, jdbcConfig: Properties, table: String): Unit = {
    df.cache().persist(StorageLevel.MEMORY_AND_DISK_SER_2)
    df.show()
    jdbcConfig.setProperty("table",table)
    df.write.mode("append").jdbc(jdbcConfig.getProperty("url"), jdbcConfig.getProperty("table"), jdbcConfig)
  }
}
