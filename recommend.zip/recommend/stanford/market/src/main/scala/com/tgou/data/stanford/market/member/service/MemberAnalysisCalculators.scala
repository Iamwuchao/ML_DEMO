package com.tgou.data.stanford.market.member.service

import java.time.{DayOfWeek, LocalDate}

import com.tgou.data.stanford.market.member.Bean.{DateInterval, OverviewResult}
import com.tgou.data.stanford.market.member.utils.DateIntervalUtil
import org.apache.spark.sql.{DataFrame, SparkSession}



object MemberAnalysisCalculators {


  def getMemberRegisterSql(date: LocalDate, newRegister: Boolean): String = {
    val yesterdayDate = LocalDate.now().plusDays(-1)
    if(date == null){
      s"""
        | SELECT member_id FROM dw.member where his_time = '$yesterdayDate'
      """.stripMargin
    }else if(newRegister){
      s"""
         | SELECT member_id FROM dw.member where his_time = '$yesterdayDate' and register_time >= '$date' and register_time < '${date.plusDays(1)}'
      """.stripMargin
    }else{
      s"""
        | SELECT member_id FROM dw.member where his_time = '$yesterdayDate' and register_time < '${date.plusDays(1)}'
      """.stripMargin
    }
  }
  def init(spark: SparkSession,date: LocalDate): Unit = {
    val guestFirstSessionSql =
      s"""
         | SELECT t1.uuid as member_ud,2 as m_type,min(t1.session_id) as session_id FROM
         |    (SELECT time,uuid,session_id FROM dw.uba_page where his_time = '$date') t1
         | INNER JOIN
         |    (SELECT MIN(time) as time,uuid FROM dw.uba_page where his_time = '$date' group by uuid having max(member_id) = '') t2
         |  ON t1.uuid = t2.uuid
         |  AND t1.time = t2.time
         | GROUP BY t1.uuid
       """.stripMargin

    val memberFirstSessionSql =
      s"""
        |  SELECT member_id as member_ud,1 as m_type ,min(session_id) as session_id FROM (
        |   SELECT t1.session_id,t1.member_id FROM
        |   (SELECT time,member_id,session_id FROM dw.uba_page where his_time = '$date') t1
        |     INNER JOIN
        |   (SELECT MIN(time) as time,member_id FROM dw.uba_page where his_time = '$date' GROUP BY member_id) t2
        |     ON t1.member_id = t2.member_id
        |     AND t1.time = t2.time
        | ) t
        | GROUP BY member_id
      """.stripMargin

    val firstSessionSql =
      s"""
        |  ($guestFirstSessionSql) UNION ($memberFirstSessionSql)
      """.stripMargin

    spark.udf.register("to_member_ud",(member_id: String, uuid: String) => {if(member_id.isEmpty) uuid else member_id}: String)
    spark.udf.register("get_member_type",(member_id: String, new_member_id: String) => {if(member_id.isEmpty) -1 else if(new_member_id != null) 1 else 0}: Int)

    val firstSessionDf = spark.sql(
      s"""
        |SELECT
        | to_member_ud(t1.member_id,t1.uuid) as member_ud,
        | t1.member_id,
        | CASE
        |     WHEN t1.jr like 'wt.%' THEN '公众号菜单'
        |     WHEN t1.jr like 'tg.push.wt.%' or t1.jr like 'tg.push.bat.%' or t1.jr like 'tg.push.fzwz.%.' THEN '公众号推送'
        |     WHEN t1.jr like 'tg.push.task.%' THEN 'APP推送'
        |     WHEN t1.jr = '' and global in ('ios','android') THEN 'APP'
        |     WHEN t1.jr like 'kd.%' or t1.jr like 'erp.%' or t1.jr like 'sl.%' THEN '二维码'
        |     WHEN t1.jr like 'wifi.%' THEN 'WIFI'
        |     ELSE '其他' END AS jr,
        | t1.time,
        | t1.page,
        | get_member_type(t1.member_id,t3.member_id) as new_register,
        | scp_table_yt as source,
        | bk
        | FROM dw.uba_page t1
        | INNER JOIN ($firstSessionSql) t2
        | ON t1.session_id = t2.session_id
        | AND (t1.member_id = t2.member_ud or t1.uuid = t2.member_ud)
        | LEFT JOIN (${getMemberRegisterSql(date,true)}) t3
        | ON t1.member_id = t3.member_id
        | WHERE t1.his_time = '$date'
      """.stripMargin)
    firstSessionDf.cache()
    firstSessionDf.createOrReplaceTempView("first_uba")
  }



  /**
    * 总觉得这样传参数，不够优雅。咋办。
    */
  def calOverview(spark: SparkSession, date: LocalDate): OverviewResult = {
    val dayInterval = DateIntervalUtil.dateValidate(date,"day")
    val weekInterval = DateIntervalUtil.dateValidate(date,"week")
    val monthInterval = DateIntervalUtil.dateValidate(date,"month")
    //总会员数
    val totalMembersCount = spark.sql(
      s"""
         | SELECT 1 FROM (${getMemberRegisterSql(date,false)})t
      """.stripMargin).count()
    //日活跃
    var dayActive: Long = 0L
    //日新增
    var dayNewRegister: Long = 0L
    //日访客
    var dayGuest: Long = 0L
    var dayBrought: Long = 0L
    var dayTrans: Long = 0L
    if(dayInterval.isValidate){
      //日新增
      dayNewRegister = spark.sql(
        s"""
          | SELECT 1 FROM (${getMemberRegisterSql(date,true)})t
        """.stripMargin).count()
      //日访客（未登陆的）
      dayGuest = calGuest(spark, dayInterval)
      //日活跃
      dayActive = calCount(spark, dayInterval)
      dayBrought = MemberTransCalculator.calBrought(spark, dayInterval)
      dayTrans = MemberTransCalculator.calTrans(spark, dayInterval)
    }
    //周活跃
    var weekActive: Long = 0L
    var weekGuest: Long = 0L
    var weekBrought: Long = 0L
    var weekTrans: Long = 0L
    if(weekInterval.isValidate){
      weekActive = calCount(spark, weekInterval)
      weekBrought = MemberTransCalculator.calBrought(spark, weekInterval)
      weekGuest = calGuest(spark, weekInterval)
      weekTrans = MemberTransCalculator.calTrans(spark, weekInterval)
    }
    //月活跃
    var monthActive: Long = 0L
    var monthGuest: Long = 0L
    var monthBrought: Long = 0L
    var monthTrans: Long = 0L
    if(monthInterval.isValidate){
      monthActive = calCount(spark, monthInterval)
      monthBrought = MemberTransCalculator.calBrought(spark, monthInterval)
      monthGuest = calGuest(spark, monthInterval)
      monthTrans = MemberTransCalculator.calTrans(spark, monthInterval)
    }
    OverviewResult(totalMembersCount, dayActive, dayNewRegister, dayGuest, dayBrought, dayTrans, weekActive, weekGuest, weekBrought, weekTrans, monthActive, monthGuest, monthBrought, monthTrans, date)
  }


  def calCount(spark: SparkSession, dateInterval: DateInterval): Long = {
    val count = spark.sql(
      s"""
         | SELECT DISTINCT member_id FROM dw.uba_page WHERE his_time >= '${dateInterval.dateBegin}' and his_time < '${dateInterval.dateEnd}'
         | AND member_id != ''
        """.stripMargin).count()
    count
  }

  def calGuest(spark: SparkSession, dateInterval: DateInterval): Long = {
    val count = spark.sql(
      s"""
         | SELECT 1 FROM dw.uba_page where  his_time >= '${dateInterval.dateBegin}' and his_time < '${dateInterval.dateEnd}'
         | group by uuid having max(member_id) is  null or max(member_id) = ''
        """.stripMargin).count()
    count
  }

  def calGlobalDetails(spark: SparkSession, date: LocalDate): DataFrame = {
    /** 客户端 ******************************************************************/
    val sQLText =
      s"""
        |  SELECT count(distinct member_id) as global_count,global,new_register,'$date' as date
        |   FROM(
        |   SELECT t1.member_id, FIRST_VALUE(global) as global, FIRST_VALUE(new_register) as new_register
        |     FROM
        |   (SELECT
        |     t1.member_id,
        |     CASE WHEN t1.global not in ('ios','android','wechat') THEN 'others'
        |         ELSE t1.global END AS global,
        |     CASE WHEN t3.member_id is not null THEN 1
        |         ELSE 0 END AS new_register
        |   FROM dw.uba_page t1
        |   LEFT JOIN (${getMemberRegisterSql(date, true)}) t3
        |   ON t1.member_id = t3.member_id
        |   where t1.his_time = '$date' and t1.member_id != '')
        |   GROUP bY t1.member_id
        |   ) t
        |   GROUP BY global,new_register
      """.stripMargin
    val globalDf = spark.sql(sQLText)

    val guestSqlText =
      s"""
         | SELECT count(distinct uuid) as global_count,
         |  global,
         |  -1 as new_register,
         |  '$date' as date
         | FROM (SELECT  uuid,
         |          CASE
         |            WHEN FIRST_VALUE(global) not in ('ios','android','wechat') THEN 'others'
         |            ELSE FIRST_VALUE(global)
         |            END AS global
         |          FROM dw.uba_page where his_time = '$date'
         |        group by uuid having max(member_id) = '')
         | GROUP by global
       """.stripMargin
    val guestGlobalDf = spark.sql(guestSqlText)

    globalDf.union(guestGlobalDf)
  }

  def calOriginDetails(spark: SparkSession, date: LocalDate): DataFrame = {
    //目的可以有多个。来源只能有一个。
    /** 来源 ******************************************************************/
    val sQLText =
      s"""
        | SELECT count(distinct t1.member_ud) as origin_count,t1.jr,t1.new_register,'$date' as date
        |  FROM (
        |   SELECT t1.member_ud,FIRST_VALUE(t1.jr) as jr,FIRST_VALUE(t1.new_register) as new_register
        |     FROM
        |     first_uba t1
        |     INNER JOIN
        |     (select min(time) as m_time ,member_ud from first_uba group by member_ud) t2
        |     ON t1.member_ud = t2.member_ud
        |     AND t1.time = t2.m_time
        |     GROUP BY t1.member_ud
        |  ) t1
        | GROUP BY t1.jr,t1.new_register
      """.stripMargin
    val originDf = spark.sql(sQLText)
    originDf
  }

  def calGoalDetails(spark: SparkSession, date: LocalDate): DataFrame = {
    /** 目的 ******************************************************************/
    // max time往后推了10分钟。因为扫码可能最后个页面直接跳出。
    // 且，两个session直接间隔会间隔10分钟么？
    val firstSessionTimeIntervalDf = spark.sql(
      """
        | SELECT
        |  from_unixtime((unix_timestamp(MAX(time),'yyyy-MM-dd HH:mm:ss') + 60*10),'yyyy-MM-dd HH:mm:ss') as max_time,
        |  from_unixtime((unix_timestamp(MIN(time),'yyyy-MM-dd HH:mm:ss') - 60*10),'yyyy-MM-dd HH:mm:ss') as min_time,
        |  MAX(new_register) as new_register,
        |  member_ud
        | FROM first_uba
        | GROUP BY member_ud
      """.stripMargin)
    firstSessionTimeIntervalDf.cache()
    firstSessionTimeIntervalDf.createOrReplaceTempView("time_interval")
    spark.sql(
      """
        | SELECT count(1),new_register from time_interval group by new_register
      """.stripMargin).show()
    val saomaSql =
      s"""
        | SELECT mi.member_id as member_ud,min(ms.time) as time FROM
        |(select cid,
        | from_unixtime(substr(jysj,0,10),'yyyy-MM-dd HH:mm:ss') as time
        | FROM dw.pos_zz
        | WHERE his_time = '$date'
        | AND thyy in ('03', '04', '05', '06', '07', '09') and cid is not null and jyje > 0
        | )ms
        | inner join (select member_id,cid from dw.card_bind where his_time = '$date') mi
        | ON ms.cid = mi.cid
        | GROUP BY mi.member_id
      """.stripMargin

    val saoma2Sql =
      """
        | SELECT distinct member_id as member_ud
        | FROM first_uba
        | WHERE page = '05.code'
      """.stripMargin

    val eleTicketSql =
      s"""
        | SELECT member_id as member_ud,
        |     min(create_time) as time
        |   FROM dw.order_information
        |   WHERE his_time = '$date'
        |    and order_source = '1'
        |    and receive_method in ( '00','01')
        |    and pay_method != '000'
        |    and order_type = '0'
        |    and to_date(ship_time)  =  to_date(pay_time)
        |    and create_time >= '$date' and create_time < '${date.plusDays(1)}'
        |  GROUP BY member_id
      """.stripMargin

    //跨境包括三方面
    //1浏览过普通跨境页
    //2浏览的品是跨境的
    //3下的订单是跨境的
    val overseaSql =
      s"""
        |
        | SELECT distinct member_ud FROM (
        | (SELECT member_ud FROM first_uba where source = '4')
        |  UNION
        | ( SELECT member_ud FROM
        |   (SELECT member_ud,subString(bk,6) as listing_id FROM first_uba where bk != '' and bk like 'item-%') t1
        |   INNER JOIN
        |   (SELECT listing_id,source,store_id FROM dw.listing where his_time = '$date' and source = '4') t2
        |     ON t1.listing_id = t2.listing_id
        |   INNER JOIN (SELECT id FROM dw.store where his_time = '$date' AND is_international = 1 and yt = '4') t3
        |   ON t2.store_id = t3.id
        |    )
        |  UNION
        |  (SELECT t1.member_id as member_ud
        |     FROM dw.order_information t1
        |     INNER JOIN (SELECT id FROM dw.store where his_time = '$date' AND is_international = 1 and yt = '4') t2
        |     ON t1.store_id = t2.id
        |     INNER JOIN time_interval t3
        |     ON t3.member_ud = t1.member_id
        |     AND t1.create_time >= t3.min_time
        |     AND t1.create_time <= t3.max_time
        |     where t1.his_time = '$date'
        |     and t1.create_time >= '$date' and t1.create_time < '${date.plusDays(1)}'
        |     and t1.order_source = '4'
        |     )
        | ) t
      """.stripMargin
    //二期新加，统计签到、搜索、百货购物、超市购物、内容（发现、是一宿）、停车缴费。
    val signInSql =
      s"""
         | SELECT distinct member_ud  FROM first_uba
         | WHERE page in ('05.tgsign','05.forcpn','05.sign')
       """.stripMargin

    val searchSql =
      s"""
        | SELECT distinct member_ud FROM first_uba
        | WHERE page in ('07.searchsp','07.searchresult','07.searchovse','07.searchstore','07.search','07.class','07.dsrlt','07.asrlt','07.ddsearch') or page like '07.brand%'
      """.stripMargin

    val storeSql =
      s"""
        | SELECT distinct member_ud FROM
        | (SELECT member_ud FROM
        |   (SELECT member_ud,subString(bk,6) as listing_id FROM first_uba where bk != '' and bk like 'item-%') t1
        |   INNER JOIN
        |   (SELECT listing_id,source,store_id FROM dw.listing where his_time = '$date' and source = '1') t2
        |     ON t1.listing_id = t2.listing_id
        |   INNER JOIN (SELECT id FROM dw.store where his_time = '$date' AND is_international = 0 and yt = '1') t3
        |   ON t2.store_id = t3.id)
        | UNION
        | (SELECT distinct member_ud FROM first_uba
        |   WHERE page in ('02.dd','02.sdact','02.csign','02.guide','02.classl') or page like '%02.sd%')
      """.stripMargin

    val marketSql =
      s"""
        | SELECT distinct member_ud FROM
        | (SELECT member_ud FROM
        |   (SELECT member_ud,subString(bk,6) as listing_id FROM first_uba where bk != '' and bk like 'item-%') t1
        |   INNER JOIN
        |   (SELECT listing_id,source,store_id FROM dw.listing where his_time = '$date' and source = '2') t2
        |     ON t1.listing_id = t2.listing_id
        |   INNER JOIN (SELECT id FROM dw.store where his_time = '$date' AND is_international = 0 and yt = '2') t3
        |   ON t2.store_id = t3.id
        |    )
        |  UNION
        | (SELECT distinct member_ud FROM first_uba
        | WHERE page in ('08.smc','08.agio','08.smg','08.addgoods')
        | )
      """.stripMargin

    val itemSql =
      s"""
        | SELECT distinct member_ud FROM first_uba
        | WHERE page in ('01.fx','01.myfind','01.hisfind','01.like','01.pfind') or page like '0301.album%' or page like '01.place.find%' or page like '0301%'
      """.stripMargin

    val parkSql =
      s"""
         | SELECT distinct member_ud FROM first_uba
         | WHERE page in ('05.park','05.addcar','05.carma','05.parkcou','05.parkaid')
       """.stripMargin
    val wifiSql =
      s"""
         | SELECT distinct member_ud FROM first_uba
         | WHERE JR = 'WIFI'
       """.stripMargin

    val goalSql =
      s"""
        | SELECT ti.member_ud,
        |  CASE WHEN et.member_ud is not null THEN 1 ELSE 0 END AS do_ele_ticket,
        |  CASE WHEN sm.member_ud is not null or sm2.member_ud is not null THEN 1 ELSE 0 END AS do_sao_ma,
        |  CASE WHEN os.member_ud is not null THEN 1 ELSE 0 END AS do_oversea,
        |  CASE WHEN sign.member_ud is not null THEN 1 ELSE 0 END AS do_sign_in,
        |  CASE WHEN search.member_ud is not null THEN 1 ELSE 0 END AS do_search,
        |  CASE WHEN st.member_ud is not null THEN 1 ELSE 0 END AS do_store,
        |  CASE WHEN market.member_ud is not null THEN 1 ELSE 0 END AS do_market,
        |  CASE WHEN item.member_ud is not null THEN 1 ELSE 0 END AS do_item,
        |  CASE WHEN park.member_ud is not null THEN 1 ELSE 0 END AS do_park,
        |  CASE WHEN wifi.member_ud is not null THEN 1 ELSE 0 END AS do_wifi,
        |  CASE WHEN sm.member_ud is null and os.member_ud is null and et.member_ud is null and sm2.member_ud is null
        |     and sign.member_ud is null and search.member_ud is null and st.member_ud is null and market.member_ud is null
        |     and item.member_ud is null and park.member_ud is null and wifi.member_ud is null
        |   THEN 1 ELSE 0 END AS do_others,
        |  ti.new_register
        |  FROM time_interval ti
        |  LEFT JOIN ($eleTicketSql) et
        |   ON ti.member_ud = et.member_ud
        |    AND et.time >= ti.min_time
        |    AND et.time <= ti.max_time
        |  LEFT JOIN ($saomaSql) sm
        |   ON ti.member_ud = sm.member_ud
        |    AND sm.time >= ti.min_time
        |    AND sm.time <= ti.max_time
        |  LEFT JOIN ($saoma2Sql) sm2
        |    ON ti.member_ud = sm2.member_ud
        |  LEFT JOIN ($overseaSql) os
        |    ON ti.member_ud = os.member_ud
        |  LEFT JOIN ($signInSql) sign
        |    ON ti.member_ud = sign.member_ud
        |  LEFT JOIN ($searchSql) search
        |    ON ti.member_ud = search.member_ud
        |  LEFT JOIN ($storeSql) st
        |    ON ti.member_ud = st.member_ud
        |  LEFT JOIN ($marketSql) market
        |    ON ti.member_ud = market.member_ud
        |  LEFT JOIN ($itemSql) item
        |    ON ti.member_ud = item.member_ud
        |  LEFT JOIN ($parkSql) park
        |    ON ti.member_ud = park.member_ud
        |  LEFT JOIN ($wifiSql) wifi
        |    ON ti.member_ud = wifi.member_ud
      """.stripMargin



    val sqlText =
      s"""
        | SELECT new_register,
        |   sum(do_ele_ticket) as do_ele_ticket,
        |   sum(do_sao_ma) as do_sao_ma,
        |   sum(do_oversea) as do_oversea,
        |   sum(do_sign_in) as do_sign_in,
        |   sum(do_search) as do_search,
        |   sum(do_store) as do_store,
        |   sum(do_market) as do_market,
        |   sum(do_item) as do_item,
        |   sum(do_park) as do_park,
        |   sum(do_wifi) as do_wifi,
        |   sum(do_others) as do_others,
        |   '$date' as date
        |  FROM
        | (
        |   select member_ud,
        |   max(do_ele_ticket) as do_ele_ticket,
        |   max(do_sao_ma) as do_sao_ma,
        |   max(do_oversea) as do_oversea,
        |   max(do_sign_in) as do_sign_in,
        |   max(do_search) as do_search,
        |   max(do_store) as do_store,
        |   max(do_market) as do_market,
        |   max(do_item) as do_item,
        |   max(do_park) as do_park,
        |   max(do_wifi) as do_wifi,
        |   max(do_others) as do_others,
        |   max(new_register) as new_register
        |   from ($goalSql) t
        |   GROUP BY member_ud
        | ) GROUP BY new_register
      """.stripMargin
    val goalDf = spark.sql(sqlText)
    goalDf
  }
}
