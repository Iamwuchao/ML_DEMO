package com.tgou.data.stanford.market.cyclebuying.bean

case class ProductProperty (
                             id: Long,
                             create_time: String,
                             fk_property_id: Int,
                             fk_property_value_id: Int,
                             fk_product_id: Long,
                             sort_order: Int,
                             modify_time: String
                           ){}
