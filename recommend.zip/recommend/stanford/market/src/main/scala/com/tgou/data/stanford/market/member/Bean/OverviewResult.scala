package com.tgou.data.stanford.market.member.Bean

import java.time.LocalDate

case class OverviewResult(
                           total_members_count: Long,
                           day_active: Long,
                           day_new_register: Long,
                           day_guest: Long,
                           day_brought: Long,
                           day_trans: Long,
                           week_active: Long,
                           week_guest: Long,
                           week_brought: Long,
                           week_trans: Long,
                           month_active: Long,
                           month_guest: Long,
                           month_brought: Long,
                           month_trans: Long,
                           date: LocalDate
                         ) {
}
