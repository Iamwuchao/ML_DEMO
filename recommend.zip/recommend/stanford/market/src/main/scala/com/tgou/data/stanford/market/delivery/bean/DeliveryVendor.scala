package com.tgou.data.stanford.market.delivery.bean

/**
  * Created by 李震 on 2018/1/4.
  */
case class DeliveryVendor (
                            id: Long,
                            version: Int,
                            name: String,
                            code: String,
                            url: String,
                            store_id: Long,
                            full_name: String,
                            payee_bank: String,
                            bank_account: String,
                            contact_name: String,
                            contact_tel: String,
                            comment: String,
                            modify_time: String,
                            vendor_tag: Int,
                            is_elec_delivery_sheet: Int,
                            code_to_kdn: String
                          )
