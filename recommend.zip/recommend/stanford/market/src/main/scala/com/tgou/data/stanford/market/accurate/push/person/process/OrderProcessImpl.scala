package com.tgou.data.stanford.market.accurate.push.person.process

import com.google.inject.Inject
import com.tgou.data.stanford.market.accurate.push.person.bean.agg.{OrderAgg, OrderItemAgg}
import com.tgou.data.stanford.market.accurate.push.person.bean.attr.OrderItemAttr
import com.tgou.data.stanford.market.accurate.push.person.source.{PushPersonSource, TgOrderSource}
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.joda.time.LocalDate

/**
  * Created by 李震 on 2017/11/14.
  */
class OrderProcessImpl @Inject()(spark: SparkSession, date: LocalDate) extends OrderProcess {

  @Inject
  var pushPersonSource: PushPersonSource = _

  @Inject
  var tgOrderSource: TgOrderSource = _


  lazy val shoppingCartDF = initShoppingCartDF()


  /**
    * 处理订单
    *
    * @return
    *
    * - push_task_id 推送 ID
    * - member_id 会员 ID
    * - is_buy_now 是否立即购买
    * - is_buy_now_pay 是否立即购买并支付
    * - is_shopping_cart 是否收藏或加入购物车
    * - is_shopping_cart_create 是否收藏或加入购物车并下单
    * - is_shopping_cart_pay 是否收藏或加入购物车并支付
    * - is_order_create 是否下单
    * - first_order_create_time 首次订单创建时间
    * - is_order_pay 是否支付
    * - order_pay_amount 支付金额
    * - first_order_pay_time 首次订单支付时间
    * - is_order_only_create 订单仅支付
    *
    * */
  def processOrderDF: DataFrame = {
    import spark.implicits._

    pushPersonSource.pushMemberDF.createOrReplaceTempView("push_member")
    tgOrderSource.orderProductDF.createOrReplaceTempView("online_order_product")
    tgOrderSource.shoppingCartLogDF.createOrReplaceTempView("shop_cart_log")

    this.shoppingCartDF.createOrReplaceTempView("shopping_cart")

    spark.sql(
      """
        |select
        |    pm.push_task_id,
        |    pm.member_id,
        |    pm.push_time,
        |    oop.order_id,
        |    cast(oop.total_amount as double) as total_amount,
        |    oop.create_time,
        |    oop.pay_time,
        |    oop.pay_method,
        |    sc.shopping_cart_time
        |from online_order_product oop
        |join push_member pm
        |on oop.member_id = pm.member_id
        |and oop.create_time > pm.push_time
        |left join shopping_cart sc
        |on sc.push_task_id = pm.push_task_id
        |and sc.member_id = pm.member_id
        |and sc.item_id = oop.item_id
      """.stripMargin).as[OrderItemAttr].groupByKey(oi => (oi.push_task_id, oi.member_id, oi.order_id))
      .mapGroups((k, vs) => {
        var totalAmount: Double = 0.0
        var createTime: String = null
        var payTime: String = null
        var payMethod: String = null

        var isShoppingCart = false // 是否为收藏或加入购物车订单

        for (v <- vs) {
          if (totalAmount == 0.0) totalAmount = v.total_amount

          if (createTime == null) createTime = v.create_time

          if (payTime == null) payTime = v.pay_time

          if (payMethod == null) payMethod = v.pay_method

          if (v.shopping_cart_time != null && v.push_time < v.shopping_cart_time) {
            isShoppingCart = true
          }
        }

        OrderItemAgg(k._1, k._2, k._3, totalAmount, createTime, payTime, payMethod, isShoppingCart)
      }).groupByKey(o => (o.push_task_id, o.member_id))
      .mapGroups((k, vs) => {
        var isBuyNow = false
        var isBuyNowPay = false

        var isShoppingCart = false
        var isShoppingCartCreate = false
        var isShoppingCartPay = false

        var isOrderCreate = false
        var firstOrderCreateTime: String = null
        var isOrderPay = false
        var orderPayAmount = BigDecimal(0)
        var firstOrderPayTime: String = null
        var isOrderOnlyCreate = false  // 仅下单

        for (v <- vs) {
          if (v.is_shopping_cart) {
            // 收藏或加购
            isShoppingCart = true

            if (v.create_time != null) isShoppingCartCreate = true

            if (v.pay_time != null && !"010".equals(v.pay_method)) isShoppingCartPay = true
          } else {
            // 立即购买
            isBuyNow = true

            if (v.pay_time != null && !"010".equals(v.pay_method)) isBuyNowPay = true
          }

          if (v.create_time != null) {
            isOrderCreate = true

            if (firstOrderCreateTime == null) firstOrderCreateTime = v.create_time
            else if (firstOrderCreateTime > v.create_time) {
              firstOrderCreateTime = v.create_time
            }
          }

          if (v.pay_time != null && !"010".equals(v.pay_method)) {
            isOrderPay = true
            orderPayAmount += BigDecimal(v.total_amount)

            if (firstOrderPayTime == null) firstOrderPayTime = v.pay_time
            else if (firstOrderPayTime > v.pay_time) {
              firstOrderPayTime = v.pay_time
            }
          } else {
            isOrderOnlyCreate = true
          }
        }

        OrderAgg(
          k._1,
          k._2,
          isBuyNow,
          isBuyNowPay,
          isShoppingCartCreate,
          isShoppingCartPay,
          isOrderCreate,
          firstOrderCreateTime,
          isOrderPay,
          orderPayAmount.toDouble,
          firstOrderPayTime,
          isOrderOnlyCreate
        )
      }).toDF()
  }


  /**
    * 推送会员收藏和加入购物车数据
    *
    * @return
    *
    * - push_task_id 推送 ID
    * - member_id 会员 ID
    * - is_shopping_cart 是否收藏或加入购物车
    *
    * */
  def processShoppingCartDF(): DataFrame = {
    this.shoppingCartDF.createOrReplaceTempView("shopping_cart")

    spark.sql(
      """
        |select
        |    push_task_id,
        |    member_id,
        |    true as is_shopping_cart
        |from shopping_cart sc
        |group by push_task_id, member_id
      """.stripMargin)
  }


  /**
    * 推送会员收藏和加入购物车数据
    *
    * @return
    *
    * - push_task_id 推送 ID
    * - member_id 会员 ID
    * - item_id 单品 ID
    * - shopping_cart_time 收藏或加入购物车时间
    *
    * */
  private def initShoppingCartDF(): DataFrame = {
    spark.sql(
      s"""
         |select
         |    m.push_task_id,
         |    m.member_id,
         |    m.item_id,
         |    min(m.create_time) as shopping_cart_time
         |from (
         |    select
         |        pm.push_task_id,
         |        pm.member_id,
         |        ci.mall_activity_product_id as item_id,
         |        ci.create_time as create_time
         |    from dw.collection_info ci
         |    join push_member pm
         |    on ci.fk_member_id = pm.member_id
         |    and ci.his_time = '${date.toString("yyyy-MM-dd")}'
         |    and ci.create_time > pm.push_time
         |    union
         |    select
         |        pm.push_task_id,
         |        pm.member_id,
         |        scl.activity_product_id as item_id,
         |        scl.create_time as create_time
         |    from shop_cart_log scl
         |    join push_member pm
         |    on scl.fk_member_id = pm.member_id
         |    and scl.create_time > pm.push_time
         |) m
         |group by m.push_task_id, m.member_id, m.item_id
      """.stripMargin)
  }

}
