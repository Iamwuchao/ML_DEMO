package com.tgou.data.stanford.market.delivery.bean

/**
  * Created by 李震 on 2018/1/4.
  */
case class ThirdDeliveryInfoRecord (
                                    id: Long,
                                    fk_tgou_order_id: Long,
                                    tracking_no: String,
                                    query_time: String,
                                    result_type: Int,
                                    comment: String,
                                    modify_time: String,
                                    state: String
                                   )
