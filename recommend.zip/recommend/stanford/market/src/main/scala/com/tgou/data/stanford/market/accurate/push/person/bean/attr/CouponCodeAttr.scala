package com.tgou.data.stanford.market.accurate.push.person.bean.attr

/**
  * Created by 李震 on 2017/11/22.
  */
case class CouponCodeAttr (
                            coupon_id: Long,
                            activity_id: Option[Long],
                            push_task_id: Long,
                            member_id: Long,
                            group: String,
                            subject_code: String,
                            object_id: Long,
                            object_type: String,
                            total_amount: Double
                          )
