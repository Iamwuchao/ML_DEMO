package com.tgou.data.stanford.market.delivery

import com.google.inject.AbstractModule
import com.google.inject.name.Names
import com.tgou.data.stanford.market.delivery.sink.DeliverySink
import com.tgou.data.stanford.market.delivery.sink.impl.DeliverySinkImpl
import com.tgou.data.stanford.market.delivery.source.DeliverySource
import com.tgou.data.stanford.market.delivery.source.impl.DeliverySourceImpl
import org.apache.spark.sql.SparkSession
import org.joda.time.LocalDate

/**
  * Created by 李震 on 2018/1/4.
  */
class ApplicationModule(spark: SparkSession, appName: String, date: LocalDate) extends AbstractModule {

  override def configure(): Unit = {
    bind(classOf[SparkSession]).toInstance(spark)
    bind(classOf[String]).annotatedWith(Names.named("appName")).toInstance(appName)
    bind(classOf[LocalDate]).toInstance(date)

    bind(classOf[DeliverySource]).to(classOf[DeliverySourceImpl])

    bind(classOf[DeliverySink]).to(classOf[DeliverySinkImpl])
  }

}

object ApplicationModule {

  def apply(spark: SparkSession, appName: String, date: LocalDate): ApplicationModule = new ApplicationModule(spark, appName, date)

}
