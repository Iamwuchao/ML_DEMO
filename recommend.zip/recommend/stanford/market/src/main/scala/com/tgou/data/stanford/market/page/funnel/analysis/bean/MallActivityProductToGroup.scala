package com.tgou.data.stanford.market.page.funnel.analysis.bean

case class MallActivityProductToGroup(
                                       id: Long,
                                       fk_mall_parent_id: Long,
                                       fk_mall_sub_id: Long,
                                       price: String,
                                       short_name: String,
                                       num: Int,
                                       version: Int,
                                       modify_time: String
                                ) {}
