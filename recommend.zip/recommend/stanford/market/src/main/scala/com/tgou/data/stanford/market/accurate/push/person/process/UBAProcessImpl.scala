package com.tgou.data.stanford.market.accurate.push.person.process

import com.google.inject.Inject
import com.tgou.data.stanford.market.accurate.push.Constants
import com.tgou.data.stanford.market.accurate.push.person.source.PushPersonSource
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.joda.time.LocalDate

/**
  * Created by 李震 on 2017/11/14.
  */
class UBAProcessImpl @Inject()(spark: SparkSession, date: LocalDate) extends UBAProcess {

  @Inject
  var pushPersonSource: PushPersonSource = _


  def processUBADF: DataFrame = {
    pushPersonSource.pushMemberDF.createOrReplaceTempView("push_member")

    spark.sql(
      s"""
        |select
        |    pm.push_task_id,
        |    pm.member_id,
        |    count(1) as platform_pv,
        |    min(up.time) as first_visit_time
        |from dw.uba_page up
        |join push_member pm
        |on up.member_id = pm.member_id
        |and up.his_time >= '${date.minusDays(Constants.STATICS_DURATION - 1).toString("yyyy-MM-dd")}'
        |and up.his_time <= '${date.toString("yyyy-MM-dd")}'
        |and up.time > pm.push_time
        |group by pm.push_task_id, pm.member_id
      """.stripMargin)
  }

}
