package com.tgou.data.stanford.market.accurate.push.person.process

import com.google.inject.Inject
import com.tgou.data.stanford.market.accurate.push.person.source.PushPersonSource
import org.apache.spark.sql.catalyst.encoders.RowEncoder
import org.apache.spark.sql.types.{LongType, StructField, StructType}
import org.apache.spark.sql.{DataFrame, Row, SparkSession}
import org.joda.time.LocalDate

/**
  * Created by 李震 on 2017/11/10.
  */
class PersonProcessImpl @Inject()(spark: SparkSession, date: LocalDate) extends PersonProcess {

  @Inject
  var pushPersonSource: PushPersonSource = _


  def processPushPersonCount: DataFrame = {
    val inputSchema = StructType(
      StructField("push_count", LongType) ::
        StructField("receive_count", LongType) :: Nil
    )
    val outputSchema = StructType(
      StructField("push_task_id", LongType) ::
        StructField("push_count", LongType) ::
        StructField("receive_count", LongType) :: Nil
    )

    import spark.implicits._
    pushPersonSource.pushPersonDF.groupByKey(r => r.getLong(0))
      .mapValues(r => {
        if (r.getBoolean(8)) Row(1l, 1l) else Row(1l, 0l)
      })(RowEncoder(inputSchema))
      .reduceGroups((l, r) => Row(l.getLong(0) + r.getLong(0), l.getLong(1) + r.getLong(1)))
      .map(t => Row(t._1, t._2.get(0), t._2.get(1)))(RowEncoder(outputSchema))
  }

}
