package com.tgou.data.stanford.market.delivery.bean

/**
  * Created by 李震 on 2018/1/4.
  */
case class DeliveryInfoBean (
                              tracking_no: String,
                              state: String,
                              comment: String,
                              log_state: String,
                              event_time: String
                            )
