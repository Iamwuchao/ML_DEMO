package com.tgou.data.stanford.market.accurate.push.rebackChannel

import com.tgou.data.stanford.market.accurate.push.Constants
import com.tgou.data.stanford.market.core.MarketSource
import org.apache.spark.sql.types._
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.joda.time.LocalDate

/**
  * Created by 张少锐 on 2017/11/10.
  * 精准推送回访渠道分析-跨天表字段的处理
  */
class RebackChannelKDayProcessor protected(spark: SparkSession, date: LocalDate){

  /**
    * 交易概况统计结果
    *
    * @param rebackDF
    *
    * @return
    *
    * 字段：
    * - push_task_id   推送 ID
    * - reback_count   回访用户数
    * - order_count    下单用户数
    * - order_sum      下单金额
    * - pay_count      支付用户数
    * - pay_sum        支付金额
    * - kdj            支付客单价
    * - platform_pv    回访平台流量
    * - platform_uv    回访平台用户数
    * - add_cart_count 收藏或加购物商品人数
    * */
  def processTradingCount(rebackDF: DataFrame): DataFrame = {

    rebackDF.createOrReplaceTempView("reback")

    // 回访用户数，回访平台流量，回访平台用户数
    val memberCountDF = spark.sql(
      """
        |select
        |     r.push_task_id,
        |     count(distinct upk.member_id) as reback_count,
        |     count(distinct upk.member_id) as platform_uv,
        |     count(1) as platform_pv
        |from uba_page_kday upk
        |join reback r
        |on (
        |    upk.member_id = r.member_id
        |    and upk.time > r.push_time
        |)
        |group by r.push_task_id
      """.stripMargin)

    // 下单用户数，下单金额
    val createCountDF = spark.sql(
      """
        |select
        |     r.push_task_id,
        |     count(distinct o.member_id) as order_count,
        |     nvl(cast(sum(o.total_amount) as decimal(18,2)),0) as order_sum
        |from create_order o
        |join reback r
        |on (
        |   o.member_id = r.member_id
        |   and o.create_time > r.push_time
        |)
        |group by r.push_task_id
      """.stripMargin)

    // 支付用户数，支付金额，支付客单价
    val payCountDF = spark.sql(
      """
        |select
        |     push_task_id,
        |     pay_count,
        |     pay_sum,
        |     case when pay_count = 0 or isnull(pay_count) = true then 0 else round(pay_sum/pay_count,2) end as kdj
        |from (
        |     select
        |          r.push_task_id as push_task_id,
        |          count(distinct o.member_id) as pay_count,
        |          nvl(cast(sum(o.total_amount) as decimal(18,2)),0) as pay_sum
        |     from pay_order o
        |     join reback r
        |     on (
        |        o.member_id = r.member_id
        |        and o.create_time > r.push_time
        |        and o.pay_time > r.push_time
        |     )
        |     group by r.push_task_id
        |)
      """.stripMargin)

    // 收藏或加购物商品人数
    val addCartCount = spark.sql(
      s"""
         |select
         |    m.push_task_id,
         |    count(distinct m.member_id) as add_cart_count
         |from (
         |    select
         |        r.push_task_id,
         |        r.member_id
         |    from dw.collection_info ci
         |    join reback r
         |    on ci.fk_member_id = r.member_id
         |    and ci.his_time = '${date.toString("yyyy-MM-dd")}'
         |    and ci.create_time > r.push_time
         |    union
         |    select
         |        r.push_task_id,
         |        r.member_id
         |    from shop_cart_log scl
         |    join reback r
         |    on scl.fk_member_id = r.member_id
         |    and scl.create_time > r.push_time
         |) m
         |group by m.push_task_id
       """.stripMargin)

    // 合并统计结果
    memberCountDF.
      join(createCountDF,Seq("push_task_id"),"full").
      join(payCountDF,Seq("push_task_id"),"full").
      join(addCartCount,Seq("push_task_id"),"full").
      select(
        "push_task_id",
        "reback_count",
        "order_count",
        "order_sum",
        "pay_count",
        "pay_sum",
        "kdj",
        "platform_pv",
        "platform_uv",
        "add_cart_count"
      )
  }

  /**
    * 流量数据统计结果
    *
    * @param rebackDF
    *
    * @return
    *
    * 字段：
    * - push_task_id  推送 ID
    * - jz_jyrs_count 精准交易人数
    * - jz_jybs_count 精准交易笔数
    * - jz_jyje_sum   精准交易金额
    * - ld_jyrs_count 联带交易人数
    * - ld_jybs_count 联带交易笔数
    * - ld_jyje_sum   联带交易金额
    * */
  def processFlowCount(rebackDF: DataFrame): DataFrame = {

    // 券的精准和联带统计
    val couponCountDF = getCouponCount(rebackDF.filter("subject_code = '502'"))

    // 券活动的精准和联带统计
    val couponActivityCountDF = getCouponActivityCount(rebackDF.filter("subject_code = '503' and object_type = '3'"))

    // 展示类活动的精准和联带统计
    val exhibitionCountDF = getExhibitionCount(rebackDF.filter("subject_code = '503' and object_type = '4'"))

    // 单品类的精准和联带统计
    val itemCountDF = getItemCount(rebackDF.filter("subject_code = '503' and object_type = '6'"))

    // 抽奖类的精准和联带统计
    val prizeCountDF = getPrizeCount(rebackDF.filter("subject_code = '503' and object_type = '7'"))

    couponCountDF.union(couponActivityCountDF).union(exhibitionCountDF).union(itemCountDF).union(prizeCountDF)
  }

  /**
    * 券流量数据统计结果
    *
    * @param rebackDF
    *
    * @return
    *
    * 字段：
    * - push_task_id         推送 ID
    * - coupon_type          券类型(1现金券，2折扣券，3满减券，4满送券)
    * - coupon_id            券ID
    * - coupon_total_sum     券总数
    * - coupon_receive_count 领券人数
    * - coupon_user_count    用券人数
    * - coupon_ship_count    用券数
    * - coupon_ship_sum      券核销金额
    * */
  def processCouponFlowCount(rebackDF: DataFrame): DataFrame = {

    // 券流量统计
    val couponFlowCountDF = getCouponFlowCount(rebackDF.filter("subject_code = '502'"))

    // 券活动流量统计
    val couponActivityFlowCountDF = getCouponActivityFlowCount(rebackDF.filter("subject_code = '503' and object_type = '3'"))

    couponFlowCountDF.union(couponActivityFlowCountDF)
  }

  // 券流量统计
  def getCouponFlowCount(couponFlowDF: DataFrame): DataFrame = {
    couponFlowDF.createOrReplaceTempView("coupon_flow")
    // 券总数，领券人数
    val receiveDF = spark.sql(
      s"""
         |select
         |     cf.push_task_id,
         |     cf.object_type as coupon_type,
         |     cf.object_id as coupon_id,
         |     cta.total_qty as coupon_total_sum,
         |     count(distinct cc.member_id) as coupon_receive_count
         |from coupon_flow cf
         |join coupon_code cc
         |on cf.member_id = cc.member_id
         |and cf.object_id = cc.fk_coupon_id
         |and cc.create_time is not null
         |and cc.create_time >= cf.push_time
         |join coupon_to_activity cta
         |on cc.fk_coupon_id = cta.fk_coupon_id
         |group by cf.push_task_id,cf.object_type,cf.object_id,cta.total_qty
       """.stripMargin)

    // 用券人数，用券数， 券核销金额
    val useDF = spark.sql(
      s"""
         | select
         |      cf.push_task_id,
         |      cf.object_type as coupon_type,
         |      cf.object_id as coupon_id,
         |      count(distinct cc.member_id) as coupon_user_count,
         |      count(1) as coupon_ship_count,
         |      nvl(cast(sum(co.total_amount) as decimal(18,2)),0) as coupon_ship_sum
         |from coupon_flow cf
         |join coupon_code cc
         |on cf.member_id = cc.member_id
         |and cf.object_id = cc.fk_coupon_id
         |and cc.create_time is not null
         |and cc.create_time >= cf.push_time
         |and cc.use_time is not null
         |and cc.use_tag = '2'
         |join order_preferential op
         |on cc.coupon_code_id = op.object_id
         |and op.order_preferential_type = '3'
         |join create_order co
         |on op.fk_tgou_order_id = co.order_id
         |and co.member_id = cf.member_id
         |and co.create_time > cf.push_time
         |group by cf.push_task_id,cf.object_type,cf.object_id
       """.stripMargin)

    receiveDF.join(useDF,Seq("push_task_id","coupon_type","coupon_id"),"full")
  }

  // 券活动流量统计
  def getCouponActivityFlowCount(couponActivityFlowDF: DataFrame): DataFrame = {
    couponActivityFlowDF.createOrReplaceTempView("coupon_activity_flow")
    // 券总数，领券人数
    val receiveDF = spark.sql(
      s"""
         |select
         |     caf.push_task_id,
         |     ci.type as coupon_type,
         |     cta.fk_coupon_id as coupon_id,
         |     cta.total_qty as coupon_total_sum,
         |     count(distinct cc.member_id) as coupon_receive_count
         |from coupon_activity_flow caf
         |join coupon_to_activity cta
         |on caf.object_id = cta.fk_activity_id
         |join coupon_information ci
         |on cta.fk_coupon_id = ci.coupon_id
         |join coupon_code cc
         |on cta.fk_coupon_id = cc.fk_coupon_id
         |and caf.member_id = cc.member_id
         |and caf.object_id = cc.fk_activity_id
         |and cc.create_time is not null
         |and cc.create_time > caf.push_time
         |group by caf.push_task_id,ci.type,cta.fk_coupon_id,cta.total_qty
       """.stripMargin)

    // 用券人数，用券数， 券核销金额
    val useDF = spark.sql(
      s"""
         |select
         |     caf.push_task_id,
         |     ci.type as coupon_type,
         |     cta.fk_coupon_id as coupon_id,
         |     count(distinct cc.member_id) as coupon_user_count,
         |     count(1) as coupon_ship_count,
         |     nvl(cast(sum(co.total_amount) as decimal(18,2)),0) as coupon_ship_sum
         |from coupon_activity_flow caf
         |join coupon_to_activity cta
         |on caf.object_id = cta.fk_activity_id
         |join coupon_information ci
         |on cta.fk_coupon_id = ci.coupon_id
         |join coupon_code cc
         |on cta.fk_coupon_id = cc.fk_coupon_id
         |and caf.member_id = cc.member_id
         |and caf.object_id = cc.fk_activity_id
         |and cc.create_time is not null
         |and cc.create_time > caf.push_time
         |and cc.use_time is not null
         |and cc.use_tag = '2'
         |join order_preferential op
         |on cc.coupon_code_id = op.object_id
         |and op.order_preferential_type = '3'
         |join create_order co
         |on op.fk_tgou_order_id = co.order_id
         |and co.member_id = caf.member_id
         |and co.create_time > caf.push_time
         |group by caf.push_task_id,ci.type,cta.fk_coupon_id
       """.stripMargin)

    receiveDF.join(useDF,Seq("push_task_id","coupon_type","coupon_id"),"full")
  }

  // 券的精准和联带统计
  def getCouponCount(couponsDF: DataFrame): DataFrame = {
    couponsDF.createOrReplaceTempView("coupons")

    // 精准交易
    val jzCount = spark.sql(
      s"""
         |select
         |     c.push_task_id,
         |     count(distinct po.member_id) as jz_jyrs_count,
         |     count(po.order_id) as jz_jybs_count,
         |     nvl(cast(sum(po.total_amount) as decimal(18,2)),0) as jz_jyje_sum
         |from coupons c
         |join coupon_code cc
         |on c.member_id = cc.member_id
         |and c.object_id = cc.fk_coupon_id
         |and cc.create_time >= c.push_time
         |and cc.use_time is not null
         |and cc.use_tag = '2'
         |join order_preferential op
         |on cc.coupon_code_id = op.object_id
         |and op.order_preferential_type = '3'
         |join pay_order po
         |on op.fk_tgou_order_id = po.order_id
         |and po.member_id = c.member_id
         |and po.create_time > c.push_time
         |and po.pay_time > c.push_time
         |group by c.push_task_id
       """.stripMargin)

    // 联带交易
    val ldCount = spark.sql(
      s"""
         |select
         |     cs.push_task_id,
         |     count(distinct po.member_id) as ld_jyrs_count,
         |     count(po.order_id) as ld_jybs_count,
         |     nvl(cast(sum(po.total_amount) as decimal(18,2)),0) as ld_jyje_sum
         |from coupons cs
         |join pay_order po
         |on cs.member_id = po.member_id
         |and po.create_time > cs.push_time
         |and po.pay_time > cs.push_time
         |where po.order_id not in(
         |    select po.order_id
         |      from coupons c
         |      join coupon_code cc
         |      on c.member_id = cc.member_id
         |      and c.object_id = cc.fk_coupon_id
         |      and cc.create_time >= c.push_time
         |      and cc.use_time is not null
         |      and cc.use_tag = '2'
         |      join order_preferential op
         |      on cc.coupon_code_id = op.object_id
         |      and op.order_preferential_type = '3'
         |      join pay_order po
         |      on op.fk_tgou_order_id = po.order_id
         |      and po.member_id = c.member_id
         |      and po.create_time > c.push_time
         |      and po.pay_time > c.push_time
         |)
         |group by cs.push_task_id
       """.stripMargin)
    jzCount.join(ldCount,Seq("push_task_id"),"full")
  }

  // 券活动的精准和联带统计
  def getCouponActivityCount(couponActivityDF: DataFrame): DataFrame = {
    couponActivityDF.createOrReplaceTempView("coupon_activity")

    // 精准交易
    val jzCount = spark.sql(
      s"""
         |select
         |     ca.push_task_id,
         |     count(distinct po.member_id) as jz_jyrs_count,
         |     count(po.order_id) as jz_jybs_count,
         |     nvl(cast(sum(po.total_amount) as decimal(18,2)),0) as jz_jyje_sum
         |from coupon_activity ca
         |join coupon_to_activity cta
         |on ca.object_id = cta.fk_activity_id
         |join coupon_code cc
         |on cta.fk_coupon_id = cc.fk_coupon_id
         |and ca.member_id = cc.member_id
         |and ca.object_id = cc.fk_activity_id
         |and cc.create_time > ca.push_time
         |and cc.use_time is not null
         |and cc.use_tag = '2'
         |join order_preferential op
         |on cc.coupon_code_id = op.object_id
         |and op.order_preferential_type = '3'
         |join pay_order po
         |on op.fk_tgou_order_id = po.order_id
         |and po.member_id = ca.member_id
         |and po.create_time > ca.push_time
         |and po.pay_time > ca.push_time
         |group by ca.push_task_id
       """.stripMargin)

    // 联带交易
    val ldCount = spark.sql(
      s"""
         |select
         |     ca.push_task_id,
         |     count(distinct po.member_id) as ld_jyrs_count,
         |     count(po.order_id) as ld_jybs_count,
         |     nvl(cast(sum(po.total_amount) as decimal(18,2)),0) as ld_jyje_sum
         |from coupon_activity ca
         |join pay_order po
         |on ca.member_id = po.member_id
         |and po.create_time > ca.push_time
         |and po.pay_time > ca.push_time
         |where po.order_id not in(
         |    select po.order_id
         |      from coupon_activity ca
         |      join coupon_to_activity cta
         |      on ca.object_id = cta.fk_activity_id
         |      join coupon_code cc
         |      on cta.fk_coupon_id = cc.fk_coupon_id
         |      and ca.member_id = cc.member_id
         |      and ca.object_id = cc.fk_activity_id
         |      and cc.create_time > ca.push_time
         |      and cc.use_time is not null
         |      and cc.use_tag = '2'
         |      join order_preferential op
         |      on cc.coupon_code_id = op.object_id
         |      and op.order_preferential_type = '3'
         |      join pay_order po
         |      on op.fk_tgou_order_id = po.order_id
         |      and po.member_id = ca.member_id
         |      and po.create_time > ca.push_time
         |      and po.pay_time > ca.push_time
         |)
         |group by ca.push_task_id
       """.stripMargin)

    jzCount.join(ldCount,Seq("push_task_id"),"full")
  }

  // 展示类活动的精准和联带统计
  def getExhibitionCount(exhibitionDF: DataFrame): DataFrame = {
    exhibitionDF.createOrReplaceTempView("exhibition")

     spark.sql(
        s"""
           |select
           |     e.push_task_id,
           |     null as jz_jyrs_count,
           |     null as jz_jybs_count,
           |     null as jz_jyje_sum,
           |     count(distinct po.member_id) as ld_jyrs_count,
           |     count(po.order_id) as ld_jybs_count,
           |     nvl(cast(sum(po.total_amount) as decimal(18,2)),0) as ld_jyje_sum
           |from exhibition e
           |join pay_order po
           |on e.member_id = po.member_id
           |and po.create_time > e.push_time
           |and po.pay_time > e.push_time
           |group by e.push_task_id
         """.stripMargin).filter("push_task_id is not null")
  }

  // 单品类的精准和联带统计
  def getItemCount(itemDF: DataFrame): DataFrame = {
    itemDF.createOrReplaceTempView("item")

    // 精准交易
    val jzCount = spark.sql(
      s"""
         |select
         |      c.push_task_id,
         |      count(distinct c.member_id) as jz_jyrs_count,
         |      count(c.order_id) as jz_jybs_count,
         |      nvl(cast(sum(c.total_amount) as decimal(18,2)),0) as jz_jyje_sum
         |from (
         |      select
         |        p.push_task_id,
         |        p.member_id,
         |        p.order_id,
         |        max(p.total_amount) as total_amount
         |      from (
         |          select
         |              ap.fk_listing_id as item_id,
         |              a.activity_id
         |          from dw.activity_product ap
         |          join dw.activity a
         |          on ap.fk_activity_id = a.activity_id
         |          and ap.his_time = '${date.toString("yyyy-MM-dd")}'
         |          and a.his_time = '${date.toString("yyyy-MM-dd")}'
         |          and a.type = '6'
         |      ) a join (
         |          select
         |              i.push_task_id,
         |              i.member_id,
         |              pop.item_id,
         |              pop.order_id,
         |              pop.total_amount,
         |              i.object_id
         |          from pay_order_product pop
         |          join item i
         |          on pop.member_id = i.member_id
         |          and pop.create_time > i.push_time
         |          and pop.pay_time > i.push_time
         |      ) p
         |      on a.item_id = p.item_id
         |      and a.activity_id = p.object_id
         |      group by p.push_task_id,p.member_id,p.order_id
         |    ) c
         |group by c.push_task_id
         """.stripMargin)

    // 联带交易
    val ldCount = spark.sql(
      s"""
         |select
         |    i.push_task_id,
         |    count(distinct po.member_id) as ld_jyrs_count,
         |    count(po.order_id) as ld_jybs_count,
         |    nvl(cast(sum(po.total_amount) as decimal(18,2)),0) as ld_jyje_sum
         |from pay_order po
         |join item i
         |on po.member_id = i.member_id
         |and po.create_time > i.push_time
         |and po.pay_time > i.push_time
         |left join (
         |            select
         |              p.push_task_id,
         |              p.member_id,
         |              p.order_id,
         |              max(p.total_amount) as total_amount
         |            from (
         |                select
         |                    ap.fk_listing_id as item_id,
         |                    a.activity_id
         |                from dw.activity_product ap
         |                join dw.activity a
         |                on ap.fk_activity_id = a.activity_id
         |                and ap.his_time = '${date.toString("yyyy-MM-dd")}'
         |                and a.his_time = '${date.toString("yyyy-MM-dd")}'
         |                and a.type = '6'
         |            ) a join (
         |                select
         |                    i.push_task_id,
         |                    i.member_id,
         |                    pop.item_id,
         |                    pop.order_id,
         |                    pop.total_amount,
         |                    i.object_id
         |                from pay_order_product pop
         |                join item i
         |                on pop.member_id = i.member_id
         |                and pop.create_time > i.push_time
         |                and pop.pay_time > i.push_time
         |            ) p
         |            on a.item_id = p.item_id
         |            and a.activity_id = p.object_id
         |            group by p.push_task_id,p.member_id,p.order_id
         |		   ) c
         |on po.order_id =  c.order_id
         |and i.push_task_id = c.push_task_id
         |and po.member_id = c.member_id
         |where isnull(c.order_id)
         |group by i.push_task_id
       """.stripMargin)

    jzCount.join(ldCount,Seq("push_task_id"),"full")
  }

  // 抽奖类的精准和联带统计
  def getPrizeCount(prizeDF: DataFrame): DataFrame = {
    prizeDF.createOrReplaceTempView("prize")

    // 精准交易
    val jzCount = spark.sql(
      s"""
         |select
         |     p.push_task_id,
         |     count(distinct usk.member_id) as jz_jyrs_count,
         |     null as jz_jybs_count,
         |     null as jz_jyje_sum
         |from prize p
         |join uba_scp_kday usk
         |on p.member_id = usk.member_id
         |and usk.a_b_c = '12.2.3'
         |and usk.time > p.push_time
         |group by p.push_task_id
       """.stripMargin)

    // 联带交易
    val ldCount = spark.sql(
      s"""
         |select
         |    p.push_task_id,
         |    count(distinct po.member_id) as ld_jyrs_count,
         |    count(po.order_id) as ld_jybs_count,
         |    nvl(cast(sum(po.total_amount) as decimal(18,2)),0) as ld_jyje_sum
         |from prize p
         |join uba_scp_kday usk
         |on p.member_id = usk.member_id
         |and usk.a_b_c != '12.2.3'
         |and usk.time > p.push_time
         |join pay_order po
         |on usk.member_id = po.member_id
         |and po.create_time > p.push_time
         |and po.pay_time > p.push_time
         |group by p.push_task_id
       """.stripMargin)

    jzCount.join(ldCount,Seq("push_task_id"),"full")
  }

  def getShopCartLogODSDF(): DataFrame = {
    val schema = StructType(
      StructField("id", LongType, false) ::
        StructField("fk_shop_cart_id", LongType, true) ::
        StructField("modify_time", StringType, true) ::
        StructField("fk_store_id", LongType, true) ::
        StructField("activity_product_id", LongType, true) ::
        StructField("sku_id", LongType, true) ::
        StructField("quantity", IntegerType, true) ::
        StructField("fk_member_id", LongType, true) ::
        StructField("create_time", StringType, true) :: Nil
    )
    MarketSource.getDurationDF(spark, "/tiangou/tgouorder/shop_cart_log", date.minusDays(Constants.STATICS_DURATION - 1), date, schema)
  }

  def getCouponToActivityDF(): DataFrame = {
    val schema = StructType(
      StructField("id", LongType, false) ::
        StructField("fk_activity_id", LongType, true) ::
        StructField("fk_coupon_id", LongType, true) ::
        StructField("total_qty", IntegerType, true) ::
        StructField("remain_qty", IntegerType, true) ::
        StructField("version", StringType, true) ::
        StructField("limit_qty", IntegerType, true) ::
        StructField("fake_sold_qty", IntegerType, true) ::
        StructField("daily_limit_qty", IntegerType, true) ::
        StructField("daily_get_limit_qty", IntegerType, true) ::
        StructField("publish_time", StringType, true) ::
        StructField("off_time", StringType, true) ::
        StructField("coupon_heat", StringType, true) ::
        StructField("modify_time", StringType, true) :: Nil
    )
    val df = MarketSource.getCompleteDF(spark, "/tiangou/tgou/coupon_to_activity", date, schema)
    MarketSource.getNewestDF(df, Seq("id"), "modify_time")
  }

}

object RebackChannelKDayProcessor {

  def apply(spark: SparkSession, date: LocalDate): RebackChannelKDayProcessor = new RebackChannelKDayProcessor(spark, date)

}


