package com.tgou.data.stanford.market.delivery.bean

/**
  * Created by 李震 on 2018/1/4.
  */
case class TgouPackage (
                        id: Long,
                        version: Int,
                        create_time: String,
                        state: String,
                        tracking_no: String,
                        ship_fee: Double,
                        estimate_ship_fee: Double,
                        receive_time: String,
                        weight: Double,
                        volumn: String,
                        ship_time: String,
                        ship_operator: String,
                        ship_pc: String,
                        trade_id: Long,
                        pick_operator: String,
                        fk_delivery_vendor_id: Long,
                        print_times: Int,
                        special_flag: Int,
                        fk_tgou_order_id: Long,
                        fk_supplier_id: Long,
                        modify_time: String,
                        remark: String
                       )
