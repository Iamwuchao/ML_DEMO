package com.tgou.data.stanford.market.accurate.push.bean

/**
  * Created by 李震 on 2017/11/16.
  */
case class OrderPreferentialODS(
                              id: Long,
                              order_preferential_type: Int,
                              object_id: Long,
                              discount_bears: String,
                              fk_tgou_order_id: Long,
                              amount: Double,
                              excute_time: String,
                              object_code: String,
                              modify_time: String
                             )
