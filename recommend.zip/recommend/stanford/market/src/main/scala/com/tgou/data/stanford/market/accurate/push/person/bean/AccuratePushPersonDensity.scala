package com.tgou.data.stanford.market.accurate.push.person.bean

/**
  * Created by 李震 on 2017/11/20.
  */
case class AccuratePushPersonDensity (
                                      push_task_id: Long,
                                      group: Long,
                                      density_type: String,
                                      density_day: Int,
                                      density_hour: Int,
                                      density_value: Long
                                     )
