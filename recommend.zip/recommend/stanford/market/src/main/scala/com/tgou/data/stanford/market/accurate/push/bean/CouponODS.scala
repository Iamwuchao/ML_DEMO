package com.tgou.data.stanford.market.accurate.push.bean

/**
  * Created by 李震 on 2017/11/16.
  */
case class CouponODS (
                      id: Long,
                      version: Int,
                      coupon_type: Int,
                      start_time: String,
                      end_time: String,
                      value: Double,
                      name: String,
                      state: String,
                      rule: Double,
                      rule_desc: String,
                      creator: String,
                      create_time: String,
                      source: Int,
                      confirmer: String,
                      confirm_time: String,
                      image_url: String,
                      source_type: Int,
                      publish_type: Int,
                      pay_type: Int,
                      pay_amount: Double,
                      use_type: Int,
                      data_source: Int,
                      fk_brand_id: Long,
                      use_way: Int,
                      delivery_way: Int,
                      mis_product_id: Long,
                      promotion_rule: String,
                      modify_time: String
                     )
