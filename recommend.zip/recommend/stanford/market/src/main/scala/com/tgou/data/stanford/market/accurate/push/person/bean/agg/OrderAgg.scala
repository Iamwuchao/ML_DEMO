package com.tgou.data.stanford.market.accurate.push.person.bean.agg

/**
  * Created by 李震 on 2017/11/17.
  */
case class OrderAgg (
                      push_task_id: Long,
                      member_id: Long,
                      is_buy_now: Boolean,
                      is_buy_now_pay: Boolean,
                      is_shopping_cart_create: Boolean,
                      is_shopping_cart_pay: Boolean,
                      is_order_create: Boolean,
                      first_order_create_time: String,
                      is_order_pay: Boolean,
                      order_pay_amount: Double,
                      first_order_pay_time: String,
                      is_order_only_create: Boolean
                    )
