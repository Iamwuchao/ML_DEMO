package com.tgou.data.stanford.market.page.code.analysis

import java.time.LocalDate
import java.util.Properties

import com.tgou.data.stanford.market.member.JdbcBootstrap
import com.tgou.data.stanford.market.page.code.analysis.service.{InnerScpService, JrService, RegisterTableService, OverviewService}
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.sql.execution.datasources.jdbc.{JDBCOptions, JdbcUtils}
import org.apache.spark.storage.StorageLevel

object AnalysisMain {
  def main(args: Array[String]): Unit = {
    JdbcBootstrap(args).bootstrap(execute)
  }
  def execute(spark: SparkSession,appName: String, date: LocalDate, jdbcConfig: Properties): Unit = {
    //1、生成用户表。区分登陆与未登陆
    RegisterTableService.registerDayMemberTable(spark, date)
    RegisterTableService.registerDayPageMemberTable(spark, date)
    RegisterTableService.fullMemberScpTable(spark, date)
//    2、Overview的
    val overviewDf = OverviewService.getOverview(spark, date)
//    3、入口数据
    val jrDf = JrService.getJr(spark, date)
//    4、详情数据
    val map = InnerScpService.getMapBroadcast(spark).value
    val infoDf = InnerScpService.getScpInfo(spark, date, map)
    //to Sink
    val code_page_overview_t = "SIRIUS_CODE_PAGE_OVERVIEW_T"
    val code_page_jr_t = "SIRIUS_CODE_PAGE_JR_T"
    val code_page_info_t = "SIRIUS_CODE_PAGE_INFO_T"
    var jdbcConfigMap = Map[String,String]()
    jdbcConfig.setProperty("driver","oracle.jdbc.driver.OracleDriver")
    jdbcConfigMap+=("driver"->"oracle.jdbc.driver.OracleDriver")
    jdbcConfigMap+=("url"->jdbcConfig.getProperty("url"))
    jdbcConfigMap+=("user"->jdbcConfig.getProperty("user"))
    jdbcConfigMap+=("password"->jdbcConfig.getProperty("password"))
    jdbcConfigMap+=("dbtable"->code_page_overview_t)
    val conn = JdbcUtils.createConnectionFactory(new JDBCOptions(jdbcConfigMap)).apply
    try{
      //clear olds
      val list = Seq(code_page_overview_t,code_page_jr_t,code_page_info_t)
      for(t <- list){
        conn.prepareStatement(
          s"""
             |delete from $t where "DATE" = to_date('$date','yyyy-mm-dd')
        """.stripMargin).executeUpdate
      }
    }finally conn.close()
    //sink
    save(overviewDf.selectExpr("date as `ID`","pv as `PV`","uv as `UV`","c_pv as `C_PV`","c_uv as `C_UV`","to_date(date) as `DATE`")
      ,jdbcConfig,code_page_overview_t)
    save(jrDf.selectExpr("CONCAT(date,'-',n_jr) as `ID`","n_jr as `N_JR`","pv as `PV`","uv as `UV`","c_pv as `C_PV`","c_uv as `C_UV`","to_date(date) as `DATE`")
      ,jdbcConfig,code_page_jr_t)
    save(infoDf.selectExpr("CONCAT(date,'-',scp_type) as `ID`","scp_type as `SCP_TYPE`","pv as `PV`","uv as `UV`","c_pv as `C_PV`","c_uv as `C_UV`","to_date(date) as `DATE`")
      ,jdbcConfig,code_page_info_t)
  }
  def save(df: DataFrame, jdbcConfig: Properties, table: String): Unit = {
    df.cache().persist(StorageLevel.MEMORY_AND_DISK_SER_2)
    jdbcConfig.setProperty("table",table)
    df.show()
    df.write.mode("append").jdbc(jdbcConfig.getProperty("url"), jdbcConfig.getProperty("table"), jdbcConfig)
  }
}
