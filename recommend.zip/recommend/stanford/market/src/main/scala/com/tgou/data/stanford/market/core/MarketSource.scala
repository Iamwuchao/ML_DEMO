package com.tgou.data.stanford.market.core

import com.tgou.data.stanford.market.core.utils.HDFSUtils
import org.apache.spark.sql.{DataFrame, Row, SparkSession}
import org.apache.spark.sql.functions.{column, max}
import org.apache.spark.sql.types.StructType
import org.joda.time.LocalDate

/**
  * Created by 李震 on 2017/11/8.
  */
object MarketSource {

  def getCompleteDF(spark: SparkSession, path: String, date: LocalDate, schema: StructType): DataFrame = {
    var df: DataFrame = spark.createDataFrame(spark.sparkContext.emptyRDD[Row], schema)

    for (year <- 2014 until date.getYear) {
      val dataPath = s"${path}/${year}"
      if (HDFSUtils.exists(dataPath)) {
        val csvDF = spark.read
          .options(Map(
            "delimiter" -> "^",
            "nullValue" -> "\\N",
            "quote" -> ""
          ))
          .schema(schema)
          .csv(dataPath + "/*/*")
        df = df.union(csvDF)
      }
    }

    for (month <- 1 until date.getMonthOfYear) {
      val dataPath = s"${path}/${date.getYear}/${"%02d".format(month)}"
      if (HDFSUtils.exists(dataPath)) {
        val csvDF = spark.read
          .options(Map(
            "delimiter" -> "^",
            "nullValue" -> "\\N",
            "quote" -> ""
          ))
          .schema(schema)
          .csv(dataPath + "/*")
        df = df.union(csvDF)
      }
    }

    for (day <- 1 to date.getDayOfMonth) {
      val dataPath = s"${path}/${date.getYear}/${"%02d".format(date.getMonthOfYear)}/${"%02d".format(day)}"
      if (HDFSUtils.exists(dataPath)) {
        val csvDF = spark.read
          .options(Map(
            "delimiter" -> "^",
            "nullValue" -> "\\N",
            "quote" -> ""
          ))
          .schema(schema)
          .csv(dataPath + "/*")
        df = df.union(csvDF)
      }
    }

    if (df != null) df else df
  }


  def getAppendDF(spark: SparkSession, path: String, date: LocalDate, schema: StructType): DataFrame = {
    spark.read
      .options(Map(
        "delimiter" -> "^",
        "nullValue" -> "\\N",
        "quote" -> ""
      ))
      .schema(schema)
      .csv(s"${path}/${date.toString("yyyy/MM/dd")}")
  }


  def getUpdateDF(spark: SparkSession, path: String, date: LocalDate, primaryKey: Seq[String], timestamp: String, schema: StructType): DataFrame = {
    val completeDF = getCompleteDF(spark, path, date, schema)
    getNewestDF(completeDF, primaryKey, timestamp)
  }


  def getDurationDF(spark: SparkSession, path: String, startDate: LocalDate, endDate: LocalDate, schema: StructType): DataFrame = {
    var df: DataFrame = spark.createDataFrame(spark.sparkContext.emptyRDD[Row], schema)

    var date = startDate
    while (date.compareTo(endDate) <= 0) {
      val dataPath = s"${path}/${date.toString("yyyy/MM/dd")}"
      if (HDFSUtils.exists(dataPath)) {
        val csvDF = spark.read
          .options(Map(
            "delimiter" -> "^",
            "nullValue" -> "\\N",
            "quote" -> ""
          ))
          .schema(schema)
          .csv(dataPath + "/*")
        df = df.union(csvDF)
      }

      date = date.plusDays(1)
    }

    df
  }


  def getNewestDF(df: DataFrame, primaryKey: Seq[String], timestamp: String): DataFrame = {
    df.join(df.groupBy(primaryKey.map(column): _*).agg(max(timestamp) as timestamp), primaryKey :+ timestamp)
  }

}
