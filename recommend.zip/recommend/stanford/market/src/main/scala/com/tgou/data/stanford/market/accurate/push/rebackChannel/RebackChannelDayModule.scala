package com.tgou.data.stanford.market.accurate.push.rebackChannel

import com.tgou.data.stanford.market.accurate.push.{OrderSource, PushSource}
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.joda.time.LocalDate

/**
  * Created by 张少锐 on 2017/11/10.
  * 精准推送回访渠道分析-天表
  */
object RebackChannelDayModule {

  def getRebackChannelDay(spark: SparkSession, date: LocalDate): DataFrame = {

    val yesterday = date.toString("yyyy-MM-dd")
    val today = date.plusDays(1).toString("yyyy-MM-dd")
    val rebackChannel = RebackChannelProcessor(spark, date)
    val rebackChannelDay = RebackChannelDayProcessor(spark, date)

    // 获取昨天的uba_page信息表
    spark.sql(
      s"""
         |select id,global,time,member_id
         |from dw.uba_page up
         |where up.his_time = '$yesterday'
         |and up.member_id != ''
       """.stripMargin).createOrReplaceTempView("uba_page_day")

    // 获取去除掉电子小票-支付的订单
    OrderSource(spark,date).onlineOrderDF.
      filter(s"pay_time is not null and pay_method != '010' and pay_time >= concat('$yesterday',' 00:00:00') and pay_time < concat('$today',' 00:00:00')").
        select("member_id","create_time","pay_time","total_amount").createOrReplaceTempView("order")

    // 统计所有的数据
    val allRebackCountDF = rebackChannelDay.processRebackChannelCount(rebackChannel.allPerson).
      selectExpr("*","'所有' as reback_channel")

    // 统计APP的数据
    val appRebackCountDF = rebackChannelDay.processRebackChannelCount(rebackChannel.appPerson).
      selectExpr("*","'APP' as reback_channel")

    // 统计微信的数据
    val wechatRebackCountDF = rebackChannelDay.processRebackChannelCount(rebackChannel.wechatPerson).
      selectExpr("*","'微信' as reback_channel")

    // 统计WEB的数据
    val webRebackCountDF = rebackChannelDay.processRebackChannelCount(rebackChannel.webPerson).
      selectExpr("*","'WEB' as reback_channel")

    // 渠道汇总的数据
    val allCountDF = allRebackCountDF.union(appRebackCountDF).union(wechatRebackCountDF).union(webRebackCountDF)

  /**
    *
    * 精准推送回访渠道分析-天表
    *
    * 字段：
    *
    * - push_id              推送ID
    * - start_time           精准活动开始时间
    * - end_time             精准活动结束时间
    * - push_count           推送人数
    * - receive_count        触达人数
    * - reback_channel       回访渠道(所有，APP，微信，WEB)
    * - reback_count         回访用户数
    * - pay_count            支付人数
    * - pay_sum              支付金额
    * - activity_page_count  全平台流量
    * */
    val fields = Map("push_count"->0,"receive_count"->0,"reback_count"->0,"pay_count"->0,"pay_sum"->0.0,"activity_page_count"->0)

    rebackChannel.pushPerson.select("push_task_id","start_time","end_time").distinct().
      join(rebackChannelDay.processPushPersonCount(rebackChannel.pushPerson),"push_task_id").
      join(allCountDF,"push_task_id").
      selectExpr(
        "push_task_id as push_id",
        "start_time",
        "end_time",
        "push_count",
        "receive_count",
        "reback_channel",
        "reback_count",
        "pay_count",
        "pay_sum",
        "activity_page_count"
      ).na.fill(fields)

  }

}
