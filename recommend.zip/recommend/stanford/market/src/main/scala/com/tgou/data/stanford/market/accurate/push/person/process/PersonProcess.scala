package com.tgou.data.stanford.market.accurate.push.person.process

import org.apache.spark.sql.DataFrame

/**
  * Created by 李震 on 2017/11/20.
  */
trait PersonProcess {

  /**
    * 计算推送人数
    *
    * @return
    *
    * 字段：
    *
    * - push_task_id  推送 ID
    * - push_count  推送人数
    * - receive_count  推送触达人数
    *
    * */
  def processPushPersonCount: DataFrame

}
