package com.tgou.data.stanford.market.page.funnel.analysis.service

import org.apache.spark.sql.DataFrame

trait FunnelService {

  def getFunnel_1: DataFrame

  def getFunnel_2: DataFrame

  def getFunnel_3: DataFrame

}
