package com.tgou.data.stanford.market.page.funnel.normal

import java.time.LocalDate

import ch.cern.sparkmeasure.StageMetrics
import com.tgou.data.stanford.market.page.util.udf.{HardcoreFunnelUDAF, SumFunnelUDAF}
import org.apache.spark.sql.SparkSession

import scala.util.Success

object FunnelMain {
  def main(args: Array[String]): Unit = {

    def str2date(str: String): LocalDate= {
      scala.util.Try(str.toInt) match {
        case Success(_) => LocalDate.now().plusDays(str.toInt);
        case _ => LocalDate.parse(str)
      }
    }

    val appName = args(0)
    val pages = args(1)
    val date = str2date(args(2))

    System.setProperty("hive.metastore.uris", "thrift://hnode1:9083")
    val spark = if (appName.startsWith("test")) {
      // Debug 模式
      SparkSession.builder()
        .master("local")
        .appName(appName)
        .enableHiveSupport()
        .getOrCreate()
    } else {
      SparkSession.builder()
        .master("yarn")
        .appName(appName)
        .enableHiveSupport()
        .config("spark.eventLog.enabled", true)
        .config("spark.eventLog.dir", "hdfs://nameservice1/user/spark/applicationHistory")
        .config("spark.yarn.historyServer.address", "http://hnode10:18080")
        .getOrCreate()
    }

    // 日志级别
    spark.sparkContext.setLogLevel("WARN")

    try {
      val sm = StageMetrics(spark)
      sm.begin()

      // 执行
      execute(spark, appName, pages, date)

      sm.end()
      sm.printReport()
    } catch {
      case e: Exception => throw new RuntimeException(e)
    } finally {
      spark.close()
    }
  }

  def execute(spark: SparkSession, appName: String, pages: String, date: LocalDate): Unit = {
    val pageList = pages.split(",").toList
    spark.udf.register("funnel_count", new HardcoreFunnelUDAF(pageList))
    spark.udf.register("to_funnel_sum", new SumFunnelUDAF(pageList))
    val p1_like = "'" + pageList(0) + "%'"
    val afterSqlText = pageList.map(p => " page like '" + p + "%'").mkString(" or ")

    /**
      * 获得了funnel_count
      */
    val funnel_count_t_sqlText =
      s"""
         | SELECT
         | p1.uuid,
         | p1.deep,
         | p1.path,
         | funnel_count(p2.deep, p2.page) as funnel_count
         | from
         | ( SELECT p1.deep,p1.uuid,p1.session_id,p0.path
         |         FROM
         |    (
         |      (SELECT uuid,session_id,deep,page from dw.uba_page where his_time = '$date' and page like $p1_like and deep != 0) p1
         |      INNER join (select uuid,session_id,deep,page,CONCAT( 'm.51tiangou.com',substr(split(orgin,'[?]')[0],24)) as path from dw.uba_page where his_time = '$date') p0
         |      ON p0.deep +1 = p1.deep
         |        and p0.uuid = p1.uuid
         |        and p0.session_id = p1.session_id
         |        and p0.page not like $p1_like
         |        )
         |        UNION (select uuid,session_id,deep,'-' as path from dw.uba_page where his_time = '$date' and page like $p1_like and deep = 0)
         |  ) p1
         | inner join (
         |    select uuid,session_id,deep,page from dw.uba_page where his_time = '$date'  and ($afterSqlText)
         | ) p2
         | on p2.deep >= p1.deep
         | and p2.uuid = p1.uuid
         | and p2.session_id = p1.session_id
         | GROUP BY p1.uuid,p1.session_id,p1.deep,p1.path
           """.stripMargin
    val funnelCountDf = spark.sql(funnel_count_t_sqlText)
    funnelCountDf.cache()
    funnelCountDf.createOrReplaceTempView("funnel_t")

    /**
      *
      */
    val sQLText =
      s"""
         | SELECT path,funnel_sum FROM (
         | SELECT path,
         |      to_funnel_sum(funnel_count,uv) as funnel_sum,
         |       CASE WHEN path = '全部' then 0
         |       ELSE 1 END AS to_order
         |       FROM (
         |    SELECT count(distinct uuid) as uv,path,funnel_count  FROM
         |    (
         |    (SELECT uuid, '全部' as path, max(funnel_count) as funnel_count FROM funnel_t group by uuid)
         |      UNION
         |    (SELECT uuid,path,funnel_count FROM funnel_t)
         |    ) t
         |    GROUP BY path,funnel_count
         |  ) GROUP BY path
         |  ) order by to_order,path
       """.stripMargin
    val resultDf = spark.sql(sQLText)
    resultDf.cache()
    resultDf.show(100,true)
    resultDf.coalesce(1).write.mode("overwrite").json("/tmp/caoz/normal_funnel/"+ pages + "-" + date)
  }
}
