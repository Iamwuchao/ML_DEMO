package com.tgou.data.stanford.market.member
import java.time.LocalDate
import java.util.Properties

import org.apache.spark.sql.SparkSession

import scala.util.Success

/**
  * init jdbc Config。
  * @param args
  */
class JdbcBootstrap(args: Array[String]) {
  var appName = "default-name"
  var date = LocalDate.now().plusDays(-1)

  def bootstrap(execute: (SparkSession, String, LocalDate, Properties) => Unit): Unit = {
    appName = args(0)

    def str2date(str: String): LocalDate= {
      scala.util.Try(str.toInt) match {
        case Success(_) => LocalDate.now().plusDays(str.toInt);
        case _ => LocalDate.parse(str)
      }
    }
    var begin = str2date(args(1))
    val end = str2date(args(2))

    val jdbcProperties = new Properties
    jdbcProperties.setProperty("driver","com.mysql.jdbc.Driver")
    jdbcProperties.setProperty("url",  args(3))
    jdbcProperties.setProperty("user",  args(4))
    jdbcProperties.setProperty("password",  args(5))

    val spark = SparkSession.builder()
      .enableHiveSupport()
      .appName(appName)
      .config("hive.metastore.uris","thrift://hnode1:9083")
      .getOrCreate()
    spark.sparkContext.setLogLevel("WARN")// 日志级别

    try {
      while (!begin.isAfter(end)){
        date = begin
        begin = begin.plusDays(1)
        execute(spark, appName, date, jdbcProperties)
      }
    } catch {
      case e: Exception => throw new RuntimeException(e)
    } finally {
      spark.close()
    }
  }
}

object JdbcBootstrap {
  def apply(args: Array[String]): JdbcBootstrap = new JdbcBootstrap(args)

}
