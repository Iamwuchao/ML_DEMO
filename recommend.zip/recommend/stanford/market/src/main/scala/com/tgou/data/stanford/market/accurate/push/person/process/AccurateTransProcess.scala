package com.tgou.data.stanford.market.accurate.push.person.process

import org.apache.spark.sql.DataFrame

/**
  * Created by 李震 on 2017/11/20.
  */
trait AccurateTransProcess {

  /**
    * 处理精准交易
    *
    * @return
    *
    * 字段：
    *
    * - push_task_id  推送任务 ID
    * - group  分组
    * - accurate_amount  精准交易金额
    * - is_use_coupon  是否使用券
    *
    * */
  def processAccurateTransDF: DataFrame

}
