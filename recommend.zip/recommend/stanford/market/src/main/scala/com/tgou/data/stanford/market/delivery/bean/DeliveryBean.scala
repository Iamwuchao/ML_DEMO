package com.tgou.data.stanford.market.delivery.bean

/**
  * Created by 李震 on 2018/1/4.
  */
case class DeliveryBean (
                          tracking_no: String,
                          accept_time: String,
                          way_time: String,
                          receive_time: String,
                          state: String,
                          tracing_time: String,
                          tracing_msg: String
                        )
