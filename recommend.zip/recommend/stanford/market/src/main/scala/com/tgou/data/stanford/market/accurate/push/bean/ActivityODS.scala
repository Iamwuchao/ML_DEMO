package com.tgou.data.stanford.market.accurate.push.bean

/**
  * Created by 李震 on 2017/11/16.
  */
case class ActivityODS (
                        id: Long,
                        activity_type: Int,
                        title: String,
                        state: String,
                        image_url: String,
                        start_time: String,
                        end_time: String,
                        version: Int,
                        creator: String,
                        create_time: String,
                        source: Int,
                        heat: Int,
                        fk_advertise_id: Long,
                        pv: Long,
                        uv: Long,
                        show_type: Int,
                        click_url: String,
                        custom_type: Int,
                        daily_limit_qty: Long,
                        limit_qty: Long,
                        use_start: String,
                        use_end: String,
                        data_source: Int,
                        affect_price: Int,
                        slogan: String,
                        subsidy: Int,
                        modify_time: String,
                        authority: Int
                       )
