package com.tgou.data.stanford.market.page.funnel.analysis.service.impl

import com.google.inject.Inject
import com.tgou.data.stanford.market.page.funnel.analysis.service.FunnelService
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.joda.time.LocalDate

class FunnelServiceImpl  @Inject()(spark: SparkSession, date: LocalDate) extends FunnelService{
  val caseYtSql =
    """
      | CASE WHEN yt = 1 THEN '百货' WHEN yt = 2 THEN '超市' WHEN yt = 3 THEN '品牌商' WHEN yt = 4 THEN '跨境'
      | ELSE '百货' END as yt
    """.stripMargin

  /**
    * 用的是UV。且未做强时间关联。默认交易前必先创建订单，创建订单前，必须加购物车/立即购买，也就必须浏览了商品详情页。
    * 还要跟踪购买的情况。
    * @return
    */
  override def getFunnel_1: DataFrame = {
    val pageInnerTodoSql =
      s"""
         | SELECT uuid,todo,yt,max(is_order) as is_order FROM
         | (SELECT t1.uuid,
         |  CASE WHEN t2.page = '10.shopcar' then 1 when t2.page = '10.conmorder' then 2 ELSE 3 END AS todo,
         |  t1.yt,
         |  CASE WHEN t3.member_id is not null THEN 1 ELSE 0 END as is_order
         |  FROM
         |  listing_page_t t1
         | LEFT JOIN today_page_t t2
         |  ON t1.uuid = t2.uuid
         |  AND t1.session_id = t2.session_id
         |  AND t1.deep +1 = t2.deep
         | LEFT JOIN
         |  zuhe_t zh_t
         |  ON t1.listing_id = zh_t.fk_mall_parent_id
         | LEFT JOIN
         |  (SELECT
         |    t1.mall_product_id as listing_id,
         |    t1.product_id,
         |    t2.member_id
         |   FROM dw.order_product t1
         |    INNER JOIN (SELECT member_id,order_id FROM  dw.order_information WHERE his_time = '$date') t2
         |    ON t1.tgou_order_id = t2.order_id
         |    WHERE t1.his_time = '$date' and create_time>= '$date' and t1.create_time < '${date.plusDays(1)}'
         |    ) t3
         |  ON t1.member_id = t3.member_id
         |  AND (t1.listing_id = t3.listing_id
         |      OR zh_t.fk_mall_sub_id = t3.listing_id)
         | WHERE (t2.page = '10.conmorder' or t2.page = '10.shopcar') AND t2.member_id != ''
         | ) GROUP BY uuid,todo,yt
       """.stripMargin
    val pageInnerTodoDf = spark.sql(pageInnerTodoSql)
    pageInnerTodoDf.cache()
    pageInnerTodoDf.createOrReplaceTempView("inner_todo_pre_t")
    //浏览到-》点击的。
    var sQLText =
      s"""
         | SELECT uuid,
         |  MAX(shop_car_uuid) as shop_car_uuid,
         |  CASE WHEN MAX(shop_car_order) = 1 THEN MAX(shop_car_uuid) ELSE NULL END  as shop_car_order_uuid,
         |  MAX(order_uuid) as order_uuid,
         |  CASE WHEN MAX(o_order) = 1 THEN MAX(order_uuid) ELSE NULL END   as o_order_uuid,
         |  CASE WHEN MAX(shop_car_uuid) is null and MAX(order_uuid) is null THEN uuid
         |  ELSE null END AS nothing_uuid,
         |  yt
         |  FROM(
         | SELECT t1.uuid,
         |    todo1.uuid as shop_car_uuid,
         |    todo1.is_order as shop_car_order,
         |    todo2.uuid as order_uuid,
         |    todo2.is_order as o_order,
         |    t1.yt FROM
         |  ( SELECT distinct uuid,yt FROM listing_page_t) t1
         | LEFT JOIN inner_todo_pre_t todo1
         |  ON t1.uuid =  todo1.uuid
         |  AND t1.yt = todo1.yt
         |  AND todo1.todo = 1
         | LEFT JOIN inner_todo_pre_t todo2
         |  ON t1.uuid =  todo2.uuid
         |  AND t1.yt = todo2.yt
         |  AND todo2.todo = 2
         | ) GROUP BY uuid,yt
       """.stripMargin
    val tmpDf = spark.sql(sQLText)
    tmpDf.cache()
    tmpDf.createOrReplaceTempView("inner_todo_t")
    sQLText =
      s"""
         | (SELECT count(distinct uuid) as uv,
         | count(distinct shop_car_uuid) as shop_cart_uv,
         | count(distinct shop_car_order_uuid) as shop_cart_buy_uv,
         | count(distinct order_uuid) as order_uv,
         | count(distinct o_order_uuid) as order_buy_uv,
         | count(distinct nothing_uuid) as nothing_uv,
         | '全部' as yt,0 as order
         | FROM inner_todo_t)
         | UNION
         | (
         | SELECT count(distinct uuid) as uv,
         | count(distinct shop_car_uuid) as shop_cart_uv,
         | count(distinct shop_car_order_uuid) as shop_cart_buy_uv,
         | count(distinct order_uuid) as order_uv,
         | count(distinct o_order_uuid) as order_buy_uv,
         | count(distinct nothing_uuid) as nothing_uv,
         | $caseYtSql,yt as order
         | FROM inner_todo_t GROUP BY yt
         | )
       """.stripMargin
    val resultSql =
      s"""
         | SELECT '$date' as date,
         | yt,
         | order_uv,
         | CONCAT(round(order_uv*100/uv,2),'%') as order_ratio,
         | order_buy_uv,
         | CONCAT(round(order_buy_uv*100/order_uv,2),'%') as order_buy_ratio,
         | shop_cart_uv,
         | CONCAT(round(shop_cart_uv*100/uv,2),'%') as shop_cart_ratio,
         | shop_cart_buy_uv,
         | CONCAT(round(shop_cart_buy_uv*100/shop_cart_uv,2),'%') as shop_cart_buy_ratio,
         | nothing_uv,
         | CONCAT(round(nothing_uv*100/uv,2),'%') as nothing_ratio,
         | uv FROM
         | ($sQLText) t
         | order by order
       """.stripMargin
    spark.sql(resultSql)
  }

  /**
    *  商品详情页UV、商品详情页打开率、商品详情页流失率
    * @return
    */
  override def getFunnel_2: DataFrame = {
    val totalUv =
      s"""
         | SELECT count(distinct uuid) as uv,'$date' as date
         | FROM dw.uba_page
         | WHERE his_time = '$date'
       """.stripMargin
    // 注册个临时表。uuid是访问商品详情页的，yt是业态。
    var sQLText =
      s"""
         | SELECT
         | t1.uuid,t2.yt,t1.is_out
         |  FROM dw.uba_page t1
         | INNER JOIN
         |  listing_t t2
         |  ON subString(t1.bk,6) = t2.listing_id
         | WHERE t1.his_time = '$date' and t1.a_b = '10.pd'
       """.stripMargin
    val tmpDf = spark.sql(sQLText)
    tmpDf.cache()
    tmpDf.createOrReplaceTempView("listing_yt_out_t")
    sQLText =
      s"""
         | (
         |  SELECT t1.uv,t2.out_uv,t3.uv as total_uv,'全部' as yt,0 as order FROM
         |  (SELECT count(distinct uuid) as uv,'$date' as date
         |    FROM  listing_yt_out_t) t1
         |    INNER JOIN
         |    (SELECT COUNT(distinct uuid) as out_uv, '$date' as date
         |    FROM  listing_yt_out_t where is_out =1) t2
         |    ON t1.date = t2.date
         |    INNER JOIN ($totalUv) t3
         |    ON t1.date = t3.date
         |  )
         |  UNION
         |  (
         |    SELECT t1.uv,t2.out_uv,t3.uv as total_uv,
         |     CASE WHEN t1.yt = 1 THEN '百货' WHEN t1.yt = 2 THEN '超市' WHEN t1.yt = 3 THEN '品牌商' WHEN t1.yt = 4 THEN '跨境'
         |      ELSE '百货' END as yt,t1.yt as order
         |     FROM
         |  (SELECT count(distinct uuid) as uv, yt, '$date' as date
         |    FROM  listing_yt_out_t GROUP BY yt) t1
         |    INNER JOIN
         |  (SELECT COUNT(distinct uuid) as out_uv, yt, '$date' as date
         |    FROM  listing_yt_out_t where is_out =1 GROUP BY yt) t2
         |    ON t1.date = t2.date
         |    AND t1.yt = t2.yt
         |    INNER JOIN ($totalUv) t3
         |    ON t1.date = t3.date
         |  )
       """.stripMargin
    val resultSql =
      s"""
         | SELECT '$date' as date,
         |    yt,
         |    uv,
         |    CONCAT(round(uv*100/total_uv,2),'%') as uv_ratio,
         |    CONCAT(round(out_uv*100/uv,2),'%') as out_ratio,
         |    total_uv FROM
         | ($sQLText) t
         | ORDER BY t.order
       """.stripMargin
    spark.sql(resultSql)
  }

  override def getFunnel_3: DataFrame = {

    var sqlText =
      s"""
         | SELECT t1.uuid,t2.yt,CONCAT( 'm.51tiangou.com',substr(split(t1.url,'[?]')[0],24)) as path
         |  FROM
         |  today_page_t t1
         | INNER JOIN listing_page_t t2
         |  ON t1.uuid = t2.uuid
         |  AND t1.session_id = t2.session_id
         |  AND t1.deep +1 = t2.deep
       """.stripMargin
    val tmpDf = spark.sql(sqlText)
    tmpDf.cache()
    tmpDf.createOrReplaceTempView("path_t")
    val pathSql =
      s"""
         | (
         | SELECT COUNT(distinct uuid) as uv, path,'全部' as yt,0 as order,'$date' as date
         |    FROM path_t
         |  GROUP BY path
         | )
         | UNION
         | (
         |  SELECT COUNT(distinct uuid) as uv, path,$caseYtSql,yt as order,'$date' as date
         |    FROM path_t
         |  GROUP BY yt,path
         | )
       """.stripMargin

    val totalUvSql =
      s"""
         | (
         | SELECT count(distinct uuid) as total_uv,'$date' as date,'全部' as yt
         | FROM listing_page_t
         | ) UNION
         | ( SELECT count(distinct uuid) as total_uv,'$date' as date,$caseYtSql FROM listing_page_t GROUP BY yt)
       """.stripMargin
    sqlText =
      s"""
         | SELECT t1.date,
         | t1.yt,
         | t1.path,
         | t1.uv,
         | CONCAT(round(t1.uv*100/t2.total_uv,2),'%') as uv_ratio FROM
         | ($pathSql) t1
         | INNER JOIN
         | ($totalUvSql) t2
         | ON t1.yt = t2.yt AND t1.date = t2.date
         | WHERE round(t1.uv*100/t2.total_uv,2) > 1
         | order by t1.yt,t1.uv desc
       """.stripMargin
    spark.sql(sqlText)
  }

}
