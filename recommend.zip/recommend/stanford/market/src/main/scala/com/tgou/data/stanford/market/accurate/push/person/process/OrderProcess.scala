package com.tgou.data.stanford.market.accurate.push.person.process

import org.apache.spark.sql.DataFrame

/**
  * Created by 李震 on 2017/11/20.
  */
trait OrderProcess {

  /**
    * 处理订单
    *
    * @return
    *
    * 字段：
    *
    * - push_task_id 推送任务 ID
    * - member_id 会员 ID
    * - is_buy_now 是否立即购买
    * - is_buy_now_pay 是否立即购买并支付
    * - is_shopping_cart 是否收藏或加入购物车
    * - is_shopping_cart_create 是否收藏或加入购物车并下单
    * - is_shopping_cart_pay 是否收藏或加入购物车并支付
    * - is_order_create 是否下单
    * - first_order_create_time 首次下单时间
    * - is_order_pay 是否支付
    * - first_order_pay_time 首次支付时间
    *
    * */
  def processOrderDF: DataFrame


  /**
    * 推送会员收藏和加入购物车数据
    *
    * @return
    *
    * - push_task_id 推送 ID
    * - member_id 会员 ID
    * - is_shopping_cart 是否收藏或加入购物车
    *
    * */
  def processShoppingCartDF(): DataFrame

}
