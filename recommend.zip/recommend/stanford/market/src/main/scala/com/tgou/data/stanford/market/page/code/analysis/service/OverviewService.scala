package com.tgou.data.stanford.market.page.code.analysis.service

import java.time.LocalDate

import org.apache.spark.sql.{DataFrame, SparkSession}

object OverviewService {
  def getOverview(spark: SparkSession, date: LocalDate): DataFrame = {
    val sQLText =
      s"""
         | SELECT t1.uv,t1.pv,t2.c_uv,t2.c_pv,t1.date FROM
         | (select count(distinct member_id) as uv,count(1) as pv, '$date' as date
         |    from dw.uba_page where his_time = '$date' and page = '05.code' and member_id != '') t1
         |  inner join
         |  (select count(distinct member_id) as c_uv,count(1) as c_pv,'$date' as date
         |    from dw.uba_scp where his_time = '$date' and member_id != '' and a_b = '05.code') t2
         |  ON t1.date = t2.date
       """.stripMargin
    spark.sql(sQLText)
  }
}
