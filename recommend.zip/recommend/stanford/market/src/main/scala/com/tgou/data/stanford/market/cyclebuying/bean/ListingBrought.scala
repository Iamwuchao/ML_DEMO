package com.tgou.data.stanford.market.cyclebuying.bean

import java.time.LocalDate

case class ListingBrought(pay_time: LocalDate, quantity: Int){}
