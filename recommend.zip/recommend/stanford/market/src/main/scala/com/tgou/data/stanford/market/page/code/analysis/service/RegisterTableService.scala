package com.tgou.data.stanford.market.page.code.analysis.service

import java.time.LocalDate

import com.tgou.data.stanford.market.page.code.analysis.util.FullMemberIdHelper
import org.apache.spark.sql.SparkSession

object RegisterTableService {
  def registerDayMemberTable(spark: SparkSession, date: LocalDate): Unit = {
    val sqlText =
      s"""
          | SELECT * FROM
          | (SELECT distinct member_id as m_ud,1 as m_type FROM
          | dw.uba_page where his_time = '$date' and member_id != '')
          | UNION
          | (select uuid as m_ud,2 as m_type FROM
          | dw.uba_page where his_time = '$date' group by uuid having max(member_id) is  null or max(member_id) = '')
       """.stripMargin
    val df = spark.sql(sqlText)
    df.cache()
    df.createOrReplaceTempView("day_member")
  }

  /**
    * 必须在上面的表，完成以后，才能使用。
    * 使用了店铺的信息。区分超市跟百货。只有yt = 1的时候，才展示专柜动态。
    */
  def registerDayPageMemberTable(spark: SparkSession, date: LocalDate): Unit = {
    val sqlText =
      s"""
        | SELECT
        | CASE WHEN t1.global in ('ios','android') THEN 1
        | ELSE 2 END AS global,
        | t2.m_ud,
        | t3.yt
        |  FROM dw.uba_page t1
        | INNER JOIN
        | day_member t2
        | ON (t1.member_id = t2.m_ud or t1.uuid = t2.m_ud)
        | LEFT JOIN
        | (SELECT id,yt FROM dw.store where his_time = '$date') t3
        | ON t1.store_id = t3.id
        | where t1.his_time = '$date' and t1.page = '05.code'
      """.stripMargin
    val df = spark.sql(sqlText)
    df.cache()
    df.createOrReplaceTempView("day_page_code_member")
  }

  def fullMemberScpTable(spark: SparkSession, date: LocalDate): Unit ={
    //scp这个表要不要过滤。time,需要么？
    //就是member_id补全。也不能直接拿最大的uuid来补。嗯
    val sqlText =
      s"""
        | SELECT member_id,uuid,time,scp FROM dw.uba_scp where his_time = '$date'
      """.stripMargin
    val tmpDf = spark.sql(sqlText)
    val scpMemberDf = FullMemberIdHelper.fullMemberIdWithUuid(spark, tmpDf)
    scpMemberDf.cache()
    scpMemberDf.write.mode("overwrite").parquet("/tmp/caoz/fm_scp")
    scpMemberDf.createOrReplaceTempView("fm_scp")
  }

}
