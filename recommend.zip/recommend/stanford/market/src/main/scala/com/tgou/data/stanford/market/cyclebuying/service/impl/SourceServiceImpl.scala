package com.tgou.data.stanford.market.cyclebuying.service.impl

import com.google.inject.Inject
import com.tgou.data.stanford.market.core.MarketSource
import com.tgou.data.stanford.market.core.utils.BeanUtils
import com.tgou.data.stanford.market.cyclebuying.bean.{ProductProperty, PropertyValue}
import com.tgou.data.stanford.market.cyclebuying.service.SourceService
import org.apache.spark.sql.{DataFrame, SparkSession}
import java.time.LocalDate

class SourceServiceImpl @Inject()(spark: SparkSession, date: LocalDate) extends SourceService{

  override def productPropertyDf: DataFrame = {
    val jodaTime = org.joda.time.LocalDate.parse(date.toString)
    MarketSource.getUpdateDF(
      spark,
      "/tiangou/item/product_property",
      jodaTime,
      Seq("id"),
      "modify_time",
      BeanUtils.getSchemaFromBean[ProductProperty]
    )
  }

  override def propertyValueDf: DataFrame = {
    val jodaTime = org.joda.time.LocalDate.parse(date.toString)
    MarketSource.getAppendDF(
      spark,
      "/tiangou/item/property_value",
      jodaTime,
      BeanUtils.getSchemaFromBean[PropertyValue]
    )
  }
}
