package com.tgou.data.stanford.market.accurate.push.person.bean.agg

/**
  * Created by 李震 on 2017/11/27.
  */
case class AccurateTransGroupAgg (
                                   push_task_id: Long,
                                   group: String,
                                   kdj: Double,
                                   ship_coupon_count: Long
                                 )
