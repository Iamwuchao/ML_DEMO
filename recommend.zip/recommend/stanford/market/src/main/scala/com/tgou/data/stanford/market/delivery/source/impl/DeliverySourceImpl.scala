package com.tgou.data.stanford.market.delivery.source.impl

import com.google.inject.Inject
import com.tgou.data.stanford.market.core.MarketSource
import com.tgou.data.stanford.market.core.utils.BeanUtils
import com.tgou.data.stanford.market.delivery.bean.{DeliveryVendor, TgouPackage, ThirdDeliveryInfoRecord, ThirdDeliveryInfoRecordLog}
import com.tgou.data.stanford.market.delivery.source.DeliverySource
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.joda.time.LocalDate

/**
  * Created by 李震 on 2018/1/4.
  */
class DeliverySourceImpl @Inject()(spark: SparkSession, date: LocalDate) extends DeliverySource {

  override def tgouPackageDF: DataFrame = {
    MarketSource.getUpdateDF(
      spark,
      "/tiangou/tgouorder/tgou_package",
      date,
      Seq("tracking_no", "fk_tgou_order_id"),
      "modify_time",
      BeanUtils.getSchemaFromBean[TgouPackage]
    )
  }

  override def thirdDeliveryInfoRecordDF: DataFrame = {
    MarketSource.getUpdateDF(
      spark,
      "/tiangou/tgouorder/third_delievry_info_record",
      date,
      Seq("tracking_no"),
      "modify_time",
      BeanUtils.getSchemaFromBean[ThirdDeliveryInfoRecord]
    )
  }

  override def thirdDeliveryInfoRecordLogDF: DataFrame = {
    MarketSource.getCompleteDF(
      spark,
      "/tiangou/tgouorder/third_delievry_info_record_log",
      date,
      BeanUtils.getSchemaFromBean[ThirdDeliveryInfoRecordLog]
    )
  }

  override def deliveryVendorDF: DataFrame = {
    MarketSource.getAppendDF(
      spark,
      "/tiangou/tgouorder/delivery_vendor",
      date,
      BeanUtils.getSchemaFromBean[DeliveryVendor]
    )
  }
}
