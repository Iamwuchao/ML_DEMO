package com.tgou.data.stanford.market.member.service

import java.time.LocalDate
import java.util.Date

import com.tgou.data.stanford.market.member.utils.DateIntervalUtil
import org.apache.spark.sql.{DataFrame, SparkSession}

case class MemberRetention(date: LocalDate, member_count: Int, retention_type: String, retention_count: Int){}

object MemberRetentionCalculator {
  val yesterday = LocalDate.now().plusDays(-1)





  def calRetention(spark: SparkSession, date: LocalDate): DataFrame = {
    val dayRetentionDf = calDayRetention(spark, date)
    var resultDf = dayRetentionDf
    if(DateIntervalUtil.dateValidate(date,"week").isValidate){
      resultDf = resultDf.union(calWeekRetention(spark, date))
    }
    if(DateIntervalUtil.dateValidate(date, "month").isValidate){
      resultDf = resultDf.union(calMonthRetention(spark, date))
    }
    resultDf
  }

  def getMemberRegisterSql(date: LocalDate, daysAgo: LocalDate): String = {
    val memberRegisterDaySql =
      s"""
         | SELECT member_id, register_time FROM dw.member where his_time = '$yesterday'
         | AND register_time > '$daysAgo'
         | AND register_time < '${date.plusDays(1)}'
      """.stripMargin
    memberRegisterDaySql
  }

  //14天的留存
  def calDayRetention(spark: SparkSession, date: LocalDate): DataFrame = {
    val daysAgo14 = date.plusDays(-14)
    val memberRegisterDaySql = getMemberRegisterSql(date, daysAgo14)
    val sqlText =
      s"""
        | SELECT
        | '$date' as `date`,
        |  count(distinct t1.member_id) as member_count,
        | 'day' as retention_type,
        |  datediff('$date',to_date(t2.register_time)) as retention_count
        |  FROM dw.uba_page t1
        | INNER JOIN ($memberRegisterDaySql) t2
        | ON t1.member_id = t2.member_id
        | WHERE t1.his_time = '$date'
        | AND t1.member_id != ''
        | GROUP BY to_date(t2.register_time)
      """.stripMargin
    spark.sql(sqlText).filter("retention_count<=13")
  }

  //12周的留存
  def calWeekRetention(spark: SparkSession, date: LocalDate): DataFrame = {
    val weekAgo12 = date.plusWeeks(-12)
    val memberRegisterDaySql = getMemberRegisterSql(date, weekAgo12)
    spark.udf.register("getWeekBegin",(date: String)=>LocalDate.parse(date).plusDays(-LocalDate.parse(date).getDayOfWeek.getValue+1).toString)
    val sqlText =
      s"""
        | SELECT
        | '$date' as `date`,
        | count(distinct t1.member_id) as member_count,
        | 'week' as retention_type,
        |  datediff('$date',getWeekBegin(to_date(t2.register_time)))/7-1 as retention_count
        |  FROM dw.uba_page t1
        | INNER JOIN ($memberRegisterDaySql) t2
        | ON t1.member_id = t2.member_id
        | WHERE t1.his_time >= getWeekBegin(to_date('$date'))
        | AND t1.his_time <= '$date'
        | AND t1.member_id != ''
        | GROUP BY getWeekBegin(to_date(t2.register_time))
      """.stripMargin
    spark.sql(sqlText).filter("retention_count<=11")
  }

  //12月的留存
  def calMonthRetention(spark: SparkSession, date: LocalDate): DataFrame = {
    val monthAgo12 = date.plusMonths(-12)
    val memberRegisterDaySql = getMemberRegisterSql(date, monthAgo12)
    spark.udf.register("getMonthBegin",(date: String)=>LocalDate.parse(date).plusDays(-LocalDate.parse(date).getDayOfMonth+1).toString)
    spark.udf.register("monthdiff",(date1: String, date2: String) =>{
      val dateTime1 = LocalDate.parse(date1)
      val dateTime2 = LocalDate.parse(date2)
      (dateTime1.getMonthValue-dateTime2.getMonthValue + 12 * (dateTime1.getYear-dateTime2.getYear))%13
    })
    val sqlText =
      s"""
        | SELECT
        | '$date' as `date`,
        | count(distinct t1.member_id) as member_count,
        | 'month' as retention_type,
        |  monthdiff('$date',getMonthBegin(to_date(t2.register_time))) as retention_count
        |  FROM dw.uba_page t1
        | INNER JOIN ($memberRegisterDaySql) t2
        | ON t1.member_id = t2.member_id
        | WHERE t1.his_time >= getMonthBegin(to_date('$date'))
        | AND t1.his_time <= '$date'
        | AND t1.member_id != ''
        | GROUP BY getMonthBegin(to_date(t2.register_time))
      """.stripMargin
    spark.sql(sqlText).filter("retention_count<=11")
  }

}
