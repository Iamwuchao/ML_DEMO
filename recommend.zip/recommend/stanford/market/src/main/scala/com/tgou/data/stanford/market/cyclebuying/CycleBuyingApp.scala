package com.tgou.data.stanford.market.cyclebuying

import java.util.Properties

import com.google.inject.{Guice, Inject}
import com.tgou.data.stanford.market.cyclebuying.service.SourceService
import com.tgou.data.stanford.market.cyclebuying.udf.{FaceMaskCycle2UDAF, FaceMaskCycleUDAF, FaceMaskQuantityUDAF}
import com.tgou.data.stanford.market.member.JdbcBootstrap
import org.apache.spark.sql.execution.datasources.jdbc.{JDBCOptions, JdbcUtils}
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.storage.StorageLevel
import java.time.LocalDate
/**
  * 周期购分析--面膜
  */
object CycleBuyingApp {

  def main(args: Array[String]): Unit = {
    JdbcBootstrap(args).bootstrap(execute)
  }

  def execute(spark: SparkSession, appName: String, date: LocalDate, jdbcConfig: Properties): Unit = {
    val injector = Guice.createInjector(CycleBuyingModule(spark, appName, date, jdbcConfig))
    injector.getInstance(classOf[CycleBuyingApp]).run
  }

  class CycleBuyingApp @Inject()(spark: SparkSession, date: LocalDate, jdbcConfig: Properties) {
    @Inject
    var source:SourceService = _

    def run: Unit = {
      // 加载商品属性数据
      val productPropertyDf = source.productPropertyDf
      productPropertyDf.createOrReplaceTempView("product_property_t")
      // 加载商品属性值的数据
      val propertyValueDf = source.propertyValueDf
      propertyValueDf.createOrReplaceTempView("property_value_t")
      // 通过商品属性，得到商品的度量
      spark.udf.register("get_quantity",new FaceMaskQuantityUDAF)
      spark.udf.register("face_mask_cycle",new FaceMaskCycleUDAF(java.time.LocalDate.parse(date.toString())))
      spark.udf.register("face_mask_cycle2",new FaceMaskCycle2UDAF(java.time.LocalDate.parse(date.toString())))
      //现在只涉及面膜。
      val faceMaskCycleSql =
        s"""
           | SELECT t.product_id,
           |  1 AS type,
           |  get_quantity(pv.name,pv.fk_property_id) as quantity
           |  FROM
           | (SELECT product_id FROM dw.product WHERE his_time = '$date' AND product_third_category = '101821' AND name like '%面膜%') t
           | LEFT JOIN product_property_t pp
           | ON t.product_id = pp.fk_product_id
           | LEFT JOIN property_value_t pv
           | ON pv.id = pp.fk_property_value_id
           | AND pv.fk_property_id in ('64899','64896','64900','64898')
           | GROUP BY t.product_id
         """.stripMargin

      //所有可以周期购的品类
      val productSqlText =
        s"""
          | SELECT * FROM
          | ($faceMaskCycleSql) face_mask
        """.stripMargin
      //通过listing，过滤，只要跨境的商品。不过存在个问题，麦凯乐进口超市的问题，暂时不知道如何解决。
      var sqlText =
        s"""
          | SELECT t1.listing_id,t1.product_id,t3.type,t3.quantity  FROM
          | (SELECT listing_id,source,store_id,product_id,name FROM dw.listing where his_time = '$date' and source = '4') t1
          | INNER JOIN (SELECT id FROM dw.store where his_time = '$date' AND is_international = 1 and yt = '4') t2
          | ON t1.store_id = t2.id
          | INNER JOIN ($productSqlText) t3
          | ON t1.product_id = t3.product_id
          | AND t3.quantity > 0
        """.stripMargin
      val cyclingProductDf = spark.sql(sqlText)
      cyclingProductDf.createOrReplaceTempView("cycling_product")
      cyclingProductDf.show()

      sqlText =
        s"""
           | SELECT oi.member_id,
           | cp.type,
           | CASE
           |  WHEN cp.type = 1
           |    THEN face_mask_cycle(cp.quantity * op.product_quantity, op.pay_time)
           |  ELSE false END AS is_face_mask ,
           |  face_mask_cycle2(cp.quantity * op.product_quantity, op.pay_time) as time
           |  FROM
           |  dw.order_product op
           | INNER JOIN (SELECT member_id,order_id FROM dw.order_information WHERE his_time = '$date' and pay_time is not null) oi
           | ON oi.order_id = op.tgou_order_id
           | INNER JOIN cycling_product cp
           |  ON op.mall_product_id = cp.listing_id
           | WHERE op.his_time = '$date'
           |  AND op.pay_time is not null
           | GROUP BY oi.member_id, cp.type
         """.stripMargin

      val cyclingDf = spark.sql(sqlText)
      cyclingDf.filter("is_face_mask").distinct().createOrReplaceTempView("cycling_bingo_t")
      val faceMaskSqlText =
        s"""
          | SELECT DISTINCT
          | cb.member_id as fk_member_id,
          | cp.listing_id as item_id,
          |  1 as item_type,
          | '${date.plusDays(1)}' as create_time
          |  FROM
          |  cycling_bingo_t cb
          | LEFT JOIN (SELECT member_id,order_id,pay_time FROM dw.order_information WHERE his_time = '$date' and pay_time is not null and pay_time >= '${date.plusDays(-89)}') oi
          |   ON cb.member_id = oi.member_id
          | LEFT JOIN (SELECT tgou_order_id,mall_product_id,pay_time FROM  dw.order_product WHERE his_time = '$date' and pay_time is not null and pay_time >= '${date.plusDays(-89)}') op
          |   ON oi.order_id = op.tgou_order_id
          | LEFT JOIN cycling_product cp
          |   ON op.mall_product_id = cp.listing_id
        """.stripMargin

      // 在faceMaskSqlText 外面再包一层，干掉由于LEFT JOIN引入的脏数据。
      val tmpDf = spark.sql(faceMaskSqlText)
      tmpDf.cache()
      tmpDf.createOrReplaceTempView("face_mask_t")
      val resultCleanSql =
        s"""
          | ( SELECT * FROM (face_mask_t) WHERE 1=1
          |     AND fk_member_id in (
          |         SELECT fk_member_id FROM (face_mask_t) GROUP by fk_member_id,item_type Having count(1) = 1
          |     )
          |  )
          |  UNION
          |  ( SELECT * FROM (face_mask_t) WHERE 1=1
          |   AND fk_member_id in (
          |         SELECT fk_member_id FROM (face_mask_t) GROUP by fk_member_id,item_type Having count(1) > 1
          |     )
          |   AND item_id is not null
          |  )
        """.stripMargin

      val resultSqlText =
        s"""
           | SELECT t1.*,
           | CASE WHEN t2.best_channel is not null and t2.best_channel = 1 then '0001'
           |  WHEN t2.best_channel is not null and t2.best_channel = 2 then '1000'
           |  WHEN t2.best_channel is not null and t2.best_channel = 3 then '0100'
           | ELSE '0100' END AS channel
           | FROM
           | ($resultCleanSql) t1
           | LEFT JOIN
           | persona.push_label_table t2
           | on t1.fk_member_id = t2.member_id
         """.stripMargin
      val resultDF = spark.sql(resultSqlText)
      val tableName = "member_cycling_buy"
      //jdbc一份吧。闹心。
      var jdbcConfigMap = Map[String,String]()
      jdbcConfigMap+=("driver"->jdbcConfig.getProperty("driver"))
      jdbcConfigMap+=("url"->jdbcConfig.getProperty("url"))
      jdbcConfigMap+=("user"->jdbcConfig.getProperty("user"))
      jdbcConfigMap+=("password"->jdbcConfig.getProperty("password"))
      jdbcConfigMap+=("dbtable"->tableName)
      val conn = JdbcUtils.createConnectionFactory(new JDBCOptions(jdbcConfigMap)).apply
      try{
        //clear olds
        conn.prepareStatement(
          s"""
             |delete from $tableName where create_time = '${date.plusDays(1)}'
        """.stripMargin).executeUpdate
      }finally conn.close()
      save(resultDF, jdbcConfig, tableName)
    }

    def save(df: DataFrame, jdbcConfig: Properties, table: String): Unit = {
      df.cache().persist(StorageLevel.MEMORY_AND_DISK_SER_2)
      jdbcConfig.setProperty("table",table)
      df.write.mode("overwrite").parquet("/data/market/cycling_buy/"+date.toString().replace("-","/"))
      df.write.mode("append").jdbc(jdbcConfig.getProperty("url"), jdbcConfig.getProperty("table"), jdbcConfig)
    }
  }
}
