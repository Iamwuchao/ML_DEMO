package com.tgou.data.stanford.market.delivery.source

import org.apache.spark.sql.DataFrame

/**
  * Created by 李震 on 2018/1/4.
  */
trait DeliverySource {

  def tgouPackageDF: DataFrame

  def thirdDeliveryInfoRecordDF: DataFrame

  def thirdDeliveryInfoRecordLogDF: DataFrame

  def deliveryVendorDF: DataFrame

}
