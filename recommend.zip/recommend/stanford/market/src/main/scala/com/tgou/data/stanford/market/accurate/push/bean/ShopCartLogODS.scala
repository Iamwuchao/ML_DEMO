package com.tgou.data.stanford.market.accurate.push.bean

/**
  * Created by 李震 on 2017/11/17.
  */
case class ShopCartLogODS (
                            id: Long,
                            fk_shop_cart_id: Long,
                            modify_time: String,
                            fk_store_id: Long,
                            activity_product_id: Long,
                            sku_id: Long,
                            quantity: Int,
                            fk_member_id: Long,
                            create_time: String
                          )
