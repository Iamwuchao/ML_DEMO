package com.tgou.data.stanford.market.member.service

import java.time.LocalDate

import com.tgou.data.stanford.market.member.Bean.DateInterval
import com.tgou.data.stanford.market.member.utils.DateIntervalUtil
import org.apache.spark.sql.{DataFrame, SparkSession}

/**
  * 用户交易相关的计算。
  * 转化分析，
  */
object MemberTransCalculator {
  val yesterdayDate = LocalDate.now().plusDays(-1)

  def calLifeCycle(spark: SparkSession, date: LocalDate): DataFrame = {
    val daysBefore90 = date.plusDays(-90).plusDays(1)
    val daysBefore150 = date.plusDays(-150).plusDays(1)
    val daysBefore365 = date.plusDays(-365).plusDays(1)
    var sqlText =
      s"""
         | SELECT
         |   m.member_id,
         |   count(distinct oi.order_id) AS frequency
         | FROM (SELECT member_id FROM dw.member WHERE his_time = '$date') m
         | LEFT JOIN
         |   (SELECT o.order_id,member_id FROM dw.order_information o WHERE o.his_time = '$date'
         |     and o.order_type = '0'
         |     and (
         |       o.receive_method not in ('00', '01')
         |       or o.pay_time is null
         |       or o.ship_time is null
         |       or to_date(o.pay_time) != to_date(o.ship_time)
         |     )
         |   ) oi
         | ON m.member_id = oi.member_id
         | GROUP BY m.member_id
      """.stripMargin
    spark.sql(sqlText).createOrReplaceTempView("origin_t")
    sqlText =
      s"""
         |SELECT
         | life_cycle,
         | count(1) as life_cycle_count,
         | '$date' as `date`
         | FROM (
         | SELECT
         | ot.member_id,
         | CASE
         |   WHEN  page.last_access < '$daysBefore150' THEN '流失期'
         |   WHEN  page.last_access >= '$daysBefore150' AND ot.frequency = 0  THEN '考察期'
         |   WHEN  ot.frequency < 3 AND page.last_access >= '$daysBefore90' THEN '发展期'
         |   WHEN  ot.frequency >= 3 AND page.last_access >= '$daysBefore90' THEN '成熟期'
         |   WHEN  ot.frequency >= 1 AND page.last_access < '$daysBefore90' AND page.last_access >= '$daysBefore150' THEN '衰退期'
         |   ELSE '流失期' END AS life_cycle
         | FROM origin_t ot
         | LEFT JOIN
         |   (SELECT member_id,nvl(max(time),'$daysBefore365') AS last_access  FROM dw.uba_page WHERE his_time >= '$daysBefore150' group by member_id) page
         | ON page.member_id = ot.member_id
         | )t
         |GROUP BY life_cycle
      """.stripMargin
    spark.sql(sqlText)
  }

  def calBrought(spark: SparkSession, dateInterval: DateInterval): Long = {
    val sqlText =
      s"""
        |  SELECT distinct member_id FROM dw.order_information o WHERE o.his_time = '$yesterdayDate'
        |     and o.order_type = '0'
        |     and (
        |       o.receive_method not in ('00', '01')
        |       or o.pay_time is null
        |       or o.ship_time is null
        |       or to_date(o.pay_time) != to_date(o.ship_time)
        |     )
        |     and o.create_time >= '${dateInterval.dateBegin}'
        |     and o.create_time < '${dateInterval.dateEnd}'
      """.stripMargin
    spark.sql(sqlText).count()
  }

  //因为pay_time cancel_time return_time都是有状态的。所以如果是60内的订单，选择endDate的前一天的时间
  def calTrans(spark: SparkSession, dateInterval: DateInterval):Long = {
    val his_time = {
      if(dateInterval.dateEnd.plusDays(-1).isBefore(yesterdayDate.plusDays(-60))){
        yesterdayDate
      }else{
        dateInterval.dateEnd.plusDays(-1)
      }
    }
    val sqlText =
      s"""
         | SELECT distinct member_id FROM dw.order_information o WHERE o.his_time = '$his_time'
         |     and o.order_type = '0'
         |     and (
         |       o.receive_method not in ('00', '01')
         |       or o.pay_time is null
         |       or o.ship_time is null
         |       or to_date(o.pay_time) != to_date(o.ship_time)
         |     )
         |     and o.create_time >= '${dateInterval.dateBegin}'
         |     and o.create_time < '${dateInterval.dateEnd}'
         |     and o.pay_time is not null
         |     and o.cancel_time is null
         |     and o.return_time is null
       """.stripMargin
    spark.sql(sqlText).count()
  }

  def main(args: Array[String]): Unit = {
    val date = LocalDate.parse("2017-10-31")
    val monthInterval = DateIntervalUtil.dateValidate(date,"month")
    val dateInterval = monthInterval
    val his_time = {
      if(dateInterval.dateEnd.plusDays(-1).isBefore(yesterdayDate.plusDays(-60))){
        yesterdayDate
      }else{
        dateInterval.dateEnd.plusDays(-1)
      }
    }
    println(his_time)
  }

  def calRfModel(spark: SparkSession, date: LocalDate): DataFrame = {
    spark.udf.register("rf",(r: Int, f: Int) =>{
      val r_val = {
        if(r<=30){1}
        else if(r>30 && r<=90){2}
        else if(r>90 && r<=180){3}
        else if(r>180){4}
        else 0
      }
      val f_val = {
        if(f>5) {5}
        else {f}
      }
      r_val * 10+ f_val
    })
    val oneYearBrought =
      s"""
        | SELECT
        |  order_id,
        |  total_amount,
        |  member_id,
        |  create_time
        |  FROM
        | dw.order_information
        |   WHERE his_time = '$yesterdayDate'
        |     and order_type = '0'
        |     and (
        |       receive_method not in ('00', '01')
        |       or pay_time is null
        |       or ship_time is null
        |       or to_date(pay_time) != to_date(ship_time)
        |     )
        |     and pay_time is not null
        |     and cancel_time is null
        |     and return_time is null
        |     and create_time >= '${date.plusDays(-364)}' and create_time < '${date.plusDays(1)}'
      """.stripMargin
    val sqlText =
      s"""
        | SELECT rf,count(1) as rf_count,sum(amount) as rf_amount,'$date' as date FROM (
        |   SELECT rf(datediff('$date',max(create_time))+1,count(distinct order_id)) as rf,
        |       member_id,
        |       sum(total_amount) as amount  FROM
        |  ($oneYearBrought) order_info
        |     GROUP BY member_id
        | ) t WHERE rf >10 and rf%10 != 0 GROUP BY rf
      """.stripMargin
    spark.sql(sqlText)
  }
}
