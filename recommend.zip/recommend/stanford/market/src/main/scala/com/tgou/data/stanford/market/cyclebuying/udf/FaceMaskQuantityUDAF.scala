package com.tgou.data.stanford.market.cyclebuying.udf

import org.apache.spark.sql.Row
import org.apache.spark.sql.expressions.{MutableAggregationBuffer, UserDefinedAggregateFunction}
import org.apache.spark.sql.types._

/**
  * 通过属性，得到面膜的
  */
class FaceMaskQuantityUDAF extends UserDefinedAggregateFunction{

  /**
      //64899单件片数 单位是片
      //64896面膜分类 贴片式|水洗式|睡眠免洗式
      //64900数量 1-10
      //64898单件净含量 单位是ml、g。
    */
  val fenlei = "64896"
  val danpianshuliang = "64899"
  val shuliang = "64900"
  val jinghanliang = "64898"


  override def inputSchema: StructType = StructType(List(StructField("name", StringType),StructField("fk_property_id", StringType)))

  override def bufferSchema: StructType = StructType(StructField("values", MapType(StringType, StringType))::Nil)

  override def dataType: DataType = IntegerType

  override def deterministic: Boolean = true

  override def initialize(buffer: MutableAggregationBuffer): Unit = {
    buffer(0) = Map()
  }

  override def update(buffer: MutableAggregationBuffer, input: Row): Unit = {
    var map = buffer.getMap[String,String](0)
    map = map + (input.getString(1) -> input.getString(0))
    buffer(0) = map
  }

  override def merge(buffer1: MutableAggregationBuffer, buffer2: Row): Unit = {
    if(buffer2(0)!=null){
      val map2 = buffer2.getMap[String,String](0)
      var map1 = buffer1.getMap[String,String](0)
      for(kv <- map2){
        map1 = map1 + kv
      }
      buffer1(0) = map1
    }
  }

  override def evaluate(buffer: Row): Any = {
    if(buffer(0) != null){
      val map = buffer.getMap[String,String](0)
      map.getOrElse(fenlei,null) match {
        case "贴片式" => {
          toMaybeInt(map.getOrElse(danpianshuliang,"0").replaceAll("片","")).getOrElse(0) * toMaybeInt(map.getOrElse(shuliang,"0")).getOrElse(0) * 6
        }
        case "水洗式" =>{
          toMaybeInt(map.getOrElse(jinghanliang,"0").replaceAll("ml","").replaceAll("g","")).getOrElse(0) * toMaybeInt(map.getOrElse(shuliang,"0")).getOrElse(0)
        }
        case "睡眠免洗式" => {
          (toMaybeInt(map.getOrElse(jinghanliang,"0").replaceAll("ml","").replaceAll("g","")).getOrElse(0) * toMaybeInt(map.getOrElse(shuliang,"0")).getOrElse(0))
        }
        case _ => 0
      }
    }else{
      0
    }
  }

  def toMaybeInt(s:String) = {
    scala.util.Try(s.toInt)
  }
}
