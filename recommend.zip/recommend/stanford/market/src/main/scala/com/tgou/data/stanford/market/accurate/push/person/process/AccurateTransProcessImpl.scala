package com.tgou.data.stanford.market.accurate.push.person.process

import com.google.inject.Inject
import com.tgou.data.stanford.market.accurate.push.person.bean.agg.{AccurateTransGroupAgg, AccurateTransPersonAgg}
import com.tgou.data.stanford.market.accurate.push.person.bean.attr.CouponCodeAttr
import com.tgou.data.stanford.market.accurate.push.person.source.{PushPersonSource, TgOrderSource}
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.joda.time.LocalDate

/**
  * Created by 李震 on 2017/11/14.
  */
class AccurateTransProcessImpl @Inject()(spark: SparkSession, date: LocalDate) extends AccurateTransProcess {

  @Inject
  var pushPersonSource: PushPersonSource = _

  @Inject
  var tgOrderSource: TgOrderSource = _


  def processAccurateTransDF: DataFrame = {
    import spark.implicits._

    pushPersonSource.pushGroupMemberDF.createOrReplaceTempView("push_group_member")

    tgOrderSource.orderDF.createOrReplaceTempView("online_order")
    tgOrderSource.orderProductDF.createOrReplaceTempView("online_order_product")
    tgOrderSource.orderPreferentialDF.createOrReplaceTempView("online_order_preferential")

    processPushCouponDF().union(processPushItemDF()).as[AccurateTransPersonAgg]
      .groupByKey(at => (at.push_task_id, at.group))
      .mapGroups((k, rs) => {
        var amount = BigDecimal(0)
        var count = 0l
        var coupon_ship_count = 0l

        for (r <- rs) {
          amount += BigDecimal(r.accurate_amount)
          count += r.accurate_count
          if (r.is_use_coupon) coupon_ship_count += 1L
        }

        val kdj = if (count == 0L) 0.0 else (amount / BigDecimal(count)).doubleValue()

        AccurateTransGroupAgg(k._1, k._2, kdj, coupon_ship_count)
      }).toDF()
  }


  /**
    * 处理推送券
    * */
  private def processPushCouponDF(): DataFrame = {
    import spark.implicits._

    spark.sql(
      s"""
         |select
         |    cast(cc.fk_coupon_id as bigint) as coupon_id,
         |    cast(cc.fk_activity_id as bigint) as activity_id,
         |    pm.push_task_id,
         |    pm.member_id,
         |    pm.group,
         |    pm.subject_code,
         |    pm.object_id,
         |    pm.object_type,
         |    cast(oo.total_amount as double) as total_amount
         |from dw.coupon_code cc
         |join push_group_member pm
         |on cc.member_id = pm.member_id
         |and cc.his_time = '${date.toString("yyyy-MM-dd")}'
         |and cc.create_time >= pm.push_time
         |and cc.use_time is not null
         |and cc.use_tag = '2'
         |join online_order_preferential oop
         |on cc.coupon_code_id = oop.object_id
         |and oop.order_preferential_type = '3'
         |join online_order oo
         |on oop.fk_tgou_order_id = oo.order_id
         |and oo.member_id = pm.member_id
      """.stripMargin).as[CouponCodeAttr]
      .groupByKey(cc => (cc.push_task_id, cc.member_id, cc.group))
      .mapGroups((k, rs) => {
        var accurateAmount = BigDecimal(0)
        var accurateCount = 0l
        var isUseCoupon = false

        for (r <- rs) {
          if ("502".equals(r.subject_code)) {
            // 推送券
            if (r.coupon_id == r.object_id) {
              isUseCoupon = true
              accurateAmount += BigDecimal(r.total_amount) // 精准金额
              accurateCount += 1l // 精准人数
            }
          } else if ("503".equals(r.subject_code) && "3".equals(r.object_type)) {
            // 推送券活动
            if (r.activity_id == r.object_id) {
              isUseCoupon = true
              accurateAmount += BigDecimal(r.total_amount)
              accurateCount += 1l // 精准人数
            }
          }
        }

        AccurateTransPersonAgg(k._1, k._2, k._3, accurateAmount.doubleValue(), accurateCount, isUseCoupon)
      }).toDF()
  }


  /**
    * 处理推送单品
    * */
  private def processPushItemDF(): DataFrame = {
    spark.sql(
      s"""
        |select
        |    p.push_task_id,
        |    p.member_id,
        |    p.group,
        |    sum(accurate_amount) as accurate_amount,
        |    count(1) as accurate_count,
        |    false as is_use_coupon
        |from (
        |    select
        |        p.push_task_id,
        |        p.member_id,
        |        p.group,
        |        max(p.total_amount) as accurate_amount
        |    from (
        |        select
        |            ap.fk_listing_id as item_id,
        |            a.activity_id
        |        from dw.activity_product ap
        |        join dw.activity a
        |        on ap.fk_activity_id = a.activity_id
        |        and ap.his_time = '${date.toString("yyyy-MM-dd")}'
        |        and a.his_time = '${date.toString("yyyy-MM-dd")}'
        |        and a.type = '6'
        |    ) a join (
        |        select
        |            pm.push_task_id,
        |            pm.member_id,
        |            pm.group,
        |            oop.item_id,
        |            oop.order_id,
        |            oop.total_amount,
        |            pm.object_id
        |        from online_order_product oop
        |        join push_group_member pm
        |        on oop.member_id = pm.member_id
        |        and oop.create_time > pm.push_time
        |        and oop.return_time is null
        |        and pm.subject_code = '503'
        |        and pm.object_type = '6'
        |    ) p
        |    on a.item_id = p.item_id
        |    and a.activity_id = p.object_id
        |    group by p.push_task_id, p.member_id, p.group, p.order_id
        |) p
        |group by p.push_task_id, p.member_id, p.group
      """.stripMargin)
  }

}
