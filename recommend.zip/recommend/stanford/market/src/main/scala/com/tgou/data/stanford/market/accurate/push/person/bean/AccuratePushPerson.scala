package com.tgou.data.stanford.market.accurate.push.person.bean

/**
  * 精准推送人员
  *
  * 维度：
  *
  * - push_task_id  推送 ID
  * - group  顾客群 new 新顾客 old 老顾客
  * - is_first_online  是否首次购物 0 否 1 是
  *
  * Created by 李震 on 2017/11/16.
  */
case class AccuratePushPerson (
                                push_task_id: Long,
                                start_time: String,
                                end_time: String,
                                group: String,
                                is_first_online: Int,
                                group_count: Long,
                                buy_count: Long,
                                buy_pay_count: Long,
                                add_cart_count: Long,
                                only_add_cart_count: Long,
                                cart_order_create_count: Long,
                                cart_order_pay_count: Long,
                                order_count: Long,
                                only_order_count: Long,
                                pay_count: Long,
                                pay_amount: Double,
                                high_level_count: Long,
                                mid_high_level_count: Long,
                                mid_level_count: Long,
                                low_level_count: Long,
                                platform_pv: Long,
                                platform_uv: Long
                              )
