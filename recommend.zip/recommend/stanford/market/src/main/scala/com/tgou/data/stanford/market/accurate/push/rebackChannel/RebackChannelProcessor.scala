package com.tgou.data.stanford.market.accurate.push.rebackChannel

import com.tgou.data.stanford.market.accurate.push.{Constants, PushSource}
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.storage.StorageLevel
import org.joda.time.LocalDate

/**
  * Created by 张少锐 on 2017/11/10.
  * 触达会员回访渠道的处理
  */
class RebackChannelProcessor protected(spark: SparkSession, date: LocalDate){

  val yesterday:String = date.toString("yyyy-MM-dd")
  val minus31:String = date.minusDays(Constants.STATICS_DURATION - 1).toString("yyyy-MM-dd")

  // 获取member信息表
  lazy val memberDF:DataFrame = spark.sql(
    s"""
       |select id,member_id,cell_phone
       |from dw.member m
       |where m.his_time = '$yesterday'
       """.stripMargin)

  // 获取31天的uba_page信息表
  lazy val ubaPage31DF:DataFrame = spark.sql(
    s"""
       |select id,global,time,member_id
       |from dw.uba_page up
       |where up.his_time >= '$minus31'
       |and up.his_time <= '$yesterday'
       |and up.member_id != ''
       """.stripMargin)

  // 获取精准推送人
  lazy val pushPerson:DataFrame = PushSource(spark, date).pushPersonDF.persist(StorageLevel.MEMORY_AND_DISK_SER)

  // 按照渠道划分精准推送人群
  lazy val allPerson:DataFrame = processRebackChannel(pushPerson).filter("reback_channel != '其他'").persist(StorageLevel.MEMORY_AND_DISK_SER)
  lazy val appPerson:DataFrame = processRebackChannel(pushPerson).filter("reback_channel = 'APP'").persist(StorageLevel.MEMORY_AND_DISK_SER)
  lazy val wechatPerson:DataFrame = processRebackChannel(pushPerson).filter("reback_channel = '微信'").persist(StorageLevel.MEMORY_AND_DISK_SER)
  lazy val webPerson:DataFrame = processRebackChannel(pushPerson).filter("reback_channel = 'WEB'").persist(StorageLevel.MEMORY_AND_DISK_SER)

  /**
    * 处理触达会员回访渠道
    *
    * @param pushPersonDF
    *
    * @return
    *
    * 字段：
    *
    * - push_task_id  推送 ID
    * - push_time  推送时间
    * - start_time  精准活动开始时间
    * - end_time  精准活动结束时间
    * - subject_code  推送内容编码 502 券 503 活动
    * - object_id 推送内容ID
    * - object_type 推送内容类型
    * - member_id  会员 ID
    * - reback_channel  回访渠道(所有:!='其他'，APP:android,ios，微信:wechat，WEB:webapp)
    * */
  private def processRebackChannel(pushPersonDF: DataFrame): DataFrame = {
    // 过滤触达会员
    val pushAccuratePersonDF = pushPersonDF.filter("is_received = true")

    // 关联member表
    val pushMemberDF = pushAccuratePersonDF.join(memberDF,pushAccuratePersonDF("phone") === memberDF("cell_phone")).
      select(
        "push_task_id",
        "push_time",
        "start_time",
        "end_time",
        "subject_code",
        "object_id",
        "object_type",
        "member_id"
      )
    pushMemberDF.createOrReplaceTempView("push_member")

    // 关联uba_page表,获取会员第一次触发渠道
    ubaPage31DF.createOrReplaceTempView("uba_page")

    val ubaPageDF = spark.sql(
      s"""
        |select
        |    distinct m.push_task_id,
        |    m.member_id,
        |    case when up.global = 'android' or up.global = 'ios' then 'APP'
        |         when up.global = 'wechat' then '微信'
        |         when up.global in ('webapp','AlipayClient','airmall') then 'WEB'
        |         else '其他'
        |    end as  reback_channel
        |from uba_page up
        |join (
        |      select pm.member_id,pm.push_task_id,min(up.time) as first_time
        |      from uba_page up
        |      join push_member pm
        |      on up.member_id = pm.member_id
        |      and up.time > pm.push_time
        |      group by pm.member_id,pm.push_task_id
        |      ) m
        |on up.member_id = m.member_id
        |and up.time = m.first_time
      """.stripMargin)

    // 触达会员回访渠道
    pushMemberDF.join(ubaPageDF,Seq("push_task_id","member_id")).
      select(
        "push_task_id",
        "push_time",
        "start_time",
        "end_time",
        "subject_code",
        "object_id",
        "object_type",
        "member_id",
        "reback_channel"
      )
  }
}

object RebackChannelProcessor {

  def apply(spark: SparkSession, date: LocalDate): RebackChannelProcessor = new RebackChannelProcessor(spark, date)

}
