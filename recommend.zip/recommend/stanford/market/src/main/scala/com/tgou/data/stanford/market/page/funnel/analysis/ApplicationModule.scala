package com.tgou.data.stanford.market.page.funnel.analysis

import org.joda.time.LocalDate
import com.google.inject.name.Names
import com.google.inject.{AbstractModule, Guice, Inject}
import com.tgou.data.stanford.market.page.funnel.analysis.service.FunnelService
import com.tgou.data.stanford.market.page.funnel.analysis.service.impl.FunnelServiceImpl
import com.tgou.data.stanford.market.page.funnel.analysis.source.FunnelSource
import com.tgou.data.stanford.market.page.funnel.analysis.source.impl.FunnelSourceImpl
import org.apache.spark.sql.SparkSession

class ApplicationModule(spark: SparkSession, appName: String, date: LocalDate) extends AbstractModule {

  override def configure(): Unit = {
    bind(classOf[SparkSession]).toInstance(spark)
    bind(classOf[String]).annotatedWith(Names.named("appName")).toInstance(appName)
    bind(classOf[LocalDate]).toInstance(date)
    bind(classOf[FunnelSource]).to(classOf[FunnelSourceImpl])
    bind(classOf[FunnelService]).to(classOf[FunnelServiceImpl])
  }
}

object ApplicationModule {
  def apply(spark: SparkSession, appName: String, date: LocalDate): ApplicationModule = new ApplicationModule(spark, appName, date)
}