package com.tgou.data.stanford.market.accurate.push.person.bean.attr

/**
  * Created by 李震 on 2017/11/20.
  */
case class OrderItemAttr (
                          push_task_id: Long,
                          member_id: Long,
                          push_time: String,
                          order_id: Long,
                          total_amount: Double,
                          create_time: String,
                          pay_time: String,
                          pay_method: String,
                          shopping_cart_time: String
                         )
