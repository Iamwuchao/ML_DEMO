package com.tgou.data.stanford.market.delivery

import java.util.Date

import com.google.inject.{Guice, Inject}
import com.tgou.data.stanford.market.core.MarketBootstrap
import com.tgou.data.stanford.market.delivery.bean.{DeliveryBean, DeliveryInfoBean}
import com.tgou.data.stanford.market.delivery.sink.DeliverySink
import com.tgou.data.stanford.market.delivery.source.DeliverySource
import org.apache.spark.sql.SparkSession
import org.apache.spark.storage.StorageLevel
import org.joda.time.LocalDate

/**
  * Created by 李震 on 2018/1/4.
  */
object Application {

  def main(args: Array[String]): Unit = {
    MarketBootstrap(args).bootstrapWithCassandra(execute)
  }

  def execute(spark: SparkSession, appName: String, date: LocalDate): Unit = {
    val injector = Guice.createInjector(ApplicationModule(spark, appName, date))
    injector.getInstance(classOf[Application]).run
  }

}

class Application @Inject()(spark: SparkSession, date: LocalDate) {

  @Inject
  var deliverySource: DeliverySource = _

  @Inject
  var deliverySink: DeliverySink = _

  def run: Unit = {
    import spark.implicits._

    val tgouPackageDF = deliverySource.tgouPackageDF
    tgouPackageDF.createOrReplaceTempView("tgou_package")

    val thirdDeliveryInfoRecordDF = deliverySource.thirdDeliveryInfoRecordDF
    thirdDeliveryInfoRecordDF.createOrReplaceTempView("third_delivery_info_record")

    val thirdDeliveryInfoRecordLogDF = deliverySource.thirdDeliveryInfoRecordLogDF
    thirdDeliveryInfoRecordLogDF.createOrReplaceTempView("third_delivery_info_record_log")

    val deliveryVendorDF = deliverySource.deliveryVendorDF
    deliveryVendorDF.createOrReplaceTempView("delivery_vendor")

    val deliveryDF = spark.sql(
      """
        |select
        |  r.tracking_no,
        |  r.state,
        |  r.comment,
        |  l.state as log_state,
        |  l.create_time as event_time
        |from third_delivery_info_record r
        |join third_delivery_info_record_log l
        |on r.tracking_no = l.tracking_no
        |and r.tracking_no is not null
        |and l.tracking_no is not null
      """.stripMargin).as[DeliveryInfoBean]
      .groupByKey(info => info.tracking_no)
      .mapGroups((k, vs) => {

        def getLatestTracingInfo(comment: String): (String, String) = {
          import collection.JavaConversions._
          import com.alibaba.fastjson.{JSON, JSONObject}

          var tracing_time: String = null
          var tracing_msg: String = null

          try {
            val ja = JSON.parseArray(comment)
            var latestDate: Option[Date] = None // 最近的追踪信息日期
            for(i <- ja) {
              // 获取最新的一条追踪信息
              try {
                if (i.isInstanceOf[JSONObject]) {
                  val jo = i.asInstanceOf[JSONObject]

                  latestDate match {
                    case None => {
                      latestDate = Some(jo.getDate("excuteTime"))

                      tracing_time = jo.getString("excuteTime")
                      tracing_msg = jo.getString("description")
                    }
                    case Some(d) => {
                      if (d.compareTo(jo.getDate("excuteTime")) < 0) {
                        latestDate = Some(jo.getDate("excuteTime"))

                        tracing_time = jo.getString("excuteTime")
                        tracing_msg = jo.getString("description")
                      }
                    }
                  }
                }
              } catch {
                case e: Exception => e.printStackTrace()
              }
            }
          } catch {
            case e: Exception => e.printStackTrace()
          }

          (tracing_time, tracing_msg)
        }

        var state: String = null
        var comment: String = null
        var accept_time: String = null
        var way_time: String = null
        var receive_time: String = null

        for(v <- vs) {
          if (state == null) state = v.state
          if (comment == null) comment = v.comment

          if ("1".equals(v.log_state)) {
            // 揽收
            accept_time = v.event_time
          } else if ("3".equals(v.log_state)) {
            // 收货
            receive_time = v.event_time
          } else if (v.log_state.startsWith("2")) {
            // 在途
            way_time = v.event_time
          }

          // 处理在途时间
          if (way_time == null) way_time = receive_time

          // 处理揽收时间
          if (accept_time == null) accept_time = way_time
        }

        if (comment != null && comment.trim.size > 0) {
          val tracing = getLatestTracingInfo(comment)
          DeliveryBean(k, accept_time, way_time, receive_time, state, tracing._1, tracing._2)
        } else {
          DeliveryBean(k, accept_time, way_time, receive_time, state, null, null)
        }
      })
    deliveryDF.persist(StorageLevel.MEMORY_AND_DISK)
    deliveryDF.createOrReplaceTempView("delivery")

    val df = spark.sql(
      s"""
        |select
        |    o.order_id,
        |    nvl(p.tracking_no, "") as tracking_no,
        |    dv.name as delivery_name,
        |    o.store_id,
        |    s.store_name,
        |    s.area_id,
        |    s.area_name,
        |    if(o.order_source = '4' and s.is_international	= '0', '3', o.order_source) as yt,
        |    to_utc_timestamp(o.pay_time, 'GMT') as pay_time,
        |    to_date(o.pay_time) as pay_date,
        |    to_utc_timestamp(d.accept_time, 'GMT') as accept_time,
        |    to_utc_timestamp(o.ship_time, 'GMT') as ship_time,
        |    to_utc_timestamp(d.way_time, 'GMT') as way_time,
        |    to_utc_timestamp(d.receive_time, 'GMT') as receive_time,
        |    d.state,
        |    if(isNotNull(d.tracing_time), to_utc_timestamp(d.tracing_time, 'GMT'), null)  as tracing_time,
        |    d.tracing_msg
        |from dw.order_information o
        |join dw.store s
        |on o.store_id = s.id
        |and o.his_time = '${date.toString("yyyy-MM-dd")}'
        |and s.his_time = '${date.toString("yyyy-MM-dd")}'
        |and o.pay_time is not null
        |and o.pay_time >= '2017-12-01 00:00:00'
        |and o.cancel_time is null
        |and o.pay_method not in ('000', '010')
        |and o.order_type = '0'
        |and o.receive_method in ('10')
        |left join tgou_package p
        |on o.order_id = p.fk_tgou_order_id
        |left join delivery_vendor dv
        |on p.fk_delivery_vendor_id = dv.id
        |left join delivery d
        |on p.tracking_no = d.tracking_no
      """.stripMargin)

    deliverySink.saveToCassandra(df)
  }

}
