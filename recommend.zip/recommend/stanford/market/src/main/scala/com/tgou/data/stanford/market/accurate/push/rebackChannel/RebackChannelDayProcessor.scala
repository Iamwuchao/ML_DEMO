package com.tgou.data.stanford.market.accurate.push.rebackChannel

import org.apache.spark.sql.{DataFrame, Row, SparkSession}
import org.apache.spark.sql.catalyst.encoders.RowEncoder
import org.apache.spark.sql.types.{LongType, StructField, StructType}
import org.joda.time.LocalDate

/**
  * Created by 张少锐 on 2017/11/10.
  * 精准推送回访渠道分析-天表字段的处理
  */
class RebackChannelDayProcessor protected(spark: SparkSession, date: LocalDate){

  /**
    * 计算推送人数
    *
    * @param pushPersonDF
    *
    * @return
    *
    * 字段：
    *
    * - push_task_id  推送 ID
    * - push_count  推送人数
    * - receive_count  推送触达人数
    *
    * */
  def processPushPersonCount(pushPersonDF: DataFrame): DataFrame = {
    val inputSchema = StructType(
      StructField("push_count", LongType) ::
        StructField("receive_count", LongType) :: Nil
    )
    val outputSchema = StructType(
      StructField("push_task_id", LongType) ::
        StructField("push_count", LongType) ::
        StructField("receive_count", LongType) :: Nil
    )

    import spark.implicits._
    pushPersonDF.groupByKey(r => r.getLong(0))
      .mapValues(r => {
        if (r.getBoolean(8)) Row(1l, 1l) else Row(1l, 0l)
      })(RowEncoder(inputSchema))
      .reduceGroups((l, r) => Row(l.getLong(0) + r.getLong(0), l.getLong(1) + r.getLong(1)))
      .map(t => Row(t._1, t._2.get(0), t._2.get(1)))(RowEncoder(outputSchema))
  }

  /**
    * 处理回访渠道统计结果
    *
    * @param rebackDF
    *
    * @return
    *
    * 字段：
    * - push_task_id  推送 ID
    * - reback_count  回访用户数
    * - pay_count  支付人数
    * - pay_sum  支付金额
    * - activity_page_count  全平台流量
    *
    * */
  def processRebackChannelCount(rebackDF: DataFrame): DataFrame = {

    rebackDF.createOrReplaceTempView("reback")

    val memberCountDF = spark.sql(
      """
        |select
        |     r.push_task_id,
        |     count(distinct upd.member_id) as reback_count,
        |     count(1) as activity_page_count
        |from uba_page_day upd
        |join reback r
        |on upd.member_id = r.member_id
        |and upd.time > r.push_time
        |group by r.push_task_id
      """.stripMargin)

    val payCountDF = spark.sql(
      """
        |select
        |     r.push_task_id,
        |     count(distinct o.member_id) as pay_count,
        |     nvl(cast(sum(o.total_amount) as decimal(18,2)),0) as pay_sum
        |from order o
        |join reback r
        |on (
        |   o.member_id = r.member_id
        |   and o.create_time > r.push_time
        |   and o.pay_time > r.push_time
        |)
        |group by r.push_task_id
      """.stripMargin)

    memberCountDF.join(payCountDF,Seq("push_task_id"),"full").
      select(
        "push_task_id",
        "reback_count",
        "pay_count",
        "pay_sum",
        "activity_page_count"
      )
  }

}
object RebackChannelDayProcessor {

  def apply(spark: SparkSession, date: LocalDate): RebackChannelDayProcessor = new RebackChannelDayProcessor(spark, date)

}
