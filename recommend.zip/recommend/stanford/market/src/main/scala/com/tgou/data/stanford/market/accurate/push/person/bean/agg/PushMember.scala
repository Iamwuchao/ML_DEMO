package com.tgou.data.stanford.market.accurate.push.person.bean.agg

/**
  * 推送会员属性
  *
  * 维度：
  *
  * - push_task_id  推送 ID
  * - member_id  会员 ID
  *
  * Created by 李震 on 2017/11/16.
  */
case class PushMember(
                        push_task_id: Long,
                        member_id: Long,
                        start_time: String,  // 精准活动开始时间
                        end_time: String,  // 精准活动结束时间
                        group: String,  // 新老顾客
                        is_first_online: Int,  // 是否首次线上购物
                        is_buy_now: Boolean,  // 是否立即购买
                        is_buy_now_pay: Boolean,  // 是否立即购买并支付
                        is_shopping_cart: Boolean,  // 是否收藏或加入购物车
                        is_shopping_cart_create: Boolean,  // 是否收藏或加入购物车并下单
                        is_shopping_cart_pay: Boolean,  // 是否收藏或加入购物车并支付
                        is_order_create: Boolean,  // 是否下单
                        is_order_pay: Boolean,  // 是否支付
                        order_pay_amount: Double, // 订单支付金额
                        is_order_only_create: Boolean,  // 是否仅下单
                        level: String,  // 消费级别：高、中高、中、低
                        platform_pv: Long  // 平台 PV
                      )
