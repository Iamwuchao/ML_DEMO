package com.tgou.data.stanford.market.accurate.push.person

import com.google.inject.name.Named
import com.google.inject.{Guice, Inject}
import com.tgou.data.stanford.market.accurate.push.person.bean.AccuratePushPerson
import com.tgou.data.stanford.market.accurate.push.person.bean.agg.PushMember
import com.tgou.data.stanford.market.accurate.push.person.process.{AccurateTransProcess, OrderProcess, PersonProcess, UBAProcess}
import com.tgou.data.stanford.market.accurate.push.person.sink.AccuratePushPersonSink
import com.tgou.data.stanford.market.accurate.push.person.source.PushPersonSource
import com.tgou.data.stanford.market.core.MarketBootstrap
import org.apache.spark.sql.SparkSession
import org.apache.spark.storage.StorageLevel
import org.joda.time.LocalDate

/**
  * Created by 李震 on 2017/11/6.
  */
class Application @Inject()(spark: SparkSession, @Named("appName")appName: String, date: LocalDate) {

  @Inject
  var personProcess: PersonProcess = _

  @Inject
  var pushPersonSource: PushPersonSource = _

  @Inject
  var orderProcess: OrderProcess = _

  @Inject
  var accurateTransProcess: AccurateTransProcess = _

  @Inject
  var ubaProcess: UBAProcess = _

  @Inject
  var accuratePushPersonSink: AccuratePushPersonSink = _


  def run: Unit = {
    pushPersonSource
      .pushGroupMemberDF
      .createOrReplaceTempView("push_member_group")

    orderProcess
      .processOrderDF
      .createOrReplaceTempView("push_member_order")

    orderProcess
      .processShoppingCartDF()
        .createOrReplaceTempView("push_member_shopping_cart")

    accurateTransProcess
      .processAccurateTransDF
      .createOrReplaceTempView("push_member_accurate_trans")

    ubaProcess
      .processUBADF
      .createOrReplaceTempView("push_member_uba")

    personProcess
      .processPushPersonCount
      .createOrReplaceTempView("push_person_count")

    runAccuratePushPerson
    runAccuratePushPersonDensity
  }


  private def runAccuratePushPerson: Unit = {
    import spark.implicits._

    val df = spark.sql(
      """
        |select
        |    pmg.push_task_id,
        |    pmg.member_id,
        |    pmg.start_time,
        |    pmg.end_time,
        |    pmg.group,
        |    pmg.is_first_online,
        |    nvl(pmo.is_buy_now, false) as is_buy_now,
        |    nvl(pmo.is_buy_now_pay, false) as is_buy_now_pay,
        |    nvl(pmsc.is_shopping_cart, false) as is_shopping_cart,
        |    nvl(pmo.is_shopping_cart_create, false) as is_shopping_cart_create,
        |    nvl(pmo.is_shopping_cart_pay, false) as is_shopping_cart_pay,
        |    nvl(pmo.is_order_create, false) as is_order_create,
        |    nvl(pmo.is_order_pay, false) as is_order_pay,
        |    nvl(pmo.order_pay_amount, 0.0) as order_pay_amount,
        |    nvl(pmo.is_order_only_create, false) as is_order_only_create,
        |    fi.level,
        |    nvl(pmu.platform_pv, 0l) as platform_pv
        |from push_member_group pmg
        |left join push_member_order pmo
        |on pmg.push_task_id = pmo.push_task_id
        |and pmg.member_id = pmo.member_id
        |left join push_member_shopping_cart pmsc
        |on pmg.push_task_id = pmsc.push_task_id
        |and pmg.member_id = pmsc.member_id
        |left join persona.favor_info fi
        |on pmg.member_id = fi.member_id
        |left join push_member_uba pmu
        |on pmg.push_task_id = pmu.push_task_id
        |and pmg.member_id = pmu.member_id
      """.stripMargin).as[PushMember]
      .groupByKey(pm => (pm.push_task_id, pm.group, pm.is_first_online))
      .mapGroups((k, pms) => {
        var start_time: String = null
        var end_time: String = null

        var group_count = 0l
        var buy_count = 0l
        var buy_pay_count = 0l
        var add_cart_count = 0l
        var only_add_cart_count = 0l
        var cart_order_create_count = 0l
        var cart_order_pay_count = 0l
        var order_count = 0l
        var only_order_count = 0l
        var pay_count = 0l
        var pay_amount = BigDecimal(0)
        var high_level_count = 0l
        var mid_high_level_count = 0l
        var mid_level_count = 0l
        var low_level_count = 0l
        var platform_pv = 0l
        var platform_uv = 0l

        for (pm <- pms) {
          // 精准推送开始时间
          if (start_time == null) start_time = pm.start_time

          // 精准推送结束时间
          if (end_time == null) end_time = pm.end_time

          // 客户群人数
          group_count += 1

          // 立即购买人数
          if (pm.is_buy_now) buy_count += 1

          // 立即购买支付人数
          if (pm.is_buy_now_pay) buy_pay_count += 1

          // 收藏或加入购物车人数
          if (pm.is_shopping_cart) add_cart_count += 1

          // 仅收藏或加入购物车人数
          if (pm.is_shopping_cart && !pm.is_shopping_cart_create) only_add_cart_count += 1

          // 收藏或加入购物车下单人数
          if (pm.is_shopping_cart_create) cart_order_create_count += 1

          // 收藏或加入购物车支付人数
          if (pm.is_shopping_cart_pay) cart_order_pay_count += 1

          // 下单人数
          if (pm.is_order_create) order_count += 1

          // 仅下单人数
          if (pm.is_order_only_create) only_order_count += 1

          // 支付人数
          if (pm.is_order_pay) {
            pay_count += 1
            pay_amount += BigDecimal(pm.order_pay_amount)
          }

          // 高消费能力用户人数
          if (pm.level != null && "高".equals(pm.level)) high_level_count += 1

          // 中高消费能力用户数
          if (pm.level != null && "中高".equals(pm.level)) mid_high_level_count += 1

          // 中消费能力用户数
          if (pm.level != null && "中".equals(pm.level)) mid_level_count += 1

          // 低消费能力用户数
          if (pm.level != null && "低".equals(pm.level)) low_level_count += 1

          if (pm.platform_pv > 0) {
            platform_uv += 1
            platform_pv += pm.platform_pv
          }

        }

        AccuratePushPerson(
          k._1,
          start_time,
          end_time,
          k._2,
          k._3,
          group_count,
          buy_count,
          buy_pay_count,
          add_cart_count,
          only_add_cart_count,
          cart_order_create_count,
          cart_order_pay_count,
          order_count,
          only_order_count,
          pay_count,
          pay_amount.toDouble,
          high_level_count,
          mid_high_level_count,
          mid_level_count,
          low_level_count,
          platform_pv,
          platform_uv
        )
      }).createOrReplaceTempView("accurate_push_person")

    val r = spark.sql(
      """
        |select
        |    app.push_task_id,
        |    app.start_time,
        |    app.end_time,
        |    app.group,
        |    app.is_first_online,
        |    ppc.push_count,
        |    ppc.receive_count,
        |    app.group_count,
        |    app.buy_count,
        |    app.buy_pay_count,
        |    app.add_cart_count,
        |    app.only_add_cart_count,
        |    app.cart_order_create_count,
        |    app.cart_order_pay_count,
        |    app.order_count,
        |    app.only_order_count,
        |    app.pay_count,
        |    app.pay_amount,
        |    nvl(pmat.ship_coupon_count, 0.0) as ship_coupon_count,
        |    app.high_level_count,
        |    app.mid_high_level_count,
        |    app.mid_level_count,
        |    app.low_level_count,
        |    app.platform_pv,
        |    app.platform_uv
        |from push_person_count ppc
        |join accurate_push_person app
        |on ppc.push_task_id = app.push_task_id
        |left join push_member_accurate_trans pmat
        |on pmat.push_task_id = app.push_task_id
        |and pmat.group = app.group
      """.stripMargin)

    accuratePushPersonSink.persistAccuratePushPersonDF(r)
  }


  private def runAccuratePushPersonDensity: Unit = {
    val densityDF = spark.sql(
      """
        |select
        |    pmg.push_task_id,
        |    pmg.member_id,
        |    pmg.group,
        |    pmo.first_order_create_time,
        |    pmo.first_order_pay_time,
        |    pmu.first_visit_time
        |from push_member_group pmg
        |left join push_member_order pmo
        |on pmg.push_task_id = pmo.push_task_id
        |and pmg.member_id = pmo.member_id
        |left join push_member_uba pmu
        |on pmg.push_task_id = pmu.push_task_id
        |and pmg.member_id = pmu.member_id
      """.stripMargin)
    densityDF.persist(StorageLevel.MEMORY_AND_DISK)
    densityDF.createOrReplaceTempView("density")

    /*
     * 首次访问时间
     * */
    val firstVisitDensityDF = spark.sql(
      """
        |select
        |    d.push_task_id,
        |    d.group,
        |    'v' as density_type,
        |    year(d.first_visit_time) as density_year,
        |    month(d.first_visit_time) as density_month,
        |    day(d.first_visit_time) as density_day,
        |    hour(d.first_visit_time) as density_hour,
        |    count(d.member_id) as density_value
        |from density d
        |where d.first_visit_time is not null
        |group by d.push_task_id, d.group, year(d.first_visit_time), month(d.first_visit_time), day(d.first_visit_time), hour(d.first_visit_time)
      """.stripMargin)

    /*
     * 首次下单时间
     * */
    val firstOrderCreateDensityDF = spark.sql(
      """
        |select
        |    d.push_task_id,
        |    d.group,
        |    'o' as density_type,
        |    year(d.first_order_create_time) as density_year,
        |    month(d.first_order_create_time) as density_month,
        |    day(d.first_order_create_time) as density_day,
        |    hour(d.first_order_create_time) as density_hour,
        |    count(d.member_id) as density_value
        |from density d
        |where d.first_order_create_time is not null
        |group by d.push_task_id, d.group, year(d.first_order_create_time), month(d.first_order_create_time), day(d.first_order_create_time), hour(d.first_order_create_time)
      """.stripMargin)

    /*
     * 首次支付时间
     * */
    val firstOrderPayDensityDF = spark.sql(
      """
        |select
        |    d.push_task_id,
        |    d.group,
        |    'p' as density_type,
        |    year(d.first_order_pay_time) as density_year,
        |    month(d.first_order_pay_time) as density_month,
        |    day(d.first_order_pay_time) as density_day,
        |    hour(d.first_order_pay_time) as density_hour,
        |    count(d.member_id) as density_value
        |from density d
        |where d.first_order_pay_time is not null
        |group by d.push_task_id, d.group, year(d.first_order_pay_time), month(d.first_order_pay_time), day(d.first_order_pay_time), hour(d.first_order_pay_time)
      """.stripMargin)

    val df = firstVisitDensityDF.union(firstOrderCreateDensityDF).union(firstOrderPayDensityDF)
    accuratePushPersonSink.persistAccuratePushPersonDensityDF(df)
  }

}


object Application {

  def main(args: Array[String]): Unit = {
    MarketBootstrap(args).bootstrap(execute)
  }

  def execute(spark: SparkSession, appName: String, date: LocalDate): Unit = {
    val injector = Guice.createInjector(ApplicationModule(spark, appName, date))
    injector.getInstance(classOf[Application]).run
  }

}
