package com.tgou.data.stanford.market.delivery.bean

/**
  * Created by 李震 on 2018/1/4.
  */
case class ThirdDeliveryInfoRecordLog (
                                        id: Long,
                                        tracking_no: String,
                                        state: String,
                                        create_time: String,
                                        modify_time: String
                                      )
