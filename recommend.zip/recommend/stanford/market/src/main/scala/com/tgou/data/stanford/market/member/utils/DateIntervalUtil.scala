package com.tgou.data.stanford.market.member.utils

import java.time.{DayOfWeek, LocalDate}

import com.tgou.data.stanford.market.member.Bean.DateInterval

object DateIntervalUtil {
  /**
    * 时间是用的明天，因为T+1传入的date总是昨天的。
    */
  def dateValidate(date: LocalDate, dateType: String): DateInterval = {
    val nextDay = date.plusDays(1)
    if("month".equals(dateType) && nextDay.withDayOfMonth(1).equals(nextDay)){
      DateInterval(true,nextDay.plusMonths(-1),nextDay)
    }else if("week".equals(dateType) && nextDay.getDayOfWeek.equals(DayOfWeek.MONDAY)){
      DateInterval(true,nextDay.plusDays(-7),nextDay)
    }else if("day".equals(dateType)){
      DateInterval(true,nextDay.plusDays(-1),nextDay)
    }else{
      DateInterval(false,null,null)
    }
  }

}
