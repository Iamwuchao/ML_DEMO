package com.tgou.data.stanford.market.page.funnel.analysis.source

import org.apache.spark.sql.DataFrame

trait FunnelSource {
  def getMallActivityProductToGroupDF: DataFrame

  def getListingWithYtDf: DataFrame

  def getUbaPageWithYtDf: DataFrame

  def getTodayUbaPageDf: DataFrame
}
