package com.tgou.data.stanford.market.accurate.push.person

import com.google.inject.AbstractModule
import com.google.inject.name.Names
import com.tgou.data.stanford.market.accurate.push.person.process._
import com.tgou.data.stanford.market.accurate.push.person.sink.{AccuratePushPersonSink, AccuratePushPersonSinkImpl}
import com.tgou.data.stanford.market.accurate.push.person.source.{PushPersonSource, PushPersonSourceImpl, TgOrderSource, TgOrderSourceImpl}
import org.apache.spark.sql.SparkSession
import org.joda.time.LocalDate

/**
  * Created by 李震 on 2017/11/20.
  */
class ApplicationModule(spark: SparkSession, appName: String, date: LocalDate) extends AbstractModule {

  override def configure() = {
    bind(classOf[SparkSession]).toInstance(spark)
    bind(classOf[String]).annotatedWith(Names.named("appName")).toInstance(appName)
    bind(classOf[LocalDate]).toInstance(date)

    /*
     * Source 绑定
     * */

    // 推送人员 Source
    bind(classOf[PushPersonSource]).to(classOf[PushPersonSourceImpl])

    // 在线订单 Source
    bind(classOf[TgOrderSource]).to(classOf[TgOrderSourceImpl])

    /*
     * Process 绑定
     * */
    // 人员处理 Process
    bind(classOf[PersonProcess]).to(classOf[PersonProcessImpl])

    // 订单处理 Process
    bind(classOf[OrderProcess]).to(classOf[OrderProcessImpl])

    // 精准交易处理 Process
    bind(classOf[AccurateTransProcess]).to(classOf[AccurateTransProcessImpl])

    // 用户行为 Process
    bind(classOf[UBAProcess]).to(classOf[UBAProcessImpl])

    /*
     * Sink 绑定
     * */
    // 精准推送人群 Sink
    bind(classOf[AccuratePushPersonSink]).to(classOf[AccuratePushPersonSinkImpl])

  }

}

object ApplicationModule {

  def apply(spark: SparkSession, appName: String, date: LocalDate): ApplicationModule = new ApplicationModule(spark, appName, date)

}
