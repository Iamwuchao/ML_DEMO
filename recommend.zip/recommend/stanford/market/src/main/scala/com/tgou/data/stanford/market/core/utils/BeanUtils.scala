package com.tgou.data.stanford.market.core.utils

import scala.reflect.runtime.universe._

import org.apache.spark.sql.catalyst.ScalaReflection
import org.apache.spark.sql.types.StructType

/**
  * Created by 李震 on 2017/11/16.
  */
object BeanUtils {

  def getSchemaFromBean[T : TypeTag]: StructType = {
    ScalaReflection.schemaFor[T].dataType.asInstanceOf[StructType]
  }

}
