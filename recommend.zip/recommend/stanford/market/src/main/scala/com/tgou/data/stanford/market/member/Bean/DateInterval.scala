package com.tgou.data.stanford.market.member.Bean

import java.time.LocalDate

case class DateInterval(isValidate: Boolean, dateBegin: LocalDate, dateEnd: LocalDate){}
