package com.tgou.data.stanford.market.core

import ch.cern.sparkmeasure.StageMetrics
import org.apache.spark.sql.SparkSession
import org.joda.time.LocalDate

/**
  * Created by 李震 on 2017/11/6.
  */
class MarketBootstrap(args: Array[String]) {

  val appName = args(0)
  val date = LocalDate.now().plusDays(args(1).toInt)

  def bootstrap(execute: (SparkSession, String, LocalDate) => Unit): Unit = {
    // 配置元数据库
    System.setProperty("hive.metastore.uris", "thrift://hnode1:9083")

    val spark = if (appName.startsWith("test")) {
      // Debug 模式
      SparkSession.builder()
        .master("local")
        .appName(appName)
        .enableHiveSupport()
        .getOrCreate()
    } else {
      SparkSession.builder()
        .master("yarn")
        .appName(appName)
        .enableHiveSupport()
        .config("spark.eventLog.enabled", true)
        .config("spark.eventLog.dir", "hdfs://nameservice1/user/spark/applicationHistory")
        .config("spark.yarn.historyServer.address", "http://hnode10:18080")
        .getOrCreate()
    }

    // 日志级别
    spark.sparkContext.setLogLevel("WARN")

    try {
      val sm = StageMetrics(spark)
      sm.begin()

      // 执行
      execute(spark, appName, date)

      sm.end()
      sm.printReport()
    } catch {
      case e: Exception => throw new RuntimeException(e)
    } finally {
      spark.close()
    }
  }


  def bootstrapWithCassandra(execute: (SparkSession, String, LocalDate) => Unit): Unit = {
    // 配置元数据库
    System.setProperty("hive.metastore.uris", "thrift://hnode1:9083")

    val spark = if (appName.startsWith("test")) {
      // Debug 模式
      SparkSession.builder()
        .master("local")
        .appName(appName)
        .enableHiveSupport()
        .config("spark.cassandra.connection.keep_alive_ms", 10000) // 空闲时段保持链接10秒
        .config("spark.cassandra.connection.host", "172.16.3.9,172.16.3.10,172.16.3.11")
        .config("spark.cassandra.auth.username", "tiangou")
        .config("spark.cassandra.auth.password", "K09Kccrx]")
        .getOrCreate()
    } else {
      SparkSession.builder()
        .master("yarn")
        .appName(appName)
        .enableHiveSupport()
        .config("spark.eventLog.enabled", true)
        .config("spark.eventLog.dir", "hdfs://nameservice1/user/spark/applicationHistory")
        .config("spark.yarn.historyServer.address", "http://hnode10:18080")
        .config("spark.cassandra.connection.keep_alive_ms", 10000) // 空闲时段保持链接10秒
        .config("spark.cassandra.connection.host", "172.16.3.9,172.16.3.10,172.16.3.11")
        .config("spark.cassandra.auth.username", "tiangou")
        .config("spark.cassandra.auth.password", "K09Kccrx]")
        .getOrCreate()
    }

    // 日志级别
    spark.sparkContext.setLogLevel("WARN")

    try {
      val sm = StageMetrics(spark)
      sm.begin()

      // 执行
      execute(spark, appName, date)

      sm.end()
      sm.printReport()
    } catch {
      case e: Exception => throw new RuntimeException(e)
    } finally {
      spark.close()
    }
  }

}

object MarketBootstrap {

  def apply(args: Array[String]): MarketBootstrap = new MarketBootstrap(args)

}