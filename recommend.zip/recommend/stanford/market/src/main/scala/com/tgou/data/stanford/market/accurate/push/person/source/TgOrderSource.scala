package com.tgou.data.stanford.market.accurate.push.person.source

import org.apache.spark.sql.DataFrame

/**
  * Created by 李震 on 2017/11/20.
  */
trait TgOrderSource {

  /**
    * 在线订单
    *
    * @return
    *
    * 字段：
    *
    * - order_id 订单 ID
    * - member_id 会员 ID
    * - create_time 下单时间
    * - pay_time 支付时间
    * - ship_time 核销时间
    * - total_amount 支付金额
    *
    * */
  def orderDF: DataFrame

  /**
    * 在线订单商品
    *
    * @return
    *
    * 字段：
    *
    * - order_id 订单 ID
    * - member_id 会员 ID
    * - create_time 下单时间
    * - pay_time 支付时间
    * - ship_time 核销时间
    * - total_amount 支付金额
    * - brand_id 品牌 ID
    * - item_id 营销品 ID
    * - product_discount 商品合计金额
    *
    * */
  def orderProductDF: DataFrame

  /**
    * 订单优惠
    *
    * @return
    *
    * - order_preferential_type 订单优惠类型
    * - object_id 券 ID
    * - fk_tgou_order_id 订单 ID
    *
    * */
  def orderPreferentialDF: DataFrame

  /**
    * 购物车日志
    *
    * @return
    *
    * - activity_product_id 营销品 ID
    * - fk_member_id 会员 ID
    * - create_time 加入购物车时间
    *
    * */
  def shoppingCartLogDF: DataFrame

}
