package com.tgou.data.stanford.market.cyclebuying.bean

case class PropertyValue(
                          id: Long,
                          create_time: String,
                          sort_order: Int,
                          name: String,
                          fk_property_id: Int,
                          modify_time: String
                        ) {}
