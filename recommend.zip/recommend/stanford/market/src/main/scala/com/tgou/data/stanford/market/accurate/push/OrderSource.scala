package com.tgou.data.stanford.market.accurate.push

import com.tgou.data.stanford.market.accurate.push.bean.OrderPreferentialODS
import com.tgou.data.stanford.market.core.MarketSource
import com.tgou.data.stanford.market.core.utils.BeanUtils
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.joda.time.LocalDate

/**
  * Created by 李震 on 2017/11/13.
  */
class OrderSource (spark: SparkSession, date: LocalDate) {

  lazy val onlineOrderDF: DataFrame = {
    spark.sql(
      s"""
        |select
        |    o.order_id,
        |    o.member_id,
        |    o.create_time,
        |    o.pay_time,
        |    o.ship_time,
        |    o.return_time,
        |    o.total_amount,
        |    o.pay_method
        |from dw.order_information o
        |where o.his_time = '${date.toString("yyyy-MM-dd")}'
        |and o.order_type = '0'
        |and (
        |    o.receive_method not in ('00', '01')
        |    or o.pay_time is null
        |    or o.ship_time is null
        |    or to_date(o.pay_time) != to_date(o.ship_time)
        |)
      """.stripMargin)
  }

  lazy val onlineOrderProductDF: DataFrame = {
    spark.sql(
      s"""
         |select
         |    o.order_id,
         |    o.member_id,
         |    o.create_time,
         |    o.pay_time,
         |    o.ship_time,
         |    o.return_time,
         |    o.total_amount,
         |    o.pay_method,
         |    op.brand_id,
         |    op.mall_product_id as item_id,
         |    op.product_discount
         |from dw.order_information o
         |join dw.order_product op
         |on o.order_id = op.tgou_order_id
         |and o.his_time = '${date.toString("yyyy-MM-dd")}'
         |and op.his_time = '${date.toString("yyyy-MM-dd")}'
         |and o.order_type = '0'
         |and (
         |    o.receive_method not in ('00', '01')
         |    or o.pay_time is null
         |    or o.ship_time is null
         |    or to_date(o.pay_time) != to_date(o.ship_time)
         |)
      """.stripMargin)
  }

  lazy val onlineOrderPreferentialDF: DataFrame = {
    MarketSource.getDurationDF(
      spark,
      "/tiangou/tgouorder/order_preferential",
      date.minusDays(Constants.STATICS_DURATION - 1),
      date,
      BeanUtils.getSchemaFromBean[OrderPreferentialODS]
    )
  }

}

object OrderSource {

  def apply(spark: SparkSession, date: LocalDate): OrderSource = new OrderSource(spark, date)

}
