package com.tgou.data.stanford.market.accurate.push.person.bean.agg

/**
  * Created by 李震 on 2017/11/17.
  */
case class AccurateTransPersonAgg(
                             push_task_id: Long,
                             member_id: Long,
                             group: String,
                             accurate_amount: Double,
                             accurate_count: Long,
                             is_use_coupon: Boolean
                           )