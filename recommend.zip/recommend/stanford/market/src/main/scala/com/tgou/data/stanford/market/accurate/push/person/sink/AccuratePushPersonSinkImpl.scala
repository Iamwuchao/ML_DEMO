package com.tgou.data.stanford.market.accurate.push.person.sink

import com.google.inject.Inject
import com.tgou.data.stanford.market.core.MarketSink
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.joda.time.LocalDate

/**
  * Created by 李震 on 2017/11/20.
  */
class AccuratePushPersonSinkImpl @Inject()(spark: SparkSession, date: LocalDate) extends AccuratePushPersonSink {

  override def persistAccuratePushPersonDF(df: DataFrame): Unit = {
    MarketSink.saveAsCSV(df, Seq(col("push_task_id"), col("group"), col("is_first_online")), date, "/data/market/accurate_push_person")
  }

  override def persistAccuratePushPersonDensityDF(df: DataFrame): Unit = {
    MarketSink.saveAsCSV(df, Seq(col("push_task_id"), col("group"), col("density_type"), col("density_year"), col("density_month"), col("density_day"), col("density_hour")), date, "/data/market/accurate_push_person_density")
  }

}
