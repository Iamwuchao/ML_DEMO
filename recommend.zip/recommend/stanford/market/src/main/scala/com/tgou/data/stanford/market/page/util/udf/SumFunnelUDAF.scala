package com.tgou.data.stanford.market.page.util.udf

import org.apache.spark.sql.Row
import org.apache.spark.sql.expressions.{MutableAggregationBuffer, UserDefinedAggregateFunction}
import org.apache.spark.sql.types._


class SumFunnelUDAF(pages: List[String]) extends UserDefinedAggregateFunction{
  override def inputSchema: StructType = StructType(Seq(StructField("funnel_count", IntegerType),StructField("uv",IntegerType)))

  override def bufferSchema: StructType = StructType(StructField("values", MapType(IntegerType/*代表第几层*/, IntegerType/*第几层的值*/))::Nil)

  override def dataType: DataType = StringType

  override def deterministic: Boolean = true

  override def initialize(buffer: MutableAggregationBuffer): Unit = {
    buffer(0) = Map[String,Seq[Map[Int, Int]]]()
  }

  override def update(buffer: MutableAggregationBuffer, input: Row): Unit = {
    var map = buffer.getAs[Map[Int, Int]](0)
    map = map + (input.getInt(0) -> input.getInt(1))
    buffer(0) = map
  }

  override def merge(buffer1: MutableAggregationBuffer, buffer2: Row): Unit = {
    if(buffer2(0) != null){
      var map1 = buffer1.getAs[Map[Int, Int]](0)
      val map2 = buffer2.getAs[Map[Int, Int]](0)
      for(kv <- map2){
        map1 = map1 + kv
      }
      buffer1(0) = map1
    }
  }

  override def evaluate(buffer: Row): Any = {
    if(buffer(0) != null){
      var map = buffer.getAs[Map[Int, Int]](0)
      val length = pages.size
      for(i <- 0 until length){
        var v = 0
        for(p <-i until length){
          v = map.getOrElse(p+1,0) + v
        }
        map =  map + (i+1 -> v)
      }
      map.toList.sortWith((t1,t2) => t1._1 < t2._1).mkString(",")
    }else{
      val length = pages.size
      var map = Map(0 -> 0)
      for(i <- 0 until length){
        var v = 0
        map =  map + (i -> v)
      }
      map.toList.sortWith((t1,t2) => t1._1 < t2._1).mkString(",")
    }
  }
}
object SumFunnelUDAF {
  def main(args: Array[String]): Unit = {
    val pageList = List("10.pd","01.fx")
    new SumFunnelUDAF(pageList)
    var map = Map(
      (0->1),
      (1->2)
    )
    val length = pageList.size
    val length2 = map.size
    for(i <- 0 until length){
      var v = 0
      for(p <- i until length2){
        v = map.getOrElse(p,0) + v
      }
      map =  map + (i -> v)
    }
    val result = map.toList.sortWith((t1,t2) => t1._1 < t2._1).mkString(",")
    println(result)
  }
}