package com.tgou.data.stanford.market.accurate.push.person.source

import com.google.inject.Inject
import com.tgou.data.stanford.market.accurate.push.PushSource
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.joda.time.LocalDate

/**
  * Created by 李震 on 2017/11/20.
  */
class PushPersonSourceImpl @Inject()(spark: SparkSession, date: LocalDate) extends PushPersonSource {

  private val pushSource: PushSource = PushSource(spark, date)

  lazy val pushPersonDF = initPushPersonDF()

  lazy val pushMemberDF = initPushMemberDF()

  lazy val pushGroupMemberDF = initPushGroupMemberDF()


  private def initPushPersonDF(): DataFrame = {
    pushSource.pushPersonDF
  }


  private def initPushMemberDF(): DataFrame = {
    pushSource.pushMemberDF
  }


  private def initPushGroupMemberDF(): DataFrame = {
    // 新用户
    val newMemberDF = this.pushMemberDF.filter("register_time > push_time")
    newMemberDF.createOrReplaceTempView("new_member")

    // 老用户
    val oldMemberDF = this.pushMemberDF.filter("register_time <= push_time")
    oldMemberDF.createOrReplaceTempView("old_member")

    /*
     * 首次线上购物订单
     *
     * 条件：
     *
     * - 在线支付
     * - 物流配送
     *
     * 字段：
     *
     * - member_id  会员 ID
     * - first_online_time  第一次线上购物时间
     *
     * */
    val firstOnlineOrderDF = spark.sql(
      s"""
         |select
         |    o.member_id,
         |    min(o.create_time) as first_online_time
         |from dw.order_information o
         |join old_member om
         |on o.member_id = om.member_id
         |and o.his_time = '${date.toString("yyyy-MM-dd")}'
         |and o.order_type = '0'
         |and o.pay_method != '000'
         |and o.receive_method = '10'
         |and o.pay_time is not null
         |group by o.member_id
      """.stripMargin)
    firstOnlineOrderDF.createOrReplaceTempView("first_online_order")

    spark.sql(
      """
        |select
        |    nm.push_task_id,
        |    nm.push_time,
        |    nm.start_time,
        |    nm.end_time,
        |    nm.subject_code,
        |    nm.object_id,
        |    nm.object_type,
        |    nm.member_id,
        |    'new' as group,
        |    1 as is_first_online
        |from new_member nm
        |union
        |select
        |    om.push_task_id,
        |    om.push_time,
        |    om.start_time,
        |    om.end_time,
        |    om.subject_code,
        |    om.object_id,
        |    om.object_type,
        |    om.member_id,
        |    'old' as group,
        |    if(foo.first_online_time > om.push_time, 1, 0) as is_first_online
        |from old_member om
        |left join first_online_order foo
        |on om.member_id = foo.member_id
      """.stripMargin)
  }

}
