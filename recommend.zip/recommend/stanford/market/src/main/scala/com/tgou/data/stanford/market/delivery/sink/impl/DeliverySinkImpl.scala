package com.tgou.data.stanford.market.delivery.sink.impl

import com.datastax.spark.connector.cql.CassandraConnector
import com.google.inject.Inject
import com.tgou.data.stanford.market.delivery.sink.DeliverySink
import org.apache.spark.sql.cassandra._
import org.apache.spark.sql.{DataFrame, SparkSession}

/**
  * Created by 李震 on 2018/1/4.
  */
class DeliverySinkImpl @Inject()(spark: SparkSession) extends DeliverySink {

  override def saveToCassandra(df: DataFrame): Unit = {
    // 先删
    val connector = CassandraConnector(spark.sparkContext.getConf)
    connector.withSessionDo(session => {
      session.execute("truncate table market.tgou_delivery")
    })

    // 后存
    df.write.cassandraFormat("tgou_delivery", "market", "BI Cluster", true).save()
  }

}
