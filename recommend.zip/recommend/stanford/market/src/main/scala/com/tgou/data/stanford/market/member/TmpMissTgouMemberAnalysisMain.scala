package com.tgou.data.stanford.market.member

import java.time.LocalDate
import java.util.Properties

import org.apache.spark.sql.{DataFrame, SparkSession}
import scala.collection.mutable.ArrayBuffer

/**
  * 统计平台活跃&新增
  */
object TmpMissTgouMemberAnalysisMain {
  def main(args: Array[String]): Unit = {
    JdbcBootstrap(args).bootstrap(execute)
  }

  def execute(spark: SparkSession,appName: String, date: LocalDate, jdbcConfig: Properties): Unit = {
    var dateStart = LocalDate.parse("2018-03-01")
    val dateEnd = LocalDate.parse("2018-03-31")
    var buffer:ArrayBuffer[DataFrame] = ArrayBuffer()
    while (!dateStart.isAfter(dateEnd)){
      init(spark,dateStart)
      buffer += calErpOriginDetails(spark, dateStart)
      dateStart = dateStart.plusDays(1)
    }
    val result = buffer.reduce(_ union _)
    result.cache()
    result.createOrReplaceTempView("result_view")
    spark.sql(
      """
        | SELECT
        |  sum(count) as sum_count,
        |  path
        |  FROM result_view group by path
      """.stripMargin).show(false)
  }

  def init(spark: SparkSession,date: LocalDate): Unit = {

    val firstSessionSql =
      s"""
         |  SELECT member_id,min(session_id) as session_id FROM (
         |   SELECT t1.session_id,t1.member_id FROM
         |   (SELECT time,member_id,session_id FROM dw.uba_page where his_time = '$date' and member_id != '') t1
         |     INNER JOIN
         |   (SELECT MIN(time) as time,member_id FROM dw.uba_page where his_time = '$date' and member_id != '' GROUP BY member_id) t2
         |     ON t1.member_id = t2.member_id
         |     AND t1.time = t2.time
         | ) t
         | GROUP BY member_id
      """.stripMargin

    val firstSessionDf = spark.sql(
      s"""
         |SELECT
         | t1.member_id,
         | CASE
         |     WHEN t1.jr like 'erp.%' THEN 1
         |     ELSE 0 END AS jr,
         |     t1.page as page,
         |     t1.orgin as url,
         |     t1.time
         | FROM dw.uba_page t1
         | INNER JOIN ($firstSessionSql) t2
         | ON t1.session_id = t2.session_id
         | AND t1.member_id = t2.member_id
         | WHERE t1.his_time = '$date' and t1.member_id != ''
      """.stripMargin).filter(" jr > 0")
    firstSessionDf.cache()
    firstSessionDf.createOrReplaceTempView("first_uba")
  }

  def calErpOriginDetails(spark: SparkSession, date: LocalDate): DataFrame = {
    val innerSqlText =
      s"""
         | SELECT parse_url(t1.url, 'PATH') as path,t1.member_id FROM first_uba t1
         | INNER JOIN
         |  (SELECT min(time) as m_time, member_id FROM first_uba where jr is not null and jr >0 GROUP BY member_id) t2
         | ON t1.member_id = t2.member_id
         | AND t1.time = t2.m_time
       """.stripMargin
    val sQLText =
      s"""
         | SELECT count(distinct member_id) as count,path,'$date' as date
         | FROM
         |  ($innerSqlText)
         |  GROUP BY path
       """.stripMargin
    spark.sql(sQLText)
  }



  def calOriginDetails(spark: SparkSession, date: LocalDate): DataFrame = {
    //目的可以有多个。来源只能有一个。
    /** 来源 ******************************************************************/
    val sQLText =
      s"""
         | SELECT count(distinct t1.member_id) as origin_count,t1.jr,'$date' as date
         |  FROM (
         |   SELECT t1.member_id,FIRST_VALUE(t1.jr) as jr
         |     FROM
         |     first_uba t1
         |     INNER JOIN
         |     (select min(time) as m_time ,member_id from first_uba group by member_id) t2
         |     ON t1.member_id = t2.member_id
         |     AND t1.time = t2.m_time
         |     GROUP BY t1.member_id
         |  ) t1
         | GROUP BY t1.jr
      """.stripMargin
    val originDf = spark.sql(sQLText)
    originDf
  }
}
