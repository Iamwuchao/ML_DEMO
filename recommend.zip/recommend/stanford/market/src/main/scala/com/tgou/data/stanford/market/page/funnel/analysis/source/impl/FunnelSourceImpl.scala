package com.tgou.data.stanford.market.page.funnel.analysis.source.impl

import com.google.inject.Inject
import com.tgou.data.stanford.market.core.MarketSource
import com.tgou.data.stanford.market.core.utils.BeanUtils
import com.tgou.data.stanford.market.page.funnel.analysis.bean.MallActivityProductToGroup
import com.tgou.data.stanford.market.page.funnel.analysis.source.FunnelSource
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.joda.time.LocalDate

class FunnelSourceImpl @Inject()(spark: SparkSession, date: LocalDate) extends FunnelSource{

  override def getMallActivityProductToGroupDF: DataFrame = {
    MarketSource.getUpdateDF(
      spark,
      "/tiangou/item/mall_activity_product_to_group",
      date,
      Seq("id"),
      "modify_time",
      BeanUtils.getSchemaFromBean[MallActivityProductToGroup]
    )
  }

  /**
    * 4跨境 3是奇怪的yt 1是百货 2是超市
    * @return 加上yt的
    */
  override def getListingWithYtDf: DataFrame = {
    val sQLText =
      s"""
         | SELECT
         |  t1.listing_id,
         |  t1.product_id,
         |  CASE
         |   WHEN t1.source = 4 AND t2.is_international = 1 AND t2.yt = '4' then 4
         |   WHEN t1.source = 4 AND t2.is_international = 0 AND t2.yt = '4' then 3
         |   WHEN t1.source = 1 AND t2.is_international = 0 AND t2.yt = '1' then 1
         |   WHEN t1.source = 2 AND t2.is_international = 0 AND t2.yt = '2' then 2
         |   ELSE t1.source END as yt
         |  FROM
         | (SELECT listing_id,source,store_id,product_id FROM dw.listing where his_time = '$date' ) t1
         |  INNER JOIN
         |  (SELECT id,is_international,yt FROM dw.store where his_time = '$date') t2
         |  ON t1.store_id = t2.id
       """.stripMargin
    spark.sql(sQLText)
  }

  /**
    *
    * 必须在listing_t create后才可使用
    * @return
    */
  override def getUbaPageWithYtDf: DataFrame = {
    val sQLText =
      s"""
         | SELECT t1.*,t2.yt,t2.product_id FROM
         |  (SELECT member_id,uuid,subString(bk,6) as listing_id,deep,session_id FROM
         |      dw.uba_page
         |    WHERE his_time = '$date'
         |      AND a_b = '10.pd') t1
         | INNER JOIN listing_t t2
         |  ON t1.listing_id = t2.listing_id
       """.stripMargin
    spark.sql(sQLText)

  }

  override def getTodayUbaPageDf: DataFrame = {
    spark.sql(
      s"""
         | SELECT member_id,uuid,deep,session_id,page,orgin as url FROM
         | dw.uba_page
         | WHERE his_time = '$date'
       """.stripMargin)
  }
}
