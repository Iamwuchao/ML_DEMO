package com.tgou.data.stanford.market.accurate.push.person.process

import org.apache.spark.sql.DataFrame

/**
  * Created by 李震 on 2017/11/20.
  */
trait UBAProcess {

  /**
    * 处理用户行为
    *
    * @return
    *
    * 字段：
    *
    * - push_task_id 推送任务 ID
    * - member_id 会员 ID
    * - platform_pv 平台 PV
    * - first_visit_time 首次访问时间
    *
    * */
  def processUBADF: DataFrame

}
