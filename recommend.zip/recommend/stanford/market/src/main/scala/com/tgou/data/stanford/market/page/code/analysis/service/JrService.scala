package com.tgou.data.stanford.market.page.code.analysis.service

import java.time.LocalDate

import org.apache.spark.sql.{DataFrame, SparkSession}

object JrService {
  def getJr(spark: SparkSession, date: LocalDate): DataFrame = {
    //pv的inner sql。
    val innerTableSql =
      s"""
         | SELECT
         | CASE WHEN
         |    t.scp like '05.1.adv%' or t.scp like '05.1.uscode.01%' then '我的'
         |    WHEN
         |     t.scp like '14.sp.uscode.01%' or t.scp like '14.sp.uscode.00%' then '购物页'
         |    WHEN
         |    t.scp like '02.dd.code.0%' or t.scp like '08.smc.code.0%'
         |      or t.scp like '02.dd.uscode.01%' or t.scp like '08.smc.uscode.01%' then '逛店页'
         |    WHEN
         |    t.scp like '06.seaamoy.uscode.01%' then '跨境页'
         |    WHEN
         |     t.jr like 'erp.%' then '扫二维码' 
         |    WHEN
         |    t2.page = '05.1' then '我的' 
         |    WHEN
         |    t2.page in ('02.dd','08.smc') then '逛店页'
         |    WHEN
         |    t2.page = '14.sp' then '购物页'
         |    WHEN
         |    t2.page = '06.seaamoy' then '跨境页'
         |    ELSE '其他' END AS n_jr,
         |    t.member_id,
         |    t.uuid,t.scp,t.jr,t2.page as pre_page from
         |  (select t1.page,t1.m_id,t1.member_id,t1.uuid,t1.scp,t1.jr,max(t2.deep) as pre_deep
         |from 
         |(select page,member_id,uuid,member_identity_id as m_id,jr,scp,deep from  dw.uba_page where his_time = '$date' and page = '05.code' and arrival_mode = 1) t1
         |left join 
         |(select page,member_identity_id as m_id,deep from  dw.uba_page where his_time = '$date' and page in ('05.1','14.sp','01.store','02.dd','08.smc','06.seaamoy') ) t2
         |on t1.deep > t2.deep
         |and t1.m_id = t2.m_id
         |group by t1.page,t1.m_id,t1.member_id,t1.uuid,t1.scp,t1.jr) t
         |left join 
         |(select page,member_identity_id as m_id,deep from  dw.uba_page where his_time = '$date' and page in ('05.1','14.sp','01.store','02.dd','08.smc','06.seaamoy') ) t2
         |on t.m_id = t2.m_id
         |and t.pre_deep is not null
         |and t.pre_deep = t2.deep
       """.stripMargin
    val innerTableDf = spark.sql(innerTableSql)
    innerTableDf.cache()
    innerTableDf.createOrReplaceTempView("inner_table")
    //加上用户m_ud。然后求出其pv、uv
    val pageViewSqlText =
      s"""
         | SELECT * FROM
         | (  SELECT count(1) as pv,count(distinct m_ud) as uv,n_jr FROM
         |    (SELECT t2.m_ud,t1.n_jr
         |    FROM
         |      inner_table t1
         |    INNER JOIN
         |      day_member t2
         |      ON (t1.member_id = t2.m_ud or t1.uuid = t2.m_ud)
         |    ) group by n_jr
         | )UNION
         | (
         |  SELECT 0 as pv,count(distinct t2.m_ud),'合计' as n_jr
         |    FROM
         |      inner_table t1
         |    INNER JOIN
         |      day_member t2
         |      ON (t1.member_id = t2.m_ud or t1.uuid = t2.m_ud)
         | )
       """.stripMargin

    spark.sql(s"SELECT jr,member_id ,uuid,scp, page from dw.uba_page where his_time = '$date' and page = '05.code' and jr != '' and jr like 'erp.%' and scp = ''")
      .createOrReplaceTempView("jr_table")
    val clickSqlTextInner =
      s"""
         |  SELECT t2.m_ud,t1.n_jr FROM
         |  (SELECT * FROM
         |    (select
         |    CASE
         |    WHEN t.scp like '05.1.adv.%' or t.scp like '05.1.uscode.01%' then '我的'
         |    WHEN
         |      t.scp like '14.sp.uscode.01%' then '购物页'
         |    WHEN
         |      t.scp like '02.dd.code.%' or t.scp like '08.smc.code.%'
         |      or t.scp like '02.dd.uscode.01%' or t.scp like '08.smc.uscode.01%' then '逛店页'
         |    WHEN
         |      t.scp like '06.seaamoy.uscode.01%' then '跨境页'
         |    END AS n_jr,
         |    m_id as member_id,uuid FROM
         |  fm_scp t WHERE  (
         |      t.scp like '05.1.adv.%'
         |      or t.scp like '05.1.uscode.01%'
         |      or t.scp like '14.sp.uscode.01%'
         |      or t.scp like '02.dd.uscode.01%'
         |      or t.scp like '02.dd.code.%'
         |      or t.scp like '08.smc.code.%'
         |      or t.scp like '08.smc.uscode.01%'
         |      or scp like '06.seaamoy.uscode.01%')
         |  )
         |  UNION
         |    ( SELECT '扫二维码' AS n_jr,member_id,uuid from jr_table )
         | ) t1
         | INNER JOIN
         |  day_member t2
         | ON (t1.member_id = t2.m_ud or t1.uuid = t2.m_ud)
       """.stripMargin
    val clickDf = spark.sql(clickSqlTextInner)
    clickDf.cache()
    clickDf.createOrReplaceTempView("click_inner_t")
    val clickSqlText =
      s"""
         | SELECT * FROM
         | (
         |  SELECT count(1) as c_pv,count(distinct m_ud) as c_uv,n_jr FROM
         |    click_inner_t
         |    GROUP BY n_jr
         | )
         | UNION
         | (
         |  SELECT 0 as c_pv,count(distinct m_ud),'合计' as n_jr FROM click_inner_t
         | )
       """.stripMargin
    val sqlText =
      s"""
         | SELECT
         |   t1.n_jr,
         |   t1.pv,
         |   t2.c_pv,
         |   t1.uv,
         |   t2.c_uv,
         |   '$date' as `date` FROM
         | ($pageViewSqlText) t1
         | left join
         | ($clickSqlText) t2
         | ON t1.n_jr = t2.n_jr
       """.stripMargin
    spark.sql(sqlText)
  }
}
