package com.tgou.data.stanford.market.accurate.push;

/**
 * Created by 李震 on 2017/11/16.
 */
public interface Constants {

    public static final int STATICS_DURATION = 31;

}
