# Stanford工程为新的bi工程

- core 核心模块
- dw 数据仓库
- mail 邮件系统
- market 数据集市
- persona 推荐系统工具包，主要用于xclient和recommend接口工程
- rec-common
- recommend 推荐系统模块
- sirius 新的BI的spark后端服务
- streaming 流处理模块