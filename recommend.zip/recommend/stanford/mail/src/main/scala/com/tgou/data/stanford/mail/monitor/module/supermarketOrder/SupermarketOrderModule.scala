package com.tgou.data.stanford.mail.monitor.module.supermarketOrder

import org.apache.spark.sql.{DataFrame, SparkSession}
import org.joda.time.LocalDate

/**
  * Created by 张少锐 on 2017/9/26.
  * 天狗超市订单
  */
object SupermarketOrderModule {

  def getSupermarketOrder(spark: SparkSession, date: LocalDate): DataFrame = {

    val yesterday = date.toString("yyyy-MM-dd")
    val month = date.withDayOfMonth(1).toString("yyyy-MM-dd")
    val monthPlus1 = date.plusDays(1).toString("yyyy-MM-dd")
    /*
     * 加载数据源
     * */
    spark.sql(
      s"""
         |select
         |     oi.id,
         |     oi.order_id,
         |     oi.member_id,
         |     oi.receive_method,
         |     cast(oi.`total_amount` as double) as total_amount,
         |     to_date(oi.create_time) as create_time,
         |     to_date(oi.pay_time) as pay_time,
         |     to_date(oi.ship_time) as ship_time
         |from dw.order_information oi
         |where
         |     oi.his_time = '${yesterday}'
         |and  oi.order_source = '2'
       """.stripMargin).createTempView("supermarket_order_information")

    spark.sql(
      s"""
         |select
         |      op.fk_order_information_id,
         |      cast(op.`product_quantity` as bigint) as product_quantity
         |from  dw.order_product op
         |where
         |      op.his_time = '${yesterday}'
         |and   op.product_source = '2'
       """.stripMargin).createTempView("supermarket_order_product")

    /**
      * 天狗超市订单
      *
      * 字段：
      *
      * - sm_order_count  当日下单笔数
      * - sm_member_count 当日下单人数
      * - sm_product_quantity_sum 当日下单商品数量
      * - sm_total_amount_sum 当日下单总金额
      * - sm_pay_order_count  当日支付笔数
      * - sm_pay_member_count  当日支付人数
      * - sm_pay_total_amount_sum  当日支付总金额
      * - sm_month_total_amount_sum 当月累计下单金额
      * - sm_month_pay_total_amount_sum 当月累计支付金额
      * - sm_send_order_count  当日下单笔数(配送)
      * - sm_send_member_count 当日下单人数(配送)
      * - sm_send_product_quantity_sum 当日下单商品数量(配送)
      * - sm_send_total_amount_sum 当日下单总金额(配送)
      * - sm_send_pay_order_count  当日支付笔数(配送)
      * - sm_send_pay_member_count  当日支付人数(配送)
      * - sm_send_pay_total_amount_sum  当日支付总金额(配送)
      * - sm_ship_send_order_count  当日配送订单笔数(配送)
      * - sm_ship_send_total_amount_sum 当日配送订单金额(配送)
      * - sm_month_send_total_amount_sum 当月累计下单金额(配送)
      * - sm_month_send_pay_total_amount_sum 当月累计支付金额(配送)
      **/
    /*
      *  sm_order_count  当日下单笔数
      *  sm_member_count 当日下单人数
      *  sm_product_quantity_sum 当日下单商品数量
      */
    val goodsOrderDF = spark.sql(
      s"""
         |select
         |    count(distinct oi.order_id) as sm_order_count,
         |    count(distinct oi.member_id) as sm_member_count,
         |    nvl(sum(op.product_quantity),0) as sm_product_quantity_sum
         |from supermarket_order_information oi
         |join (
         |    select
         |      op.fk_order_information_id,
         |      op.product_quantity
         |    from supermarket_order_product op
         |) op
         |on (
         |    oi.id = op.fk_order_information_id
         |    and oi.create_time is not null
         |    and oi.create_time = '${yesterday}'
         |)
      """.stripMargin
    )

    /*
     * sm_total_amount_sum 当日下单总金额
     * */
    val goodsOrderSumDF = spark.sql(
      s"""
         |select
         |    nvl(cast(sum(oi.total_amount) as decimal(18,2)),0) as sm_total_amount_sum
         |from supermarket_order_information oi
         |where oi.create_time is not null
         |and oi.create_time = '${yesterday}'
      """.stripMargin
    )

    /*
      *  sm_pay_order_count  当日支付笔数
      *  sm_pay_member_count  当日支付人数
      *  sm_pay_total_amount_sum  当日支付总金额
      */
    val payOrderDF = spark.sql(
      s"""
         |select
         |    count(distinct oi.order_id) as sm_pay_order_count,
         |    count(distinct oi.member_id) as sm_pay_member_count,
         |    nvl(cast(sum(oi.total_amount) as decimal(18,2)),0) as sm_pay_total_amount_sum
         |from supermarket_order_information oi
         |where oi.pay_time is not null
         |and oi.pay_time = '${yesterday}'
       """.stripMargin
    )

    /*
      *  sm_month_total_amount_sum 当月累计下单金额
      */
    val monthOrderDF = spark.sql(
      s"""
         |select
         |    nvl(cast(sum(oi.total_amount) as decimal(18,2)),0) as sm_month_total_amount_sum
         |from supermarket_order_information oi
         |where oi.create_time is not null
         |and oi.create_time >= '${month}'
         |and oi.create_time < '${monthPlus1}'
       """.stripMargin
    )

    /*
      *  sm_month_pay_total_amount_sum 当月累计支付金额
      */
    val monthPayDF = spark.sql(
      s"""
         |select
         |    nvl(cast(sum(oi.total_amount) as decimal(18,2)),0) as sm_month_pay_total_amount_sum
         |from supermarket_order_information oi
         |where oi.pay_time is not null
         |and oi.pay_time >= '${month}'
         |and oi.pay_time < '${monthPlus1}'
       """.stripMargin
    )

    /*
      *  sm_send_order_count  当日下单笔数(配送)
      *  sm_send_member_count 当日下单人数(配送)
      *  sm_send_product_quantity_sum 当日下单商品数量(配送)
      *
      */
    val sendOrderDF = spark.sql(
      s"""
         |select
         |    count(distinct oi.order_id) as sm_send_order_count,
         |    count(distinct oi.member_id) as sm_send_member_count,
         |    nvl(sum(op.product_quantity),0) as sm_send_product_quantity_sum
         |from supermarket_order_information oi
         |join (
         |    select
         |      op.fk_order_information_id,
         |      op.product_quantity
         |    from supermarket_order_product op
         |) op
         |on (
         |    oi.id = op.fk_order_information_id
         |    and oi.receive_method = '10'
         |    and oi.create_time is not null
         |    and oi.create_time = '${yesterday}'
         |)
       """.stripMargin
    )

    /*
     * sm_send_total_amount_sum 当日下单总金额(配送)
     * */
    val sendOrderSumDF = spark.sql(
      s"""
         |select
         |    nvl(cast(sum(oi.total_amount) as decimal(18,2)),0) as sm_send_total_amount_sum
         |from supermarket_order_information oi
         |where oi.receive_method = '10'
         |and oi.create_time is not null
         |and oi.create_time = '${yesterday}'
       """.stripMargin
    )

    /*
      *  sm_send_pay_order_count  当日支付笔数(配送)
      *  sm_send_pay_member_count  当日支付人数(配送)
      *  sm_send_pay_total_amount_sum  当日支付总金额(配送)
      */
    val sendPayDF = spark.sql(
      s"""
         |select
         |    count(distinct oi.order_id) as sm_send_pay_order_count,
         |    count(distinct oi.member_id) as sm_send_pay_member_count,
         |    nvl(cast(sum(oi.total_amount) as decimal(18,2)),0) as sm_send_pay_total_amount_sum
         |from supermarket_order_information oi
         |where oi.receive_method = '10'
         |and oi.pay_time is not null
         |and oi.pay_time = '${yesterday}'
       """.stripMargin
    )

    /*
      *  sm_ship_send_order_count  当日配送订单笔数(配送)
      *  sm_ship_send_total_amount_sum 当日配送订单金额(配送)
      */
    val sendShipDF = spark.sql(
      s"""
         |select
         |    count(distinct oi.order_id) as sm_ship_send_order_count,
         |    nvl(cast(sum(oi.total_amount) as decimal(18,2)),0) as sm_ship_send_total_amount_sum
         |from supermarket_order_information oi
         |where oi.receive_method = '10'
         |and oi.ship_time is not null
         |and oi.ship_time = '${yesterday}'
       """.stripMargin
    )

    /*
      *  sm_month_send_total_amount_sum 当月累计下单金额(配送)
      */
    val sendMonthOrderDF = spark.sql(
      s"""
         |select
         |    nvl(cast(sum(oi.total_amount) as decimal(18,2)),0) as sm_month_send_total_amount_sum
         |from supermarket_order_information oi
         |where oi.receive_method = '10'
         |and oi.create_time is not null
         |and oi.create_time >= '${month}'
         |and oi.create_time < '${monthPlus1}'
       """.stripMargin
    )

    /*
      *  sm_month_send_pay_total_amount_sum 当月累计支付金额(配送)
      */
    val sendMonthPayDF = spark.sql(
      s"""
         |select
         |    nvl(cast(sum(oi.total_amount) as decimal(18,2)),0) as sm_month_send_pay_total_amount_sum
         |from supermarket_order_information oi
         |where oi.receive_method = '10'
         |and oi.pay_time is not null
         |and oi.pay_time >= '${month}'
         |and oi.pay_time < '${monthPlus1}'
       """.stripMargin
    )

    goodsOrderDF.crossJoin(goodsOrderSumDF)
      .crossJoin(payOrderDF)
      .crossJoin(monthOrderDF)
      .crossJoin(monthPayDF)
      .crossJoin(sendOrderDF)
      .crossJoin(sendOrderSumDF)
      .crossJoin(sendPayDF)
      .crossJoin(sendShipDF)
      .crossJoin(sendMonthOrderDF)
      .crossJoin(sendMonthPayDF)
      .select(
        "sm_order_count",
        "sm_member_count",
        "sm_product_quantity_sum",
        "sm_total_amount_sum",
        "sm_pay_order_count",
        "sm_pay_member_count",
        "sm_pay_total_amount_sum",
        "sm_month_total_amount_sum",
        "sm_month_pay_total_amount_sum",
        "sm_send_order_count",
        "sm_send_member_count",
        "sm_send_product_quantity_sum",
        "sm_send_total_amount_sum",
        "sm_send_pay_order_count",
        "sm_send_pay_member_count",
        "sm_send_pay_total_amount_sum",
        "sm_ship_send_order_count",
        "sm_ship_send_total_amount_sum",
        "sm_month_send_total_amount_sum",
        "sm_month_send_pay_total_amount_sum"
      )

  }
}
