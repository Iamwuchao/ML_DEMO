package com.tgou.data.stanford.mail.tiangouBrand.module

import org.apache.spark.sql.{DataFrame, SparkSession}
import org.joda.time.LocalDate

/**
  * Created by 张少锐 on 2017/12/18.
  * 天狗百货品牌汇总表
  */

object TiangouBrandSum {

  def getTiangouBrandSum(spark: SparkSession, appName: String, date: LocalDate): DataFrame = {

    val yesterday = date.toString("yyyy-MM-dd")
    var yesterdayPlus1: String = null
    var yesterdayMinus7: String = null

    if (appName.equals("weekcount")) {
      //周统计
      yesterdayMinus7 = date.minusDays(6).toString("yyyy-MM-dd")
      yesterdayPlus1 = date.plusDays(1).toString("yyyy-MM-dd")

    } else if (appName.equals("monthcount")) {
      //月统计
      yesterdayMinus7 = date.withDayOfMonth(1).toString("yyyy-MM-dd")
      yesterdayPlus1 = date.plusMonths(1).withDayOfMonth(1).toString("yyyy-MM-dd")

    }else {
      //每个月的周五都运行,但是限制每个月的周五在2号到8号才执行
      if(2<=date.plusDays(1).getDayOfMonth&&date.plusDays(1).getDayOfMonth<=8){
        //月初第一周统计
        yesterdayMinus7 = date.withDayOfMonth(1).toString("yyyy-MM-dd")
        yesterdayPlus1 = date.withDayOfWeek(5).toString("yyyy-MM-dd")
      }else{
        //让程序报错，不运行
        System.out.println("当前统计日期是"+date+",不符合月初第一周")
        spark.close()
      }

    }

    /*
      * 加载数据源
      * */
    spark.sql(
      s"""
         |select
         |     l.product_id
         |from dw.listing l
         |where l.his_time = '$yesterday'
         |and l.state = 'onshelf'
         |and l.source = '1'
       """.stripMargin).createOrReplaceTempView("listing")

    spark.sql(
      s"""
         |select
         |     p.product_id,
         |     p.brand_id
         |from dw.product p
         |where p.his_time = '$yesterday'
       """.stripMargin).createOrReplaceTempView("product")

    spark.sql(
      s"""
         |select
         |     b.id,
         |     b.name
         |from dw.brand b
         |where b.his_time = '$yesterday'
       """.stripMargin).createOrReplaceTempView("brand")

    spark.sql(
      s"""
         |select
         |     oi.order_id
         |from dw.order_information oi
         |where
         |     oi.his_time = '${yesterday}'
         |and  oi.order_source = '1'
         |and  oi.receive_method = '10'
       """.stripMargin).createOrReplaceTempView("order_information")

    spark.sql(
      s"""
         |select
         |     op.tgou_order_id,
         |     op.brand_id,
         |     to_date(op.cancel_time) as cancel_time,
         |     to_date(op.return_time) as return_time,
         |     to_date(op.create_time) as create_time,
         |     to_date(op.ship_time) as ship_time
         |from dw.order_product op
         |where
         |     op.his_time = '${yesterday}'
         |and  op.product_source = '1'
       """.stripMargin).createOrReplaceTempView("order_product")

    /**
      * 天狗百货品牌汇总表
      *
      * 字段:
      *  - kxspps 可销售品牌数
      *  - xdpps 下单品牌数
      *  - xdpspps 下单配送品牌数
      *  - qxpps 取消品牌数
      *  - thpps 退货品牌数
      *  - hxpps 核销品牌数
      *  - pspps 物流配送品牌数
      **/
    val kxsppsDF = spark.sql(
      s"""
         |select
         |     count(distinct b.name) as kxspps
         |from listing l
         |join product p
         |on l.product_id = p.product_id
         |join brand b
         |on p.brand_id = b.id
       """.stripMargin)

    val xdppsDF = spark.sql(
      s"""
         |select
         |     count(distinct b.name) as xdpps
         |from order_product op
         |join brand b
         |on op.brand_id = b.id
         |where op.create_time >= '$yesterdayMinus7'
         |and op.create_time < '$yesterdayPlus1'
       """.stripMargin)

    val xdpsppsDF = spark.sql(
      s"""
         |select
         |     count(distinct b.name) as xdpspps
         |from order_product op
         |join order_information oi
         |on oi.order_id = op.tgou_order_id
         |join brand b
         |on op.brand_id = b.id
         |where op.create_time >= '$yesterdayMinus7'
         |and op.create_time < '$yesterdayPlus1'
       """.stripMargin)

    val qxppsDF = spark.sql(
      s"""
         |select
         |     count(distinct b.name) as qxpps
         |from order_product op
         |join brand b
         |on op.brand_id = b.id
         |where op.cancel_time >= '$yesterdayMinus7'
         |and op.cancel_time < '$yesterdayPlus1'
       """.stripMargin)

    val thppsDF = spark.sql(
      s"""
         |select
         |     count(distinct b.name) as thpps
         |from order_product op
         |join brand b
         |on op.brand_id = b.id
         |where op.return_time >= '$yesterdayMinus7'
         |and op.return_time < '$yesterdayPlus1'
       """.stripMargin)

    val hxppsDF = spark.sql(
      s"""
         |select
         |     count(distinct b.name) as hxpps
         |from order_product op
         |join brand b
         |on op.brand_id = b.id
         |where op.ship_time >= '$yesterdayMinus7'
         |and op.ship_time < '$yesterdayPlus1'
       """.stripMargin)

    val psppsDF = spark.sql(
      s"""
         |select
         |     count(distinct b.name) as pspps
         |from order_product op
         |join order_information oi
         |on oi.order_id = op.tgou_order_id
         |join brand b
         |on op.brand_id = b.id
         |where op.ship_time >= '$yesterdayMinus7'
         |and op.ship_time < '$yesterdayPlus1'
       """.stripMargin)

    kxsppsDF.crossJoin(xdppsDF).
      crossJoin(xdpsppsDF).
      crossJoin(qxppsDF).
      crossJoin(thppsDF).
      crossJoin(hxppsDF).
      crossJoin(psppsDF)
  }
}
