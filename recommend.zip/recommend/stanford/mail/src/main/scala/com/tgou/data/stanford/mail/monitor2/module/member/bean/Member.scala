package com.tgou.data.stanford.mail.monitor2.module.member.bean

/**
  * Created by 李震 on 2017/12/5.
  */
case class Member (
                    member_id: String,
                    register_time: String
                  )
