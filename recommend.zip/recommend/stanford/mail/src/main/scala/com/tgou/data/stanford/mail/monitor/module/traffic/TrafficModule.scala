package com.tgou.data.stanford.mail.monitor.module.traffic

import org.apache.spark.sql.{DataFrame, SparkSession}
import org.joda.time.LocalDate

/**
  * Created by 李震 on 2017/9/27.
  */
object TrafficModule {

  /**
    * 天狗平台流量统计
    *
    * @param spark
    * @param date
    *
    * @return
    *
    * 字段：
    *
    * - platform_pv  平台 PV
    * - platform_uv  平台 UV
    * - platform_search  平台搜索量
    *
    * */
  def getTrafficDF(spark: SparkSession, date: LocalDate): DataFrame = {

    /*
     * 加载数据源
     * */
    val source = TrafficSource(spark)
    source.getAppendUbaPageDWDF(date).createTempView("traffic_uba_page")
    source.getAppendSearchODSDF(date).createTempView("traffic_search")

    /*
     * platform_pv  平台 PV
     * platform_uv  平台 UV
     * */
    val platformUBADF = spark.sql(
      """
        |select
        |  count(1) AS platform_pv,
        |  count(distinct up.uuid) AS platform_uv
        |from traffic_uba_page up
      """.stripMargin)

    /*
     * platform_search  平台搜索
     * */
    val platformSearchDF = spark.sql(
      """
        |select
        |  count(distinct concat(s.uuid, '_', s.keyword)) as platform_search
        |from traffic_search s
      """.stripMargin)

    platformUBADF.crossJoin(platformSearchDF)
      .select("platform_pv", "platform_uv", "platform_search")
  }

}
