package com.tgou.data.stanford.mail.parkingLot

import org.apache.spark.sql.{DataFrame, SparkSession}
import com.tgou.data.stanford.mail.core.MailBootstrap
import org.apache.spark.sql.{SaveMode, SparkSession}
import org.joda.time.LocalDate
import com.tgou.data.stanford.mail.parkingLot.Bean._

/**
  * Created by 刘洋 on 2017/12/12.
  *停车场邮件报表周报
  * - query 本周合计
  */

object ParkingLotTotalMain {
  def main(args: Array[String]): Unit = {
    MailBootstrap(args).bootstrap(execute)
  }

  def execute(spark: SparkSession, appName: String, date: LocalDate): Unit = {


    /**
      * 第一步 获取数据
      * */
    val result = ParkingLotTotalMain.parkingLotTotalQuery(spark, date)
    /**
      * 第二步 保存数据到HDFS上
      * */
    result.coalesce(1).write.mode(SaveMode.Overwrite).json(s"/data/mail/parking_lot/parking_lot_total/$date/")

    spark.stop()

  }
  def parkingLotTotalQuery(spark: SparkSession, date: LocalDate): DataFrame = {

    val yesday = date.toString("yyyy-MM-dd")
    /**
      * 读取抽取层park_bill表中当天的数据
      * */
    val parkBill = spark.read
      .options(Map(
        "delimiter" -> "^",
        "nullValue" -> "\\N",
        "quote" -> ""
      ))
      .csv(s"/tiangou/tgouorder/park_bill/*/*/*/*")
      .select(ParkingBill.columns: _*)
      .toDF(ParkingBill.title: _*)

    parkBill.createTempView("park_bill_t")
    /**
      * 本周统计
      */
    val totalQuery = spark.sql(
      s"""
         |select
         |  count(distinct a.fk_member_id) as query
         |  from park_bill_t a
         |  inner join dw.ds_card_bind b
         |  on a.fk_member_id = b.member_id
         |  and b.his_time = '${yesday}'
       """.stripMargin)
    totalQuery
   }
 }

