package com.tgou.data.stanford.mail.timeLimitActivity

import com.tgou.data.stanford.mail.core.MailBootstrap
import com.tgou.data.stanford.mail.timeLimitActivity.module.{CrossBorderModule, DepartmentModule, SocialModule, TotalModule}
import org.apache.spark.sql.{SaveMode, SparkSession}
import org.joda.time.LocalDate

/**
  * Created by 张少锐 on 2018/01/05.
  * 限时抢日报
  */

object TimeLimitActivityMain {

  def main(args: Array[String]): Unit = {
    MailBootstrap(args).bootstrap(execute)
  }

  def execute(spark: SparkSession, appName: String, date: LocalDate): Unit = {
    /**
      * 第一步 获取数据
      * */
    val total = TotalModule.getTotalModule(spark,date)
    val crossBorder = CrossBorderModule.getCrossBorderModule(spark,date)
    val department = DepartmentModule.getDepartmentModule(spark,date)
    val social = SocialModule.getSocialModule(spark,date)

    /**
      * 第二步 保存数据到HDFS上
      * */
    total.coalesce(1).write.mode(SaveMode.Overwrite).json(s"/data/mail/time_limit_activity/total/$date/")
    crossBorder.coalesce(1).write.mode(SaveMode.Overwrite).json(s"/data/mail/time_limit_activity/crossBorder/$date/")
    department.coalesce(1).write.mode(SaveMode.Overwrite).json(s"/data/mail/time_limit_activity/department/$date/")
    social.coalesce(1).write.mode(SaveMode.Overwrite).json(s"/data/mail/time_limit_activity/social/$date/")
  }
}
