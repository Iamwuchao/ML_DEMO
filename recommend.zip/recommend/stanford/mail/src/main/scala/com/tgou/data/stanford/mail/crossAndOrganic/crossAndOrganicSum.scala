package com.tgou.data.stanford.mail.crossAndOrganic

import com.tgou.data.stanford.mail.core.MailSource
import org.apache.spark.sql.types.{LongType, StringType, StructField, StructType}
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.joda.time.LocalDate

/**
  * Created by 张少锐 on 2018/03/01.
  * 跨境&有机现货率日报
  */
class crossAndOrganicSum protected(spark: SparkSession, date: LocalDate){

  val yesterday = date.toString("yyyy-MM-dd")
  val today = date.plusDays(1).toString("yyyy-MM-dd")

  // 营销品库存表
  val mas = StructType(
    StructField("id", StringType, false) ::
      StructField("fk_item_id", StringType, true) ::
      StructField("fk_product_sku_id", StringType, true) ::
      StructField("price", StringType, true) ::
      StructField("image_url", StringType, true) ::
      StructField("remain_qty", LongType, true) ::
      StructField("sku_attribute_str", StringType, true) ::
      StructField("version", StringType, true) ::
      StructField("state", StringType, true) ::
      StructField("create_time", StringType, true) ::
      StructField("modify_time", StringType, true) ::Nil
  )
  MailSource.getUpdateDF(spark,"/tiangou/tgou/mall_activity_sku",date,Seq("id"),"modify_time",mas)
    .distinct().createOrReplaceTempView("mall_activity_sku")

  /**
    * 跨境商品统计
    *
    * 字段:
    *  - channel 频道
    *  - id 商品ID
    *  - name 品名
    *  - quantity 下单商品数
    *  - remain_qty 商品剩余数
    **/

   def getCrossProductSum(): DataFrame = {
    spark.sql(
      s"""
         |select
         |    '跨境' as channel,
         |    l.listing_id as id,
         |    max(l.name) as name,
         |    sum(op.product_quantity) as quantity,
         |    min(mas.remain_qty) as remain_qty
         |from dw.order_product op
         |join dw.listing l
         |on op.mall_product_id = l.listing_id
         |and op.his_time = '${yesterday}'
         |and l.his_time = '${yesterday}'
         |and op.product_source = '4'
         |and op.create_time >= '${yesterday} 00:00:00'
         |and op.create_time < '${today} 00:00:00'
         |join mall_activity_sku mas
         |on op.mall_product_id = mas.fk_item_id
         |group by l.listing_id
       """.stripMargin)
  }

  /**
    * 跨境-分类现货率统计
    *
    * 字段:
    *  - channel 频道
    *  - name 分类
    *  - zssps 在售商品数频道
    *  - kcdy0 库存大于0商品数频道
    *  - xh_rate 现货率频道
    **/
  def getCrossCategorySum(): DataFrame = {
    spark.sql(
      s"""
         |select
         |    '跨境' as channel,
         |    c.name as name,
         |    count(distinct l.listing_id) as zssps,
         |    count(distinct case when mas.remain_qty > 0 then l.listing_id else null end) as kcdy0,
         |    nvl(round((count(distinct case when mas.remain_qty > 0 then l.listing_id else null end) / count(distinct l.listing_id) ) * 100,2),0) as xh_rate
         |from dw.listing l
         |join mall_activity_sku mas
         |on l.listing_id = mas.fk_item_id
         |and l.his_time = '${yesterday}'
         |and l.state = 'onshelf'
         |and l.source = '4'
         |join dw.product p
         |on l.product_id = p.product_id
         |and p.his_time = '${yesterday}'
         |join dw.category c
         |on c.id = p.product_second_category
         |and c.his_time = '${yesterday}'
         |group by c.id,c.name
       """.stripMargin)
  }

  /**
    * 跨境-供应商现货率统计
    *
    * 字段:
    *  - channel 频道
    *  - name 店铺
    *  - zssps 在售商品数
    *  - kcdy0 库存大于0商品数
    *  - xh_rate 现货率
    **/
  def getCrossStoreSum(): DataFrame = {
    spark.sql(
      s"""
         |select
         |    '跨境' as channel,
         |    s.store_name as name,
         |    count(distinct l.listing_id) as zssps,
         |    count(distinct case when mas.remain_qty > 0 then l.listing_id else null end) as kcdy0,
         |    nvl(round((count(distinct case when mas.remain_qty > 0 then l.listing_id else null end) / count(distinct l.listing_id) ) * 100,2),0) as xh_rate
         |from dw.listing l
         |join mall_activity_sku mas
         |on l.listing_id = mas.fk_item_id
         |and l.his_time = '${yesterday}'
         |and l.state = 'onshelf'
         |and l.source = '4'
         |join dw.store s
         |on l.store_id = s.id
         |and s.his_time = '${yesterday}'
         |and s.state = 'onshelf'
         |and (s.id in(
         |            '1263',
         |            '1321',
         |            '1336',
         |            '1339',
         |            '1342',
         |            '1370',
         |            '1386',
         |            '1395',
         |            '1388',
         |            '1396',
         |            '1403',
         |            '1400',
         |            '1412',
         |            '1422',
         |            '1410',
         |            '1420',
         |            '1421',
         |            '1419',
         |            '1451',
         |            '1458',
         |            '1461',
         |            '1467',
         |            '1473',
         |            '1475',
         |            '1478'
         |     ) or s.yt = '4')
         |group by s.id,s.store_name
       """.stripMargin)
  }

}

object crossAndOrganicSum {

  def apply(spark: SparkSession, date: LocalDate): crossAndOrganicSum = new crossAndOrganicSum(spark, date)

}
