  package com.tgou.data.stanford.mail.tiangouPaymnet.module

import org.apache.spark.sql.functions
import org.apache.spark.sql.{DataFrame, SparkSession}

import org.joda.time.LocalDate

/**
  * Created by 李磊 on 2017/11/16.
  * 天狗支付方式
  */

object TiangouPaymentMethod{
  /**
    * 字段：
    * - zfbkjwap_xdbs    支付宝跨境wap下单笔数
    * - zfbkjwap_zfcgbs  支付宝跨境wap支付成功笔数
    * - zfbkjwap_xdzb  支付宝跨境wap选择支付占比
    * - zfbkjwap_zfzb  支付宝跨境wap成功支付占比
    * - zfbkjwap_zfcgl   支付宝跨境wap支付成功率

    * - zfbkjapp_xdbs    支付宝跨境app下单笔数
    * - zfbkjapp_zfcgbs  支付宝跨境app支付成功笔数
    * - zfbkjapp_xdzb  支付宝跨境app选择支付占比
    * - zfbkjapp_zfzb  支付宝跨境app成功支付占比
    * - zfbkjapp_zfcgl   支付宝跨境app支付成功率

    * - zfbgnwap_xdbs    支付宝国内wap下单笔数
    * - zfbgnwap_zfcgbs  支付宝国内wap支付成功笔数
    * - zfbgnwap_xdzb  支付宝国内wap选择支付占比
    * - zfbgnwap_zfzb  支付宝国内wap成功支付占比
    * - zfbgnwap_zfcgl   支付宝国内wap支付成功率

    * - zfbgnapp_xdbs    支付宝国内app下单笔数
    * - zfbgnapp_zfcgbs  支付宝国内app支付成功笔数
    * - zfbgnapp_xdzb  支付宝国内app选择支付占比
    * - zfbgnapp_zfzb  支付宝国内app成功支付占比
    * - zfbgnapp_zfcgl   支付宝国内app支付成功率

    * - jfdz_xdbs        积分抵值下单笔数
    * - jfdz_zfcgbs      积分抵值支付成功笔数
    * - jfdz_xdzb  积分抵值选择支付占比
    * - jfdz_zfzb  积分抵值成功支付占比
    * - jfdz_zfcgl       积分抵值支付成功率

    * - ylapp_xdbs        银联app下单笔数
    * - ylapp_zfcgbs      银联app支付成功笔数
    * - ylapp_xdzb  银联app选择支付占比
    * - ylapp_zfzb  银联app成功支付占比
    * - ylapp_zfcgl       银联app支付成功率

    * - ylposjjk_xdbs     银联POS借记卡下单笔数
    * - ylposjjk_zfcgbs   银联POS借记卡支付成功笔数
    * - ylposjjk_xdzb  银联POS借记卡选择支付占比
    * - ylposjjk_zfzb  银联POS借记卡成功支付占比
    * - ylposjjk_zfcgl    银联POS借记卡支付成功率

    * - ylposdjk_xdbs     银联POS贷记卡下单笔数
    * - ylposdjk_zfcgbs   银联POS贷记卡支付成功笔数
    * - ylposdjk_xdzb  银联POS贷记卡选择支付占比
    * - ylposdjk_zfzb  银联POS贷记卡成功支付占比
    * - ylposdjk_zfcgl    银联POS贷记卡支付成功率

    * - yhdz_xdbs     优惠抵值下单笔数
    * - yhdz_zfcgbs   优惠抵值支付成功笔数
    * - yhdz_xdzb  优惠抵值选择支付占比
    * - yhdz_zfzb  优惠抵值成功支付占比
    * - yhdz_zfcgl    优惠抵值支付成功率

    * - wxgnwap_xdbs     微信国内wap下单笔数
    * - wxgnwap_zfcgbs   微信国内wap支付成功笔数
    * - wxgnwap_xdzb  微信国内wap选择支付占比
    * - wxgnwap_zfzb  微信国内wap成功支付占比
    * - wxgnwap_zfcgl    微信国内wap支付成功率

    * - wxkjwap_xdbs     微信跨境wap下单笔数
    * - wxkjwap_zfcgbs   微信跨境wap支付成功笔数
    * - wxkjwap_xdzb  微信跨境wap选择支付占比
    * - wxkjwap_zfzb  微信跨境wap成功支付占比
    * - wxkjwap_zfcgl    微信跨境wap支付成功率

    * - wxgnapp_xdbs     微信国内app下单笔数
    * - wxgnapp_zfcgbs   微信国内app支付成功笔数
    * - wxgnapp_xdzb  微信国内app选择支付占比
    * - wxgnapp_zfzb  微信国内app成功支付占比
    * - wxgnapp_zfcgl    微信国内app支付成功率

    * - wxkjapp_xdbs     微信跨境app下单笔数
    * - wxkjapp_zfcgbs   微信跨境app支付成功笔数
    * - wxkjapp_xdzb  微信跨境app选择支付占比
    * - wxkjapp_zfzb  微信跨境app成功支付占比
    * - wxkjapp_zfcgl    微信跨境app支付成功率
    *
    * - xdbs  下单笔数
    * - zfbs    支付笔数

    * */
  def getTansDF(spark:SparkSession, date: LocalDate): DataFrame = {

    val payBill = spark.read.format("csv")
      .option("delimiter", "^")
      .option("qoute", "")
      .option("nullValue", "\\N")
      .load(s"hdfs://nameservice1/tiangou/tgouorder/pay_bill/${date.toString("yyyy/MM/dd")}/*")

    val payBillS = payBill.select("_c0","_c2","_c4","_c10").toDF("id","biz_number","pay_type","modify_time")


    var payBillMax = payBillS.groupBy("id").agg(functions.max("modify_time") as "modify_time")

    var payBillY = payBillS.join(payBillMax,
      payBillS("id") === payBillMax("id")
        &&  payBillS("modify_time") === payBillMax("modify_time")
      ,"inner"
    ).select(
      payBillS("biz_number") ,
      payBillS("pay_type")
    )



    payBillY.createOrReplaceTempView("pay_bill_lilei")

    /*
           * 下单笔数
           * */
    val xdbs = spark.sql(
      s"""
         |select
         |count(distinct order_id) xdbs
         |from dw.order_information t
         |join pay_bill_lilei b
         |on t.order_id = b.biz_number
         |where t.his_time = '${date.toString("yyyy-MM-dd")}'
         |and t.create_time >= concat('${date.toString("yyyy-MM-dd")}', ' 00:00:00')
         |and t.create_time < concat(date_format(date_sub('${date.toString("yyyy-MM-dd")}', -1), 'yyyy-MM-dd'),' 00:00:00')
         |and t.order_type = 0
         |and pay_method != '000'
      """.stripMargin)

    val xdbss = xdbs.first().get(0).toString.toDouble


    /*
          * 支付笔数
          * */
    val zfbs = spark.sql(
      s"""
         |select
         |count(distinct order_id) zfbs
         |from dw.order_information t
         |where t.his_time = '${date.toString("yyyy-MM-dd")}'
         |and t.pay_time >= concat('${date.toString("yyyy-MM-dd")}', ' 00:00:00')
         |and t.pay_time < concat(date_format(date_sub('${date.toString("yyyy-MM-dd")}', -1), 'yyyy-MM-dd'),' 00:00:00')
         |and t.create_time >= concat('${date.toString("yyyy-MM-dd")}', ' 00:00:00')
         |and t.create_time < concat(date_format(date_sub('${date.toString("yyyy-MM-dd")}', -1), 'yyyy-MM-dd'),' 00:00:00')
         |and t.order_type = 0
         |and isnull(cancel_time)
         |and pay_method != '010'
         |and pay_method != '000'
      """.stripMargin)

    val zfbss = zfbs.first().get(0).toString.toDouble




    /*
           * 支付宝跨境wap
           * */
    val zfbkjwap = spark.sql(
      s"""
         |select
         |count(distinct order_id) zfbkjwap_xdbs ,
         |count(distinct case when t.pay_time >= concat('${date.toString("yyyy-MM-dd")}', ' 00:00:00')
         |and t.pay_time < concat(date_format(date_sub('${date.toString("yyyy-MM-dd")}', -1), 'yyyy-MM-dd'),' 00:00:00')
         |and isnull(cancel_time)
         |and pay_method != '010'
         |then order_id end ) zfbkjwap_zfcgbs,
         |nvl(cast((count(distinct order_id) /${xdbss} * 100)   as decimal(18,2)),0)  as zfbkjwap_xdzb  ,
         |nvl(cast((count(distinct case when t.pay_time >= concat('${date.toString("yyyy-MM-dd")}', ' 00:00:00')
         |and t.pay_time < concat(date_format(date_sub('${date.toString("yyyy-MM-dd")}', -1), 'yyyy-MM-dd'),' 00:00:00')
         |and isnull(cancel_time)
         |and pay_method != '010'
         |then order_id end ) /  ${zfbss}  * 100 )   as decimal(18,2)),0)  as zfbkjwap_zfzb,
         |nvl(cast((count(distinct case when t.pay_time >= concat('${date.toString("yyyy-MM-dd")}', ' 00:00:00')
         |and t.pay_time < concat(date_format(date_sub('${date.toString("yyyy-MM-dd")}', -1), 'yyyy-MM-dd'),' 00:00:00')
         |and isnull(cancel_time)
         |and pay_method != '010'
         |then order_id end ) / count(distinct order_id) * 100) as decimal(18,2)),0)   as zfbkjwap_zfcgl
         |from dw.order_information t
         |join pay_bill_lilei b
         |on t.order_id = b.biz_number
         |and b.pay_type = '4'
         |where t.his_time = '${date.toString("yyyy-MM-dd")}'
         |and t.create_time >= concat('${date.toString("yyyy-MM-dd")}', ' 00:00:00')
         |and t.create_time < concat(date_format(date_sub('${date.toString("yyyy-MM-dd")}', -1), 'yyyy-MM-dd'),' 00:00:00')
         |and t.order_type = 0
         |and pay_method != '000'
      """.stripMargin)

    /*
         * 支付宝跨境app
         * */
    val zfbkjapp = spark.sql(
      s"""
         |select
         |count(distinct order_id) zfbkjapp_xdbs ,
         |count(distinct case when t.pay_time >= concat('${date.toString("yyyy-MM-dd")}', ' 00:00:00')
         |and t.pay_time < concat(date_format(date_sub('${date.toString("yyyy-MM-dd")}', -1), 'yyyy-MM-dd'),' 00:00:00')
         |and isnull(cancel_time)
         |and pay_method != '010'
         |then order_id end ) zfbkjapp_zfcgbs,
         |nvl(cast((count(distinct order_id) /${xdbss} * 100)   as decimal(18,2)),0)  as zfbkjapp_xdzb  ,
         |nvl(cast((count(distinct case when t.pay_time >= concat('${date.toString("yyyy-MM-dd")}', ' 00:00:00')
         |and t.pay_time < concat(date_format(date_sub('${date.toString("yyyy-MM-dd")}', -1), 'yyyy-MM-dd'),' 00:00:00')
         |and isnull(cancel_time)
         |and pay_method != '010'
         |then order_id end ) /  ${zfbss}  * 100 )   as decimal(18,2)),0)  as zfbkjapp_zfzb,
         |nvl(cast((count(distinct case when t.pay_time >= concat('${date.toString("yyyy-MM-dd")}', ' 00:00:00')
         |and t.pay_time < concat(date_format(date_sub('${date.toString("yyyy-MM-dd")}', -1), 'yyyy-MM-dd'),' 00:00:00')
         |and isnull(cancel_time)
         |and pay_method != '010'
         |then order_id end ) / count(distinct order_id) * 100) as decimal(18,2)),0)   as zfbkjapp_zfcgl
         |from dw.order_information t
         |join pay_bill_lilei b
         |on t.order_id = b.biz_number
         |and b.pay_type = '11'
         |where t.his_time = '${date.toString("yyyy-MM-dd")}'
         |and t.create_time >= concat('${date.toString("yyyy-MM-dd")}', ' 00:00:00')
         |and t.create_time < concat(date_format(date_sub('${date.toString("yyyy-MM-dd")}', -1), 'yyyy-MM-dd'),' 00:00:00')
         |and t.order_type = 0
         |and pay_method != '000'
      """.stripMargin)


    /*
      * 支付宝国内wap
      * */
    val zfbgnwap = spark.sql(
      s"""
         |select
         |count(distinct order_id) zfbgnwap_xdbs ,
         |count(distinct case when t.pay_time >= concat('${date.toString("yyyy-MM-dd")}', ' 00:00:00')
         |and t.pay_time < concat(date_format(date_sub('${date.toString("yyyy-MM-dd")}', -1), 'yyyy-MM-dd'),' 00:00:00')
         |and isnull(cancel_time)
         |and pay_method != '010'
         |then order_id end ) zfbgnwap_zfcgbs,
         |nvl(cast((count(distinct order_id) /${xdbss} * 100)   as decimal(18,2)),0)  as zfbgnwap_xdzb  ,
         |nvl(cast((count(distinct case when t.pay_time >= concat('${date.toString("yyyy-MM-dd")}', ' 00:00:00')
         |and t.pay_time < concat(date_format(date_sub('${date.toString("yyyy-MM-dd")}', -1), 'yyyy-MM-dd'),' 00:00:00')
         |and isnull(cancel_time)
         |and pay_method != '010'
         |then order_id end ) /  ${zfbss}  * 100 )   as decimal(18,2)),0)  as zfbgnwap_zfzb,
         |nvl(cast((count(distinct case when t.pay_time >= concat('${date.toString("yyyy-MM-dd")}', ' 00:00:00')
         |and t.pay_time < concat(date_format(date_sub('${date.toString("yyyy-MM-dd")}', -1), 'yyyy-MM-dd'),' 00:00:00')
         |and isnull(cancel_time)
         |and pay_method != '010'
         |then order_id end ) / count(distinct order_id) * 100) as decimal(18,2)),0)   as zfbgnwap_zfcgl
         |from dw.order_information t
         |join pay_bill_lilei b
         |on t.order_id = b.biz_number
         |and b.pay_type = '1'
         |where t.his_time = '${date.toString("yyyy-MM-dd")}'
         |and t.create_time >= concat('${date.toString("yyyy-MM-dd")}', ' 00:00:00')
         |and t.create_time < concat(date_format(date_sub('${date.toString("yyyy-MM-dd")}', -1), 'yyyy-MM-dd'),' 00:00:00')
         |and t.order_type = 0
         |and pay_method != '000'
      """.stripMargin)

    /*
        * 支付宝国内app
        * */
    val zfbgnapp = spark.sql(
      s"""
         |select
         |count(distinct order_id) zfbgnapp_xdbs ,
         |count(distinct case when t.pay_time >= concat('${date.toString("yyyy-MM-dd")}', ' 00:00:00')
         |and t.pay_time < concat(date_format(date_sub('${date.toString("yyyy-MM-dd")}', -1), 'yyyy-MM-dd'),' 00:00:00')
         |and isnull(cancel_time)
         |and pay_method != '010'
         |then order_id end ) zfbgnapp_zfcgbs,
         |nvl(cast((count(distinct order_id) /${xdbss} * 100)   as decimal(18,2)),0)  as zfbgnapp_xdzb  ,
         |nvl(cast((count(distinct case when t.pay_time >= concat('${date.toString("yyyy-MM-dd")}', ' 00:00:00')
         |and t.pay_time < concat(date_format(date_sub('${date.toString("yyyy-MM-dd")}', -1), 'yyyy-MM-dd'),' 00:00:00')
         |and isnull(cancel_time)
         |and pay_method != '010'
         |then order_id end ) /  ${zfbss}  * 100 )   as decimal(18,2)),0)  as zfbgnapp_zfzb,
         |nvl(cast((count(distinct case when t.pay_time >= concat('${date.toString("yyyy-MM-dd")}', ' 00:00:00')
         |and t.pay_time < concat(date_format(date_sub('${date.toString("yyyy-MM-dd")}', -1), 'yyyy-MM-dd'),' 00:00:00')
         |and isnull(cancel_time)
         |and pay_method != '010'
         |then order_id end ) / count(distinct order_id) * 100) as decimal(18,2)),0)   as zfbgnapp_zfcgl
         |from dw.order_information t
         |join pay_bill_lilei b
         |on t.order_id = b.biz_number
         |and b.pay_type = '17'
         |where t.his_time = '${date.toString("yyyy-MM-dd")}'
         |and t.create_time >= concat('${date.toString("yyyy-MM-dd")}', ' 00:00:00')
         |and t.create_time < concat(date_format(date_sub('${date.toString("yyyy-MM-dd")}', -1), 'yyyy-MM-dd'),' 00:00:00')
         |and t.order_type = 0
         |and pay_method != '000'
      """.stripMargin)



    /*
      * 积分抵值
      * */
    val jfdz = spark.sql(
      s"""
         |select
         |count(distinct order_id) jfdz_xdbs ,
         |count(distinct case when t.pay_time >= concat('${date.toString("yyyy-MM-dd")}', ' 00:00:00')
         |and t.pay_time < concat(date_format(date_sub('${date.toString("yyyy-MM-dd")}', -1), 'yyyy-MM-dd'),' 00:00:00')
         |and isnull(cancel_time)
         |and pay_method != '010'
         |then order_id end ) jfdz_zfcgbs,
         |nvl(cast((count(distinct order_id) /${xdbss} * 100)   as decimal(18,2)),0)  as jfdz_xdzb  ,
         |nvl(cast((count(distinct case when t.pay_time >= concat('${date.toString("yyyy-MM-dd")}', ' 00:00:00')
         |and t.pay_time < concat(date_format(date_sub('${date.toString("yyyy-MM-dd")}', -1), 'yyyy-MM-dd'),' 00:00:00')
         |and isnull(cancel_time)
         |and pay_method != '010'
         |then order_id end ) /  ${zfbss}  * 100 )   as decimal(18,2)),0)  as jfdz_zfzb,
         |nvl(cast((count(distinct case when t.pay_time >= concat('${date.toString("yyyy-MM-dd")}', ' 00:00:00')
         |and t.pay_time < concat(date_format(date_sub('${date.toString("yyyy-MM-dd")}', -1), 'yyyy-MM-dd'),' 00:00:00')
         |and isnull(cancel_time)
         |and pay_method != '010'
         |then order_id end ) / count(distinct order_id) * 100) as decimal(18,2)),0)   as jfdz_zfcgl
         |from dw.order_information t
         |join pay_bill_lilei b
         |on t.order_id = b.biz_number
         |and b.pay_type = '7'
         |where t.his_time = '${date.toString("yyyy-MM-dd")}'
         |and t.create_time >= concat('${date.toString("yyyy-MM-dd")}', ' 00:00:00')
         |and t.create_time < concat(date_format(date_sub('${date.toString("yyyy-MM-dd")}', -1), 'yyyy-MM-dd'),' 00:00:00')
         |and t.order_type = 0
         |and pay_method != '000'
      """.stripMargin)

    /*
     * 银联app
     * */
    val ylapp = spark.sql(
      s"""
         |select
         |count(distinct order_id) ylapp_xdbs ,
         |count(distinct case when t.pay_time >= concat('${date.toString("yyyy-MM-dd")}', ' 00:00:00')
         |and t.pay_time < concat(date_format(date_sub('${date.toString("yyyy-MM-dd")}', -1), 'yyyy-MM-dd'),' 00:00:00')
         |and isnull(cancel_time)
         |and pay_method != '010'
         |then order_id end ) ylapp_zfcgbs,
         |nvl(cast((count(distinct order_id) /${xdbss} * 100)   as decimal(18,2)),0)  as ylapp_xdzb  ,
         |nvl(cast((count(distinct case when t.pay_time >= concat('${date.toString("yyyy-MM-dd")}', ' 00:00:00')
         |and t.pay_time < concat(date_format(date_sub('${date.toString("yyyy-MM-dd")}', -1), 'yyyy-MM-dd'),' 00:00:00')
         |and isnull(cancel_time)
         |and pay_method != '010'
         |then order_id end ) /  ${zfbss}  * 100 )   as decimal(18,2)),0)  as ylapp_zfzb,
         |nvl(cast((count(distinct case when t.pay_time >= concat('${date.toString("yyyy-MM-dd")}', ' 00:00:00')
         |and t.pay_time < concat(date_format(date_sub('${date.toString("yyyy-MM-dd")}', -1), 'yyyy-MM-dd'),' 00:00:00')
         |and isnull(cancel_time)
         |and pay_method != '010'
         |then order_id end ) / count(distinct order_id) * 100) as decimal(18,2)),0)   as ylapp_zfcgl
         |from dw.order_information t
         |join pay_bill_lilei b
         |on t.order_id = b.biz_number
         |and b.pay_type = '20'
         |where t.his_time = '${date.toString("yyyy-MM-dd")}'
         |and t.create_time >= concat('${date.toString("yyyy-MM-dd")}', ' 00:00:00')
         |and t.create_time < concat(date_format(date_sub('${date.toString("yyyy-MM-dd")}', -1), 'yyyy-MM-dd'),' 00:00:00')
         |and t.order_type = 0
         |and pay_method != '000'
      """.stripMargin)

    /*
     * 银联POS借记卡
     * */
    val ylposjjk = spark.sql(
      s"""
         |select
         |count(distinct order_id) ylposjjk_xdbs ,
         |count(distinct case when t.pay_time >= concat('${date.toString("yyyy-MM-dd")}', ' 00:00:00')
         |and t.pay_time < concat(date_format(date_sub('${date.toString("yyyy-MM-dd")}', -1), 'yyyy-MM-dd'),' 00:00:00')
         |and isnull(cancel_time)
         |and pay_method != '010'
         |then order_id end ) ylposjjk_zfcgbs,
         |nvl(cast((count(distinct order_id) /${xdbss} * 100)   as decimal(18,2)),0)  as ylposjjk_xdzb  ,
         |nvl(cast((count(distinct case when t.pay_time >= concat('${date.toString("yyyy-MM-dd")}', ' 00:00:00')
         |and t.pay_time < concat(date_format(date_sub('${date.toString("yyyy-MM-dd")}', -1), 'yyyy-MM-dd'),' 00:00:00')
         |and isnull(cancel_time)
         |and pay_method != '010'
         |then order_id end ) /  ${zfbss}  * 100 )   as decimal(18,2)),0)  as ylposjjk_zfzb,
         |nvl(cast((count(distinct case when t.pay_time >= concat('${date.toString("yyyy-MM-dd")}', ' 00:00:00')
         |and t.pay_time < concat(date_format(date_sub('${date.toString("yyyy-MM-dd")}', -1), 'yyyy-MM-dd'),' 00:00:00')
         |and isnull(cancel_time)
         |and pay_method != '010'
         |then order_id end ) / count(distinct order_id) * 100) as decimal(18,2)),0)   as ylposjjk_zfcgl
         |from dw.order_information t
         |join pay_bill_lilei b
         |on t.order_id = b.biz_number
         |and b.pay_type = '22'
         |where t.his_time = '${date.toString("yyyy-MM-dd")}'
         |and t.create_time >= concat('${date.toString("yyyy-MM-dd")}', ' 00:00:00')
         |and t.create_time < concat(date_format(date_sub('${date.toString("yyyy-MM-dd")}', -1), 'yyyy-MM-dd'),' 00:00:00')
         |and t.order_type = 0
         |and pay_method != '000'
      """.stripMargin)

    /*
     * 银联POS贷记卡
     * */
    val ylposdjk = spark.sql(
      s"""
         |select
         |count(distinct order_id) ylposdjk_xdbs ,
         |count(distinct case when t.pay_time >= concat('${date.toString("yyyy-MM-dd")}', ' 00:00:00')
         |and t.pay_time < concat(date_format(date_sub('${date.toString("yyyy-MM-dd")}', -1), 'yyyy-MM-dd'),' 00:00:00')
         |and isnull(cancel_time)
         |and pay_method != '010'
         |then order_id end ) ylposdjk_zfcgbs,
         |nvl(cast((count(distinct order_id) /${xdbss} * 100)   as decimal(18,2)),0)  as ylposdjk_xdzb  ,
         |nvl(cast((count(distinct case when t.pay_time >= concat('${date.toString("yyyy-MM-dd")}', ' 00:00:00')
         |and t.pay_time < concat(date_format(date_sub('${date.toString("yyyy-MM-dd")}', -1), 'yyyy-MM-dd'),' 00:00:00')
         |and isnull(cancel_time)
         |and pay_method != '010'
         |then order_id end ) /  ${zfbss}  * 100 )   as decimal(18,2)),0)  as ylposdjk_zfzb,
         |nvl(cast((count(distinct case when t.pay_time >= concat('${date.toString("yyyy-MM-dd")}', ' 00:00:00')
         |and t.pay_time < concat(date_format(date_sub('${date.toString("yyyy-MM-dd")}', -1), 'yyyy-MM-dd'),' 00:00:00')
         |and isnull(cancel_time)
         |and pay_method != '010'
         |then order_id end ) / count(distinct order_id) * 100) as decimal(18,2)),0)   as ylposdjk_zfcgl
         |from dw.order_information t
         |join pay_bill_lilei b
         |on t.order_id = b.biz_number
         |and b.pay_type = '23'
         |where t.his_time = '${date.toString("yyyy-MM-dd")}'
         |and t.create_time >= concat('${date.toString("yyyy-MM-dd")}', ' 00:00:00')
         |and t.create_time < concat(date_format(date_sub('${date.toString("yyyy-MM-dd")}', -1), 'yyyy-MM-dd'),' 00:00:00')
         |and t.order_type = 0
         |and pay_method != '000'
      """.stripMargin)

    /*
    * 优惠抵值
    * */
    val yhdz = spark.sql(
      s"""
         |select
         |count(distinct order_id) yhdz_xdbs ,
         |count(distinct case when t.pay_time >= concat('${date.toString("yyyy-MM-dd")}', ' 00:00:00')
         |and t.pay_time < concat(date_format(date_sub('${date.toString("yyyy-MM-dd")}', -1), 'yyyy-MM-dd'),' 00:00:00')
         |and isnull(cancel_time)
         |and pay_method != '010'
         |then order_id end ) yhdz_zfcgbs,
         |nvl(cast((count(distinct order_id) /${xdbss} * 100)   as decimal(18,2)),0)  as yhdz_xdzb  ,
         |nvl(cast((count(distinct case when t.pay_time >= concat('${date.toString("yyyy-MM-dd")}', ' 00:00:00')
         |and t.pay_time < concat(date_format(date_sub('${date.toString("yyyy-MM-dd")}', -1), 'yyyy-MM-dd'),' 00:00:00')
         |and isnull(cancel_time)
         |and pay_method != '010'
         |then order_id end ) /  ${zfbss}  * 100 )   as decimal(18,2)),0)  as yhdz_zfzb,
         |nvl(cast((count(distinct case when t.pay_time >= concat('${date.toString("yyyy-MM-dd")}', ' 00:00:00')
         |and t.pay_time < concat(date_format(date_sub('${date.toString("yyyy-MM-dd")}', -1), 'yyyy-MM-dd'),' 00:00:00')
         |and isnull(cancel_time)
         |and pay_method != '010'
         |then order_id end ) / count(distinct order_id) * 100) as decimal(18,2)),0)   as yhdz_zfcgl
         |from dw.order_information t
         |left join pay_bill_lilei b
         |on t.order_id = b.biz_number
         |and b.pay_type = '0'
         |where t.his_time = '${date.toString("yyyy-MM-dd")}'
         |and t.create_time >= concat('${date.toString("yyyy-MM-dd")}', ' 00:00:00')
         |and t.create_time < concat(date_format(date_sub('${date.toString("yyyy-MM-dd")}', -1), 'yyyy-MM-dd'),' 00:00:00')
         |and t.order_type = 0
         |and pay_method = '909'
      """.stripMargin)


    val payment = spark.read.format("csv")
      .option("delimiter", "^")
      .option("qoute", "")
      .option("nullValue", "\\N")
      .load(s"hdfs://nameservice1/tiangou/tgouorder/payment/${date.toString("yyyy/MM/dd")}/*")

    val paymentS = payment.select("_c0","_c12","_c19","_c18").toDF("id","fk_tgou_order_id","account_bear","modify_time")


    var paymentMax = paymentS.groupBy("id").agg(functions.max("modify_time") as "modify_time")

    var paymentY = paymentS.join(paymentMax,
      paymentS("id") === paymentMax("id")
        &&  paymentS("modify_time") === paymentMax("modify_time")
      ,"inner"
    ).select(
      paymentS("fk_tgou_order_id") ,
      paymentS("account_bear")
    )


    var paymentYY = paymentY.groupBy("fk_tgou_order_id").agg(functions.max("account_bear") as "account_bear")

    paymentYY.createOrReplaceTempView("payment_lilei")


    /*
     * 微信国内wap
     * */
    val wxgnwap = spark.sql(
      s"""
         |select
         |count(distinct order_id) wxgnwap_xdbs ,
         |count(distinct case when t.pay_time >= concat('${date.toString("yyyy-MM-dd")}', ' 00:00:00')
         |and t.pay_time < concat(date_format(date_sub('${date.toString("yyyy-MM-dd")}', -1), 'yyyy-MM-dd'),' 00:00:00')
         |and isnull(cancel_time)
         |and pay_method != '010'
         |and isnull(b.account_bear) = false
         |then order_id end ) wxgnwap_zfcgbs,
         |nvl(cast((count(distinct order_id) /${xdbss} * 100)   as decimal(18,2)),0)  as wxgnwap_xdzb  ,
         |nvl(cast((count(distinct case when t.pay_time >= concat('${date.toString("yyyy-MM-dd")}', ' 00:00:00')
         |and t.pay_time < concat(date_format(date_sub('${date.toString("yyyy-MM-dd")}', -1), 'yyyy-MM-dd'),' 00:00:00')
         |and isnull(cancel_time)
         |and pay_method != '010'
         |and isnull(b.account_bear) = false
         |then order_id end ) /  ${zfbss}  * 100 )   as decimal(18,2)),0)  as wxgnwap_zfzb,
         |nvl(cast((count(distinct case when t.pay_time >= concat('${date.toString("yyyy-MM-dd")}', ' 00:00:00')
         |and t.pay_time < concat(date_format(date_sub('${date.toString("yyyy-MM-dd")}', -1), 'yyyy-MM-dd'),' 00:00:00')
         |and isnull(cancel_time)
         |and pay_method != '010'
         |and isnull(b.account_bear) = false
         |then order_id end ) / count(distinct order_id) * 100) as decimal(18,2)),0)   as wxgnwap_zfcgl
         |from dw.order_information t
         |join pay_bill_lilei b
         |on t.order_id = b.biz_number
         |and b.pay_type = '5'
         |left join payment_lilei b
         |on t.order_id = b.fk_tgou_order_id
         |and b.account_bear != 2
         |where t.his_time = '${date.toString("yyyy-MM-dd")}'
         |and t.create_time >= concat('${date.toString("yyyy-MM-dd")}', ' 00:00:00')
         |and t.create_time < concat(date_format(date_sub('${date.toString("yyyy-MM-dd")}', -1), 'yyyy-MM-dd'),' 00:00:00')
         |and t.order_type = 0
         |and pay_method != '000'
      """.stripMargin)


    /*
    * 微信跨境wap
    * */
    val wxkjwap = spark.sql(
      s"""
         |select
         |count(distinct order_id) wxkjwap_xdbs ,
         |count(distinct case when t.pay_time >= concat('${date.toString("yyyy-MM-dd")}', ' 00:00:00')
         |and t.pay_time < concat(date_format(date_sub('${date.toString("yyyy-MM-dd")}', -1), 'yyyy-MM-dd'),' 00:00:00')
         |and isnull(cancel_time)
         |and pay_method != '010'
         |and isnull(b.account_bear) = false
         |then order_id end ) wxkjwap_zfcgbs,
         |nvl(cast((count(distinct order_id) /${xdbss} * 100)   as decimal(18,2)),0)  as wxkjwap_xdzb  ,
         |nvl(cast((count(distinct case when t.pay_time >= concat('${date.toString("yyyy-MM-dd")}', ' 00:00:00')
         |and t.pay_time < concat(date_format(date_sub('${date.toString("yyyy-MM-dd")}', -1), 'yyyy-MM-dd'),' 00:00:00')
         |and isnull(cancel_time)
         |and pay_method != '010'
         |and isnull(b.account_bear) = false
         |then order_id end ) /  ${zfbss}  * 100 )   as decimal(18,2)),0)  as wxkjwap_zfzb,
         |nvl(cast((count(distinct case when t.pay_time >= concat('${date.toString("yyyy-MM-dd")}', ' 00:00:00')
         |and t.pay_time < concat(date_format(date_sub('${date.toString("yyyy-MM-dd")}', -1), 'yyyy-MM-dd'),' 00:00:00')
         |and isnull(cancel_time)
         |and pay_method != '010'
         |and isnull(b.account_bear) = false
         |then order_id end ) / count(distinct order_id) * 100) as decimal(18,2)),0)   as wxkjwap_zfcgl
         |from dw.order_information t
         |join pay_bill_lilei b
         |on t.order_id = b.biz_number
         |and b.pay_type = '5'
         |left join payment_lilei b
         |on t.order_id = b.fk_tgou_order_id
         |and b.account_bear = 2
         |where t.his_time = '${date.toString("yyyy-MM-dd")}'
         |and t.create_time >= concat('${date.toString("yyyy-MM-dd")}', ' 00:00:00')
         |and t.create_time < concat(date_format(date_sub('${date.toString("yyyy-MM-dd")}', -1), 'yyyy-MM-dd'),' 00:00:00')
         |and t.order_type = 0
         |and pay_method != '000'
      """.stripMargin)

    /*
   * 微信国内app
   * */
    val wxgnapp = spark.sql(
      s"""
         |select
         |count(distinct order_id) wxgnapp_xdbs ,
         |count(distinct case when t.pay_time >= concat('${date.toString("yyyy-MM-dd")}', ' 00:00:00')
         |and t.pay_time < concat(date_format(date_sub('${date.toString("yyyy-MM-dd")}', -1), 'yyyy-MM-dd'),' 00:00:00')
         |and isnull(cancel_time)
         |and pay_method != '010'
         |and isnull(b.account_bear) = false
         |then order_id end ) wxgnapp_zfcgbs,
         |nvl(cast((count(distinct order_id) /${xdbss} * 100)   as decimal(18,2)),0)  as wxgnapp_xdzb  ,
         |nvl(cast((count(distinct case when t.pay_time >= concat('${date.toString("yyyy-MM-dd")}', ' 00:00:00')
         |and t.pay_time < concat(date_format(date_sub('${date.toString("yyyy-MM-dd")}', -1), 'yyyy-MM-dd'),' 00:00:00')
         |and isnull(cancel_time)
         |and pay_method != '010'
         |and isnull(b.account_bear) = false
         |then order_id end ) /  ${zfbss}  * 100 )   as decimal(18,2)),0)  as wxgnapp_zfzb,
         |nvl(cast((count(distinct case when t.pay_time >= concat('${date.toString("yyyy-MM-dd")}', ' 00:00:00')
         |and t.pay_time < concat(date_format(date_sub('${date.toString("yyyy-MM-dd")}', -1), 'yyyy-MM-dd'),' 00:00:00')
         |and isnull(cancel_time)
         |and pay_method != '010'
         |and isnull(b.account_bear) = false
         |then order_id end ) / count(distinct order_id) * 100) as decimal(18,2)),0)   as wxgnapp_zfcgl
         |from dw.order_information t
         |join pay_bill_lilei b
         |on t.order_id = b.biz_number
         |and b.pay_type = '9'
         |left join payment_lilei b
         |on t.order_id = b.fk_tgou_order_id
         |and b.account_bear != 2
         |where t.his_time = '${date.toString("yyyy-MM-dd")}'
         |and t.create_time >= concat('${date.toString("yyyy-MM-dd")}', ' 00:00:00')
         |and t.create_time < concat(date_format(date_sub('${date.toString("yyyy-MM-dd")}', -1), 'yyyy-MM-dd'),' 00:00:00')
         |and t.order_type = 0
         |and pay_method != '000'
      """.stripMargin)

    /*
   * 微信跨境app
   * */
    val wxkjapp = spark.sql(
      s"""
         |select
         |count(distinct order_id) wxkjapp_xdbs ,
         |count(distinct case when t.pay_time >= concat('${date.toString("yyyy-MM-dd")}', ' 00:00:00')
         |and t.pay_time < concat(date_format(date_sub('${date.toString("yyyy-MM-dd")}', -1), 'yyyy-MM-dd'),' 00:00:00')
         |and isnull(cancel_time)
         |and pay_method != '010'
         |and isnull(b.account_bear) = false
         |then order_id end ) wxkjapp_zfcgbs,
         |nvl(cast((count(distinct order_id) /${xdbss} * 100)   as decimal(18,2)),0)  as wxkjapp_xdzb  ,
         |nvl(cast((count(distinct case when t.pay_time >= concat('${date.toString("yyyy-MM-dd")}', ' 00:00:00')
         |and t.pay_time < concat(date_format(date_sub('${date.toString("yyyy-MM-dd")}', -1), 'yyyy-MM-dd'),' 00:00:00')
         |and isnull(cancel_time)
         |and pay_method != '010'
         |and isnull(b.account_bear) = false
         |then order_id end ) /  ${zfbss}  * 100 )   as decimal(18,2)),0)  as wxkjapp_zfzb,
         |nvl(cast((count(distinct case when t.pay_time >= concat('${date.toString("yyyy-MM-dd")}', ' 00:00:00')
         |and t.pay_time < concat(date_format(date_sub('${date.toString("yyyy-MM-dd")}', -1), 'yyyy-MM-dd'),' 00:00:00')
         |and isnull(cancel_time)
         |and pay_method != '010'
         |and isnull(b.account_bear) = false
         |then order_id end ) / count(distinct order_id) * 100) as decimal(18,2)),0)   as wxkjapp_zfcgl
         |from dw.order_information t
         |join pay_bill_lilei b
         |on t.order_id = b.biz_number
         |and b.pay_type = '9'
         |left join payment_lilei b
         |on t.order_id = b.fk_tgou_order_id
         |and b.account_bear = 2
         |where t.his_time = '${date.toString("yyyy-MM-dd")}'
         |and t.create_time >= concat('${date.toString("yyyy-MM-dd")}', ' 00:00:00')
         |and t.create_time < concat(date_format(date_sub('${date.toString("yyyy-MM-dd")}', -1), 'yyyy-MM-dd'),' 00:00:00')
         |and t.order_type = 0
         |and pay_method != '000'
      """.stripMargin)

    val rs = zfbkjwap.crossJoin(zfbkjapp)
      .crossJoin(zfbgnapp)
      .crossJoin(zfbgnwap)
      .crossJoin(jfdz)
      .crossJoin(ylapp)
      .crossJoin(ylposjjk)
      .crossJoin(ylposdjk)
      .crossJoin(yhdz)
      .crossJoin(wxgnwap)
      .crossJoin(wxkjwap)
      .crossJoin(wxgnapp)
      .crossJoin(wxkjapp)
      .crossJoin(xdbs)
      .crossJoin(zfbs)
      .select(
        "zfbkjwap_xdbs",
        "zfbkjwap_zfcgbs",
        "zfbkjwap_xdzb",
        "zfbkjwap_zfzb",
        "zfbkjwap_zfcgl",
        "zfbkjapp_xdbs",
        "zfbkjapp_zfcgbs",
        "zfbkjapp_xdzb",
        "zfbkjapp_zfzb",
        "zfbkjapp_zfcgl",
        "zfbgnwap_xdbs",
        "zfbgnwap_zfcgbs",
        "zfbgnwap_xdzb",
        "zfbgnwap_zfzb",
        "zfbgnwap_zfcgl",
        "zfbgnapp_xdbs",
        "zfbgnapp_zfcgbs",
        "zfbgnapp_xdzb",
        "zfbgnapp_zfzb",
        "zfbgnapp_zfcgl",
        "jfdz_xdbs",
        "jfdz_zfcgbs",
        "jfdz_xdzb",
        "jfdz_zfzb",
        "jfdz_zfcgl",
        "ylapp_xdbs",
        "ylapp_zfcgbs",
        "ylapp_xdzb",
        "ylapp_zfzb",
        "ylapp_zfcgl",
        "ylposjjk_xdbs",
        "ylposjjk_zfcgbs",
        "ylposjjk_xdzb",
        "ylposjjk_zfzb",
        "ylposjjk_zfcgl",
        "ylposdjk_xdbs",
        "ylposdjk_zfcgbs",
        "ylposdjk_xdzb",
        "ylposdjk_zfzb",
        "ylposdjk_zfcgl",
        "yhdz_xdbs",
        "yhdz_zfcgbs",
        "yhdz_xdzb",
        "yhdz_zfzb",
        "yhdz_zfcgl",
        "wxgnwap_xdbs",
        "wxgnwap_zfcgbs",
        "wxgnwap_xdzb",
        "wxgnwap_zfzb",
        "wxgnwap_zfcgl",
        "wxkjwap_xdbs",
        "wxkjwap_zfcgbs",
        "wxkjwap_xdzb",
        "wxkjwap_zfzb",
        "wxkjwap_zfcgl",
        "wxgnapp_xdbs",
        "wxgnapp_zfcgbs",
        "wxgnapp_xdzb",
        "wxgnapp_zfzb",
        "wxgnapp_zfcgl",
        "wxkjapp_xdbs",
        "wxkjapp_zfcgbs",
        "wxkjapp_xdzb",
        "wxkjapp_zfzb",
        "wxkjapp_zfcgl",
        "xdbs",
        "zfbs"
      )

    return rs
  }
}
