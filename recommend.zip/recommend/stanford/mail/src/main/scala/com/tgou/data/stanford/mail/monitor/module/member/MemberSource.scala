package com.tgou.data.stanford.mail.monitor.module.member

import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.sql.types._
import org.joda.time.LocalDate

/**
  * Created by 李震 on 2017/9/28.
  */
class MemberSource(spark: SparkSession) {

  def getUpdateMemberDWDF(date: LocalDate): DataFrame = {
    spark.sql(
      s"""
        |select
        |  m.member_id,
        |  from_unixtime(unix_timestamp(m.register_time, 'yyyy-MM-dd HH:mm:ss.S'), 'yyyy-MM-dd') as register_time
        |from dw.member m
        |where m.his_time = '${date.toString("yyyy-MM-dd")}'
      """.stripMargin)
  }

  def getUpdateDsCardBindDWDF(date: LocalDate): DataFrame = {
    spark.sql(
      s"""
        |select
        |  cb.member_id,
        |  cb.card_id,
        |  cb.store_code,
        |  cb.bind_status,
        |  cb.first_bind_time
        |from dw.ds_card_bind cb
        |where cb.his_time = '${date.toString("yyyy-MM-dd")}'
      """.stripMargin)
  }

  def getCompleteDaMmcIblnTgODSDF(date: LocalDate): DataFrame = {
    val dmitDF = spark.read
      .options(Map(
        "delimiter" -> "^",
        "nullValue" -> "\\N",
        "quote" -> ""
      ))
      .schema(StructType(Seq(
        StructField("storecode", StringType),
        StructField("cid", StringType),
        StructField("lasttime", StringType),
        StructField("ttlamount", DoubleType),
        StructField("ttlintegral", DoubleType),
        StructField("ttlpay", DoubleType),
        StructField("ttlgift", DoubleType),
        StructField("ttlclear", DoubleType),
        StructField("savintegral", DoubleType),
        StructField("cyamount", DoubleType),
        StructField("yiamount", DoubleType),
        StructField("haploidintegral", DoubleType)
      )))
      .csv("/mis/da_mmc_ibln_tg/*/*/*")
      .select(
        "storecode",
        "cid",
        "lasttime",
        "haploidintegral"
      )

    val f = dmitDF.groupBy("storecode", "cid").agg(("lasttime", "max")).toDF("storecode", "cid", "lasttime") // 根据 storecode cid 取 max(lasttime)

    dmitDF.join(f,
      dmitDF.col("storecode") === f.col("storecode") and dmitDF.col("cid") === f.col("cid") and dmitDF.col("lasttime") === f.col("lasttime"))
      .select(dmitDF.col("storecode"), dmitDF.col("cid"), dmitDF.col("haploidintegral"))
  }

  def getUpdateOrderInformationDWDF(date: LocalDate): DataFrame = {
    spark.sql(
      s"""
        |select
        |  o.order_id,
        |  o.order_source,
        |  o.ship_time
        |from dw.order_information o
        |where o.his_time = '${date.toString("yyyy-MM-dd")}'
      """.stripMargin)
  }

  def getAppendPosZzDWDF(date: LocalDate): DataFrame = {
    spark.sql(
      s"""
        |select
        |  pz.cid
        |from dw.pos_zz pz
        |where pz.his_time = '${date.toString("yyyy-MM-dd")}'
      """.stripMargin)
  }

  def getAppendLast30DaysUbaPageDWDF(date: LocalDate): DataFrame = {
    spark.sql(
      s"""
        |select
        |  up.member_id,
        |  up.his_time
        |from dw.uba_page up
        |where up.his_time >= '${date.minusDays(30).toString("yyyy-MM-dd")}'
      """.stripMargin)
  }

}

object MemberSource {

  def apply(spark: SparkSession): MemberSource = new MemberSource(spark)

}