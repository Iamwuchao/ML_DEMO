package com.tgou.data.stanford.mail.crossBorder

import org.apache.spark.sql.{DataFrame, SparkSession}
import org.joda.time.LocalDate

/**
  * Created by liuyang on 2018/05/03.
  */

object CrossBorderMember {

  def getCrossBorderMember(spark: SparkSession,appName:String, date: LocalDate): DataFrame = {
    //时间
    var lastDay :String= null
    if(appName.equals("week")){
      lastDay = date.minusDays(6).toString("yyyy-MM-dd")
    }else if (appName.equals("day")){
      lastDay = date.toString("yyyy-MM-dd")
    }
    val yesterday = date.toString("yyyy-MM-dd")
    val today = date.plusDays(1).toString("yyyy-MM-dd")

    //店铺信息表 二代数仓
    spark.table("dw.store").filter(s"his_time = '${yesterday}'").createOrReplaceTempView("store")
    //天狗用户信息表
    spark.table("dw.member").filter(s"his_time = '${yesterday}'").createOrReplaceTempView("member")
    //订单信息表 二代数仓
    spark.table("dw.order_information").filter(s"his_time = '${yesterday}'").createOrReplaceTempView("order_information")
    /*
      * 字段：
      * - member_id_zc	  天狗网新增注册用户
      * - member_id_xd    跨境（国际）新增下单用户
      * - member_id_zf    跨境（国际）新增支付用户
      * - member_id_old   付款老买家人数
      * - member_id_dqkj  截止当前跨境的支付用户数
      */

    val zcDF = spark.sql(
      s"""
         |select
         |  nvl(count(distinct member_id),0) as member_id_zc
         |from member
         | where register_time >= '${lastDay} 00:00:00'
         |and register_time < '${today} 00:00:00'
       """.stripMargin)

    val xdDF = spark.sql(
      s"""
         |  select
         |    nvl(count(distinct a.member_id),0) member_id_xd
         | from order_information a
         |  join store b
         | on a.store_id = b.id
         |  where a.create_time >='${lastDay} 00:00:00'
         | and a.create_time < '${today} 00:00:00'
         | and b.yt = '4'
         | and b.state = 'onshelf'
         | and b.is_international = '1'
       """.stripMargin)

    val zfDF = spark.sql(
      s"""
         |  select
         |    nvl(count(distinct a.member_id),0) member_id_zf
         | from order_information a
         |  join store b
         |on a.store_id = b.id
         |  where a.pay_time >='${lastDay} 00:00:00'
         | and a.pay_time < '${today} 00:00:00'
         | and b.yt = '4'
         | and b.state = 'onshelf'
         | and b.is_international = '1'
       """.stripMargin)

    val oldDF = spark.sql(
      s"""
         |  select
         |    nvl(count(distinct a.member_id),0) as member_id_old
         | from order_information a
         |  join store b
         |  on a.store_id = b.id
         | where b.yt = '4'
         |  and b.state = 'onshelf'
         |  and b.is_international = '1'
         |  and a.pay_time >= '${lastDay} 00:00:00'
         |  and a.pay_time < '${today} 00:00:00'
         |  and a.member_id in(
         |      select
         |         distinct a.member_id
         |     from order_information a
         |      join store b
         |      on a.store_id = b.id
         |     and b.yt = '4'
         |     and b.state = 'onshelf'
         |     and b.is_international = '1'
         |     and a.create_time < '${yesterday} 00:00:00'
         |    )
       """.stripMargin)

    val dqkjDF = spark.sql(
      s"""
         |  select
         |    nvl(count(distinct a.member_id),0) as member_id_dqkj
         |from order_information a
         |  join store b
         |  on a.store_id = b.id
         |where b.yt = '4'
         | and b.state = 'onshelf'
         | and a.pay_time < '${today} 00:00:00'
       """.stripMargin)
    zcDF.crossJoin(xdDF).crossJoin(zfDF).crossJoin(oldDF).crossJoin(dqkjDF)
  }
}
