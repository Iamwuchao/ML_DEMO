package com.tgou.data.stanford.mail.timeLimitActivity.module

import org.apache.spark.sql.{DataFrame, SparkSession}
import org.joda.time.LocalDate

/**
  * Created by 张少锐 on 2018/01/05.
  * 限时抢日报-纯跨境
  *
  */

object CrossBorderModule {

  def getCrossBorderModule(spark: SparkSession,date: LocalDate): DataFrame = {

    // 加载数据源
    val table = TableProcessor(spark,date)
    val yesterday = table.yesterday.concat(" 00:00:00")
    val today = table.today.concat(" 00:00:00")

    /**
      * 限时抢日报-纯跨境
      *
      * 字段：
      *
      * - cyspks  参与商品款数
      * - dds 订单数
      * - zfdds 已支付订单数
      * - zfddje 已支付订单金额
      * - zfddkdj  已支付订单客单价
      * - zfsps  已支付商品数量
      * - zfspks  已支付商品款数
      * - zfddyhs 已支付订单用户数
      * - zfyhs_old 已支付老用户数
      * - zfdds_old  老用户已支付订单数
      * - zfddje_old 老用户已支付订单金额
      * - zfyhs_new 已支付新用户数
      * - zfdds_new 新用户已支付订单数
      * - zfddje_new  新用户已支付订单金额
      **/

    /*
     *  cyspks  参与商品款数
     */
    val cyspksDF = spark.sql(
      s"""
         |select
         |    count(distinct a.fk_listing_id) cyspks
         |from (
         |    select distinct ap.fk_listing_id
         |    from activity a
         |    join activity_product ap
         |    on a.activity_id = ap.fk_activity_id
         |    where a.group_id = '5471'
         |    and a.state = "processing"
         |    and a.start_time < '${today}'
         |    and a.stop_time >= '${yesterday}'
         |    and ap.start_time < '${today}'
         |    and ap.stop_time >= '${yesterday}'
         |    and ap.stop_time >= ap.start_time
         |) a
         |join listing l
         |on a.fk_listing_id = l.listing_id
         |join store s
         |on l.store_id = s.id
         |and s.yt = '4'
         |and s.is_international = '1'
       """.stripMargin)

    /*
     *  dds 订单数
     */
    val ddsDF = spark.sql(
      s"""
         |select count(distinct oi.order_id) dds
         |from
         |(
         |    select distinct ap.fk_listing_id
         |    from activity a
         |    join activity_product ap
         |    on a.activity_id = ap.fk_activity_id
         |    where a.group_id = '5471'
         |    and a.state = "processing"
         |    and a.start_time < '${today}'
         |    and a.stop_time >= '${yesterday}'
         |    and ap.start_time < '${today}'
         |    and ap.stop_time >= '${yesterday}'
         |    and ap.stop_time >= ap.start_time
         |) a
         |join order_product op
         |on a.fk_listing_id = op.mall_product_id
         |join order_information oi
         |on oi.order_id = op.tgou_order_id
         |and oi.order_source = '4'
         |and oi.receive_method = '10'
         |and oi.create_time >= '${yesterday}'
         |and oi.create_time < '${today}'
         |join store s
         |on oi.store_id = s.id
         |and s.is_international = '1'
       """.stripMargin)

    /*
     *  zfdds 已支付订单数
     *  zfddje 已支付订单金额
     *  zfddkdj  已支付订单客单价
     *  zfddyhs 已支付订单用户数
     */
    val zfddDF = spark.sql(
      s"""
         |select
         |    zfdds,
         |    zfddje,
         |    case when zfdds = 0 or isnull(zfdds) = true then 0 else round(zfddje/zfdds,2) end as zfddkdj,
         |    zfddyhs
         |from
         |(
         |    select
         |        count(distinct b.order_id) zfdds,
         |        nvl(cast(sum(b.total_amount) as decimal(18,2)),0) as zfddje,
         |        count(distinct b.member_id) zfddyhs
         |    from(
         |         select
         |            distinct oi.order_id,
         |            oi.total_amount,
         |            oi.member_id
         |         from
         |         (
         |             select distinct ap.fk_listing_id
         |             from activity a
         |             join activity_product ap
         |             on a.activity_id = ap.fk_activity_id
         |             where a.group_id = '5471'
         |             and a.state = "processing"
         |             and a.start_time < '${today}'
         |             and a.stop_time >= '${yesterday}'
         |             and ap.start_time < '${today}'
         |             and ap.stop_time >= '${yesterday}'
         |             and ap.stop_time >= ap.start_time
         |         ) a
         |         join order_product op
         |         on a.fk_listing_id = op.mall_product_id
         |         join order_information oi
         |         on oi.order_id = op.tgou_order_id
         |         and oi.order_source = '4'
         |         and oi.receive_method = '10'
         |         and oi.pay_time >= '${yesterday}'
         |         and oi.pay_time < '${today}'
         |         join store s
         |         on oi.store_id = s.id
         |         and s.is_international = '1'
         |    ) b
         |)
       """.stripMargin)

    /*
     *  zfsps   已支付商品数量
     *  zfspks  已支付商品款数
     */
    val zfspksDF = spark.sql(
      s"""
         |select
         |    nvl(sum(op.product_quantity),0) zfsps,
         |    count(distinct op.mall_product_id) zfspks
         |from
         |(
         |    select distinct ap.fk_listing_id
         |    from activity a
         |    join activity_product ap
         |    on a.activity_id = ap.fk_activity_id
         |    where a.group_id = '5471'
         |    and a.state = "processing"
         |    and a.start_time < '${today}'
         |    and a.stop_time >= '${yesterday}'
         |    and ap.start_time < '${today}'
         |    and ap.stop_time >= '${yesterday}'
         |    and ap.stop_time >= ap.start_time
         |) a
         |join order_product op
         |on a.fk_listing_id = op.mall_product_id
         |join order_information oi
         |on oi.order_id = op.tgou_order_id
         |and oi.order_source = '4'
         |and oi.receive_method = '10'
         |and oi.pay_time >= '${yesterday}'
         |and oi.pay_time < '${today}'
         |join store s
         |on oi.store_id = s.id
         |and s.is_international = '1'
       """.stripMargin)

    /*
     *  zfyhs_old 已支付老用户数
     *  zfdds_old  老用户已支付订单数
     *  zfddje_old 老用户已支付订单金额
     */
    val oldDF = spark.sql(
      s"""
         |select
         |    count(distinct b.member_id) zfyhs_old,
         |    count(distinct b.order_id) zfdds_old,
         |    nvl(cast(sum(b.total_amount) as decimal(18,2)),0) as zfddje_old
         |from
         |(
         |    select
         |      distinct oi.member_id,
         |      oi.order_id,
         |      oi.total_amount
         |    from
         |    (
         |        select distinct ap.fk_listing_id
         |        from activity a
         |        join activity_product ap
         |        on a.activity_id = ap.fk_activity_id
         |        where a.group_id = '5471'
         |        and a.state = "processing"
         |        and a.start_time < '${today}'
         |        and a.stop_time >= '${yesterday}'
         |        and ap.start_time < '${today}'
         |        and ap.stop_time >= '${yesterday}'
         |        and ap.stop_time >= ap.start_time
         |    ) a
         |    join order_product op
         |    on a.fk_listing_id = op.mall_product_id
         |    join order_information oi
         |    on oi.order_id = op.tgou_order_id
         |    and oi.order_source = '4'
         |    and oi.receive_method = '10'
         |    and oi.pay_time >= '${yesterday}'
         |    and oi.pay_time < '${today}'
         |    join store s
         |    on oi.store_id = s.id
         |    and s.is_international = '1'
         |    where oi.member_id in (
         |        select
         |          distinct oi.member_id
         |        from order_information oi
         |        join store s
         |        on oi.store_id = s.id
         |        and oi.order_source = '4'
         |        and oi.receive_method = '10'
         |        and oi.pay_time < '${yesterday}'
         |        and s.is_international = '1'
         |       )
         |) b
       """.stripMargin)

    /*
     *  zfyhs_new 已支付新用户数
     *  zfdds_new 新用户已支付订单数
     *  zfddje_new  新用户已支付订单金额
     */
    val newDF = spark.sql(
      s"""
         |select
         |    count(distinct b.member_id) zfyhs_new,
         |    count(distinct b.order_id) zfdds_new,
         |    nvl(cast(sum(b.total_amount) as decimal(18,2)),0) as zfddje_new
         |from
         |(
         |    select
         |        distinct oi.member_id,
         |        oi.order_id,
         |        oi.total_amount
         |    from
         |    (
         |        select distinct ap.fk_listing_id
         |        from activity a
         |        join activity_product ap
         |        on a.activity_id = ap.fk_activity_id
         |        where a.group_id = '5471'
         |        and a.state = "processing"
         |        and a.start_time < '${today}'
         |        and a.stop_time >= '${yesterday}'
         |        and ap.start_time < '${today}'
         |        and ap.stop_time >= '${yesterday}'
         |        and ap.stop_time >= ap.start_time
         |    ) a
         |    join order_product op
         |    on a.fk_listing_id = op.mall_product_id
         |    join order_information oi
         |    on oi.order_id = op.tgou_order_id
         |    and oi.order_source = '4'
         |    and oi.receive_method = '10'
         |    and oi.pay_time >= '${yesterday}'
         |    and oi.pay_time < '${today}'
         |    join store s
         |    on oi.store_id = s.id
         |    and s.is_international = '1'
         |    where oi.member_id not in (
         |        select
         |          distinct oi.member_id
         |        from order_information oi
         |        join store s
         |        on oi.store_id = s.id
         |        and oi.order_source = '4'
         |        and oi.receive_method = '10'
         |        and oi.pay_time < '${yesterday}'
         |        and s.is_international = '1'
         |       )
         |) b
       """.stripMargin)

    cyspksDF.crossJoin(ddsDF).
      crossJoin(zfddDF).
      crossJoin(zfspksDF).
      crossJoin(oldDF).
      crossJoin(newDF)
  }

}
