package com.tgou.data.stanford.mail.monitor2.module.member

import com.tgou.data.stanford.mail.core.MailSource
import com.tgou.data.stanford.mail.core.utils.BeanUtils
import com.tgou.data.stanford.mail.monitor2.module.member.bean.HaploidIntegral
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.sql.functions._
import org.joda.time.{LocalDate, LocalDateTime, LocalTime}
import com.tgou.data.stanford.mail.monitor2.module.member.bean._
import org.joda.time.format.DateTimeFormat

/**
  * Created by 李震 on 2017/12/4.
  */
object MemberModule {


  private def getHaploidIntegralDF(spark: SparkSession, date: LocalDate): DataFrame = {
    MailSource.getUpdateDF(spark, "/mis/da_mmc_ibln_tg", date, Seq("storecode", "cid"), "lasttime", BeanUtils.getSchemaFromBean[HaploidIntegral])
  }


  /**
    * 会员
    *
    * @return
    *
    * 字段：
    *
    * - member_count 总注册用户数
    * - new_member_count 新增注册用户数
    * - emember_count 总电狗用户数
    * - new_emember_count 新增电狗用户数
    * - emember_trans_percent 电狗用户消费占比
    * - emember_total_points 天狗电子会员积分余额
    *
    * */
  def getMemberDF(spark: SparkSession, date: LocalDate): DataFrame = {
    import spark.implicits._

    val newMemberTime = date.toLocalDateTime(new LocalTime(0, 0, 0, 0)).toString("yyyy-MM-dd HH:mm:ss.S")

    /*
     * 总注册用户数、新增注册用户数
     * */

    val memberResult = spark.sql(
      s"""
        |select
        |    m.member_id,
        |    m.register_time
        |from dw.member m
        |where m.his_time = '${date.toString("yyyy-MM-dd")}'
      """.stripMargin).as[Member]
      .mapPartitions((ms) => {
        var memberCount = 0l
        var newMemberCount = 0l

        val startTime = LocalDateTime.parse(newMemberTime, DateTimeFormat.forPattern("yyyy-MM-dd HH:mm:ss.S"))
        val endTime = startTime.plusDays(1)

        for (m <- ms) {
          memberCount += 1l

          try {
            if (m.register_time != null) {
              val registerTime = LocalDateTime.parse(m.register_time, DateTimeFormat.forPattern("yyyy-MM-dd HH:mm:ss.S"))
              if (registerTime.compareTo(startTime) >= 0 && registerTime.compareTo(endTime) < 0) newMemberCount += 1l
            }
          } catch {
            case e: Exception => e.printStackTrace()
          }
        }

        Iterator(MemberResult(memberCount, newMemberCount))
      }).reduce((x, y) => MemberResult(x.member_count + y.member_count, x.new_member_count + y.new_member_count))
    val memberResultDF = spark.createDataFrame(Seq(memberResult))


    /*
     * 总电狗用户数、新增电狗用户数
     * */

    val cardBindDF = spark.sql(
      s"""
        |select
        |    from_unixtime(cb.first_bind_time / 1000, 'yyyy-MM-dd') as first_bind_time,
        |    cb.cid,
        |    cb.member_id,
        |    cb.store_code
        |from dw.card_bind cb
        |where cb.his_time = '${date.toString("yyyy-MM-dd")}'
        |and cb.bind_status = '0'
      """.stripMargin)
    cardBindDF.createOrReplaceTempView("card_bind")

    val ememberCount = cardBindDF.agg(countDistinct("member_id") as "emember_count")
    val newEmemberCount = cardBindDF.filter(s"first_bind_time = '${date.toString("yyyy-MM-dd")}'").agg(countDistinct("member_id") as "new_emember_count")


    /*
     * 电狗用户消费占比（笔数）
     * */

    val ememberTransPercentDF = spark.sql(
      s"""
        |select
        |    round(t1.emember_trans_count / t2.total_trans_count, 4) as emember_trans_percent
        |from (
        |    select
        |        count(1) as emember_trans_count
        |    from dw.pos_zz pz
        |    join card_bind cb
        |    on pz.cid = cb.cid
        |    and pz.his_time = '${date.toString("yyyy-MM-dd")}'
        |    and pz.jyje > 0
        |    and pz.cid is not null
        |) t1 cross join (
        |    select
        |        count(1) as total_trans_count
        |    from dw.pos_zz pz
        |    where pz.his_time = '${date.toString("yyyy-MM-dd")}'
        |    and pz.jyje > 0
        |) t2
      """.stripMargin)


    /*
     * 天狗电子会员积分余额
     * */

    getHaploidIntegralDF(spark, date).createOrReplaceTempView("da_mmc_ibln_tg")

    val ememberTotalPointsDF = spark.sql(
      """
        |select
        |    sum(haploidintegral) / 1000000000 as emember_total_points
        |from da_mmc_ibln_tg dmit
        |inner join card_bind cb
        |on dmit.storecode = cb.store_code
        |and dmit.cid = cb.cid
      """.stripMargin)


    memberResultDF.crossJoin(ememberCount).crossJoin(newEmemberCount).crossJoin(ememberTransPercentDF).crossJoin(ememberTotalPointsDF)
  }

}
