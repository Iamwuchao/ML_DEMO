package com.tgou.data.stanford.mail.monitor2.module.listing

import com.tgou.data.stanford.mail.core.MailSource
import org.apache.spark.sql.types._
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.joda.time.LocalDate

/**
  * Created by 刘洋 on 2017/12/05.
  */
object SingleGoodsModule {
  /**
    * 单品统计（百货）
    *
    * @param spark
    * @param date
    *
    * @return
    *
    * 字段：
    * sjsps - 百货上架商品数
    * rwsps - 百货入围商品数
    * gwsps - 全球购上架商品数
    * gnsps - 品牌商上架商品数
    *
    *
    * */
  def getSingleDF(spark: SparkSession, date: LocalDate): DataFrame = {

    val ysday = date.toString("yyyy-MM-dd")

    /**
     * 读取抽取层counter_item_selected表中当天的数据
     * */
    val schema = StructType(
      StructField("id", LongType, false) ::
        StructField("fk_item_id", LongType, true) ::
        StructField("fk_brand_id", LongType, true) ::
        StructField("selected", IntegerType, true) ::
        StructField("fk_counter_id", LongType, true) ::
        StructField("create_time", StringType, true) ::
        StructField("modify_time", StringType, true) :: Nil
    )
    val totalCounterSelectedDF = MailSource.getUpdateDF(spark,"/tiangou/item/counter_item_selected",date,Seq("id"),"modify_time",schema)

    totalCounterSelectedDF.createTempView("counterSelected")
    /**
      * sjsps - 百货上架商品数
      * */
    val sjsps = spark.sql(
      s"""
         |select
         |  count(s.listing_id) as sjsps
         |  from dw.listing s
         |  where s.source='1'
         |  and s.state='onshelf'
         |  and s.his_time = '${ysday}'
       """.stripMargin
    )
    /**
      * rwsps - 百货入围商品数
      * */
    val rwsps = spark.sql(
      s"""
         |select
         |  count(s.listing_id) as rwsps
         |  from dw.listing s
         |  join counterSelected c
         |  on c.fk_item_id=s.listing_id
         |  where s.source='1'
         |  and s.state='onshelf'
         |  and c.selected='1'
         |  and s.his_time = '${ysday}'
       """.stripMargin
    )
    /**
      * gwsps - 全球购上架商品数
      * */
    val gwsps = spark.sql(
      s"""
         |select
         |  count(t.listing_id) as gwsps
         |  from dw.listing t
         |  join dw.store s
         |  on t.store_id=s.id
         |  and s.is_international = '1'
         |  and t.state='onshelf'
         |  and t.source='4'
         |  and t.his_time = '${ysday}'
         |  and s.his_time = '${ysday}'
       """.stripMargin
    )
    /**
      * gnsps - 品牌商上架商品数
      * */
    val gnsps = spark.sql(
      s"""
         |select
         |  count(t.listing_id) as gnsps
         |  from dw.listing t
         |  join dw.store s
         |  on t.store_id=s.id
         |  and s.is_international = '0'
         |  and t.state='onshelf'
         |  and t.source='4'
         |  and t.his_time = '${ysday}'
         |  and s.his_time = '${ysday}'
       """.stripMargin
    )
    val singleGoods = sjsps.crossJoin(rwsps)
      .crossJoin(gwsps)
      .crossJoin(gnsps)
      .select("sjsps",
        "rwsps",
        "gwsps",
        "gnsps"
      )
    singleGoods
  }

}
