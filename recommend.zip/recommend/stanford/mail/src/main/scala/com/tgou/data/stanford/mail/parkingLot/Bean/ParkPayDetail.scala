package com.tgou.data.stanford.mail.parkingLot.Bean

import com.tgou.data.stanford.mail.core.BaseBean
/**
  * Created by 李震 on 2017/9/27.
  *
  *
  *
  *
    create_time  2
  fk_park_bill_id  停车缴费单ID  3
   amount 支付金额  5
    pay_method 具体的支付方式 9
  *
  */
object ParkPayDetail extends BaseBean {

  override def list: List[(Any,String)] = {

    List(
      (2, "create_time"),
      (3, "fk_park_bill_id"),
      (5, "amount"),
      (9, "pay_method")
    )

  }
}