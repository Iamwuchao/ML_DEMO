package com.tgou.data.stanford.mail.monitor2.module.tgOrder

import com.tgou.data.stanford.mail.core.MailSource
import org.apache.spark.sql.types._
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.joda.time.LocalDate

object TGOrderModule {

  def getTGOrder(spark: SparkSession, date: LocalDate): DataFrame = {

    //本月的第一天
    val monthFirstDay = date.withDayOfMonth(1).toString("yyyy-MM-dd")
    //本月的昨天
    val yesterday = date.toString("yyyy-MM-dd")

    //上个月的第一天
    val lastMonthFirstDay = date.minusMonths(1).withDayOfMonth(1).toString("yyyy-MM-dd")
    //上个月的昨天
    val lastMonthYesterday = date.minusMonths(1).toString("yyyy-MM-dd")

    /*
     * 加载数据源
     * */

    // 订单其他金额（除订单金额外订单金额）
    val oa = StructType(
      StructField("id", StringType, false) ::
        StructField("fk_tgou_order_id", StringType, true) ::
        StructField("name", StringType, true) ::
        StructField("type", StringType, true) ::
        StructField("sub_type", StringType, true) ::
        StructField("biz_id", StringType, true) ::
        StructField("amount", DoubleType, true) ::
        StructField("frozen_amount", DoubleType, true) ::
        StructField("balance", DoubleType, true) ::
        StructField("quantity", LongType, true) ::
        StructField("state", StringType, true) ::
        StructField("pay_method", StringType, true) ::
        StructField("mis_amount_code", StringType, true) ::
        StructField("exchange_rate", StringType, true) ::
        StructField("currency_code", StringType, true) ::
        StructField("create_time", StringType, true) ::
        StructField("modify_time", StringType, true) ::
        StructField("ext", StringType, true) ::
        StructField("version", StringType, true) ::
        StructField("paid_payment_id", StringType, true) ::
        StructField("card_no", StringType, true) ::Nil
    )
    MailSource.getUpdateDF(spark,"/tiangou/tgouorder/order_amount",date,Seq("id"),"modify_time",oa).distinct()
      .createOrReplaceTempView("order_amount")

    spark.sql(
      s"""
         |select
         |     oi.order_id,
         |     oi.pay_method,
         |     oi.receive_method,
         |     oi.store_id,
         |     oi.order_source,
         |     oi.order_type,
         |     to_date(oi.create_time) as create_time,
         |     to_date(oi.pay_time) as pay_time,
         |     to_date(oi.ship_time) as ship_time
         |from dw.order_information oi
         |where oi.his_time = '${yesterday}'
       """.stripMargin).createTempView("order_information")

    spark.sql(
      s"""
         |select
         |      op.tgou_order_id,
         |      cast(op.`product_discount` as double) as product_discount
         |from  dw.order_product op
         |where op.his_time = '${yesterday}'
       """.stripMargin).createTempView("order_product")

    spark.sql(
      s"""
         |select
         |      s.id,
         |      s.is_international
         |from  dw.store s
         |where s.his_time = '${yesterday}'
       """.stripMargin).createTempView("store")

    /*
      *  在线支付到店自提-电子小票
      *
      *  pay_eleticket_count  支付笔数
      *  pay_eleticket_sum  支付金额
      *  pay_eleticket_rate 支付率
      *
      */
    val eleticketDF = spark.sql(
      s"""
         |select
         |    t1.pay_eleticket_count,
         |    t1.pay_eleticket_sum,
         |    case when t2.create_eleticket_count = 0 or isnull(t2.create_eleticket_count) = true then 0 else round(t1.pay_eleticket_count / t2.create_eleticket_count * 100, 2) end as pay_eleticket_rate
         |from (
         |    select
         |        count(distinct a.order_id) as pay_eleticket_count,
         |        sum(nvl(a.product_discount,0))+sum(nvl(b.amount,0)) as pay_eleticket_sum
         |    from(
         |         select
         |            oi.order_id,
         |            nvl(cast(sum(op.product_discount) as decimal(18,2)),0) as product_discount
         |         from order_information oi
         |         join order_product op
         |         on oi.order_id = op.tgou_order_id
         |         and oi.order_type = '0'
         |         and to_date(oi.pay_time) = to_date(oi.ship_time)
         |         and oi.pay_method != '000'
         |         and oi.receive_method in ('00','01')
         |         and oi.order_source = '1'
         |         and to_date(oi.pay_time) = '$yesterday'
         |         group by oi.order_id
         |     ) a
         |     left join(
         |         select
         |            oa.fk_tgou_order_id,
         |            nvl(cast(sum(oa.amount) as decimal(18,2)),0) as amount
         |         from order_amount oa
         |         where oa.type in('4','5')
         |         group by oa.fk_tgou_order_id
         |     ) b
         |     on a.order_id = b.fk_tgou_order_id
         |) t1 cross join (
         |    select
         |        count(oi.order_id) as create_eleticket_count
         |    from order_information oi
         |    where oi.order_type = '0'
         |    and to_date(oi.pay_time) = to_date(oi.ship_time)
         |    and oi.pay_method != '000'
         |    and oi.receive_method in ('00','01')
         |    and oi.order_source = '1'
         |    and to_date(oi.create_time) = '$yesterday'
         |) t2
         """.stripMargin)

    /*
      *  在线支付到店自提-电子小票
      *
      *  pay_eleticket_monthSum  月累计
      *  pay_eleticket_mom 环比
      *
      */
    val monthEleticketDF = spark.sql(
      s"""
         |select
         |      t1.pay_eleticket_monthSum,
         |      case when t2.pay_eleticket_lastMonthSum = 0 then 0 else round((t1.pay_eleticket_monthSum - t2.pay_eleticket_lastMonthSum) / t2.pay_eleticket_lastMonthSum * 100,2) end as pay_eleticket_mom
         |from (
         |     select
         |         sum(nvl(a.product_discount,0))+sum(nvl(b.amount,0)) as pay_eleticket_monthSum
         |     from (
         |         select
         |            oi.order_id,
         |            nvl(cast(sum(op.product_discount) as decimal(18,2)),0) as product_discount
         |         from order_information oi
         |         join order_product op
         |         on oi.order_id = op.tgou_order_id
         |         and oi.order_type = '0'
         |         and to_date(oi.pay_time) = to_date(oi.ship_time)
         |         and oi.pay_method != '000'
         |         and oi.receive_method in ('00','01')
         |         and oi.order_source = '1'
         |         and to_date(oi.pay_time) >= '$monthFirstDay'
         |         and to_date(oi.pay_time) <= '$yesterday'
         |         group by oi.order_id
         |     ) a
         |     left join (
         |         select
         |            oa.fk_tgou_order_id,
         |            nvl(cast(sum(oa.amount) as decimal(18,2)),0) as amount
         |         from order_amount oa
         |         where oa.type in('4','5')
         |         group by oa.fk_tgou_order_id
         |     ) b
         |     on a.order_id = b.fk_tgou_order_id
         |) t1 cross join (
         |     select
         |         sum(nvl(a.product_discount,0))+sum(nvl(b.amount,0)) as pay_eleticket_lastMonthSum
         |     from (
         |         select
         |            oi.order_id,
         |            nvl(cast(sum(op.product_discount) as decimal(18,2)),0) as product_discount
         |         from order_information oi
         |         join order_product op
         |         on oi.order_id = op.tgou_order_id
         |         and oi.order_type = '0'
         |         and to_date(oi.pay_time) = to_date(oi.ship_time)
         |         and oi.pay_method != '000'
         |         and oi.receive_method in ('00','01')
         |         and oi.order_source = '1'
         |         and to_date(oi.pay_time) >= '$lastMonthFirstDay'
         |         and to_date(oi.pay_time) <= '$lastMonthYesterday'
         |         group by oi.order_id
         |     ) a
         |     left join (
         |         select
         |            oa.fk_tgou_order_id,
         |            nvl(cast(sum(oa.amount) as decimal(18,2)),0) as amount
         |         from order_amount oa
         |         where oa.type in('4','5')
         |         group by oa.fk_tgou_order_id
         |     ) b
         |     on a.order_id = b.fk_tgou_order_id
         |) t2
         """.stripMargin)

    /*
      *  在线支付到店自提-其他
      *
      *  pay_other_count  支付笔数
      *  pay_other_sum  支付金额
      *  pay_other_rate 支付率
      *
      */
    val otherDF = spark.sql(
      s"""
         |select
         |      t1.pay_other_count,
         |      t1.pay_other_sum,
         |      case when t2.create_other_count = 0 or isnull(t2.create_other_count) = true then 0 else round(t1.pay_other_count / t2.create_other_count * 100, 2) end as pay_other_rate
         |from (
         |  select sum(t.pay_other_count) pay_other_count,
         |         sum(t.pay_other_sum) pay_other_sum
         |  from(
         |      select
         |          count(distinct a.order_id) as pay_other_count,
         |          sum(nvl(a.product_discount,0))+sum(nvl(b.amount,0)) as pay_other_sum
         |      from (
         |          select
         |             oi.order_id,
         |             nvl(cast(sum(op.product_discount) as decimal(18,2)),0) as product_discount
         |          from order_information oi
         |          join order_product op
         |          on oi.order_id = op.tgou_order_id
         |          and oi.order_type = '0'
         |          and (
         |              oi.pay_time is null
         |              or oi.ship_time is null
         |              or to_date(oi.pay_time) != to_date(oi.ship_time)
         |              )
         |          and oi.order_source = '1'
         |          and oi.pay_method not in ('000','010')
         |          and oi.receive_method in ('00','01')
         |          and to_date(oi.pay_time) = '$yesterday'
         |          group by oi.order_id
         |         ) a
         |         left join(
         |             select
         |                oa.fk_tgou_order_id,
         |                nvl(cast(sum(oa.amount) as decimal(18,2)),0) as amount
         |             from order_amount oa
         |             where oa.type in('4','5')
         |             group by oa.fk_tgou_order_id
         |         ) b
         |         on a.order_id = b.fk_tgou_order_id
         |      union
         |      select
         |          count(distinct a.order_id) as pay_other_count,
         |          sum(nvl(a.product_discount,0))+sum(nvl(b.amount,0)) as pay_other_sum
         |      from (
         |            select
         |                oi.order_id,
         |                nvl(cast(sum(op.product_discount) as decimal(18,2)),0) as product_discount
         |            from order_information oi
         |            join order_product op
         |            on oi.order_id = op.tgou_order_id
         |            and oi.order_type = '0'
         |            and oi.order_source = '2'
         |            and oi.pay_method not in ('000','010')
         |            and oi.receive_method in ('00','01')
         |            and to_date(oi.pay_time) = '$yesterday'
         |            group by oi.order_id
         |          ) a
         |       left join(
         |             select
         |                oa.fk_tgou_order_id,
         |                nvl(cast(sum(oa.amount) as decimal(18,2)),0) as amount
         |             from order_amount oa
         |             where oa.type in('4','5')
         |             group by oa.fk_tgou_order_id
         |        ) b
         |        on a.order_id = b.fk_tgou_order_id
         |    ) t
         |) t1 cross join(
         |  select sum(t.create_other_count) create_other_count
         |  from(
         |      select
         |          count(distinct oi.order_id) as create_other_count
         |      from order_information oi
         |      where oi.order_type = '0'
         |      and (
         |          oi.pay_time is null
         |          or oi.ship_time is null
         |          or to_date(oi.pay_time) != to_date(oi.ship_time)
         |          )
         |      and oi.order_source = '1'
         |      and oi.pay_method != '000'
         |      and oi.receive_method in ('00','01')
         |      and to_date(oi.create_time) = '$yesterday'
         |      union
         |      select
         |          count(distinct oi.order_id) as create_other_count
         |      from order_information oi
         |      where oi.order_type = '0'
         |      and oi.order_source = '2'
         |      and oi.pay_method != '000'
         |      and oi.receive_method in ('00','01')
         |      and to_date(oi.create_time) = '$yesterday'
         |    ) t
         |) t2
         """.stripMargin)

    /*
      *  在线支付到店自提-其他
      *
      *  pay_other_monthSum  月累计
      *  pay_other_mom 环比
      *
      */
    val monthOtherDF = spark.sql(
      s"""
         |select
         |      t1.pay_other_monthSum,
         |      case when t2.pay_other_lastMonthSum = 0 then 0 else round((t1.pay_other_monthSum - t2.pay_other_lastMonthSum) / t2.pay_other_lastMonthSum * 100,2) end as pay_other_mom
         |from (
         |    select sum(t.pay_other_monthSum) pay_other_monthSum
         |    from (
         |         select
         |             sum(nvl(a.product_discount,0))+sum(nvl(b.amount,0)) as pay_other_monthSum
         |         from(
         |            select
         |               oi.order_id,
         |               nvl(cast(sum(op.product_discount) as decimal(18,2)),0) as product_discount
         |            from order_information oi
         |            join order_product op
         |            on oi.order_id = op.tgou_order_id
         |            and oi.order_type = '0'
         |            and (
         |                oi.pay_time is null
         |                or oi.ship_time is null
         |                or to_date(oi.pay_time) != to_date(oi.ship_time)
         |                )
         |            and oi.order_source = '1'
         |            and oi.pay_method not in ('000','010')
         |            and oi.receive_method in ('00','01')
         |            and to_date(oi.pay_time) >= '$monthFirstDay'
         |            and to_date(oi.pay_time) <= '$yesterday'
         |            group by oi.order_id
         |         ) a
         |         left join(
         |            select
         |               oa.fk_tgou_order_id,
         |               nvl(cast(sum(oa.amount) as decimal(18,2)),0) as amount
         |            from order_amount oa
         |            where oa.type in('4','5')
         |            group by oa.fk_tgou_order_id
         |         ) b
         |         on a.order_id = b.fk_tgou_order_id
         |         union
         |         select
         |             sum(nvl(a.product_discount,0))+sum(nvl(b.amount,0)) as pay_other_monthSum
         |         from(
         |            select
         |               oi.order_id,
         |               nvl(cast(sum(op.product_discount) as decimal(18,2)),0) as product_discount
         |            from order_information oi
         |            join order_product op
         |            on oi.order_id = op.tgou_order_id
         |            and oi.order_type = '0'
         |            and oi.order_source = '2'
         |            and oi.pay_method not in ('000','010')
         |            and oi.receive_method in ('00','01')
         |            and to_date(oi.pay_time) >= '$monthFirstDay'
         |            and to_date(oi.pay_time) <= '$yesterday'
         |            group by oi.order_id
         |         ) a
         |         left join(
         |            select
         |               oa.fk_tgou_order_id,
         |               nvl(cast(sum(oa.amount) as decimal(18,2)),0) as amount
         |            from order_amount oa
         |            where oa.type in('4','5')
         |            group by oa.fk_tgou_order_id
         |         ) b
         |         on a.order_id = b.fk_tgou_order_id
         |     ) t
         |) t1 cross join (
         |    select sum(t.pay_other_lastMonthSum) pay_other_lastMonthSum
         |    from (
         |         select
         |            sum(nvl(a.product_discount,0))+sum(nvl(b.amount,0)) as pay_other_lastMonthSum
         |         from(
         |            select
         |               oi.order_id,
         |               nvl(cast(sum(op.product_discount) as decimal(18,2)),0) as product_discount
         |            from order_information oi
         |            join order_product op
         |            on oi.order_id = op.tgou_order_id
         |            and oi.order_type = '0'
         |            and (
         |                oi.pay_time is null
         |                or oi.ship_time is null
         |                or to_date(oi.pay_time) != to_date(oi.ship_time)
         |                )
         |            and oi.order_source = '1'
         |            and oi.pay_method not in ('000','010')
         |            and oi.receive_method in ('00','01')
         |            and to_date(oi.pay_time) >= '$lastMonthFirstDay'
         |            and to_date(oi.pay_time) <= '$lastMonthYesterday'
         |            group by oi.order_id
         |         ) a
         |         left join(
         |            select
         |               oa.fk_tgou_order_id,
         |               nvl(cast(sum(oa.amount) as decimal(18,2)),0) as amount
         |            from order_amount oa
         |            where oa.type in('4','5')
         |            group by oa.fk_tgou_order_id
         |         ) b
         |         on a.order_id = b.fk_tgou_order_id
         |         union
         |         select
         |             sum(nvl(a.product_discount,0))+sum(nvl(b.amount,0)) as pay_other_lastMonthSum
         |         from(
         |            select
         |               oi.order_id,
         |               nvl(cast(sum(op.product_discount) as decimal(18,2)),0) as product_discount
         |            from order_information oi
         |            join order_product op
         |            on oi.order_id = op.tgou_order_id
         |            and oi.order_type = '0'
         |            and oi.order_source = '2'
         |            and oi.pay_method not in ('000','010')
         |            and oi.receive_method in ('00','01')
         |            and to_date(oi.pay_time) >= '$lastMonthFirstDay'
         |            and to_date(oi.pay_time) <= '$lastMonthYesterday'
         |            group by oi.order_id
         |         ) a
         |         left join(
         |            select
         |               oa.fk_tgou_order_id,
         |               nvl(cast(sum(oa.amount) as decimal(18,2)),0) as amount
         |            from order_amount oa
         |            where oa.type in('4','5')
         |            group by oa.fk_tgou_order_id
         |         ) b
         |         on a.order_id = b.fk_tgou_order_id
         |     ) t
         |) t2
         """.stripMargin)


    /*
      *  在线支付物流配送-实体门店
      *
      *  pay_entity_count  支付笔数
      *  pay_entity_sum  支付金额
      *  pay_entity_rate 支付率
      *
      */
    val entityDF = spark.sql(
      s"""
         |select
         |      t1.pay_entity_count,
         |      t1.pay_entity_sum,
         |      case when t2.create_entity_count = 0 or isnull(t2.create_entity_count) = true then 0 else round(t1.pay_entity_count / t2.create_entity_count * 100, 2) end as pay_entity_rate
         |from (
         |      select
         |          count(distinct a.order_id) as pay_entity_count,
         |          sum(nvl(a.product_discount,0))+sum(nvl(b.amount,0)) as pay_entity_sum
         |      from(
         |         select
         |            oi.order_id,
         |            nvl(cast(sum(op.product_discount) as decimal(18,2)),0) as product_discount
         |         from order_information oi
         |         join order_product op
         |         on oi.order_id = op.tgou_order_id
         |         and oi.order_type = '0'
         |         and oi.order_source in ('1','2')
         |         and oi.receive_method = '10'
         |         and oi.pay_method not in ('000','010')
         |         and to_date(oi.pay_time) = '$yesterday'
         |         group by oi.order_id
         |      ) a
         |      left join(
         |         select
         |            oa.fk_tgou_order_id,
         |            nvl(cast(sum(oa.amount) as decimal(18,2)),0) as amount
         |         from order_amount oa
         |         where oa.type in('4','5')
         |         group by oa.fk_tgou_order_id
         |      ) b
         |      on a.order_id = b.fk_tgou_order_id
         |) t1 cross join (
         |      select
         |          count(oi.order_id) as create_entity_count
         |      from order_information oi
         |      where oi.order_type = '0'
         |      and oi.order_source in ('1','2')
         |      and oi.receive_method = '10'
         |      and oi.pay_method != '000'
         |      and to_date(oi.create_time) = '$yesterday'
         |) t2
         """.stripMargin)

    /*
      *  在线支付物流配送-实体门店
      *
      *  pay_entity_monthSum  月累计
      *  pay_entity_mom 环比
      *
      */
    val monthEntityDF = spark.sql(
      s"""
         |select
         |      t1.pay_entity_monthSum,
         |      case when t2.pay_entity_lastMonthSum = 0 then 0 else round((t1.pay_entity_monthSum - t2.pay_entity_lastMonthSum) / t2.pay_entity_lastMonthSum * 100,2) end as pay_entity_mom
         |from (
         |     select
         |         sum(nvl(a.product_discount,0))+sum(nvl(b.amount,0)) as pay_entity_monthSum
         |     from(
         |        select
         |            oi.order_id,
         |            nvl(cast(sum(op.product_discount) as decimal(18,2)),0) as product_discount
         |        from order_information oi
         |        join order_product op
         |        on oi.order_id = op.tgou_order_id
         |        and oi.order_type = '0'
         |        and oi.order_source in ('1','2')
         |        and oi.receive_method = '10'
         |        and oi.pay_method not in ('000','010')
         |        and to_date(oi.pay_time) >= '$monthFirstDay'
         |        and to_date(oi.pay_time) <= '$yesterday'
         |        group by oi.order_id
         |     ) a
         |     left join(
         |         select
         |            oa.fk_tgou_order_id,
         |            nvl(cast(sum(oa.amount) as decimal(18,2)),0) as amount
         |         from order_amount oa
         |         where oa.type in('4','5')
         |         group by oa.fk_tgou_order_id
         |     ) b
         |     on a.order_id = b.fk_tgou_order_id
         |) t1 cross join (
         |     select
         |         sum(nvl(a.product_discount,0))+sum(nvl(b.amount,0)) as pay_entity_lastMonthSum
         |     from(
         |        select
         |            oi.order_id,
         |            nvl(cast(sum(op.product_discount) as decimal(18,2)),0) as product_discount
         |        from order_information oi
         |        join order_product op
         |        on oi.order_id = op.tgou_order_id
         |        and oi.order_type = '0'
         |        and oi.order_source in ('1','2')
         |        and oi.receive_method = '10'
         |        and oi.pay_method not in ('000','010')
         |        and to_date(oi.pay_time) >= '$lastMonthFirstDay'
         |        and to_date(oi.pay_time) <= '$lastMonthYesterday'
         |        group by oi.order_id
         |     ) a
         |     left join(
         |         select
         |            oa.fk_tgou_order_id,
         |            nvl(cast(sum(oa.amount) as decimal(18,2)),0) as amount
         |         from order_amount oa
         |         where oa.type in('4','5')
         |         group by oa.fk_tgou_order_id
         |     ) b
         |     on a.order_id = b.fk_tgou_order_id
         |) t2
         """.stripMargin)

    /*
      *  在线支付物流配送-全球购
      *
      *  pay_global_count  支付笔数
      *  pay_global_sum  支付金额
      *  pay_global_rate 支付率
      *
      */
    val globalDF = spark.sql(
      s"""
         |select
         |      t1.pay_global_count,
         |      t1.pay_global_sum,
         |      case when t2.create_global_count = 0 or isnull(t2.create_global_count) = true then 0 else round(t1.pay_global_count / t2.create_global_count * 100, 2) end as pay_global_rate
         |from (
         |     select
         |         count(distinct a.order_id) as pay_global_count,
         |         sum(nvl(a.product_discount,0))+sum(nvl(b.amount,0)) as pay_global_sum
         |     from(
         |         select
         |            oi.order_id,
         |            nvl(cast(sum(op.product_discount) as decimal(18,2)),0) as product_discount
         |         from order_information oi
         |         join order_product op
         |         on oi.order_id = op.tgou_order_id
         |         join store s
         |         on oi.store_id = s.id
         |         and oi.order_type = '0'
         |         and oi.order_source = '4'
         |         and oi.receive_method = '10'
         |         and oi.pay_method not in ('000','010')
         |         and s.is_international = '1'
         |         and to_date(oi.pay_time) = '$yesterday'
         |         group by oi.order_id
         |     ) a
         |     left join(
         |         select
         |            oa.fk_tgou_order_id,
         |            nvl(cast(sum(oa.amount) as decimal(18,2)),0) as amount
         |         from order_amount oa
         |         where oa.type in('4','5')
         |         group by oa.fk_tgou_order_id
         |     ) b
         |     on a.order_id = b.fk_tgou_order_id
         |) t1 cross join (
         |    select
         |         count(oi.order_id) as create_global_count
         |     from order_information oi
         |     join store s
         |     on oi.store_id = s.id
         |     and oi.order_type = '0'
         |     and oi.order_source = '4'
         |     and oi.receive_method = '10'
         |     and oi.pay_method != '000'
         |     and s.is_international = '1'
         |     and to_date(oi.create_time) = '$yesterday'
         |) t2
           """.stripMargin)

    /*
      *  在线支付物流配送-全球购
      *
      *  pay_global_monthSum  月累计
      *  pay_global_mom 环比
      *
      */
    val monthGlobalDF = spark.sql(
      s"""
         |select
         |      t1.pay_global_monthSum,
         |      case when t2.pay_global_lastMonthSum = 0 then 0 else round((t1.pay_global_monthSum - t2.pay_global_lastMonthSum) / t2.pay_global_lastMonthSum * 100,2) end as pay_global_mom
         |from (
         |     select
         |         sum(nvl(a.product_discount,0))+sum(nvl(b.amount,0)) as pay_global_monthSum
         |     from(
         |        select
         |            oi.order_id,
         |            nvl(cast(sum(op.product_discount) as decimal(18,2)),0) as product_discount
         |        from order_information oi
         |        join order_product op
         |        on oi.order_id = op.tgou_order_id
         |        join store s
         |        on oi.store_id = s.id
         |        and oi.order_type = '0'
         |        and oi.order_source = '4'
         |        and oi.receive_method = '10'
         |        and oi.pay_method not in ('000','010')
         |        and s.is_international = '1'
         |        and to_date(oi.pay_time) >= '$monthFirstDay'
         |        and to_date(oi.pay_time) <= '$yesterday'
         |        group by oi.order_id
         |     ) a
         |     left join(
         |         select
         |            oa.fk_tgou_order_id,
         |            nvl(cast(sum(oa.amount) as decimal(18,2)),0) as amount
         |         from order_amount oa
         |         where oa.type in('4','5')
         |         group by oa.fk_tgou_order_id
         |     ) b
         |     on a.order_id = b.fk_tgou_order_id
         |) t1 cross join (
         |     select
         |         sum(nvl(a.product_discount,0))+sum(nvl(b.amount,0)) as pay_global_lastMonthSum
         |     from(
         |        select
         |            oi.order_id,
         |            nvl(cast(sum(op.product_discount) as decimal(18,2)),0) as product_discount
         |        from order_information oi
         |        join order_product op
         |        on oi.order_id = op.tgou_order_id
         |        join store s
         |        on oi.store_id = s.id
         |        and oi.order_type = '0'
         |        and oi.order_source = '4'
         |        and oi.receive_method = '10'
         |        and oi.pay_method not in ('000','010')
         |        and s.is_international = '1'
         |        and to_date(oi.pay_time) >= '$lastMonthFirstDay'
         |        and to_date(oi.pay_time) <= '$lastMonthYesterday'
         |        group by oi.order_id
         |     ) a
         |     left join(
         |         select
         |            oa.fk_tgou_order_id,
         |            nvl(cast(sum(oa.amount) as decimal(18,2)),0) as amount
         |         from order_amount oa
         |         where oa.type in('4','5')
         |         group by oa.fk_tgou_order_id
         |     ) b
         |     on a.order_id = b.fk_tgou_order_id
         |) t2
           """.stripMargin)

    /*
      *  在线支付物流配送-品牌商
      *
      *  pay_brand_count  支付笔数
      *  pay_brand_sum  支付金额
      *  pay_brand_rate 支付率
      *
      */
    val brandDF = spark.sql(
      s"""
         |select
         |      t1.pay_brand_count,
         |      t1.pay_brand_sum,
         |      case when t2.create_brand_count = 0 or isnull(t2.create_brand_count) = true then 0 else round(t1.pay_brand_count / t2.create_brand_count * 100, 2) end as pay_brand_rate
         |from (
         |     select
         |         count(distinct a.order_id) as pay_brand_count,
         |         sum(nvl(a.product_discount,0))+sum(nvl(b.amount,0)) as pay_brand_sum
         |     from(
         |        select
         |            oi.order_id,
         |            nvl(cast(sum(op.product_discount) as decimal(18,2)),0) as product_discount
         |        from order_information oi
         |        join order_product op
         |        on oi.order_id = op.tgou_order_id
         |        join store s
         |        on oi.store_id = s.id
         |        and oi.order_type = '0'
         |        and oi.order_source = '4'
         |        and oi.receive_method = '10'
         |        and oi.pay_method not in ('000','010')
         |        and s.is_international = '0'
         |        and to_date(oi.pay_time) = '$yesterday'
         |        group by oi.order_id
         |     ) a
         |     left join(
         |         select
         |            oa.fk_tgou_order_id,
         |            nvl(cast(sum(oa.amount) as decimal(18,2)),0) as amount
         |         from order_amount oa
         |         where oa.type in('4','5')
         |         group by oa.fk_tgou_order_id
         |     ) b
         |     on a.order_id = b.fk_tgou_order_id
         |) t1 cross join (
         |     select
         |         count(oi.order_id) as create_brand_count
         |     from order_information oi
         |     join store s
         |     on oi.store_id = s.id
         |     and oi.order_type = '0'
         |     and oi.order_source = '4'
         |     and oi.receive_method = '10'
         |     and oi.pay_method != '000'
         |     and s.is_international = '0'
         |     and to_date(oi.create_time) = '$yesterday'
         |) t2
         """.stripMargin)

    /*
      *  在线支付物流配送-品牌商
      *
      *  pay_brand_monthSum  月累计
      *  pay_brand_mom 环比
      *
      */
    val monthBrandDF = spark.sql(
      s"""
         |select
         |      t1.pay_brand_monthSum,
         |      case when t2.pay_brand_lastMonthSum = 0 then 0 else round((t1.pay_brand_monthSum - t2.pay_brand_lastMonthSum) / t2.pay_brand_lastMonthSum * 100,2) end as pay_brand_mom
         |from (
         |     select
         |         sum(nvl(a.product_discount,0))+sum(nvl(b.amount,0)) as pay_brand_monthSum
         |     from(
         |        select
         |            oi.order_id,
         |            nvl(cast(sum(op.product_discount) as decimal(18,2)),0) as product_discount
         |        from order_information oi
         |        join order_product op
         |        on oi.order_id = op.tgou_order_id
         |        join store s
         |        on oi.store_id = s.id
         |        and oi.order_type = '0'
         |        and oi.order_source = '4'
         |        and oi.receive_method = '10'
         |        and oi.pay_method not in ('000','010')
         |        and s.is_international = '0'
         |        and to_date(oi.pay_time) >= '$monthFirstDay'
         |        and to_date(oi.pay_time) <= '$yesterday'
         |        group by oi.order_id
         |     ) a
         |     left join(
         |         select
         |            oa.fk_tgou_order_id,
         |            nvl(cast(sum(oa.amount) as decimal(18,2)),0) as amount
         |         from order_amount oa
         |         where oa.type in('4','5')
         |         group by oa.fk_tgou_order_id
         |     ) b
         |     on a.order_id = b.fk_tgou_order_id
         |) t1 cross join (
         |     select
         |         sum(nvl(a.product_discount,0))+sum(nvl(b.amount,0)) as pay_brand_lastMonthSum
         |     from(
         |        select
         |            oi.order_id,
         |            nvl(cast(sum(op.product_discount) as decimal(18,2)),0) as product_discount
         |        from order_information oi
         |        join order_product op
         |        on oi.order_id = op.tgou_order_id
         |        join store s
         |        on oi.store_id = s.id
         |        and oi.order_type = '0'
         |        and oi.order_source = '4'
         |        and oi.receive_method = '10'
         |        and oi.pay_method not in ('000','010')
         |        and s.is_international = '0'
         |        and to_date(oi.pay_time) >= '$lastMonthFirstDay'
         |        and to_date(oi.pay_time) <= '$lastMonthYesterday'
         |        group by oi.order_id
         |     ) a
         |     left join(
         |         select
         |            oa.fk_tgou_order_id,
         |            nvl(cast(sum(oa.amount) as decimal(18,2)),0) as amount
         |         from order_amount oa
         |         where oa.type in('4','5')
         |         group by oa.fk_tgou_order_id
         |     ) b
         |     on a.order_id = b.fk_tgou_order_id
         |) t2
         """.stripMargin)


    /*
      *  到店支付到店自提
      *
      *  pay_offline_count  支付笔数
      *  pay_offline_sum  支付金额
      *  pay_offline_rate 支付率
      *
      */
    val offlineDF = spark.sql(
      s"""
         |select
         |      t1.pay_offline_count,
         |      t1.pay_offline_sum,
         |      case when t2.create_offline_count = 0 or isnull(t2.create_offline_count) = true then 0 else round(t1.pay_offline_count / t2.create_offline_count * 100, 2) end as pay_offline_rate
         |from (
         |     select
         |         count(distinct a.order_id) as pay_offline_count,
         |         sum(nvl(a.product_discount,0))+sum(nvl(b.amount,0)) as pay_offline_sum
         |     from(
         |        select
         |            oi.order_id,
         |            nvl(cast(sum(op.product_discount) as decimal(18,2)),0) as product_discount
         |        from order_information oi
         |        join order_product op
         |        on oi.order_id = op.tgou_order_id
         |        and oi.order_type = '0'
         |        and oi.order_source in ('1','2')
         |        and oi.receive_method in ('00','01')
         |        and oi.pay_method = '000'
         |        and to_date(oi.pay_time) = '$yesterday'
         |        group by oi.order_id
         |     ) a
         |     left join(
         |         select
         |            oa.fk_tgou_order_id,
         |            nvl(cast(sum(oa.amount) as decimal(18,2)),0) as amount
         |         from order_amount oa
         |         where oa.type in('4','5')
         |         group by oa.fk_tgou_order_id
         |     ) b
         |     on a.order_id = b.fk_tgou_order_id
         |) t1 cross join (
         |    select
         |         count(oi.order_id) as create_offline_count
         |     from order_information oi
         |     where oi.order_type = '0'
         |     and oi.order_source in ('1','2')
         |     and oi.receive_method in ('00','01')
         |     and oi.pay_method = '000'
         |     and to_date(oi.create_time) = '$yesterday'
         |) t2
         """.stripMargin)

    /*
      *  到店支付到店自提
      *
      *  pay_offline_monthSum  月累计
      *  pay_offline_mom 环比
      *
      */
    val monthOfflineDF = spark.sql(
      s"""
         |select
         |      t1.pay_offline_monthSum,
         |      case when t2.pay_offline_lastMonthSum = 0 then 0 else round((t1.pay_offline_monthSum - t2.pay_offline_lastMonthSum) / t2.pay_offline_lastMonthSum * 100,2) end as pay_offline_mom
         |from (
         |     select
         |         sum(nvl(a.product_discount,0))+sum(nvl(b.amount,0)) as pay_offline_monthSum
         |     from(
         |        select
         |            oi.order_id,
         |            nvl(cast(sum(op.product_discount) as decimal(18,2)),0) as product_discount
         |        from order_information oi
         |        join order_product op
         |        on oi.order_id = op.tgou_order_id
         |        and oi.order_type = '0'
         |        and oi.order_source in ('1','2')
         |        and oi.receive_method in ('00','01')
         |        and oi.pay_method = '000'
         |        and to_date(oi.pay_time) >= '$monthFirstDay'
         |        and to_date(oi.pay_time) <= '$yesterday'
         |        group by oi.order_id
         |     ) a
         |     left join(
         |         select
         |            oa.fk_tgou_order_id,
         |            nvl(cast(sum(oa.amount) as decimal(18,2)),0) as amount
         |         from order_amount oa
         |         where oa.type in('4','5')
         |         group by oa.fk_tgou_order_id
         |     ) b
         |     on a.order_id = b.fk_tgou_order_id
         |) t1 cross join (
         |     select
         |         sum(nvl(a.product_discount,0))+sum(nvl(b.amount,0)) as pay_offline_lastMonthSum
         |     from(
         |        select
         |            oi.order_id,
         |            nvl(cast(sum(op.product_discount) as decimal(18,2)),0) as product_discount
         |        from order_information oi
         |        join order_product op
         |        on oi.order_id = op.tgou_order_id
         |        and oi.order_type = '0'
         |        and oi.order_source in ('1','2')
         |        and oi.receive_method in ('00','01')
         |        and oi.pay_method = '000'
         |        and to_date(oi.pay_time) >= '$lastMonthFirstDay'
         |        and to_date(oi.pay_time) <= '$lastMonthYesterday'
         |        group by oi.order_id
         |     ) a
         |     left join(
         |         select
         |            oa.fk_tgou_order_id,
         |            nvl(cast(sum(oa.amount) as decimal(18,2)),0) as amount
         |         from order_amount oa
         |         where oa.type in('4','5')
         |         group by oa.fk_tgou_order_id
         |     ) b
         |     on a.order_id = b.fk_tgou_order_id
         |) t2
         """.stripMargin)


    eleticketDF.
      crossJoin(monthEleticketDF).
      crossJoin(otherDF).
      crossJoin(monthOtherDF).
      crossJoin(entityDF).
      crossJoin(monthEntityDF).
      crossJoin(globalDF).
      crossJoin(monthGlobalDF).
      crossJoin(brandDF).
      crossJoin(monthBrandDF).
      crossJoin(offlineDF).
      crossJoin(monthOfflineDF)
  }
}
