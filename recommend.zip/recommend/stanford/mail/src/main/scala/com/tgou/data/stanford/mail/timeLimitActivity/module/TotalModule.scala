package com.tgou.data.stanford.mail.timeLimitActivity.module

import org.apache.spark.sql.{DataFrame, SparkSession}
import org.joda.time.LocalDate

/**
  * Created by 张少锐 on 2018/01/05.
  * 限时抢日报-合计
  *
  */

object TotalModule {

  def getTotalModule(spark: SparkSession,date: LocalDate): DataFrame = {

    // 加载数据源
    val table = TableProcessor(spark,date)
    val yesterday = table.yesterday.concat(" 00:00:00")
    val today = table.today.concat(" 00:00:00")

    /**
      * 限时抢日报-合计
      *
      * 字段：
      * - 其他字段合计在html模板上计算
      * - zfdds 已支付订单数
      * - zfddje 已支付订单金额
      * - zfddkdj  已支付订单客单价
      * - zfddyhs 已支付订单用户数
      * - zfyhs_old 已支付老用户数
      * - zfdds_old 老用户已支付订单数
      * - zfddje_old 老用户已支付订单金额
      * - zfyhs_new 已支付新用户数
      * - zfdds_new 新用户已支付订单数
      * - zfddje_new 新用户已支付订单金额
      **/

    /*
     *  zfdds 已支付订单数
     *  zfddje 已支付订单金额
     *  zfddkdj  已支付订单客单价
     *  zfddyhs 已支付订单用户数
     */

    //跨境
    val crossDF = spark.sql(
      s"""
         |select
         |    distinct oi.order_id,
         |    oi.member_id,
         |    oi.total_amount
         |from
         |(
         |    select distinct ap.fk_listing_id
         |    from activity a
         |    join activity_product ap
         |    on a.activity_id = ap.fk_activity_id
         |    where a.group_id = '5471'
         |    and a.state = "processing"
         |    and a.start_time < '${today}'
         |    and a.stop_time >= '${yesterday}'
         |    and ap.start_time < '${today}'
         |    and ap.stop_time >= '${yesterday}'
         |    and ap.stop_time >= ap.start_time
         |) a
         |join order_product op
         |on a.fk_listing_id = op.mall_product_id
         |join order_information oi
         |on oi.order_id = op.tgou_order_id
         |and oi.order_source = '4'
         |and oi.receive_method = '10'
         |and oi.pay_time >= '${yesterday}'
         |and oi.pay_time < '${today}'
         |join store s
         |on oi.store_id = s.id
         |and s.is_international = '1'
       """.stripMargin)

    //百货配送
    val departDF = spark.sql(
      s"""
         |select
         |    distinct oi.order_id,
         |    oi.member_id,
         |    oi.total_amount
         |from
         |(
         |    select distinct ap.fk_listing_id
         |    from activity a
         |    join activity_product ap
         |    on a.activity_id = ap.fk_activity_id
         |    where a.group_id = '5471'
         |    and a.state = "processing"
         |    and a.start_time < '${today}'
         |    and a.stop_time >= '${yesterday}'
         |    and ap.start_time < '${today}'
         |    and ap.stop_time >= '${yesterday}'
         |    and ap.stop_time >= ap.start_time
         |) a
         |join order_product op
         |on a.fk_listing_id = op.mall_product_id
         |join order_information oi
         |on oi.order_id = op.tgou_order_id
         |and oi.order_source = '1'
         |and oi.receive_method = '10'
         |and oi.pay_time >= '${yesterday}'
         |and oi.pay_time < '${today}'
       """.stripMargin)

    //社会化
    val socialDF = spark.sql(
      s"""
         |select
         |    distinct oi.order_id,
         |    oi.member_id,
         |    oi.total_amount
         |from
         |(
         |    select distinct ap.fk_listing_id
         |    from activity a
         |    join activity_product ap
         |    on a.activity_id = ap.fk_activity_id
         |    where a.group_id = '5471'
         |    and a.state = "processing"
         |    and a.start_time < '${today}'
         |    and a.stop_time >= '${yesterday}'
         |    and ap.start_time < '${today}'
         |    and ap.stop_time >= '${yesterday}'
         |    and ap.stop_time >= ap.start_time
         |) a
         |join order_product op
         |on a.fk_listing_id = op.mall_product_id
         |join order_information oi
         |on oi.order_id = op.tgou_order_id
         |and oi.order_source = '4'
         |and oi.receive_method = '10'
         |and oi.pay_time >= '${yesterday}'
         |and oi.pay_time < '${today}'
         |join store s
         |on oi.store_id = s.id
         |and s.is_international = '0'
       """.stripMargin)

    crossDF.union(departDF).union(socialDF).createOrReplaceTempView("zfdd")

    val zfddDF = spark.sql(
      s"""
         |select
         |    zfddyhs,
         |    zfdds,
         |    zfddje,
         |    case when zfdds = 0 or isnull(zfdds) = true then 0 else round(zfddje/zfdds,2) end as zfddkdj
         |from (
         |   select
         |       count(distinct zf.member_id) as zfddyhs,
         |       count(distinct zf.order_id)  as zfdds,
         |       nvl(cast(sum(zf.total_amount) as decimal(18,2)),0) as zfddje
         |   from zfdd zf
         |)
       """.stripMargin)

    /*
     *  zfyhs_old 已支付老用户数
     *  zfdds_old 老用户已支付订单数
     *  zfddje_old 老用户已支付订单金额
     */

    //跨境
    val crossOldDF = spark.sql(
      s"""
         |select
         |    distinct oi.order_id,
         |    oi.member_id
         |from order_information oi
         |join store s
         |on oi.store_id = s.id
         |and oi.order_source = '4'
         |and oi.receive_method = '10'
         |and oi.pay_time < '${yesterday}'
         |and s.is_international = '1'
       """.stripMargin)

    //百货配送
    val departOldDF = spark.sql(
      s"""
         |select
         |    distinct oi.order_id,
         |    oi.member_id
         |from order_information oi
         |where oi.order_source = '1'
         |and oi.receive_method = '10'
         |and oi.pay_time < '${yesterday}'
       """.stripMargin)

    //社会化
    val socialOldDF = spark.sql(
      s"""
         |select
         |    distinct oi.order_id,
         |    oi.member_id
         |from order_information oi
         |join store s
         |on oi.store_id = s.id
         |and oi.order_source = '4'
         |and oi.receive_method = '10'
         |and oi.pay_time < '${yesterday}'
         |and s.is_international = '0'
       """.stripMargin)

    crossOldDF.union(departOldDF).union(socialOldDF).createOrReplaceTempView("zfdd_old")

    val oldDF = spark.sql(
      s"""
         |select
         |    count(distinct zf.member_id) as zfyhs_old,
         |    count(distinct zf.order_id)  as zfdds_old,
         |    nvl(cast(sum(zf.total_amount) as decimal(18,2)),0) as zfddje_old
         |from zfdd zf
         |where zf.member_id in(
         |  select
         |      distinct zo.member_id
         |  from zfdd_old zo
         |)
       """.stripMargin)

    /*
     *  zfyhs_new 已支付新用户数
     *  zfdds_new 新用户已支付订单数
     *  zfddje_new 新用户已支付订单金额
     */
    val newDF = spark.sql(
      s"""
         |select
         |    count(distinct zf.member_id) as zfyhs_new,
         |    count(distinct zf.order_id)  as zfdds_new,
         |    nvl(cast(sum(zf.total_amount) as decimal(18,2)),0) as zfddje_new
         |from zfdd zf
         |where zf.member_id not in(
         |  select
         |      distinct zo.member_id
         |  from zfdd_old zo
         |)
       """.stripMargin)

   zfddDF.crossJoin(oldDF).
      crossJoin(newDF)
  }

}
