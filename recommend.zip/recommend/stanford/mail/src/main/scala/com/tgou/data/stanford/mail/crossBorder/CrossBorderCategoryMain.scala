package  com.tgou.data.stanford.mail.crossBorder

import com.tgou.data.stanford.mail.core.MailBootstrap
import org.apache.spark.sql.{SaveMode, SparkSession}
import org.joda.time.LocalDate

/**
  * Created by 李磊 on 2018/01/08.
  *#31685 定时邮件：天狗全球购分类统计和每周跨境(含吃货)销售报表-邮件合并
  * 每天跨境分类
  */

object CrossBorderCategoryMain {

  def main(args: Array[String]): Unit = {
    MailBootstrap(args).bootstrap(execute)
  }

  def execute(spark: SparkSession, appName: String, date: LocalDate): Unit = {


    /**
      * 第一步 获取数据
      * 跨境分类
      * 吃货分类
      * 合计
      * */
    val crossBorder = CrossBorder.getTansDF(spark,appName,date)
  //  val crossBorderHeJi =  CrossBorderHeJi.getTansDF(spark, date)
    val crossMember = CrossBorderMember.getCrossBorderMember(spark,appName,date)
    val crossStore = CrossBorderStore.getCrossBorderMember(spark,appName,date)


    /**
      * 第三步 保存数据到HDFS上
      * */
    crossBorder.coalesce(1).write.mode(SaveMode.Overwrite).json(s"/tmp/liuyang/cross/crossBorder/$date/")
    crossMember.coalesce(1).write.mode(SaveMode.Overwrite).json(s"/tmp/liuyang/cross/crossMember/$date/")
    crossStore.coalesce(1).write.mode(SaveMode.Overwrite).json(s"/tmp/liuyang/cross/crossStore/$date/")

 //   crossBorderHeJi.coalesce(1).write.mode(SaveMode.Overwrite).json(s"/data/mail/crossBorderCategory/crossBorderHeJi/$date/")
    spark.stop()
  }
}