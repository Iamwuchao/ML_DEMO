package com.tgou.data.stanford.mail.tiangouBrand.module

import org.apache.spark.sql.{DataFrame, SparkSession}
import org.joda.time.LocalDate

/**
  * Created by 张少锐 on 2017/12/18.
  * 集团品牌/店铺销售数据
  */

object TiangouGroupSum {

  def getTiangouBrandSum(spark: SparkSession, appName: String, date: LocalDate, brandID: String, brandName: String): DataFrame = {

    val yesterday = date.toString("yyyy-MM-dd")
    var yesterdayPlus1: String = null
    var yesterdayMinus7: String = null

    if (appName.equals("weekcount")) {
      //周统计
      yesterdayMinus7 = date.minusDays(6).toString("yyyy-MM-dd")
      yesterdayPlus1 = date.plusDays(1).toString("yyyy-MM-dd")

    } else if (appName.equals("monthcount")) {
      //月统计
      yesterdayMinus7 = date.withDayOfMonth(1).toString("yyyy-MM-dd")
      yesterdayPlus1 = date.plusMonths(1).withDayOfMonth(1).toString("yyyy-MM-dd")

    }else {
      //每个月的周五都运行,但是限制每个月的周五在2号到8号才执行
      if(2<=date.plusDays(1).getDayOfMonth&&date.plusDays(1).getDayOfMonth<=8){
        //月初第一周统计
        yesterdayMinus7 = date.withDayOfMonth(1).toString("yyyy-MM-dd")
        yesterdayPlus1 = date.withDayOfWeek(5).toString("yyyy-MM-dd")
      }else{
        //让程序报错，不运行
        System.out.println("当前统计日期是"+date+",不符合月初第一周")
        spark.close()
      }

    }

    /*
      * 加载数据源
      * */
    spark.sql(
      s"""
         |select
         |     oi.order_id
         |from dw.order_information oi
         |where
         |     oi.his_time = '${yesterday}'
         |and  oi.receive_method = '10'
       """.stripMargin).createOrReplaceTempView("order_information")

    spark.sql(
      s"""
         |select
         |     op.tgou_order_id,
         |     op.brand_id,
         |     op.state,
         |     to_date(op.pay_time) as pay_time,
         |     to_date(op.etl_time) as etl_time,
         |     to_date(op.create_time) as create_time,
         |     to_date(op.ship_time) as ship_time,
         |     cast(op.`product_discount` as double) as product_discount
         |from dw.order_product op
         |where
         |     op.his_time = '${yesterday}'
         |and  op.brand_id in ($brandID)
       """.stripMargin).createOrReplaceTempView("order_product")

    /**
      * 集团-品牌销售数据
      *
      * 字段:
      *  - brand_name 品牌名称
      *  - xdbs 下单笔数
      *  - xdje 下单金额
      *  - xdpsbs 下单配送笔数
      *  - xdpsje 下单配送金额
      *  - hxbs 核销笔数
      *  - hxje 核销金额
      *  - psbs 配送笔数
      *  - psje 配送金额
      *  - zfpsbs 支付配送笔数
      *  - zfpsje 支付配送金额
      *  - thbs 退货笔数
      *  - thje 退货金额
      **/
    val brandDF = spark.sql(
      s"""
         |select
         |     distinct op.brand_id
         |from order_product op
       """.stripMargin)

    val createDF = spark.sql(
      s"""
         |select
         |     op.brand_id,
         |     count(distinct op.tgou_order_id) as xdbs,
         |     nvl(cast(sum(op.product_discount) as decimal(18,2)),0) as xdje
         |from order_product op
         |where op.create_time >= '$yesterdayMinus7'
         |and op.create_time < '$yesterdayPlus1'
         |group by op.brand_id
       """.stripMargin)

    val createSendDF = spark.sql(
      s"""
         |select
         |     op.brand_id,
         |     count(distinct op.tgou_order_id) as xdpsbs,
         |     nvl(cast(sum(op.product_discount) as decimal(18,2)),0) as xdpsje
         |from order_product op
         |join order_information oi
         |on oi.order_id = op.tgou_order_id
         |where op.create_time >= '$yesterdayMinus7'
         |and op.create_time < '$yesterdayPlus1'
         |group by op.brand_id
       """.stripMargin)

    val shipDF = spark.sql(
      s"""
         |select
         |     op.brand_id,
         |     count(distinct op.tgou_order_id) as hxbs,
         |     nvl(cast(sum(op.product_discount) as decimal(18,2)),0) as hxje
         |from order_product op
         |where op.ship_time >= '$yesterdayMinus7'
         |and op.ship_time < '$yesterdayPlus1'
         |group by op.brand_id
       """.stripMargin)

    val shipSendDF = spark.sql(
      s"""
         |select
         |     op.brand_id,
         |     count(distinct op.tgou_order_id) as psbs,
         |     nvl(cast(sum(op.product_discount) as decimal(18,2)),0) as psje
         |from order_product op
         |join order_information oi
         |on oi.order_id = op.tgou_order_id
         |where op.ship_time >= '$yesterdayMinus7'
         |and op.ship_time < '$yesterdayPlus1'
         |group by op.brand_id
       """.stripMargin)

    val payDF = spark.sql(
      s"""
         |select
         |     op.brand_id,
         |     count(distinct op.tgou_order_id) as zfpsbs,
         |     nvl(cast(sum(op.product_discount) as decimal(18,2)),0) as zfpsje
         |from order_product op
         |join order_information oi
         |on oi.order_id = op.tgou_order_id
         |where op.pay_time >= '$yesterdayMinus7'
         |and op.pay_time < '$yesterdayPlus1'
         |group by op.brand_id
       """.stripMargin)

    val returnedDF = spark.sql(
      s"""
         |select
         |     op.brand_id,
         |     count(distinct op.tgou_order_id) as thbs,
         |     nvl(cast(sum(op.product_discount) as decimal(18,2)),0) as thje
         |from order_product op
         |where op.etl_time >= '$yesterdayMinus7'
         |and op.etl_time < '$yesterdayPlus1'
         |and op.state = 'Returned'
         |group by op.brand_id
       """.stripMargin)

    brandDF.join(createDF,Seq("brand_id"),"left").
      join(createSendDF,Seq("brand_id"),"left").
      join(shipDF,Seq("brand_id"),"left").
      join(shipSendDF,Seq("brand_id"),"left").
      join(payDF,Seq("brand_id"),"left").
      join(returnedDF,Seq("brand_id"),"left").
      select(
        "brand_id",
        "xdbs",
        "xdje",
        "xdpsbs",
        "xdpsje",
        "hxbs",
        "hxje",
        "psbs",
        "psje",
        "zfpsbs",
        "zfpsje",
        "thbs",
        "thje"
      ).createOrReplaceTempView("total")

    //对brand_id进行数据汇总
    spark.sql(
      s"""
         |select
         |  '$brandName' as brand_name,
         |  nvl(sum(t.xdbs),0) as xdbs,
         |  nvl(sum(t.xdje),0) as xdje,
         |  nvl(sum(t.xdpsbs),0) as xdpsbs,
         |  nvl(sum(t.xdpsje),0) as xdpsje,
         |  nvl(sum(t.hxbs),0) as hxbs,
         |  nvl(sum(t.hxje),0) as hxje,
         |  nvl(sum(t.psbs),0) as psbs,
         |  nvl(sum(t.psje),0) as psje,
         |  nvl(sum(t.zfpsbs),0) as zfpsbs,
         |  nvl(sum(t.zfpsje),0) as zfpsje,
         |  nvl(sum(t.thbs),0) as thbs,
         |  nvl(sum(t.thje),0) as thje
         |from total t
       """.stripMargin)

  }

  def getTiangouStoreSum(spark: SparkSession, appName: String, date: LocalDate, storeID: String, storeName: String): DataFrame = {

    val yesterday = date.toString("yyyy-MM-dd")
    var yesterdayPlus1: String = null
    var yesterdayMinus7: String = null

    if (appName.equals("weekcount")) {
      //周统计
      yesterdayMinus7 = date.minusDays(6).toString("yyyy-MM-dd")
      yesterdayPlus1 = date.plusDays(1).toString("yyyy-MM-dd")

    } else if (appName.equals("monthcount")) {
      //月统计
      yesterdayMinus7 = date.withDayOfMonth(1).toString("yyyy-MM-dd")
      yesterdayPlus1 = date.plusMonths(1).withDayOfMonth(1).toString("yyyy-MM-dd")

    }

    /*
      * 加载数据源
      * */
    spark.sql(
      s"""
         |select
         |     oi.order_id,
         |     oi.store_id,
         |     oi.receive_method
         |from dw.order_information oi
         |where
         |     oi.his_time = '${yesterday}'
         |and  oi.store_id in ($storeID)
       """.stripMargin).createOrReplaceTempView("order_information")

    spark.sql(
      s"""
         |select
         |     op.tgou_order_id,
         |     op.state,
         |     to_date(op.pay_time) as pay_time,
         |     to_date(op.etl_time) as etl_time,
         |     to_date(op.create_time) as create_time,
         |     to_date(op.ship_time) as ship_time,
         |     cast(op.`product_discount` as double) as product_discount
         |from dw.order_product op
         |where
         |     op.his_time = '${yesterday}'
       """.stripMargin).createOrReplaceTempView("order_product")

    /**
      * 集团-店铺销售数据
      *
      * 字段:
      *  - store_name 店铺名称
      *  - xdbs 下单笔数
      *  - xdje 下单金额
      *  - xdpsbs 下单配送笔数
      *  - xdpsje 下单配送金额
      *  - hxbs 核销笔数
      *  - hxje 核销金额
      *  - psbs 配送笔数
      *  - psje 配送金额
      *  - zfpsbs 支付配送笔数
      *  - zfpsje 支付配送金额
      *  - thbs 退货笔数
      *  - thje 退货金额
      **/
    val storeDF = spark.sql(
      s"""
         |select
         |     distinct oi.store_id
         |from order_information oi
       """.stripMargin)

    val createDF = spark.sql(
      s"""
         |select
         |     oi.store_id,
         |     count(distinct op.tgou_order_id) as xdbs,
         |     nvl(cast(sum(op.product_discount) as decimal(18,2)),0) as xdje
         |from order_product op
         |join order_information oi
         |on oi.order_id = op.tgou_order_id
         |where op.create_time >= '$yesterdayMinus7'
         |and op.create_time < '$yesterdayPlus1'
         |group by oi.store_id
       """.stripMargin)

    val createSendDF = spark.sql(
      s"""
         |select
         |     oi.store_id,
         |     count(distinct op.tgou_order_id) as xdpsbs,
         |     nvl(cast(sum(op.product_discount) as decimal(18,2)),0) as xdpsje
         |from order_product op
         |join order_information oi
         |on oi.order_id = op.tgou_order_id
         |where op.create_time >= '$yesterdayMinus7'
         |and op.create_time < '$yesterdayPlus1'
         |and oi.receive_method = '10'
         |group by oi.store_id
       """.stripMargin)

    val shipDF = spark.sql(
      s"""
         |select
         |     oi.store_id,
         |     count(distinct op.tgou_order_id) as hxbs,
         |     nvl(cast(sum(op.product_discount) as decimal(18,2)),0) as hxje
         |from order_product op
         |join order_information oi
         |on oi.order_id = op.tgou_order_id
         |where op.ship_time >= '$yesterdayMinus7'
         |and op.ship_time < '$yesterdayPlus1'
         |group by oi.store_id
       """.stripMargin)

    val shipSendDF = spark.sql(
      s"""
         |select
         |     oi.store_id,
         |     count(distinct op.tgou_order_id) as psbs,
         |     nvl(cast(sum(op.product_discount) as decimal(18,2)),0) as psje
         |from order_product op
         |join order_information oi
         |on oi.order_id = op.tgou_order_id
         |where op.ship_time >= '$yesterdayMinus7'
         |and op.ship_time < '$yesterdayPlus1'
         |and oi.receive_method = '10'
         |group by oi.store_id
       """.stripMargin)

    val payDF = spark.sql(
      s"""
         |select
         |     oi.store_id,
         |     count(distinct op.tgou_order_id) as zfpsbs,
         |     nvl(cast(sum(op.product_discount) as decimal(18,2)),0) as zfpsje
         |from order_product op
         |join order_information oi
         |on oi.order_id = op.tgou_order_id
         |where op.pay_time >= '$yesterdayMinus7'
         |and op.pay_time < '$yesterdayPlus1'
         |and oi.receive_method = '10'
         |group by oi.store_id
       """.stripMargin)

    val returnedDF = spark.sql(
      s"""
         |select
         |     oi.store_id,
         |     count(distinct op.tgou_order_id) as thbs,
         |     nvl(cast(sum(op.product_discount) as decimal(18,2)),0) as thje
         |from order_product op
         |join order_information oi
         |on oi.order_id = op.tgou_order_id
         |where op.etl_time >= '$yesterdayMinus7'
         |and op.etl_time < '$yesterdayPlus1'
         |and op.state = 'Returned'
         |group by oi.store_id
       """.stripMargin)

    storeDF.join(createDF,Seq("store_id"),"left").
      join(createSendDF,Seq("store_id"),"left").
      join(shipDF,Seq("store_id"),"left").
      join(shipSendDF,Seq("store_id"),"left").
      join(payDF,Seq("store_id"),"left").
      join(returnedDF,Seq("store_id"),"left").
      select(
        "store_id",
        "xdbs",
        "xdje",
        "xdpsbs",
        "xdpsje",
        "hxbs",
        "hxje",
        "psbs",
        "psje",
        "zfpsbs",
        "zfpsje",
        "thbs",
        "thje"
      ).createOrReplaceTempView("total")

    //对store_id进行数据汇总
    spark.sql(
      s"""
         |select
         |  '$storeName' as store_name,
         |  nvl(sum(t.xdbs),0) as xdbs,
         |  nvl(sum(t.xdje),0) as xdje,
         |  nvl(sum(t.xdpsbs),0) as xdpsbs,
         |  nvl(sum(t.xdpsje),0) as xdpsje,
         |  nvl(sum(t.hxbs),0) as hxbs,
         |  nvl(sum(t.hxje),0) as hxje,
         |  nvl(sum(t.psbs),0) as psbs,
         |  nvl(sum(t.psje),0) as psje,
         |  nvl(sum(t.zfpsbs),0) as zfpsbs,
         |  nvl(sum(t.zfpsje),0) as zfpsje,
         |  nvl(sum(t.thbs),0) as thbs,
         |  nvl(sum(t.thje),0) as thje
         |from total t
       """.stripMargin)

  }

}
