package com.tgou.data.stanford.mail.monitor.module.listing

import com.tgou.data.stanford.mail.monitor.module.listing.bean.Listing
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.joda.time.LocalDate

/**
  * Created by 李震 on 2017/9/27.
  */
object ListingModule {

  private val SELLABLE_ITEM_STATE = Set("onshelf", "pending", "rejected", "draft", "offline")

  /**
    * 单品统计（百货）
    *
    * @param spark
    * @param date
    *
    * @return
    *
    * 字段：
    *
    * - sellable_item_count  可销售商品款数
    * - sellable_item_categroy_count  可销售商品分类数
    * - sellable_item_brand_count  可销售商品品牌数
    * - onshelf_item_count  上架商品数
    * - onshelf_item_category_count  上架商品分类数
    * - onshelf_item_brand_count  上架商品品牌数
    * - fastsale_item_count  快捷商品数
    * - fastsale_item_category_count  快捷商品分类数
    * - fastsale_item_brand_count  快捷商品品牌数
    * - sellable_not_bind_item_count  可销售商品未绑定二维码款数
    *
    * */
  def getListingDF(spark: SparkSession, date: LocalDate): DataFrame = {
    import spark.implicits._

    /*
     * 加载数据源
     * */
    val source = ListingSource(spark)
    val listingDF = source.getUpdateListingDWDF(date)
    val productDF = source.getUpdateProductDWDF(date)

    val r = listingDF.join(productDF, listingDF.col("product_id") === productDF.col("product_id"), "leftouter")
      .select(
        listingDF.col("listing_id"),
        listingDF.col("product_id"),
        listingDF.col("state"),
        listingDF.col("download_time"),
        listingDF.col("binding_time"),
        listingDF.col("is_fast_sales"),
        productDF.col("brand_id"),
        productDF.col("product_third_category")
      )
      .as[Listing]
      .map((l) => {
        var sellableItemCount = 0
        var sellableNotBindItemCount = 0
        var onshelfItemCount = 0
        var fastSaleItemCount = 0

        var sellableItemCategorySeq: Seq[String] = Seq()
        var sellableItemBrandSeq: Seq[String] = Seq()

        var onshelfItemCategorySeq: Seq[String] = Seq()
        var onshelfItemBrandSeq: Seq[String] = Seq()

        var fastSaleItemCategorySeq: Seq[String] = Seq()
        var fastSaleItemBrandSeq: Seq[String] = Seq()


        // 可销售商品
        if (SELLABLE_ITEM_STATE.contains(l.state)) {
          sellableItemCount = 1

          sellableItemCategorySeq = Seq(l.product_third_category)
          sellableItemBrandSeq = Seq(l.brand_id)

          if (l.download_time == null && l.binding_time == null) sellableNotBindItemCount = 1
        }

        // 上架商品
        if ("onshelf".equals(l.state)) {
          onshelfItemCount = 1

          onshelfItemCategorySeq = Seq(l.product_third_category)
          onshelfItemBrandSeq = Seq(l.brand_id)
        }

        // 快捷商品
        if (l.is_fast_sales) {
          fastSaleItemCount = 1

          fastSaleItemCategorySeq = Seq(l.product_third_category)
          fastSaleItemBrandSeq = Seq(l.brand_id)
        }

        (
          sellableItemCount,
          sellableItemCategorySeq,
          sellableItemBrandSeq,
          onshelfItemCount,
          onshelfItemCategorySeq,
          onshelfItemBrandSeq,
          fastSaleItemCount,
          fastSaleItemCategorySeq,
          fastSaleItemBrandSeq,
          sellableNotBindItemCount
        )
      }).reduce((t1, t2) => {
        (
          t1._1 + t2._1,
          (t1._2 ++ t2._2).distinct,
          (t1._3 ++ t2._3).distinct,
          t1._4 + t2._4,
          (t1._5 ++ t2._5).distinct,
          (t1._6 ++ t2._6).distinct,
          t1._7 + t2._7,
          (t1._8 ++ t2._8).distinct,
          (t1._9 ++ t2._9).distinct,
          t1._10 + t2._10
        )
      })

    List(
      (
        r._1,
        r._2.size,
        r._3.size,
        r._4,
        r._5.size,
        r._6.size,
        r._7,
        r._8.size,
        r._9.size,
        r._10
      )
    ).toDF(
      "sellable_item_count",
      "sellable_item_categroy_count",
      "sellable_item_brand_count",
      "onshelf_item_count",
      "onshelf_item_category_count",
      "onshelf_item_brand_count",
      "fastsale_item_count",
      "fastsale_item_category_count",
      "fastsale_item_brand_count",
      "sellable_not_bind_item_count"
    )
  }

}
