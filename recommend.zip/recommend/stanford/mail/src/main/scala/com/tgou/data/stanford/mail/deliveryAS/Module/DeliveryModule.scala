package com.tgou.data.stanford.mail.deliveryAS.Module

import org.apache.spark.sql.{DataFrame, SparkSession}
import org.joda.time.LocalDate

/**
  * Created by 刘洋 on 2018/02/24.
  */

object DeliveryModule {

  def DeliveryQuery(spark: SparkSession, date: LocalDate): DataFrame = {

    val yesDay = date.toString("yyyy-MM-dd")
    val yesDay2 = date.minusDays(1)toString("yyyy-MM-dd")
    val toDay = date.plusDays(1).toString("yyyy-MM-dd")
    /**
      * 百货发货率
      * */
    val query = spark.sql(
      s"""
         |select
         |  distinct
         |  t1.store_name ,
         |  t.store_orders ,
         |  t.order_sku ,
         |  t.order_quantity ,
         |  t.store_amount ,
         |  t.actual_orders,
         |  concat(round(t.actual_orders /t.store_orders * 100 ,2),'%') sjfhl
         |from
         |(
         |  select
         |    a.store_id,
         |    count(distinct a.id) as  store_orders,
         |    sum(distinct a.total_amount) as store_amount,
         |    COUNT(distinct CASE
         |      WHEN a.ship_time >= '${yesDay2} 15:00:00' and a.ship_time <'${toDay} 00:00:00'   THEN a.id
         |    END) actual_orders,
         |    sum( b.product_quantity) as order_quantity,
         |    count(distinct b.attr_sku) as order_sku
         |  from dw.order_information a
         |    join dw.order_product b
         |  on a.id = b.fk_order_information_id
         |  and a.create_time >= '${yesDay2} 15:00:00'
         |  and a.create_time < '${yesDay} 15:00:00'
         |  and a.pay_time >= '${yesDay2} 15:00:00'
         |  and a.pay_time < '${yesDay} 15:00:00'
         |  and a.pay_method != '010'
         |  and a.receive_method = '10'
         |  and a.order_source = '1'
         |  and a.order_type =  '0'
         |  and a.his_time = '${yesDay}'
         |  and b.his_time = '${yesDay}'
         |  group by a.store_id
         |) t
         |join dw.store t1
         |on t1.id = t.store_id
      """.stripMargin
    )
    query
  }
}