package com.tgou.data.stanford.mail.monitor.module.storeActivity.bean

import com.tgou.data.stanford.mail.core.BaseBean

object Activity extends BaseBean {

  override def list: List[(Any,String)] = {

    List(
      (0, "id"),
      (3, "state"),
      (5, "start_time"),
      (6, "end_time"),
      (10, "source"),
      (26, "modify_time")
    )

  }
}
