package com.tgou.data.stanford.mail.monitor.module.eleticket

import org.apache.spark.sql.{DataFrame, SparkSession}
import org.joda.time.LocalDate

/**
  * Created by 李震 on 2017/9/29.
  */
class EleTicketSource(spark: SparkSession) {

  def getUpdateOrderInformationDWDF(date: LocalDate): DataFrame = {
    spark.sql(
      s"""
        |select
        |  o.order_id,
        |  o.member_id,
        |  o.create_time,
        |  o.pay_time,
        |  o.ship_time,
        |  o.total_amount,
        |  o.pay_method,
        |  o.receive_method
        |from dw.order_information o
        |where o.his_time = '${date.toString("yyyy-MM-dd")}'
        |and o.order_type = '0'
      """.stripMargin)
  }

  def getUpdateOrderProductDWDF(date: LocalDate): DataFrame = {
    spark.sql(
      s"""
        |select
        |  op.tgou_order_id,
        |  op.product_quantity,
        |  op.product_discount
        |from dw.order_product op
        |where op.his_time = '${date.toString("yyyy-MM-dd")}'
      """.stripMargin)
  }

}

object EleTicketSource {

  def apply(spark: SparkSession): EleTicketSource = new EleTicketSource(spark)

}
