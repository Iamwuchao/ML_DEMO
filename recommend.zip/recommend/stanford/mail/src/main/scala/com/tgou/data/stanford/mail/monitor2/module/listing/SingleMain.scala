package com.tgou.data.stanford.mail.monitor2.module.listing

import com.tgou.data.stanford.mail.core.MailBootstrap
import org.apache.spark.sql.{SaveMode, SparkSession}
import org.joda.time.LocalDate

/**
  * Created by 刘洋 on 2017/12/05.
  */

object SingleMain {


  def main(args: Array[String]): Unit = {
    MailBootstrap(args).bootstrap(execute)
  }

  def execute(spark: SparkSession, appName: String, date: LocalDate): Unit = {

     SingleGoodsModule.getSingleDF(spark,date).show();
  }
}