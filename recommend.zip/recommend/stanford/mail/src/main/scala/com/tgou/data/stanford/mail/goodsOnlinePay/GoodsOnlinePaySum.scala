package com.tgou.data.stanford.mail.goodsOnlinePay

import org.apache.spark.sql.{DataFrame, SparkSession}
import org.joda.time.LocalDate

/**
  * Created by 张少锐 on 2017/10/20.
  * 百货订单商品邮件报表周报，月报，月初第一周统计
  */
object GoodsOnlinePaySum {

  def getGoodsOnlinePaySum(spark: SparkSession, appName: String, date: LocalDate): DataFrame = {

    val yesterday = date.toString("yyyy-MM-dd")
    var yesterdayPlus1: String = null
    var yesterdayMinus7: String = null
    //获取上次统计结果
    var oldSumDF: DataFrame = null

    if (appName.equals("weekcount")) {
      //周统计
      yesterdayMinus7 = date.minusDays(6).toString("yyyy-MM-dd")
      yesterdayPlus1 = date.plusDays(1).toString("yyyy-MM-dd")

      //获取上周日期
      val lastWeek = date.minusDays(7)
      System.out.println("上次统计日期是：" + lastWeek)
      oldSumDF = spark.read.json(s"/data/mail/goods_online_pay/${appName}/$lastWeek/")

    } else if (appName.equals("monthcount")) {
      //月统计
      yesterdayMinus7 = date.withDayOfMonth(1).toString("yyyy-MM-dd")
      yesterdayPlus1 = date.plusMonths(1).withDayOfMonth(1).toString("yyyy-MM-dd")

      //获取上月日期
      val lastMonth = date.withDayOfMonth(1).minusDays(1)
      System.out.println("上次统计日期是：" + lastMonth)
      oldSumDF = spark.read.json(s"/data/mail/goods_online_pay/${appName}/$lastMonth/")

    } else {
      //每个月的周五都运行,但是限制每个月的周五在2号到8号才执行
      if(2<=date.plusDays(1).getDayOfMonth&&date.plusDays(1).getDayOfMonth<=8){
        //月初第一周统计
        yesterdayMinus7 = date.withDayOfMonth(1).toString("yyyy-MM-dd")
        yesterdayPlus1 = date.withDayOfWeek(5).toString("yyyy-MM-dd")

        //获取上次月初第一周统计日期
        val firstDayOfLastMonth = date.minusMonths(1).withDayOfMonth(1)
        val monthOfYear = firstDayOfLastMonth.getMonthOfYear()
        val firstThurdayOfLastMonth = firstDayOfLastMonth.withDayOfWeek(4)
        val firstWeek =
          if (firstThurdayOfLastMonth.getMonthOfYear() < monthOfYear)
            firstThurdayOfLastMonth.plusDays(7)
          else firstThurdayOfLastMonth
        System.out.println("上次统计日期是：" + firstWeek)
        oldSumDF = spark.read.json(s"/data/mail/goods_online_pay/${appName}/$firstWeek/")
      }else{
        //让程序报错，不运行
        oldSumDF = null
        System.out.println("当前统计日期是"+date+",不符合月初第一周")
      }

    }

    //统计的时间范围是
    System.out.println("统计的时间范围是(左闭右开)：" + yesterdayMinus7 + "至" + yesterdayPlus1)

    /*
     * 加载数据源
     * */
    spark.sql(
      s"""
         |select
         |     oi.order_id,
         |     oi.pay_method,
         |     oi.receive_method,
         |     to_date(oi.pay_time) as pay_time,
         |     to_date(oi.ship_time) as ship_time,
         |     to_date(oi.cancel_time) as cancel_time
         |from dw.order_information oi
         |where
         |     oi.his_time = '${yesterday}'
         |and  oi.order_source = '1'
         |and  oi.order_type = '0'
         |and  oi.pay_time >= '${yesterdayMinus7}'
         |and  oi.pay_time < '${yesterdayPlus1}'
       """.stripMargin).createTempView("goods_order_information")

    spark.sql(
      s"""
         |select
         |     op.tgou_order_id,
         |     cast(op.`product_discount` as double) as product_discount
         |from dw.order_product op
         |where
         |     op.his_time = '${yesterday}'
       """.stripMargin).createTempView("goods_order_product")

    /**
      * 百货线上支付统计
      *
      * 字段:
      *  - payOrdersSum 百货线上支付的订单商品金额
      *  - eleTicketSum 电子小票交易金额
      *  - paySendSum 百货支付配送金额
      *  - onlineOrderSum 百货线上订单商品金额
      *  - onlineCancelOrderSum 百货纯线上取消订单金额
      *  - onlineNotShipOrderSum 百货纯线上未核销订单金额
      **/

    val payOrdersSumDF =
      spark.sql(
        s"""
           |select
           |     nvl(cast(sum(op.product_discount) as decimal(18,2)),0) as payOrdersSum
           |from goods_order_information oi
           |join goods_order_product op
           |on (
           |     oi.order_id = op.tgou_order_id
           |     and oi.pay_method != '000'
           |)
       """.stripMargin)

    val eleTicketSumDF =
      spark.sql(
        s"""
           |select
           |     nvl(cast(sum(op.product_discount) as decimal(18,2)),0) as eleTicketSum
           |from goods_order_information oi
           |join goods_order_product op
           |on (
           |     oi.order_id = op.tgou_order_id
           |     and oi.pay_method != '000'
           |     and oi.receive_method in ('00','01')
           |     and oi.ship_time = oi.pay_time
           |)
       """.stripMargin)

    val paySendSumDF =
      spark.sql(
        s"""
           |select
           |     nvl(cast(sum(op.product_discount) as decimal(18,2)),0) as paySendSum
           |from goods_order_information oi
           |join goods_order_product op
           |on (
           |     oi.order_id = op.tgou_order_id
           |     and oi.receive_method = '10'
           |)
       """.stripMargin)

    val onlineOrderSumDF =
      spark.sql(
        s"""
           |select
           |     nvl(cast(sum(op.product_discount) as decimal(18,2)),0) as onlineOrderSum
           |from goods_order_information oi
           |join goods_order_product op
           |on (
           |     oi.order_id = op.tgou_order_id
           |     and oi.pay_method != '000'
           |     and oi.receive_method in ('00','01')
           |     and nvl(oi.ship_time,'0') != nvl(oi.pay_time,'0')
           |)
       """.stripMargin)


    val onlineCancelOrderSumDF =
      spark.sql(
        s"""
           |select
           |     nvl(cast(sum(op.product_discount) as decimal(18,2)),0) as onlineCancelOrderSum
           |from goods_order_information oi
           |join goods_order_product op
           |on (
           |     oi.order_id = op.tgou_order_id
           |     and oi.pay_method != '000'
           |     and oi.receive_method in ('00','01')
           |     and nvl(oi.ship_time,'0') != nvl(oi.pay_time,'0')
           |     and isnull(oi.ship_time)
           |     and oi.cancel_time is not null
           |)
       """.stripMargin)

    val onlineNotShipOrderSumDF =
      spark.sql(
        s"""
           |select
           |     nvl(cast(sum(op.product_discount) as decimal(18,2)),0) as onlineNotShipOrderSum
           |from goods_order_information oi
           |join goods_order_product op
           |on (
           |     oi.order_id = op.tgou_order_id
           |     and oi.pay_method != '000'
           |     and oi.receive_method in ('00','01')
           |     and nvl(oi.ship_time,'0') != nvl(oi.pay_time,'0')
           |     and isnull(oi.ship_time)
           |     and isnull(oi.cancel_time)
           |)
       """.stripMargin)

    //本次统计结果
    val newSumDF =
      payOrdersSumDF.
        crossJoin(eleTicketSumDF).
        crossJoin(paySendSumDF).
        crossJoin(onlineOrderSumDF).
        crossJoin(onlineCancelOrderSumDF).
        crossJoin(onlineNotShipOrderSumDF)

    //上次结果和本次结果汇总
    oldSumDF.selectExpr(
      "eleTicketSum as eleTicketSumOld",
      "onlineCancelOrderSum as onlineCancelOrderSumOld",
      "onlineNotShipOrderSum as onlineNotShipOrderSumOld",
      "onlineOrderSum as onlineOrderSumOld",
      "payOrdersSum as payOrdersSumOld",
      "paySendSum as paySendSumOld"
    ).crossJoin(newSumDF)

  }

}
