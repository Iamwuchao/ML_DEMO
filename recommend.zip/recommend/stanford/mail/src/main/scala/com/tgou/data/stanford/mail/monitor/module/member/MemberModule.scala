package com.tgou.data.stanford.mail.monitor.module.member

import org.apache.spark.sql.{DataFrame, SparkSession}
import org.joda.time.LocalDate

/**
  * Created by 李震 on 2017/9/27.
  */
object MemberModule {

  /**
    * 会员相关统计
    *
    * @param spark
    * @param date
    *
    * @return
    *
    * 字段：
    *
    * member_count  累计天狗用户数
    * new_member_count  当日新增天狗用户数
    * emember_count  累计天狗电子会员数
    * new_emember_count  当日新增电子会员数
    * emember_total_points  天狗电子会员积分余额
    * emember_consum_percent  天狗电子会员会员消费占比
    * member_consum_percent  天狗用户下单比例
    * member_30days_active_percent  天狗用户30天重复登录率
    * old_member_use_percent  老用户重复使用率
    * member_30days_retention_rate  天狗电子会员30日留存率
    *
    * */
  def getMemberDF(spark: SparkSession, date: LocalDate): DataFrame = {
    import spark.implicits._

    /*
     * 加载数据源
     * */
    val source = MemberSource(spark)
    val memberDF = source.getUpdateMemberDWDF(date)
    memberDF.createOrReplaceTempView("member")
    val dsCardBindDF = source.getUpdateDsCardBindDWDF(date)
    dsCardBindDF.createOrReplaceTempView("ds_card_bind")
    source.getCompleteDaMmcIblnTgODSDF(date).createOrReplaceTempView("da_mmc_ibln_tg")
    val posZzDF = source.getAppendPosZzDWDF(date)
    posZzDF.createOrReplaceTempView("pos_zz")
    source.getUpdateOrderInformationDWDF(date).createOrReplaceTempView("order_information")
    val ubaPageDF = source.getAppendLast30DaysUbaPageDWDF(date)
    ubaPageDF.createOrReplaceTempView("uba_page")

    /*
     * memberCount  累计天狗用户数
     * newMemberCount  当日天狗用户数
     * */
    val memberCount = memberDF.count()
    val newMemberCount = memberDF
      .filter(s"register_time >= '${date.toString("yyyy-MM-dd")}' and register_time < '${date.plusDays(1).toString("yyyy-MM-dd")}'")
      .count()

    /*
     * ememberCount  累计天狗电子会员数
     * newEMemberCount  当日新增电子会员数
     * */
    val ememberCount = dsCardBindDF.select("member_id").distinct().count()
    val newEMemberCount = dsCardBindDF
      .filter(s"first_bind_time >= '${date.toString("yyyy-MM-dd")}' and first_bind_time < '${date.plusDays(1).toString("yyyy-MM-dd")}'")
      .select("member_id")
      .distinct()
      .count()

    /*
     * emember_total_points  天狗电子会员积分余额
     * */
    val ememberTotalPoints = BigDecimal(spark.sql(
      """
        |select
        |    sum(haploidintegral) / 1000000000 as emember_total_points
        |from da_mmc_ibln_tg dmit
        |inner join ds_card_bind cb
        |on dmit.storecode = cb.store_code
        |and dmit.cid = cb.card_id
      """.stripMargin).first().getDouble(0))


    /*
     * emember_consum_percent  天狗电子会员消费占比
     * member_consum_percent  天狗用户下单比例
     * */
    val totalBs = BigDecimal(posZzDF.count())

    val ememberConsumPercent = BigDecimal(spark.sql(
      """
        |select
        |    count(1) as emember_bs
        |from pos_zz pz
        |join ds_card_bind cb
        |on pz.cid = cb.card_id
        |and cb.bind_status = '0'
      """.stripMargin).first().getLong(0)) / totalBs

    val memberConsumPercent = BigDecimal(spark.sql(
      s"""
        |select
        |    count(1) as member_bs
        |from order_information o
        |where o.order_source in ('1', '2')
        |and o.ship_time >= '${date.toString("yyyy-MM-dd")}'
        |and o.ship_time < '${date.plusDays(1).toString("yyyy-MM-dd")}'
      """.stripMargin).first().getLong(0)) / totalBs

    /*
     * member_30days_active_percent  天狗用户30天重复登录率
     * */
    val member30daysActivePercent = BigDecimal(spark.sql(
      """
        |select
        |    count(his_time) as count
        |from (
        |    select
        |        up.member_id,
        |        up.his_time
        |    from uba_page up
        |    where up.member_id is not null
        |    group by up.member_id, up.his_time
        |) up
        |group by up.member_id
        |having count >= 2
      """.stripMargin).count()) / BigDecimal(ubaPageDF.select("member_id").distinct().count())

    /*
     * old_member_use_percent  老用户使用率
     * member_30days_retention_rate  天狗电子会员30日留存率
     * */
    val last_30days_active_user_count = BigDecimal(spark.sql(
      s"""
        |select
        |  count(1)
        |from (
        |  select
        |    count(his_time) as count,
        |    up.member_id
        |  from (
        |    select
        |        up.member_id,
        |        up.his_time
        |    from uba_page up
        |    where up.member_id is not null
        |    group by up.member_id, up.his_time
        |  ) up
        |  group by up.member_id
        |  having count >= 2
        |) t1 join (
        |  select
        |    m.member_id
        |  from member m
        |  where m.register_time < '${date.minusDays(30).toString("yyyy-MM-dd")}'
        |) t2
        |on t1.member_id = t2.member_id
      """.stripMargin).first().getLong(0))

    val oldMemberUsePercent = last_30days_active_user_count /
      BigDecimal(memberDF.count())

    val member30daysRetentionRate = last_30days_active_user_count /
      BigDecimal(memberDF.filter(s"register_time < '${date.minusDays(30).toString("yyyy-MM-dd")}'").count())

    List(
      (
        memberCount,
        newMemberCount,
        ememberCount,
        newEMemberCount,
        ememberTotalPoints.toDouble,
        ememberConsumPercent.toDouble,
        memberConsumPercent.toDouble,
        member30daysActivePercent.toDouble,
        oldMemberUsePercent.toDouble,
        member30daysRetentionRate.toDouble
      )
    ).toDF(
      "member_count",
      "new_member_count",
      "emember_count",
      "new_emember_count",
      "emember_total_points",
      "emember_consum_percent",
      "member_consum_percent",
      "member_30days_active_percent",
      "old_member_use_percent",
      "member_30days_retention_rate"
    )
  }

}
