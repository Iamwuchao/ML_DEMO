package com.tgou.data.stanford.mail.offlinePayment

import com.tgou.data.stanford.mail.core.MailBootstrap
import org.apache.spark.sql.{SaveMode, SparkSession}
import org.joda.time.LocalDate

/**
  * Created by 张少锐 on 2017/12/27.
  * 线下支付宝及微信邮件报表周报
  */

object OfflinePaymentMain {

  def main(args: Array[String]): Unit = {
    MailBootstrap(args).bootstrap(execute)
  }

  def execute(spark: SparkSession, appName: String, date: LocalDate): Unit = {
    /**
      * 第一步 获取数据
      * */
    val result = OfflinePaymentSum.getOfflinePaymentSum(spark,date)

    /**
      * 第二步 保存数据到HDFS上
      * */
      result.coalesce(1).write.mode(SaveMode.Overwrite).json(s"/data/mail/offline_payment_week/$date/")

    spark.stop()
  }
}
