package  com.tgou.data.stanford.mail.crossBorder

import org.apache.spark.sql.{DataFrame, SparkSession}
import org.joda.time.LocalDate

/**
  * Created by 李磊 on 2018/01/08.
  * 每天合计分类
  */
object CrossBorderHeJi {
  /**
    * 字段：
    * - name	                 分类名称
    * - product_onshelfs       在线商品数
    * - product_uploads        新上线商品数
    * - order_bill_count       下单数
    * - pay_bill_count         下单并支付数
    * - pay_product_count      支付商品数量
    * - pay_sku_count          支付SKU数量
    * - pay_bill_amount        支付订单金额
    * - pay_bill_avgs          支付订单客单价
    * - pay_bill_member        支付订单用户数
    * - pay_old_count          老用户支付订单数
    * - pay_old_amount         老用户支付订单额
    * - pay_old_member         老用户支付用户数
    * - pay_new_count          新用户支付订单数
    * - pay_new_amount         新用户支付订单额
    * - pay_new_member         新用户支付用户数
    * */
  def getTansDF(spark:SparkSession, date: LocalDate): DataFrame = {

    var date_s = date.toString("yyyy-MM-dd")
    var date_e = date.plusDays(1).toString("yyyy-MM-dd")

    /*
      * 每天合计分类
      * - name	                 分类名称
      * - product_onshelfs       在线商品数
      * - product_uploads        新上线商品数
      * */

    val crossBorder1_1 = spark.sql(
      s"""
         |select '合计' as product_second_category,
         |'--' as name,
         |count(distinct a.listing_id) as product_onshelfs,
         |count(distinct
         |case
         |when a.onshelf_time >= '${date_s}'
         |and a.onshelf_time < '${date_e}'
         |then
         |a.listing_id end) as product_uploads
         |from dw.listing a
         |join dw.store s
         |on a.store_id = s.id
         |and s.his_time = '${date_s}'
         |and s.yt = '4'
         |and s.state = 'onshelf'
         |and s.is_international = '1'
         |join dw.product b
         |on a.product_id = b.product_id
         |and b.his_time = '${date_s}'
         |and b.product_first_category in ('101798','101761')
         |left join dw.category ca
         |on b.product_second_category = ca.id
         |and ca.his_time = '${date_s}'
         |where a.his_time = '${date_s}'
         |and a.state = 'onshelf'
      """.stripMargin)

    /*
      * 每天合计分类
      * - order_bill_count       下单数
      * */

    val crossBorder1_2 = spark.sql(
      s"""
         |select '合计' as product_second_category,
         |count(distinct ord.tgou_order_id) as order_bill_count
         |from  dw.order_product ord
         |join dw.order_information ordi
         |on ord.tgou_order_id = ordi.order_id
         |and ordi.his_time = '${date_s}'
         |and ordi.create_time >= '${date_s}'
         |and ordi.create_time < '${date_e}'
         |and ordi.order_type = 0
         |join dw.store s
         |on ordi.store_id = s.id
         |and s.his_time = '${date_s}'
         |and s.yt = '4'
         |and s.state = 'onshelf'
         |and s.is_international = '1'
         |join dw.listing a
         |on a.listing_id = ord.mall_product_id
         |and a.his_time = '${date_s}'
         |join dw.product b
         |on a.product_id = b.product_id
         |and b.his_time = '${date_s}'
         |and b.product_first_category in ('101798','101761')
         |left join dw.category ca
         |on b.product_second_category = ca.id
         |and ca.his_time = '${date_s}'
         |where ord.his_time = '${date_s}'
         |and ord.create_time >= '${date_s}'
         |and ord.create_time < '${date_e}'
      """.stripMargin)

    /*
         * 每天合计分类
         * - pay_bill_count         下单并支付数
         * - pay_product_count      支付商品数量
         * - pay_sku_count          支付SKU数量
         * - pay_bill_amount        支付订单金额
         * - pay_bill_avgs          支付订单客单价
         * - pay_bill_member        支付订单用户数
         * */

    val crossBorder1_3 = spark.sql(
      s"""
         |select '合计' as product_second_category,
         |count(distinct ord.tgou_order_id ) as pay_bill_count,
         |nvl(cast(sum(ord.product_quantity) as decimal(18,0)),0) as pay_product_count,
         |count(distinct ord.sku_id ) as pay_sku_count,
         |nvl(cast(sum( ord.product_discount ) as decimal(18,2)),0) as pay_bill_amount,
         |round(sum(ord.product_discount )/
         |(case count(distinct ord.tgou_order_id )
         |when 0 then 1
         |else count(distinct ord.tgou_order_id)  end),2 ) as pay_bill_avgs,
         |count(distinct ordi.member_id ) AS pay_bill_member
         |from  dw.order_product ord
         |join dw.order_information ordi
         |on ord.tgou_order_id = ordi.order_id
         |and ordi.his_time = '${date_s}'
         |and ordi.pay_method != '010'
         |and ordi.pay_time >= '${date_s}'
         |and ordi.pay_time < '${date_e}'
         |and ordi.create_time >= '${date_s}'
         |and ordi.create_time < '${date_e}'
         |and ordi.order_type = 0
         |join dw.store s
         |on ordi.store_id = s.id
         |and s.his_time = '${date_s}'
         |and s.yt = '4'
         |and s.state = 'onshelf'
         |and s.is_international = '1'
         |join dw.listing a
         |on a.listing_id = ord.mall_product_id
         |and a.his_time = '${date_s}'
         |join dw.product b
         |on a.product_id = b.product_id
         |and b.his_time = '${date_s}'
         |and b.product_first_category in ('101798','101761')
         |left join dw.category ca
         |on b.product_second_category = ca.id
         |and ca.his_time = '${date_s}'
         |where ord.his_time = '${date_s}'
         |and ord.create_time >= '${date_s}'
         |and ord.create_time < '${date_e}'
         |and ord.pay_time >= '${date_s}'
         |and ord.pay_time < '${date_e}'
      """.stripMargin)

    /*
         * 每天合计分类
         * - pay_old_count          老用户支付订单数
         * - pay_old_amount         老用户支付订单额
         * - pay_old_member         老用户支付用户数
         * - pay_new_count          新用户支付订单数
         * - pay_new_amount         新用户支付订单额
         * - pay_new_member         新用户支付用户数
         * */

    val crossBorder1_4 = spark.sql(
      s"""
         |select
         |'合计' as product_second_category,
         |nvl(count(distinct case when isnull(ordi.member_id) = false then  yd.tgou_order_id end),0) as pay_old_count,
         |nvl(cast(sum( case when isnull(ordi.member_id) = false then  yd.product_discount end) as decimal(18,2)),0) as pay_old_amount,
         |nvl(count(distinct case when isnull(ordi.member_id) = false then  yd.member_id end),0) as pay_old_member,
         |nvl(count(distinct case when isnull(ordi.member_id) = true then  yd.tgou_order_id end),0) as pay_new_count,
         |nvl(cast(sum( case when isnull(ordi.member_id) = true then  yd.product_discount end) as decimal(18,2)),0) as pay_new_amount,
         |nvl(count(distinct case when isnull(ordi.member_id) = true then  yd.member_id end),0) as pay_new_member
         |from(select b.product_second_category,
         |ord.tgou_order_id,
         |ord.product_discount,
         |ordi.member_id,
         |ord.mall_product_id
         |from  dw.order_product ord
         |join dw.order_information ordi
         |on ord.tgou_order_id = ordi.order_id
         |and ordi.his_time = '${date_s}'
         |and ordi.pay_method != '010'
         |and ordi.pay_time >= '${date_s}'
         |and ordi.pay_time < '${date_e}'
         |and ordi.create_time >= '${date_s}'
         |and ordi.create_time < '${date_e}'
         |and ordi.order_type = 0
         |join dw.store s
         |on ordi.store_id = s.id
         |and s.his_time = '${date_s}'
         |and s.yt = '4'
         |and s.state = 'onshelf'
         |and s.is_international = '1'
         |join dw.listing a
         |on a.listing_id = ord.mall_product_id
         |and a.his_time = '${date_s}'
         |join dw.product b
         |on a.product_id = b.product_id
         |and b.his_time = '${date_s}'
         |and b.product_first_category in ('101798','101761')
         |left join dw.category ca
         |on b.product_second_category = ca.id
         |and ca.his_time = '${date_s}'
         |where ord.his_time = '${date_s}'
         |and ord.create_time >= '${date_s}'
         |and ord.create_time < '${date_e}'
         |and ord.pay_time >= '${date_s}'
         |and ord.pay_time < '${date_e}'
         |group by b.product_second_category,
         |ord.tgou_order_id,
         |ord.product_discount,
         |ordi.member_id,
         |ord.mall_product_id) yd
         |left join (select ordi.member_id
         |from  dw.order_information ordi
         |join dw.store s
         |on ordi.store_id = s.id
         |and s.his_time = '${date_s}'
         |and s.yt = '4'
         |and s.state = 'onshelf'
         |and s.is_international = '1'
         |where ordi.his_time = '${date_s}'
         |and ordi.pay_time < '${date_s}'
         |and ordi.pay_method != '010'
         |and ordi.order_type = 0
         |group by ordi.member_id) ordi
         |on yd.member_id = ordi.member_id
      """.stripMargin)

    val crossBorder1 = crossBorder1_1.join(crossBorder1_2,crossBorder1_1("product_second_category") === crossBorder1_2("product_second_category"),"left")
      .join(crossBorder1_3,crossBorder1_1("product_second_category") === crossBorder1_3("product_second_category"),"left")
      .join(crossBorder1_4,crossBorder1_1("product_second_category") === crossBorder1_4("product_second_category"),"left")
      .select(crossBorder1_1("product_second_category"),
        crossBorder1_1("name"),
        crossBorder1_1("product_onshelfs"),
        crossBorder1_1("product_uploads"),
        crossBorder1_2("order_bill_count"),
        crossBorder1_3("pay_bill_count"),
        crossBorder1_3("pay_product_count"),
        crossBorder1_3("pay_sku_count"),
        crossBorder1_3("pay_bill_amount"),
        crossBorder1_3("pay_bill_avgs"),
        crossBorder1_3("pay_bill_member"),
        crossBorder1_4("pay_old_count"),
        crossBorder1_4("pay_old_amount"),
        crossBorder1_4("pay_old_member"),
        crossBorder1_4("pay_new_count"),
        crossBorder1_4("pay_new_amount"),
        crossBorder1_4("pay_new_member")
      )

    val crossBorder = crossBorder1.selectExpr("product_second_category as name",
      "product_onshelfs",
      "product_uploads",
      "nvl(order_bill_count,0) as order_bill_count",
      "nvl(pay_bill_count,0) as pay_bill_count",
      "nvl(pay_product_count,0) as pay_product_count",
      "nvl(pay_sku_count,0) as pay_sku_count",
      "nvl(pay_bill_amount,0) as pay_bill_amount",
      "nvl(pay_bill_avgs,0) as pay_bill_avgs",
      "nvl(pay_bill_member,0) as pay_bill_member",
      "nvl(pay_old_count,0) as pay_old_count",
      "nvl(pay_old_amount,0) as pay_old_amount",
      "nvl(pay_old_member,0) as pay_old_member",
      "nvl(pay_new_count,0) as pay_new_count",
      "nvl(pay_new_amount,0) as pay_new_amount",
      "nvl(pay_new_member,0) as pay_new_member")

    return crossBorder
  }
}