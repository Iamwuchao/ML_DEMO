package com.tgou.data.stanford.mail.dogFood

import com.tgou.data.stanford.mail.core.MailBootstrap
import com.tgou.data.stanford.mail.dogFood.module.{DogFoodCouponSum, DogFoodPrizeSum, DogFoodSum,DogFoodXinZengSum}
import org.apache.spark.sql.{SaveMode, SparkSession}
import org.joda.time.LocalDate

/**
  * Created by 张少锐 on 2018/01/19.
  * 狗粮签到日统计
  */
object DogFoodMain {
  def main(args: Array[String]): Unit = {
    MailBootstrap(args).bootstrap(execute)
  }

  def execute(spark: SparkSession, appName: String, date: LocalDate): Unit = {
    /**
      * 第一步 获取数据
      * */
    // 页面访问和签到数据
    val sign = DogFoodSum.getDogFoodSum(spark,date)

    // 狗粮抽奖明细数据
    val prize = DogFoodPrizeSum.getDogFoodPrizeSum(spark,date)

    // 狗粮换券明细数据
    val coupon = DogFoodCouponSum.getDogFoodCouponSum(spark,date)

    // 二期数据
    val news = DogFoodXinZengSum.getDogXZSum(spark,date)
    /**
      * 第二步 保存数据到HDFS上
      * */
    sign.coalesce(1).write.mode(SaveMode.Overwrite).json(s"/data/mail/dog_food/page_sign/$date/")
    prize.coalesce(1).write.mode(SaveMode.Overwrite).json(s"/data/mail/dog_food/prize/$date/")
    coupon.coalesce(1).write.mode(SaveMode.Overwrite).json(s"/data/mail/dog_food/coupon/$date/")
    news.coalesce(1).write.mode(SaveMode.Overwrite).json(s"/data/mail/dog_food/news/$date/")


  }
}
