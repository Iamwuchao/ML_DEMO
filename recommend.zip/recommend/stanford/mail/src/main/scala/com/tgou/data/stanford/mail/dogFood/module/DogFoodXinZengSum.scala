package com.tgou.data.stanford.mail.dogFood.module

import com.tgou.data.stanford.mail.core.MailSource
import org.apache.spark.sql.types.{LongType, StringType, StructField, StructType}
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.joda.time.LocalDate

/**
  * Created by liuyang on 2018/04/17.
  * #31447: 定时邮件：狗粮签到相关数据邮件需求2期
  */
object DogFoodXinZengSum {
  def getDogXZSum(spark: SparkSession, date: LocalDate): DataFrame = {

    val yesterday = date.toString("yyyy-MM-dd")
    val toDay = date.plusDays(1).toString("yyyy-MM-dd")

    val mp = StructType(
      StructField("id", StringType, false) ::
        StructField("fk_member_id", StringType, true) ::
        StructField("biz_id", StringType, true) ::
        StructField("biz_type", StringType, true) ::
        StructField("status", StringType, true) ::
        StructField("point", LongType, true) ::
        StructField("reason_code", StringType, true) ::
        StructField("create_time", StringType, true) ::
        StructField("modify_time", StringType, true) ::
        StructField("version", StringType, true) ::Nil
    )
    MailSource.getUpdateDF(spark,"/tiangou/plat/point_change_logs",date,Seq("id"),"modify_time",mp).distinct()
      .createOrReplaceTempView("point_change_logs")

    /**
      *           头图数据  //       图片分享数据      //店铺推荐数据//轮播广告位数据//商品推荐数据
      *           sign_pv   /  rs_page_fx(图片展示人数)/  sign_pv   /  sign_pv      /  sign_pv    /    展示次数
      *           scp_tt    /  scp_fx(图片分享次数)    /  scp_dptj  /  scp_lbgg    /  scp_sptj    /    点击次数
      *           djl_tt    /   rs_scp_fx(图片分享人数)/  djl_dptj   /  djl_lbgg    /  djl_sptj    /   次数点击率
      *           rs_page   /   rs_fx(图片成功分享人数)/   rs_page   /  rs_page     /  rs_page     /   展示人数
      *           rs_scp_tt /  rs_fx/rs_page_fx(分享率)/rs_scp_dptj  /rs_scp_lbgg   /rs_scp_sptj   /   点击人数
      *           rs_djl_tt /  point_fx (分享狗粮数)   /rs_djl_dptj  /rs_djl_lbgg   /rs_djl_sptj   /   人数点击率
      */

  val Query=  spark.sql(
      s"""
         |select
         |  x.*,
         |  y.*,
         |  z.*,
         |  case when sign_pv != 0 then round(scp_tt * 100/sign_pv,2)  else 0 end djl_tt,
         |  case when sign_pv != 0 then round(scp_dptj * 100/sign_pv,2)  else 0 end djl_dptj,
         |  case when sign_pv != 0 then round(scp_sptj * 100/sign_pv,2)  else 0 end djl_sptj,
         |  case when sign_pv != 0 then round(scp_lbgg * 100/sign_pv,2)  else 0 end djl_lbgg,
         |  case when rs_page_fx != 0 then round(rs_scp_fx * 100/rs_page_fx,2)  else 0 end rs_djl_fx,
         |  case when rs_page != 0 then round(rs_scp_tt * 100/rs_page,2)  else 0 end rs_djl_tt,
         |  case when rs_page != 0 then round(rs_scp_dptj * 100/rs_page,2)  else 0 end rs_djl_dptj,
         |  case when rs_page != 0 then round(rs_scp_sptj * 100/rs_page,2)  else 0 end rs_djl_sptj,
         |  case when rs_page != 0 then round(rs_scp_lbgg * 100/rs_page,2)  else 0 end rs_djl_lbgg
         |from (
         |select
         |    count(case when up.page = '05.tgsign' then up.id end) as sign_pv,
         |    count(case when up.page = '05.tgsign' and (up.global ='android' or up.global ='ios') then up.id end) as sign_pv_fx,
         |    count(distinct case when up.page = '05.tgsign' then up.member_id end) as rs_page
         |from dw.uba_page up
         |where up.his_time = '${yesterday}'
         |) x
         |cross join (
         |select
         |  count(case when a.scp like '05.tgsign.goHeadUrl.%' then a.id end) as scp_tt,
         |  count(case when a.scp like '05.tgsign.brandSlider%' then a.id end) as scp_dptj,
         |  count(case when a.scp like '05.tgsign.ylike.%' then a.id end) as scp_sptj,
         |  count(case when a.scp like '05.tgsign.slider.%' then a.id end) as scp_lbgg,
         |  count(case when a.scp like '05.tgsign.share.1%' and (a.global ='android' or a.global ='ios') then a.id end) as scp_fx,
         |  count(distinct case when a.scp like '05.tgsign.goHeadUrl%' then a.member_id end) as rs_scp_tt,
         |  count(distinct case when a.scp like '05.tgsign.brandSlider%' then a.member_id end) as rs_scp_dptj,
         |  count(distinct case when a.scp like '05.tgsign.ylike.%' then a.member_id end) as rs_scp_sptj,
         |  count(distinct case when a.scp like '05.tgsign.slider.%' then a.member_id end) as rs_scp_lbgg,
         |  count(distinct case when a.scp like '05.tgsign.share.1%' and (a.global ='android' or a.global ='ios') then a.member_id end) as rs_scp_fx,
         |  count(distinct case when a.scp like '05.tgsign.sign%' and (a.global ='android' or a.global ='ios') then a.member_id end) as rs_page_fx
         |from dw.uba_scp a
         |where
         |a.his_time = '${yesterday}'
         |) y
         |cross join (
         |select
         |  count(distinct fk_member_id) as rs_fx,
         |  sum(point) point_fx
         |  from point_change_logs
         |where
         |create_time >= '${yesterday}'
         |and create_time < '${toDay}'
         |and reason_code = 'FX'
         |) z
       """.stripMargin)
    Query
  }
}
