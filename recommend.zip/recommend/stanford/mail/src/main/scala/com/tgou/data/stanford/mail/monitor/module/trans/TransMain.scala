package com.tgou.data.stanford.mail.monitor.module.trans

import com.tgou.data.stanford.mail.core.MailBootstrap
import org.apache.spark.sql.SparkSession
import org.joda.time.LocalDate

object TransMain {

  def main(args: Array[String]): Unit = {
    MailBootstrap(args).bootstrap(execute)
  }

  def execute(spark: SparkSession, appName: String, date: LocalDate): Unit = {
    TransModule.getTansDF(spark, date).show()
  }
}