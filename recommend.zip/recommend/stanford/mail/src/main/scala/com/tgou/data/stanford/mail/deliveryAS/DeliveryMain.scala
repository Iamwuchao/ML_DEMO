package com.tgou.data.stanford.mail.deliveryAS

import com.tgou.data.stanford.mail.core.MailBootstrap
import com.tgou.data.stanford.mail.deliveryAS.Module._
import org.apache.spark.sql.{SaveMode, SparkSession}
import org.joda.time.LocalDate

/**
  * Created by 刘洋 on 2018/02/24.
  *#30094:百货和超市发货率分析-迁移到新邮件系统
  */

object DeliveryMain {
  def main(args: Array[String]): Unit = {
    MailBootstrap(args).bootstrap(execute)
  }

  def execute(spark: SparkSession, appName: String, date: LocalDate): Unit = {

    /**
      * 第一步 获取数据
      * */
    val result = DeliveryModule.DeliveryQuery(spark, date)
    val Total = TotalModule.DeliveryQuery(spark, date)
    /**
      * 第二步 保存数据到HDFS上
      * */
    result.coalesce(1).write.mode(SaveMode.Overwrite).json(s"/tmp/liuyang/delivery/result/$date/")
    Total.coalesce(1).write.mode(SaveMode.Overwrite).json(s"/tmp/liuyang/delivery/total/$date/")
    spark.stop()

  }

}

