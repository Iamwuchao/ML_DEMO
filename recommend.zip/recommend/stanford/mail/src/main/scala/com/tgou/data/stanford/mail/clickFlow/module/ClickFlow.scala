package  com.tgou.data.stanford.mail.clickFlow.module

import org.apache.spark.sql.{DataFrame, SparkSession, functions}
import org.joda.time.LocalDate

/**
  * Created by 李磊 on 2017/11/16.
  * 每天点击流量转换
  */
object ClickFlow{

  /**
    * 字段：
    * - click	                 点击位
    * - PV                     PV
    * - UV                     UV
    * */
  def getTansDF(spark:SparkSession, date: LocalDate): DataFrame = {


    /*
        * 每天点击流量转换
        * */

    val dateT = date.toString("yyyy-MM-dd")

    val dateTE = date.plusDays(1).toString("yyyy-MM-dd")


    val click = spark.sql(
      s"""
         |select de.djw as click,de.pv,de.uv
         |from (
         |select
         |    '结算码' as djw,
         |    count(*) as pv,
         |    count(distinct a.uuid) as uv
         |from
         |    dw.uba_scp a
         |where
         |a.his_time>= '${dateT}'
         |and a.his_time < '${dateTE}'
         |and (a.scp like '02.sp.uscode.%' or a.scp like '14.sp.uscode.%')
         |union all
         |select
         |     '搜索' as djw,
         |    count(*) as pv,
         |    count(distinct a.uuid) as uv
         |from
         |    dw.uba_scp a
         |where
         |a.his_time>= '${dateT}'
         |and a.his_time < '${dateTE}'
         |and (a.scp like '02.sp.search.%' or a.scp like '14.sp.search.%')
         |union all
         |select
         |    '购物车' as djw,
         |    count(*) as pv,
         |    count(distinct a.uuid) as uv
         |from
         |    dw.uba_scp a
         |where
         |a.his_time>= '${dateT}'
         |and a.his_time < '${dateTE}'
         |and (a.scp like '02.sp.mr.tscar.%' or a.scp like '14.sp.mr.tscar.%')
         |union all
         |select
         |     '消息' as djw,
         |    count(*) as pv,
         |    count(distinct a.uuid) as uv
         |from
         |    dw.uba_scp a
         |where
         |a.his_time>= '${dateT}'
         |and a.his_time < '${dateTE}'
         |and (a.scp like '02.sp.noti.%' or a.scp like '14.sp.noti.%')
         |union all
         |select
         |     '弹出窗口' as djw,
         |    count(*) as pv,
         |    count(distinct a.uuid) as uv
         |from
         |    dw.uba_scp a
         |where
         |a.his_time>= '${dateT}'
         |and a.his_time < '${dateTE}'
         |and (a.scp like '14.sp.popupPoster.%' or a.scp like '02.sp.popupPoster.%')
         |union all
         |select
         |     '首页轮播总计' as djw,
         |    count(*) as pv,
         |    count(distinct a.uuid) as uv
         |from
         |    dw.uba_scp a
         |where
         |a.his_time>= '${dateT}'
         |and a.his_time < '${dateTE}'
         |and (a.scp like '02.sp.slider.%'  or a.scp like '14.sp.slider.%' )
         |union all
         |select
         |     '大促大图' as djw,
         |    count(*) as pv,
         |    count(distinct a.uuid) as uv
         |from
         |    dw.uba_scp a
         |where
         |a.his_time>= '${dateT}'
         |and a.his_time < '${dateTE}'
         |and (a.scp like '02.sp.adc.00.%'  or a.scp like '14.sp.adc.00.%' )
         |union all
         |select
         |    '快捷入口-1' as djw,
         |    count(*) as pv,
         |    count(distinct a.uuid) as uv
         |from
         |    dw.uba_scp a
         |where
         |a.his_time>= '${dateT}'
         |and a.his_time < '${dateTE}'
         |and (a.scp like '02.sp.fe.00.%' or a.scp like '14.sp.fe.0.%' or a.scp like '14.sp.fe.00.%')
         |union all
         |select
         |     '快捷入口-2' as djw,
         |    count(*) as pv,
         |    count(distinct a.uuid) as uv
         |from
         |    dw.uba_scp a
         |where
         |a.his_time>= '${dateT}'
         |and a.his_time < '${dateTE}'
         |and (a.scp like '02.sp.fe.1.%' or a.scp like '02.sp.fe.01.%' or a.scp like '14.sp.fe.1.%' or a.scp like '14.sp.fe.01.%')
         |union all
         |select
         |     '快捷入口-3' as djw,
         |    count(*) as pv,
         |    count(distinct a.uuid) as uv
         |from
         |    dw.uba_scp a
         |where
         |a.his_time>= '${dateT}'
         |and a.his_time < '${dateTE}'
         |and (a.scp like '02.sp.fe.2.%' or a.scp like '02.sp.fe.02.%' or a.scp like '14.sp.fe.2.%' or a.scp like '14.sp.fe.02.%')
         |union all
         |select
         |     '快捷入口-4' as djw,
         |    count(*) as pv,
         |    count(distinct a.uuid) as uv
         |from
         |    dw.uba_scp a
         |where
         |a.his_time>= '${dateT}'
         |and a.his_time < '${dateTE}'
         |and (a.scp like '02.sp.fe.3.%' or a.scp like '02.sp.fe.03.%' or a.scp like '14.sp.fe.3.%' or a.scp like '14.sp.fe.03.%')
         |union all
         |select
         |     '快捷入口-5' as djw,
         |    count(*) as pv,
         |    count(distinct a.uuid) as uv
         |from
         |    dw.uba_scp a
         |where
         |a.his_time>= '${dateT}'
         |and a.his_time < '${dateTE}'
         |and (a.scp like '02.sp.fe.4.%' or a.scp like '02.sp.fe.04.%' or a.scp like '14.sp.fe.4.%' or a.scp like '14.sp.fe.04.%')
         |union all
         |select
         |    '一宫格' as djw,
         |    count(*) as pv,
         |    count(distinct a.uuid) as uv
         |from
         |    dw.uba_scp a
         |where
         |a.his_time>= '${dateT}'
         |and a.his_time < '${dateTE}'
         |and a.scp like '14.sp.ad_244.%'
         |union all
         |select
         |    '天狗热点' as djw,
         |    count(*) as pv,
         |    count(distinct a.uuid) as uv
         |from
         |    dw.uba_scp a
         |where
         |a.his_time>= '${dateT}'
         |and a.his_time < '${dateTE}'
         |and a.scp like '14.sp.kx.0.%'
         |union all
         |select
         |    '限时抢' as djw,
         |    count(*) as pv,
         |    count(distinct a.uuid) as uv
         |from
         |    dw.uba_scp a
         |where
         |a.his_time>= '${dateT}'
         |and a.his_time < '${dateTE}'
         |and (a.scp like '02.sp.fsmr1.%' or a.scp like '14.sp.fsmr1.%')
         |union all
         |select
         |     '限时抢商品'  as djw,
         |    count(*) as pv,
         |    count(distinct a.uuid) as uv
         |from
         |    dw.uba_scp a
         |where
         |a.his_time>= '${dateT}'
         |and a.his_time < '${dateTE}'
         |and (a.scp like '02.sp.fspro1.%' or a.scp like '14.sp.fspro1.%')
         |union all
         |select
         |    '限时抢总计' as djw,
         |    count(*) as pv,
         |    count(distinct a.uuid) as uv
         |from
         |    dw.uba_scp a
         |where
         |a.his_time>= '${dateT}'
         |and a.his_time < '${dateTE}'
         |and  (a.scp like '14.sp.fsmr1.%' or a.scp like '14.sp.fspro1.%' or a.scp like '02.sp.fsmr1.%' or a.scp like '02.sp.fspro1.%')
         |union all
         |select
         |    '二宫格-1' as djw,
         |    count(*) as pv,
         |    count(distinct a.uuid) as uv
         |from
         |    dw.uba_scp a
         |where
         |a.his_time>= '${dateT}'
         |and a.his_time < '${dateTE}'
         |and a.scp like '14.sp.ad_353.0.%'
         |union all
         |select
         |    '二宫格-2' as djw,
         |    count(*) as pv,
         |    count(distinct a.uuid) as uv
         |from
         |    dw.uba_scp a
         |where
         |a.his_time>= '${dateT}'
         |and a.his_time < '${dateTE}'
         |and a.scp like '14.sp.ad_353.1.%'
         |union all
         |select
         |    '二宫格总计' as djw,
         |    count(*) as pv,
         |    count(distinct a.uuid) as uv
         |from
         |    dw.uba_scp a
         |where
         |a.his_time>= '${dateT}'
         |and a.his_time < '${dateTE}'
         |and a.scp like '14.sp.ad_353.%'
         |union all
         |select
         |     '四宫格-1' as djw,
         |    count(*) as pv,
         |    count(distinct a.uuid) as uv
         |from
         |    dw.uba_scp a
         |where
         |a.his_time>= '${dateT}'
         |and a.his_time < '${dateTE}'
         |and a.scp like '14.sp.ad_269.0.%'
         |union all
         |select
         |    '四宫格-2' as djw,
         |    count(*) as pv,
         |    count(distinct a.uuid) as uv
         |from
         |    dw.uba_scp a
         |where a.his_time>= '${dateT}'
         |and a.his_time < '${dateTE}'
         |and a.scp like '14.sp.ad_269.1.%'
         |union all
         |select
         |     '四宫格-3' as djw,
         |    count(*) as pv,
         |    count(distinct a.uuid) as uv
         |from
         |    dw.uba_scp a
         |where
         |a.his_time>= '${dateT}'
         |and a.his_time < '${dateTE}'
         |and a.scp like '14.sp.ad_269.2.%'
         |union all
         |select
         |     '四宫格-4' as djw,
         |    count(*) as pv,
         |    count(distinct a.uuid) as uv
         |from
         |    dw.uba_scp a
         |where
         |a.his_time>= '${dateT}'
         |and a.his_time < '${dateTE}'
         |and a.scp like '14.sp.ad_269.3.%'
         |union all
         |select
         |     '四宫格总计' as djw,
         |    count(*) as pv,
         |    count(distinct a.uuid) as uv
         |from
         |    dw.uba_scp a
         |where
         |a.his_time>= '${dateT}'
         |and a.his_time < '${dateTE}'
         |and a.scp like '14.sp.ad_269.%'
         |union all
         |select
         |     '逛商场十宫格总计' as djw,
         |    count(*) as pv,
         |    count(distinct a.uuid) as uv
         |from
         |    dw.uba_scp a
         |where
         |a.his_time>= '${dateT}'
         |and a.his_time < '${dateTE}'
         |and a.scp like '14.sp.ad_371.%'
         |union all
         |select
         |     '逛全球十宫格总计' as djw,
         |    count(*) as pv,
         |    count(distinct a.uuid) as uv
         |from
         |    dw.uba_scp a
         |where
         |a.his_time>= '${dateT}'
         |and a.his_time < '${dateTE}'
         |and a.scp like '14.sp.ad_370.%'
         |union all
         |select
         |     '1+n活动大图-1' as djw,
         |    count(*) as pv,
         |    count(distinct a.uuid) as uv
         |from
         |    dw.uba_scp a
         |where
         |a.his_time>= '${dateT}'
         |and a.his_time < '${dateTE}'
         |and a.scp like '14.sp.ad_313.0.%'
         |union all
         |select
         |     '1+n活动小图1-1' as djw,
         |    count(*) as pv,
         |    count(distinct a.uuid) as uv
         |from
         |    dw.uba_scp a
         |where
         |a.his_time>= '${dateT}'
         |and a.his_time < '${dateTE}'
         |and a.scp like '14.sp.ad_313.1.%'
         |union all
         |select
         |     '1+n活动小图1-2' as djw,
         |    count(*) as pv,
         |    count(distinct a.uuid) as uv
         |from
         |    dw.uba_scp a
         |where
         |a.his_time>= '${dateT}'
         |and a.his_time < '${dateTE}'
         |and a.scp like '14.sp.ad_313.2.%'
         |union all
         |select
         |     '1+n活动小图1-3' as djw,
         |    count(*) as pv,
         |    count(distinct a.uuid) as uv
         |from
         |    dw.uba_scp a
         |where
         |a.his_time>= '${dateT}'
         |and a.his_time < '${dateTE}'
         |and a.scp like '14.sp.ad_313.3.%'
         |union all
         |select
         |     '1+n活动小图1-4' as djw,
         |    count(*) as pv,
         |    count(distinct a.uuid) as uv
         |from
         |    dw.uba_scp a
         |where
         |a.his_time>= '${dateT}'
         |and a.his_time < '${dateTE}'
         |and a.scp like '14.sp.ad_313.4.%'
         |union all
         |select
         |     '1+n活动-1总计' as djw,
         |    count(*) as pv,
         |    count(distinct a.uuid) as uv
         |from
         |    dw.uba_scp a
         |where
         |a.his_time>= '${dateT}'
         |and a.his_time < '${dateTE}'
         |and a.scp like '14.sp.ad_313.%'
         |union all
         |select
         |     '1+n活动大图-2' as djw,
         |    count(*) as pv,
         |    count(distinct a.uuid) as uv
         |from
         |    dw.uba_scp a
         |where
         |a.his_time>= '${dateT}'
         |and a.his_time < '${dateTE}'
         |and a.scp like '14.sp.ad_312.0.%'
         |union all
         |select
         |    '1+n活动小图2-1' as djw,
         |    count(*) as pv,
         |    count(distinct a.uuid) as uv
         |from
         |    dw.uba_scp a
         |where
         |a.his_time>= '${dateT}'
         |and a.his_time < '${dateTE}'
         |and a.scp like '14.sp.ad_312.1.%'
         |union all
         |select
         |     '1+n活动小图2-2' as djw,
         |    count(*) as pv,
         |    count(distinct a.uuid) as uv
         |from
         |    dw.uba_scp a
         |where
         |a.his_time>= '${dateT}'
         |and a.his_time < '${dateTE}'
         |and a.scp like '14.sp.ad_312.2.%'
         |union all
         |select
         |     '1+n活动小图2-3' as djw,
         |    count(*) as pv,
         |    count(distinct a.uuid) as uv
         |from
         |    dw.uba_scp a
         |where
         |a.his_time>= '${dateT}'
         |and a.his_time < '${dateTE}'
         |and a.scp like '14.sp.ad_312.3.%'
         |union all
         |select
         |    '1+n活动小图2-4' as djw,
         |    count(*) as pv,
         |    count(distinct a.uuid) as uv
         |from
         |    dw.uba_scp a
         |where
         |a.his_time>= '${dateT}'
         |and a.his_time < '${dateTE}'
         |and a.scp like '14.sp.ad_312.4.%'
         |union all
         |select
         |     '1+n活动-2总计' as djw,
         |    count(*) as pv,
         |    count(distinct a.uuid) as uv
         |from
         |    dw.uba_scp a
         |where
         |a.his_time>= '${dateT}'
         |and a.his_time < '${dateTE}'
         |and a.scp like '14.sp.ad_312.%'
         |union all
         |select
         |     '1+n商品大图总计' as djw,
         |    count(*) as pv,
         |    count(distinct a.uuid) as uv
         |from
         |    dw.uba_scp a
         |where
         |a.his_time>= '${dateT}'
         |and a.his_time < '${dateTE}'
         |and (a.scp like '02.sp.aapa.all.%' or a.scp like '14.sp.aapa.all.%')
         |union all
         |select
         |    '1+n商品小图总计' as djw,
         |    count(*) as pv,
         |    count(distinct a.uuid) as uv
         |from
         |    dw.uba_scp a
         |where
         |a.his_time>= '${dateT}'
         |and a.his_time < '${dateTE}'
         | and (a.scp like '14.sp.aapa.%'
         |    or a.scp like '02.sp.aapa.%')
         | and  a.scp not like '02.sp.aapa.all.%'
         | and  a.scp not like '14.sp.aapa.all.%'
         |union all
         |select
         |     '猜你喜欢旗舰店总计' as djw,
         |    count(*) as pv,
         |    count(distinct a.uuid) as uv
         |from
         |    dw.uba_scp a
         |where
         |a.his_time>= '${dateT}'
         |and a.his_time < '${dateTE}'
         |and a.scp like '14.sp.brand.%'
         |union all
         |select
         |     '猜你喜欢商品总计' as djw,
         |    count(*) as pv,
         |    count(distinct a.uuid) as uv
         |from
         |    dw.uba_scp a
         |where
         |a.his_time>= '${dateT}'
         |and a.his_time < '${dateTE}'
         |and  (a.scp like '02.sp.ylike.%'  or a.scp like '14.sp.ylike.%' )
         |union all
         |select
         |     '猜你喜欢总计' as djw,
         |    count(*) as pv,
         |    count(distinct a.uuid) as uv
         |from
         |    dw.uba_scp a
         |where
         |a.his_time>= '${dateT}'
         |and a.his_time < '${dateTE}'
         |and (a.scp like '02.sp.ylike.%' or a.scp like '14.sp.ylike.%'
         |     or a.scp like '14.sp.brand.%')
         |union all
         |select
         |    '逛商场' as djw,
         |    count(*) as pv,
         |    count(distinct a.uuid) as uv
         |from
         |    dw.uba_scp a
         |where
         |a.his_time>= '${dateT}'
         |and a.his_time < '${dateTE}'
         |and (a.scp like '02.sp.navH.%' or a.scp like '14.sp.navH.%')
         |union all
         |select
         |    '发现' as djw,
         |    count(*) as pv,
         |    count(distinct a.uuid) as uv
         |from
         |    dw.uba_scp a
         |where
         |a.his_time>= '${dateT}'
         |and a.his_time < '${dateTE}'
         |and (a.scp like '02.sp.navC.%' or a.scp like '14.sp.navC.%')
         |union all
         |select
         |     '海外购' as djw,
         |    count(*) as pv,
         |    count(distinct a.uuid) as uv
         |from
         |    dw.uba_scp a
         |where
         |a.his_time>= '${dateT}'
         |and a.his_time < '${dateTE}'
         |and (a.scp like '02.sp.navE.%' or a.scp like '14.sp.navE.%')
         |union all
         |select
         |     '我的' as djw,
         |    count(*) as pv,
         |    count(distinct a.uuid) as uv
         |from
         |    dw.uba_scp a
         |where
         |a.his_time>= '${dateT}'
         |and a.his_time < '${dateTE}'
         |and (a.scp like '02.sp.navM.%' or a.scp like '14.sp.navM.%')
         |union all
         |select
         |     '购物' as djw,
         |    count(*) as pv,
         |    count(distinct a.uuid) as uv
         |from
         |    dw.uba_scp a
         |where
         |a.his_time>= '${dateT}'
         |and a.his_time < '${dateTE}'
         |and (a.scp like '02.sp.navS.%' or a.scp like '14.sp.navS.%')
         |) de
         |where
         |isnull(djw) = false
         |union all
         |select
         |   '其它' as click,
         |    count(*) as pv,
         |    count(distinct a.uuid) as uv
         |from
         |(select a.scp,a.uuid
         | from   dw.uba_scp a
         |where
         |a.his_time>= '${dateT}'
         |and a.his_time < '${dateTE}'
         |and  (a.scp  like '14.sp.%' or a.scp  like '02.sp.%' )  ) a
         |where   a.scp not like '02.sp.uscode.%'
         |and a.scp not like '14.sp.uscode.%'
         |and a.scp not like '02.sp.search.%'
         |and a.scp not like '14.sp.search.%'
         |and a.scp not like '02.sp.mr.tscar.%'
         |and a.scp not like '14.sp.mr.tscar.%'
         |and a.scp not like '02.sp.noti.%'
         |and a.scp not like '14.sp.noti.%'
         |and a.scp not like '14.sp.popupPoster.%'
         |and a.scp not like '02.sp.popupPoster.%'
         |and a.scp not like '02.sp.slider.%'
         |and a.scp not like '14.sp.slider.%'
         |and a.scp not like '02.sp.adc.00.%'
         |and a.scp not like '14.sp.adc.00.%'
         |and a.scp not like '02.sp.fe.00.%'
         |and a.scp not like '14.sp.fe.0.%'
         |and a.scp not like '14.sp.fe.00.%'
         |and a.scp not like '02.sp.fe.1.%'
         |and a.scp not like '02.sp.fe.01.%'
         |and a.scp not like '14.sp.fe.1.%'
         |and a.scp not like '14.sp.fe.01.%'
         |and a.scp not like '02.sp.fe.2.%'
         |and a.scp not like '02.sp.fe.02.%'
         |and a.scp not like '14.sp.fe.2.%'
         |and a.scp not like '14.sp.fe.02.%'
         |and a.scp not like '02.sp.fe.3.%'
         |and a.scp not like '02.sp.fe.03.%'
         |and a.scp not like '14.sp.fe.3.%'
         |and a.scp not like '14.sp.fe.03.%'
         |and a.scp not like '02.sp.fe.4.%'
         |and a.scp not like '02.sp.fe.04.%'
         |and a.scp not like '14.sp.fe.4.%'
         |and a.scp not like '14.sp.fe.04.%'
         |and a.scp not like '14.sp.ad_244.%'
         |and a.scp not like '14.sp.kx.0.%'
         |and a.scp not like '02.sp.fsmr1.%'
         |and a.scp not like '14.sp.fsmr1.%'
         |and a.scp not like '02.sp.fspro1.%'
         |and a.scp not like '14.sp.fspro1.%'
         |and a.scp not like '14.sp.ad_353.%'
         |and a.scp not like '14.sp.ad_269.%'
         |and a.scp not like '14.sp.ad_371.%'
         |and a.scp not like '14.sp.ad_370.%'
         |and a.scp not like '14.sp.ad_313.%'
         |and a.scp not like '14.sp.ad_312.%'
         |and a.scp not like '02.sp.aapa.all.%'
         |and a.scp not like '14.sp.aapa.all.%'
         |and a.scp not like '14.sp.aapa.%'
         |and a.scp not like '02.sp.aapa.%'
         |and a.scp not like '14.sp.br.%'
         |and a.scp not like '02.sp.ylike.%'
         |and a.scp not like '14.sp.ylike.%'
         |and a.scp not like '14.sp.brand.%'
         |and a.scp not like '14.sp.br.%'
         |and a.scp not like '02.sp.navH.%'
         |and a.scp not like '14.sp.navH.%'
         |and a.scp not like '02.sp.navC.%'
         |and a.scp not like '14.sp.navC.%'
         |and a.scp not like '02.sp.navE.%'
         |and a.scp not like '14.sp.navE.%'
         |and a.scp not like '02.sp.navM.%'
         |and a.scp not like '14.sp.navM.%'
         |and a.scp not like '02.sp.navS.%'
         |and a.scp not like '14.sp.navS.%'
      """.stripMargin)


    return click

  }

}