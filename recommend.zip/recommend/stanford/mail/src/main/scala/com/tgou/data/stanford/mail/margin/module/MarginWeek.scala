package com.tgou.data.stanford.mail.margin.module

import org.apache.spark.sql.{DataFrame, SparkSession}
import org.joda.time.LocalDate


/**
  * Created by 李磊 on 2017/11/16.
  * 每周天狗财务统计
  */
object MarginWeek {

  /**
    * 字段：
    * - id	                 主键
    * - supplier_name	       供应商名称
    * - create_time	         日期
    * - settle_amount	       结算金额
    * - real_sale	           实销金额
    * - net_sale	           净销金额
    * - discount	           活动优惠
    * - coupon	             用券金额
    * - real_margin_amount	 毛利额（实销）
    * - real_margin_rate	   毛利率（实销）
    * - net_margin_amount	   毛利额（净销）
    * - net_margin_rate	     毛利率（净销）
    * */
  def getTansDF(spark:SparkSession, date: LocalDate): DataFrame = {

    val marginWeeklyReport = spark.read.format("csv")
      .option("delimiter", "^")
      .option("qoute", "")
      .option("nullValue", "\\N")
     .load(s"hdfs://nameservice1/tiangou/tgouorder/margin_weekly_report/${date.toString("yyyy/MM/dd")}/*")
      //.load(s"hdfs://nameservice1/tiangou/tgouorder/margin_weekly_report/2017/11/20/*")

    val marginWeeklyReportS = marginWeeklyReport
      .select("_c0",
        "_c1",
        "_c2",
        "_c3",
        "_c4",
        "_c5",
        "_c6",
        "_c7",
        "_c8",
        "_c9",
        "_c10",
        "_c11")
      .toDF("id",
        "supplier_name",
        "create_time",
        "settle_amount",
        "real_sale",
        "net_sale",
        "discount",
        "coupon",
        "real_margin_amount",
        "real_margin_rate",
        "net_margin_amount",
        "net_margin_rate")

    marginWeeklyReportS.createOrReplaceTempView("margin_weekly_report_lilei")


    /*
        * 每天天狗财务
        * */
    val marginweekly = spark.sql(
      s"""
         |select id,
         |supplier_name,
         |create_time,
         |settle_amount,
         |real_sale,
         |net_sale,
         |discount,
         |coupon,
         |real_margin_amount,
         |real_margin_rate,
         |net_margin_amount,
         |net_margin_rate
         |from margin_weekly_report_lilei
      """.stripMargin)


    return marginweekly

  }
}

