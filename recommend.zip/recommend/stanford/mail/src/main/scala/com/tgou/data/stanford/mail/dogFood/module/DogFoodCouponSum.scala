package com.tgou.data.stanford.mail.dogFood.module

import org.apache.spark.sql.{DataFrame, SparkSession}
import org.joda.time.LocalDate

/**
  * Created by 张少锐 on 2018/01/19.
  * 狗粮换券明细数据
  */
object DogFoodCouponSum {
  def getDogFoodCouponSum(spark: SparkSession, date: LocalDate): DataFrame = {
    val yesterday = date.toString("yyyy-MM-dd")

    // 获取券信息表coupon_information
    spark.sql(
      s"""
         |select id,coupon_id,type,name,pay_type,pay_amount,fk_activity_id
         |from dw.coupon c
         |where c.his_time = '$yesterday'
       """.stripMargin).createOrReplaceTempView("coupon_information")

    // 获取劵核销信息表coupon_code
    spark.sql(
      s"""
         |select id,coupon_code_id,coupon_code,member_id,create_time,use_time,use_tag,fk_activity_id,fk_coupon_id
         |from dw.coupon_code cc
         |where cc.his_time = '$yesterday'
       """.stripMargin).createOrReplaceTempView("coupon_code")

    /*
      *  - coupon_name 名称
      *  - coupon_type 类型
      *  - coupon_count 领取次数
      *  - coupon_member 领取人数
      * */
    val couponDF = spark.sql(
      s"""
         |select
         |    ci.name,
         |    ci.type,
         |    count(cc.coupon_code_id) as coupon_count,
         |    count(distinct cc.member_id) as coupon_member
         |from coupon_information ci
         |join coupon_code cc
         |on ci.coupon_id = cc.fk_coupon_id
         |where ci.pay_type = '3'
         |and ci.type in('1','2','3')
         |and to_date(cc.create_time) = '${yesterday}'
         |group by ci.name,ci.type
       """.stripMargin)

    /*
      *  - ship_count 核销次数
      *  - ship_member 核销人数
      * */
    val shipDF = spark.sql(
      s"""
         |select
         |    ci.name,
         |    ci.type,
         |    count(cc.coupon_code_id) as ship_count,
         |    count(distinct cc.member_id) as ship_member
         |from coupon_information ci
         |join coupon_code cc
         |on ci.coupon_id = cc.fk_coupon_id
         |where ci.pay_type = '3'
         |and ci.type in('1','2','3')
         |and to_date(cc.use_time) = '${yesterday}'
         |and cc.use_tag = '2'
         |group by ci.name,ci.type
       """.stripMargin)

    spark.udf.register("getTypeName", (i:String)=>{if(i.equals("1")){"现金券"}else if(i.equals("2")){"折扣券"}else if(i.equals("3")){"满减券"}else{null}})
    val fields = Map("coupon_count"->0,"coupon_member"->0,"ship_count"->0,"ship_member"->0)

    couponDF.join(shipDF,Seq("name","type"),"full")
      .selectExpr(
        "name as coupon_name",
        "getTypeName(type) as coupon_type",
        "coupon_count",
        "coupon_member",
        "ship_count",
        "ship_member"
      ).na.fill(fields)
  }
}
