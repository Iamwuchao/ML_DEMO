package com.tgou.data.stanford.mail.core

import org.apache.spark.sql.Column
import org.apache.spark.sql.types.{StringType, StructField, StructType}

import scala.collection.mutable.ArrayBuffer

/**
  * Created by zhangshaorui on 2017/09/28.
  */
abstract class BaseBean {

  def list: List[(Any,String)]

  def columns: Seq[Column]  = {
    list.map(t2 => new Column("_c"+t2._1))
  }

  def title: Array[String] = {
    list.map(t2 => t2._2).toArray
  }

  def structType: StructType = {
    val buffer: ArrayBuffer[StructField] = ArrayBuffer()
    list.foreach(t2 => buffer += StructField(t2._2, StringType, nullable = true))
    StructType(buffer)
  }
}
