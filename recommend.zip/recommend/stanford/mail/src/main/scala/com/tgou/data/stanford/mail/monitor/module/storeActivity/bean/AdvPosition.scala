package com.tgou.data.stanford.mail.monitor.module.storeActivity.bean

import com.tgou.data.stanford.mail.core.BaseBean

object AdvPosition extends BaseBean {

  override def list: List[(Any,String)] = {

    List(
      (0, "id"),
      (6, "state"),
      (7, "start_time"),
      (8, "end_time"),
      (14, "fk_adv_module_id"),
      (15, "standard_sort")
    )

  }

}
