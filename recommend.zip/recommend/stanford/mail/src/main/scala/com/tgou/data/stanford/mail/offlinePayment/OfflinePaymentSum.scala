package com.tgou.data.stanford.mail.offlinePayment

import org.apache.spark.sql.{DataFrame, SparkSession}
import org.joda.time.LocalDate

/**
  * Created by 张少锐 on 2017/12/27.
  * 线下支付宝及微信邮件报表周报
  */

object OfflinePaymentSum {

  def getOfflinePaymentSum(spark: SparkSession, date: LocalDate): DataFrame = {

    val yesterday = date.toString("yyyy-MM-dd")
    val yesterdayPlus1 = date.plusDays(1).toString("yyyy-MM-dd")
    val yesterdayMinus7 = date.minusDays(6).toString("yyyy-MM-dd")


    //统计的时间范围是
    System.out.println("统计的时间范围是(左闭右开)：" + yesterdayMinus7 + "至" + yesterdayPlus1)

    /*
      * 加载数据源
      * */
    spark.sql(
      s"""
         |select
         |     s.id,
         |     s.store_code,
         |     s.store_name,
         |     s.city_id
         |from dw.store s
         |where
         |    s.his_time = '$yesterday'
         |and s.state = 'onshelf'
       """.stripMargin).createOrReplaceTempView("store")

    spark.sql(
      s"""
         |select
         |     pf.fkfsh,
         |     pf.jysbm,
         |     pf.storecode
         |from dw.pos_fk pf
         |where pf.his_time >= '$yesterdayMinus7'
         |and pf.his_time < '$yesterdayPlus1'
       """.stripMargin).createOrReplaceTempView("pos_fk")

    spark.sql(
      s"""
         |select
         |     pz.jyje,
         |     pz.jysbm,
         |     pz.storecode
         |from dw.pos_zz pz
         |where pz.his_time >= '$yesterdayMinus7'
         |and pz.his_time < '$yesterdayPlus1'
         |and pz.jyje > 0
       """.stripMargin).createOrReplaceTempView("pos_zz")

    /**
      * 线下支付宝及微信
      *
      * 字段:
      *  - store_name 店铺名称
      *  - store_code 店铺编码
      *  - je_wx 线下微信交易金额
      *  - je_zfb 线下支付宝交易金额
      *  - je_new_zfb 线下新支付宝交易金额
      *  - je_z 店铺总交易金额
      *  - je_wx_rate 线下微信交易金额占比
      *  - je_zfb_rate 线下支付宝交易金额占比
      **/

    // je_z 店铺总交易金额
    val storeDF = spark.sql(
      s"""
         |select
         |    s.store_name,
         |    s.store_code,
         |    nvl(cast(sum(pz.jyje) as decimal(18,2)),0) as je_z
         |from pos_zz pz
         |join store s
         |on s.store_code = pz.storecode
         |group by s.store_name,s.store_code
       """.stripMargin)

    // je_wx 线下微信交易金额
    val wechatDF = spark.sql(
      s"""
         |select
         |    t.store_name as store_name,
         |    t.storecode as store_code,
         |    nvl(cast(sum(t.jyje) as decimal(18,2)),0) as je_wx
         |from(
         |    select
         |        s.store_name,
         |        pz.storecode,
         |        pz.jysbm,
         |        max(pz.jyje) jyje
         |    from pos_fk pf
         |    join store s
         |    on s.store_code = pf.storecode
         |    join pos_zz pz
         |    on pf.jysbm = pz.jysbm
         |    where pf.fkfsh = '84'
         |    group by s.store_name,pz.storecode,pz.jysbm
         |) t
         |group by t.store_name,t.storecode
       """.stripMargin)

    // je_zfb 线下支付宝交易金额
    val alipayDF = spark.sql(
      s"""
         |select
         |    t.store_name as store_name,
         |    t.storecode as store_code,
         |    nvl(cast(sum(t.jyje) as decimal(18,2)),0) as je_zfb
         |from(
         |    select
         |        s.store_name,
         |        pz.storecode,
         |        pz.jysbm,
         |        max(pz.jyje) jyje
         |    from pos_fk pf
         |    join store s
         |    on s.store_code = pf.storecode
         |    join pos_zz pz
         |    on pf.jysbm = pz.jysbm
         |    where pf.fkfsh = '82'
         |    group by s.store_name,pz.storecode,pz.jysbm
         |) t
         |group by t.store_name,t.storecode
       """.stripMargin)

    // je_new_zfb 线下新支付宝交易金额
    val dlAlipayDF = spark.sql(
      s"""
         |select
         |    t.store_name as store_name,
         |    t.storecode as store_code,
         |    nvl(cast(sum(t.jyje) as decimal(18,2)),0) as je_new_zfb
         |from(
         |    select
         |        s.store_name,
         |        pz.storecode,
         |        pz.jysbm,
         |        max(pz.jyje) jyje
         |    from pos_fk pf
         |    join store s
         |    on s.store_code = pf.storecode
         |    join pos_zz pz
         |    on pf.jysbm = pz.jysbm
         |    where pf.fkfsh = '93'
         |    group by s.store_name,pz.storecode,pz.jysbm
         |) t
         |group by t.store_name,t.storecode
       """.stripMargin)

    // 将空值进行填充
    val fields = Map("je_wx"->0,"je_zfb"->0,"je_new_zfb"->0,"je_z"->0)

    storeDF.join(wechatDF,Seq("store_name","store_code"),"full").
      join(alipayDF,Seq("store_name","store_code"),"full").
      join(dlAlipayDF,Seq("store_name","store_code"),"full").
      select(
        "store_name",
        "store_code",
        "je_wx",
        "je_zfb",
        "je_new_zfb",
        "je_z"
      ).na.fill(fields).createOrReplaceTempView("total")


    spark.sql(
      s"""
         |select
         |    store_name,
         |    store_code,
         |    je_wx,
         |    je_zfb,
         |    je_new_zfb,
         |    je_z,
         |    case when je_z = 0 then 0 else round(je_wx / je_z * 100, 2) end as je_wx_rate,
         |    case when je_z = 0 then 0 else round((je_zfb + je_new_zfb) / je_z * 100, 2) end as je_zfb_rate
         |from total
       """.stripMargin)

  }

}
