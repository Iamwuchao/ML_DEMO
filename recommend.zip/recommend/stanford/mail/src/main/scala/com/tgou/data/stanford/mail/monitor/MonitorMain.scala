package com.tgou.data.stanford.mail.monitor

import com.tgou.data.stanford.mail.core.MailBootstrap
import com.tgou.data.stanford.mail.monitor.module.discover.DiscoverModule
import com.tgou.data.stanford.mail.monitor.module.eleticket.EleTicketModule
import com.tgou.data.stanford.mail.monitor.module.goodsOrder.GoodsOrderModule
import com.tgou.data.stanford.mail.monitor.module.listing.ListingModule
import com.tgou.data.stanford.mail.monitor.module.member.MemberModule
import com.tgou.data.stanford.mail.monitor.module.storeActivity.StoreActivityModule
import com.tgou.data.stanford.mail.monitor.module.supermarketOrder.SupermarketOrderModule
import com.tgou.data.stanford.mail.monitor.module.traffic.TrafficModule
import com.tgou.data.stanford.mail.monitor.module.trans.TransModule
import org.apache.spark.sql.{SaveMode, SparkSession}
import org.joda.time.LocalDate
import com.tgou.data.stanford.mail.monitor.module.crossBorder.CrossBorderModule
/**
  * Created by 李震 on 2017/9/26.
  * 每日监控
  */
object MonitorMain {


  def main(args: Array[String]): Unit = {
    MailBootstrap(args).bootstrap(execute)
  }
  def execute(spark: SparkSession, appName: String, date: LocalDate): Unit = {

    /**
      * 第一步 获取数据
      * */
    //天狗交易额指标达成进度,天狗交易额统计,天狗跨境购
    val tans = TransModule.getTansDF(spark,date)
    //天狗跨境交易-国外
    val international=CrossBorderModule.getInternationalDF(spark,date)
    //天狗跨境交易-国内
    val domestic=CrossBorderModule.getDomesticDF(spark,date)
    //天狗电子小票核销
    val eleTicket = EleTicketModule.getEleTicketDF(spark,date)
    //天狗百货订单
    val goodsOrder = GoodsOrderModule.getGoodsOrder(spark,date)
    //天狗超市订单
    val supermarketOrder = SupermarketOrderModule.getSupermarketOrder(spark,date)
    //发现频道统计
    val discover = DiscoverModule.getDiscoverDF(spark,date)
    //单品二维码统计
    val listing = ListingModule.getListingDF(spark,date)
    //天狗平台流量统计
    val traffic = TrafficModule.getTrafficDF(spark,date)
    //会员相关统计
    val member = MemberModule.getMemberDF(spark,date)
    //店铺活动统计
    val storeActivity = StoreActivityModule.getStoreActivity(spark,date)

    /**
      * 第二步 拼接数据
      * */
    val result = tans
      .crossJoin(international)
      .crossJoin(domestic)
      .crossJoin(eleTicket)
      .crossJoin(goodsOrder)
      .crossJoin(supermarketOrder)
      .crossJoin(discover)
      .crossJoin(listing)
      .crossJoin(traffic)
      .crossJoin(member)
      .crossJoin(storeActivity)

    /**
      * 第三步 保存数据到HDFS上
      * */
    result.write.mode(SaveMode.Overwrite).json(s"/data/mail/monitor/$date/")
    spark.stop()
  }

}
