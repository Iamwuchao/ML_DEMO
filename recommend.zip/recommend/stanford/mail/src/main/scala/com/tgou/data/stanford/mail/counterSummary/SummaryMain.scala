package com.tgou.data.stanford.mail.counterSummary

import com.tgou.data.stanford.mail.core.MailBootstrap
import org.apache.spark.sql.{SaveMode, SparkSession}
import org.joda.time.LocalDate

/**
  * Created by 刘洋 on 2018/02/27.
  * #30823: 定时邮件：柜组在售款数统计-迁移到新邮件系统
  */

object SummaryMain {


  def main(args: Array[String]): Unit = {
    MailBootstrap(args).bootstrap(execute)
  }

  def execute(spark: SparkSession, appName: String, date: LocalDate): Unit = {

    /**
      * 第一步 获取数据
      * */
    val result = SummaryModule.queryDF(spark,date)
    /**
      * 第二步 保存数据到HDFS上
      * */
    result.coalesce(1).write.mode(SaveMode.Overwrite).json(s"/data/mail/counter_summary/$date/")

    spark.stop()
  }
}