package  com.tgou.data.stanford.mail.returngoods

import com.tgou.data.stanford.mail.core.MailBootstrap
import org.apache.spark.sql.{SaveMode, SparkSession}
import org.joda.time.LocalDate


/**
* Created by 李磊 on 2017/11/16.
* 每日退货
*/

object ReturnGoodsMain {

  def main(args: Array[String]): Unit = {
    MailBootstrap(args).bootstrap(execute)
  }

  def execute(spark: SparkSession, appName: String, date: LocalDate): Unit = {

    /**
      * 第一步 获取数据
      * */

    val result = ReturnGoodsModule.getTansDF(spark, date)

    /**
      * 第二步 保存数据到HDFS上
      * */
    result.coalesce(1).write.mode(SaveMode.Overwrite).json(s"/data/mail/returnGoods/$date/")
    spark.stop()

  }
}
