package com.tgou.data.stanford.mail.tiangouPaymnet.module

import org.apache.spark.sql.{DataFrame, SparkSession, functions}
import org.joda.time.LocalDate

/**
* Created by 李磊 on 2017/11/16.
* 天狗支付物流
*/

object TiangouPaymentLogistics {
  /**
    * 字段：
    * - ddqh_xdbs  到店取货下单笔数
    * - ddqh_zfcgbs 到店取货支付成功笔数
    * - bddqh_zfcgl 到店取货支付成功率
    * - ddqh_xdje 到店取货下单金额
    * - ddqh_xdkdj 到店取货下单客单价
    * - ddqh_zfcgje 到店取货支付成功金额
    * - ddqh_zfcgkdj 到店取货支付成功客单价
    * - shsm_xdbs  送货上门下单笔数
    * - shsm_zfcgbs 送货上门支付成功笔数
    * - shsm_zfcgl 送货上门支付成功率
    * - shsm_xdje 送货上门下单金额
    * - shsm_xdkdj 送货上门下单客单价
    * - shsm_zfcgje 送货上门支付成功金额
    * - shsm_zfcgkdj 送货上门支付成功客单价
    * */
  def getTansDF(spark:SparkSession, date: LocalDate): DataFrame = {



    /*
       * 到店取货
       * */
    val diaodianzhiti = spark.sql(
      s"""
         |select
         |count(distinct order_id) ddqh_xdbs ,
         |count(distinct case when t.pay_time >= concat('${date.toString("yyyy-MM-dd")}', ' 00:00:00')
         |and t.pay_time < concat(date_format(date_sub('${date.toString("yyyy-MM-dd")}', -1), 'yyyy-MM-dd'),' 00:00:00')
         |and isnull(cancel_time)
         |and pay_method != '010'
         |then order_id end ) ddqh_zfcgbs,
         |nvl(cast((count(distinct case when t.pay_time >= concat('${date.toString("yyyy-MM-dd")}', ' 00:00:00')
         |and t.pay_time < concat(date_format(date_sub('${date.toString("yyyy-MM-dd")}', -1), 'yyyy-MM-dd'),' 00:00:00')
         |and isnull(cancel_time)
         |and pay_method != '010'
         |then order_id end ) / count(distinct order_id) * 100) as decimal(18,2)),0)   as bddqh_zfcgl,
         | nvl(cast(sum( total_amount) as decimal(18,2)),0) ddqh_xdje ,
         |  avg( total_amount) ddqh_xdkdj ,
         |nvl(cast(sum( case when t.pay_time >= concat('${date.toString("yyyy-MM-dd")}', ' 00:00:00')
         |and t.pay_time < concat(date_format(date_sub('${date.toString("yyyy-MM-dd")}', -1), 'yyyy-MM-dd'),' 00:00:00')
         |and isnull(cancel_time)
         |and pay_method != '010'
         |then total_amount end ) as decimal(18,2)),0) ddqh_zfcgje,
         |avg( case when t.pay_time >= concat('${date.toString("yyyy-MM-dd")}', ' 00:00:00')
         |and t.pay_time < concat(date_format(date_sub('${date.toString("yyyy-MM-dd")}', -1), 'yyyy-MM-dd'),' 00:00:00')
         |and isnull(cancel_time)
         |and pay_method != '010'
         |then total_amount end ) ddqh_zfcgkdj
         |from dw.order_information t
         |where t.his_time = '${date.toString("yyyy-MM-dd")}'
         |and t.create_time >= concat('${date.toString("yyyy-MM-dd")}', ' 00:00:00')
         |and t.create_time < concat(date_format(date_sub('${date.toString("yyyy-MM-dd")}', -1), 'yyyy-MM-dd'),' 00:00:00')
         |and t.order_type = 0
         |and t.receive_method != '10'
         |and t.receive_method != '99'
         |and pay_method != '000'
      """.stripMargin)

    /*
            * 送货上门
            * */
    val songhuoshangmen = spark.sql(
      s"""
         |select
         |count(distinct order_id) shsm_xdbs ,
         |count(distinct case when t.pay_time >= concat('${date.toString("yyyy-MM-dd")}', ' 00:00:00')
         |and t.pay_time < concat(date_format(date_sub('${date.toString("yyyy-MM-dd")}', -1), 'yyyy-MM-dd'),' 00:00:00')
         |and isnull(cancel_time)
         |and pay_method != '010'
         |then order_id end ) shsm_zfcgbs,
         |nvl(cast((count(distinct case when t.pay_time >= concat('${date.toString("yyyy-MM-dd")}', ' 00:00:00')
         |and t.pay_time < concat(date_format(date_sub('${date.toString("yyyy-MM-dd")}', -1), 'yyyy-MM-dd'),' 00:00:00')
         |and isnull(cancel_time)
         |and pay_method != '010'
         |then order_id end ) / count(distinct order_id) * 100) as decimal(18,2)),0)   as shsm_zfcgl,
         | nvl(cast(sum( total_amount) as decimal(18,2)),0) shsm_xdje ,
         |  avg( total_amount) shsm_xdkdj ,
         |nvl(cast(sum( case when t.pay_time >= concat('${date.toString("yyyy-MM-dd")}', ' 00:00:00')
         |and t.pay_time < concat(date_format(date_sub('${date.toString("yyyy-MM-dd")}', -1), 'yyyy-MM-dd'),' 00:00:00')
         |and isnull(cancel_time)
         |and pay_method != '010'
         |then total_amount end ) as decimal(18,2)),0) shsm_zfcgje,
         |avg( case when t.pay_time >= concat('${date.toString("yyyy-MM-dd")}', ' 00:00:00')
         |and t.pay_time < concat(date_format(date_sub('${date.toString("yyyy-MM-dd")}', -1), 'yyyy-MM-dd'),' 00:00:00')
         |and isnull(cancel_time)
         |and pay_method != '010'
         |then total_amount end ) shsm_zfcgkdj
         |from dw.order_information t
         |where t.his_time = '${date.toString("yyyy-MM-dd")}'
         |and t.create_time >= concat('${date.toString("yyyy-MM-dd")}', ' 00:00:00')
         |and t.create_time < concat(date_format(date_sub('${date.toString("yyyy-MM-dd")}', -1), 'yyyy-MM-dd'),' 00:00:00')
         |and t.order_type = 0
         |and t.receive_method = '10'
         |and pay_method != '000'
      """.stripMargin)

    val rs = diaodianzhiti.crossJoin(songhuoshangmen)
      .select(
        "ddqh_xdbs",
        "ddqh_zfcgbs",
        "bddqh_zfcgl",
        "ddqh_xdje",
        "ddqh_xdkdj",
        "ddqh_zfcgje",
        "ddqh_zfcgkdj",
        "shsm_xdbs",
        "shsm_zfcgbs",
        "shsm_zfcgl",
        "shsm_xdje",
        "shsm_xdkdj",
        "shsm_zfcgje",
        "shsm_zfcgkdj"
      )

    return rs
  }

}