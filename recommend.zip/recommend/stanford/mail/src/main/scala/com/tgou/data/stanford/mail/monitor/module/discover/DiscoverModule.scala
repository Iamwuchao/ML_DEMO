package com.tgou.data.stanford.mail.monitor.module.discover

import scala.collection.JavaConverters._
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.joda.time.{LocalDate, LocalTime}

/**
  * Created by 李震 on 2017/9/26.
  */
object DiscoverModule {

  private val DISCOVER_A_B = Seq(
    "01.like", // 点赞的人
    "01.nat", // 活动日历
    "01.hisfind", // 别人的发现
    "01.place", // 发现详情
    "01.fx", // 发现频道首页
    "01.myfind", // 我的发现
    "01.pfind" // 发布发现
  )

  private val BACKFLOW_JR_REGEXP = Seq(
    "sr\\.cfs\\.fd.*", // 朋友圈快照
    "sr\\.cf\\.fd.*" // 朋友圈
  )

  private val SHARE_SCP_REGEXP = Seq(
    "01\\.pfind\\.pyp.*", // 发布并分享
    "01\\.place\\.fsnapshot.*", // 朋友圈快照
    "01\\.place\\.wsnapshot.*", // 微信快照
    "01\\.place\\.fcircle.*", // 朋友圈
    "01\\.place\\.wechat.*" // 微信
  )

  /**
    * 发现频道统计
    *
    * @param spark
    * @param date
    *
    * @return
    *
    * 字段：
    *
    * - discover_pv  发现频道 PV
    * - discover_uv  发现频道 UV
    * - publish_content_count  发布内容数
    * - share_times  分享次数
    * - backflow_pv  回流次数
    * - backflow_uv  回流人数
    *
    * */
  def getDiscoverDF(spark: SparkSession, date: LocalDate): DataFrame = {

    /*
     * 加载数据源
     * */
    val source = DiscoverSource(spark)
    source.getAppendUbaPageDWDF(date).createTempView("discover_uba_page")
    source.getAppendSCPDWDF(date).createTempView("discover_uba_scp")
    source.getAppendDiscoverDWDF(date).createTempView("discover_discover")

    /*
     * discover_pv  发现频道 PV
     * discover_uv  发现频道 UV
     * */
    val discoverUBADF = spark.sql(
      s"""
         |select
         |  count(1) AS discover_pv,
         |  count(distinct up.uuid) AS discover_uv
         |from discover_uba_page up
         |where up.a_b IN (
         |    ${String.join(",", DISCOVER_A_B.map(i => s"'${i}'").asJava)}
         |)
      """.stripMargin)

    /*
     * publish_content_count  发布内容数
     * */
    val discoverPublishDF = spark.sql(
      s"""
        |select
        |    count(distinct d.discover_id) as publish_content_count
        |from discover_discover d
        |where d.create_time >= '${date.toDateTime(new LocalTime(0, 0, 0, 0)).toString("yyyy-MM-dd HH:mm:ss")}'
        |and d.create_time < '${date.plusDays(1).toDateTime(new LocalTime(0, 0, 0, 0)).toString("yyyy-MM-dd HH:mm:ss")}'
      """.stripMargin)

    /*
     * share_times  分享次数
     * */
    var shareUBADF = spark.sql(
      s"""
         |select
         |  count(1) as share_times
         |from discover_uba_scp s
         |where (
         |  ${String.join(" or ", SHARE_SCP_REGEXP.map(regexp => s"lower(s.scp) regexp '${regexp}'").asJava)}
         |)
      """.stripMargin)

    /*
     * backflow_pv  回流次数
     * backflow_uv  回流人数
     * */
    val backflowUBADF = spark.sql(
      s"""
         |select
         |  count(1) AS backflow_pv,
         |  count(distinct up.uuid) AS backflow_uv
         |from discover_uba_page up
         |where (
         |  ${String.join(" or ", BACKFLOW_JR_REGEXP.map(regexp => s"lower(up.jr) regexp '${regexp}'").asJava)}
         |)
         |and a_b = '01.place'
      """.stripMargin)


    discoverUBADF.crossJoin(discoverPublishDF)
      .crossJoin(shareUBADF)
      .crossJoin(backflowUBADF)
      .select(
        "discover_pv",
        "discover_uv",
        "publish_content_count",
        "share_times",
        "backflow_pv",
        "backflow_uv"
      )
  }

}
