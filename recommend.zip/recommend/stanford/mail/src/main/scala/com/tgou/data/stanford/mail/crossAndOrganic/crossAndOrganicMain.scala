package com.tgou.data.stanford.mail.crossAndOrganic

import com.tgou.data.stanford.mail.core.MailBootstrap
import org.apache.spark.sql.{SaveMode, SparkSession}
import org.joda.time.LocalDate

/**
  * Created by 张少锐 on 2018/03/01.
  * 跨境&有机现货率日报
  */

object crossAndOrganicMain {
  def main(args: Array[String]): Unit = {
    MailBootstrap(args).bootstrap(execute)
  }

  def execute(spark: SparkSession, appName: String, date: LocalDate): Unit = {
    /**
      * 第一步 获取数据
      * */
    val result = crossAndOrganicSum(spark,date)

    /**
      * 第二步 保存数据到HDFS上
      * */
    result.getCrossProductSum().coalesce(1).write.mode(SaveMode.Overwrite).json(s"/data/mail/cross_organic/cross_product/$date/")
    result.getCrossCategorySum().coalesce(1).write.mode(SaveMode.Overwrite).json(s"/data/mail/cross_organic/cross_category/$date/")
    result.getCrossStoreSum().coalesce(1).write.mode(SaveMode.Overwrite).json(s"/data/mail/cross_organic/cross_store/$date/")

  }
}
