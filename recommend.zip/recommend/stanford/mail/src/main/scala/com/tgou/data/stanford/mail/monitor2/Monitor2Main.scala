package com.tgou.data.stanford.mail.monitor2

import com.tgou.data.stanford.mail.core.MailBootstrap
import com.tgou.data.stanford.mail.monitor2.module.customerService.CustomerServiceModule
import com.tgou.data.stanford.mail.monitor2.module.listing.SingleGoodsModule
import com.tgou.data.stanford.mail.monitor2.module.member.MemberModule
import com.tgou.data.stanford.mail.monitor2.module.tgOrder.TGOrderModule
import com.tgou.data.stanford.mail.monitor2.module.tiangouTotalSales.TiangouTotalSalesModule
import com.tgou.data.stanford.mail.monitor2.module.traffic.TrafficModule
import org.apache.spark.sql.{SaveMode, SparkSession}
import org.joda.time.LocalDate

/**
  * Created by 李震 on 2017/12/4.
  */
object Monitor2Main {

  def main(args: Array[String]): Unit = {
    MailBootstrap(args).bootstrap(execute)
  }

  def execute(spark: SparkSession, appName: String, date: LocalDate): Unit = {

    /**
      * 第一步 获取数据
      * */
    //天狗总销
    val tgTotalSales = TiangouTotalSalesModule.getTansDF(spark,date)
    //天狗订单交易额组成
    val tgOrder = TGOrderModule.getTGOrder(spark,date)
    //售后概况
    val customerService = CustomerServiceModule.getTansDF(spark,date)
    //流量概览
    val traffic = TrafficModule.getTrafficDF(spark,date)
    //会员概况
    val member = MemberModule.getMemberDF(spark,date)
    //单品概况
    val listing = SingleGoodsModule.getSingleDF(spark,date)

    /**
      * 第二步 拼接数据
      * */
    val result = tgTotalSales.
      crossJoin(tgOrder).
      crossJoin(customerService).
      crossJoin(traffic).
      crossJoin(member).
      crossJoin(listing)


    /**
      * 第三步 保存数据到HDFS上
      * */
    result.write.mode(SaveMode.Overwrite).json(s"/data/mail/monitor2/$date/")
    spark.stop()

  }

}
