package com.tgou.data.stanford.mail.monitor2.module.customerService

import com.tgou.data.stanford.mail.core.MailBootstrap
import org.apache.spark.sql.SparkSession
import org.joda.time.LocalDate


object CustomerServiceModuleMain {
  def main(args: Array[String]): Unit = {
    MailBootstrap(args).bootstrap(execute)
  }

  def execute(spark: SparkSession, appName: String, date: LocalDate): Unit = {
    CustomerServiceModule.getTansDF(spark, date).show()
  }
}