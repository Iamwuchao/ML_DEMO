package com.tgou.data.stanford.mail.monitor2.module.member

import com.tgou.data.stanford.mail.core.MailBootstrap
import org.apache.spark.sql.SparkSession
import org.joda.time.LocalDate

/**
  * Created by 李震 on 2017/12/5.
  */
object MemberApplication {

  def main(args: Array[String]): Unit = {
    MailBootstrap.apply(args).bootstrap(execute)
  }

  def execute(spark: SparkSession, appName: String, date: LocalDate): Unit = {
    MemberModule.getMemberDF(spark, date).show()
  }

}
