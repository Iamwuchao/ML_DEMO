package com.tgou.data.stanford.mail.userBeAnalysis

import com.tgou.data.stanford.mail.core.MailBootstrap
import org.apache.spark.sql.{SaveMode, SparkSession}
import org.joda.time.LocalDate

/**
  * Created by 刘洋 on 2018/04/19.
  */

object userMain {


  def main(args: Array[String]): Unit = {
    MailBootstrap(args).bootstrap(execute)
  }

  def execute(spark: SparkSession, appName: String, date: LocalDate): Unit = {

    /**
      * 第一步 获取数据
      * */
    val result1 = userModule.query_1(spark,date)
    val result2 = userModule.query_2(spark,date)
    val result3 = userModule.query_3(spark,date)
    /**
      * 第二步 保存数据到HDFS上
      * */
    result1.coalesce(1).write.mode(SaveMode.Overwrite).json(s"/data/mail/user_analysis/query_1/$date/")
    result2.coalesce(1).write.mode(SaveMode.Overwrite).json(s"/data/mail/user_analysis/query_2/$date/")
    result3.coalesce(1).write.mode(SaveMode.Overwrite).json(s"/data/mail/user_analysis/query_3/$date/")
    spark.stop()
  }
}