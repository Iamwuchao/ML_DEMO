package com.tgou.data.stanford.mail.tiangouBrand.module

import org.apache.spark.sql.{DataFrame, SparkSession}
import org.joda.time.LocalDate

/**
  * Created by 张少锐 on 2017/12/18.
  * 百货品牌订单明细表
  */

object TiangouBrandDetailSum {

  def getTiangouBrandDetailSum(spark: SparkSession, appName: String, date: LocalDate): DataFrame = {

    val yesterday = date.toString("yyyy-MM-dd")
    var yesterdayPlus1: String = null
    var yesterdayMinus7: String = null

    if (appName.equals("weekcount")) {
      //周统计
      yesterdayMinus7 = date.minusDays(6).toString("yyyy-MM-dd")
      yesterdayPlus1 = date.plusDays(1).toString("yyyy-MM-dd")

    } else if (appName.equals("monthcount")) {
      //月统计
      yesterdayMinus7 = date.withDayOfMonth(1).toString("yyyy-MM-dd")
      yesterdayPlus1 = date.plusMonths(1).withDayOfMonth(1).toString("yyyy-MM-dd")

    }else {
      //每个月的周五都运行,但是限制每个月的周五在2号到8号才执行
      if(2<=date.plusDays(1).getDayOfMonth&&date.plusDays(1).getDayOfMonth<=8){
        //月初第一周统计
        yesterdayMinus7 = date.withDayOfMonth(1).toString("yyyy-MM-dd")
        yesterdayPlus1 = date.withDayOfWeek(5).toString("yyyy-MM-dd")
      }else{
        //让程序报错，不运行
        System.out.println("当前统计日期是"+date+",不符合月初第一周")
        spark.close()
      }

    }

    /*
      * 加载数据源
      * */
    spark.sql(
      s"""
         |select
         |     oi.order_id
         |from dw.order_information oi
         |where
         |     oi.his_time = '${yesterday}'
         |and  oi.order_source = '1'
         |and  oi.receive_method = '10'
       """.stripMargin).createOrReplaceTempView("order_information")

    spark.sql(
      s"""
         |select
         |     op.tgou_order_id,
         |     op.brand_id,
         |     op.state,
         |     to_date(op.pay_time) as pay_time,
         |     to_date(op.etl_time) as etl_time,
         |     to_date(op.create_time) as create_time,
         |     to_date(op.ship_time) as ship_time,
         |     cast(op.`product_discount` as double) as product_discount
         |from dw.order_product op
         |where
         |     op.his_time = '${yesterday}'
         |and  op.product_source = '1'
       """.stripMargin).createOrReplaceTempView("order_product")

    spark.sql(
      s"""
         |select
         |     b.id,
         |     b.name
         |from dw.brand b
         |where b.his_time = '$yesterday'
       """.stripMargin).createOrReplaceTempView("brand")

    /**
      * 百货品牌订单明细表
      *
      * 字段:
      *  - brand_name 品牌名称
      *  - xdbs 下单笔数
      *  - xdje 下单金额
      *  - xdpsbs 下单配送笔数
      *  - xdpsje 下单配送金额
      *  - hxbs 核销笔数
      *  - hxje 核销金额
      *  - psbs 配送笔数
      *  - psje 配送金额
      *  - zfpsbs 支付配送笔数
      *  - zfpsje 支付配送金额
      *  - thbs 退货笔数
      *  - thje 退货金额
      **/
    val brandDF = spark.sql(
      s"""
         |select
         |     b.name as brand_name
         |from order_product op
         |join brand b
         |on op.brand_id = b.id
         |where op.etl_time >= '$yesterdayMinus7'
         |and op.etl_time < '$yesterdayPlus1'
         |group by b.name
       """.stripMargin)

    val createDF = spark.sql(
      s"""
         |select
         |     b.name as brand_name,
         |     count(distinct op.tgou_order_id) as xdbs,
         |     nvl(cast(sum(op.product_discount) as decimal(18,2)),0) as xdje
         |from order_product op
         |join brand b
         |on op.brand_id = b.id
         |where op.create_time >= '$yesterdayMinus7'
         |and op.create_time < '$yesterdayPlus1'
         |group by b.name
       """.stripMargin)

    val createSendDF = spark.sql(
      s"""
         |select
         |     b.name as brand_name,
         |     count(distinct op.tgou_order_id) as xdpsbs,
         |     nvl(cast(sum(op.product_discount) as decimal(18,2)),0) as xdpsje
         |from order_product op
         |join order_information oi
         |on oi.order_id = op.tgou_order_id
         |join brand b
         |on op.brand_id = b.id
         |where op.create_time >= '$yesterdayMinus7'
         |and op.create_time < '$yesterdayPlus1'
         |group by b.name
       """.stripMargin)

    val shipDF = spark.sql(
      s"""
         |select
         |     b.name as brand_name,
         |     count(distinct op.tgou_order_id) as hxbs,
         |     nvl(cast(sum(op.product_discount) as decimal(18,2)),0) as hxje
         |from order_product op
         |join brand b
         |on op.brand_id = b.id
         |where op.ship_time >= '$yesterdayMinus7'
         |and op.ship_time < '$yesterdayPlus1'
         |group by b.name
       """.stripMargin)

    val shipSendDF = spark.sql(
      s"""
         |select
         |     b.name as brand_name,
         |     count(distinct op.tgou_order_id) as psbs,
         |     nvl(cast(sum(op.product_discount) as decimal(18,2)),0) as psje
         |from order_product op
         |join order_information oi
         |on oi.order_id = op.tgou_order_id
         |join brand b
         |on op.brand_id = b.id
         |where op.ship_time >= '$yesterdayMinus7'
         |and op.ship_time < '$yesterdayPlus1'
         |group by b.name
       """.stripMargin)

    val payDF = spark.sql(
      s"""
         |select
         |     b.name as brand_name,
         |     count(distinct op.tgou_order_id) as zfpsbs,
         |     nvl(cast(sum(op.product_discount) as decimal(18,2)),0) as zfpsje
         |from order_product op
         |join order_information oi
         |on oi.order_id = op.tgou_order_id
         |join brand b
         |on op.brand_id = b.id
         |where op.pay_time >= '$yesterdayMinus7'
         |and op.pay_time < '$yesterdayPlus1'
         |group by b.name
       """.stripMargin)

    val returnedDF = spark.sql(
      s"""
         |select
         |     b.name as brand_name,
         |     count(distinct op.tgou_order_id) as thbs,
         |     nvl(cast(sum(op.product_discount) as decimal(18,2)),0) as thje
         |from order_product op
         |join brand b
         |on op.brand_id = b.id
         |where op.etl_time >= '$yesterdayMinus7'
         |and op.etl_time < '$yesterdayPlus1'
         |and op.state = 'Returned'
         |group by b.name
       """.stripMargin)

    val fields = Map("xdbs"->0,"xdje"->0.0,"xdpsbs"->0,"xdpsje"->0.0,"hxbs"->0,"hxje"->0.0,
                     "psbs"->0,"psje"->0.0,"zfpsbs"->0,"zfpsje"->0.0,"thbs"->0,"thje"->0.0)

    brandDF.join(createDF,Seq("brand_name"),"left").
      join(createSendDF,Seq("brand_name"),"left").
      join(shipDF,Seq("brand_name"),"left").
      join(shipSendDF,Seq("brand_name"),"left").
      join(payDF,Seq("brand_name"),"left").
      join(returnedDF,Seq("brand_name"),"left").
      select(
        "brand_name",
        "xdbs",
        "xdje",
        "xdpsbs",
        "xdpsje",
        "hxbs",
        "hxje",
        "psbs",
        "psje",
        "zfpsbs",
        "zfpsje",
        "thbs",
        "thje"
      ).na.fill(fields)
  }
}
