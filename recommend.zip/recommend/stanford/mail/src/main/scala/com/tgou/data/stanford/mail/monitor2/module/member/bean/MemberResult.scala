package com.tgou.data.stanford.mail.monitor2.module.member.bean

/**
  * Created by 李震 on 2017/12/5.
  */
case class MemberResult (
                          member_count: Long, // 总注册用户数
                          new_member_count: Long // 新增注册用户数
                        )
