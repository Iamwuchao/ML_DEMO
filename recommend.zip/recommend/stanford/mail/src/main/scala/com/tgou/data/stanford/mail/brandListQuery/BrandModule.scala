package com.tgou.data.stanford.mail.brandListQuery

import com.tgou.data.stanford.mail.core.MailSource
import org.apache.spark.sql.types._
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.joda.time.LocalDate

/**
  * Created by 刘洋 on 2018/02/27.
  * #####################
  * #30204: 定时邮件：天狗平台热招品牌池
  * #####################
  */
object BrandModule {
  /**
    * 天狗平台热招品牌池
    * @param spark
    * @param date
    * @return
    *
    * */
  def queryDF(spark: SparkSession, date: LocalDate): DataFrame = {

    val ysday = date.toString("yyyy-MM-dd")
    val lastFriday= date.minusDays(6).toString("yyyy-MM-dd")
    val thisFriday = date.plusDays(1).toString("yyyy-MM-dd")
    /**
     * 读取抽取层counter_item_selected表中当天的数据
     * */
    val schema = StructType(
      StructField("id", LongType, false) ::
        StructField("fk_item_id", LongType, true) ::
        StructField("fk_brand_id", LongType, true) ::
        StructField("selected", IntegerType, true) ::
        StructField("fk_counter_id", LongType, true) ::
        StructField("create_time", StringType, true) ::
        StructField("modify_time", StringType, true) :: Nil
    )
    val totalCounterSelectedDF = MailSource.getUpdateDF(spark,"/tiangou/item/counter_item_selected",date,Seq("id"),"modify_time",schema)
    totalCounterSelectedDF.createTempView("counterSelected")
    /**
      * 读取抽取层brand表中当天的数据
      * */
    val schema_brand = StructType(
      StructField("id", LongType, false) ::
        StructField("name", StringType, true) ::
        StructField("mis_code", LongType, true) ::
        StructField("is_on", StringType, true) ::
        StructField("merged_to_mis_code", LongType, true) ::
        StructField("fk_brand_category_id", LongType, true) ::
        StructField("logo_image_url", LongType, true) ::
        StructField("head_figure_url", LongType, true) ::
        StructField("description", StringType, true) ::
        StructField("flag", IntegerType, true) ::
        StructField("modify_time", StringType, true) :: Nil
    )
    val brandDF = MailSource.getUpdateDF(spark,"/tiangou/tgou/brand",date,Seq("id"),"modify_time",schema_brand)
    brandDF.createTempView("brand")
    /**
      * 读取业务给的数据
      * */
    val tmp = spark.read.format("csv")
      .option("delimiter", "^")
      .option("qoute", "")
      .option("nullValue", "\\N")
      .load(s"hdfs://nameservice1/data/tg_mail_date/ppc1").select("_c0","_c1","_c2").toDF("product_first_category","product_second_category","brand_name")
    tmp.createTempView("tmp_product")
    /**
      * product_first_category 一级分类
      * product_second_category 二级分类
      * brand_name  --品牌名
      * brand_id    --品牌id
      * yxsps --品牌有效商品数
      * ppzgzs--品牌专柜总数
      * yxs --品牌有效商品数（入围）
      * zgs --品牌专柜总数（入围）
      * bz_yxs ----品牌有效商品数（本周入围）
      * bz_zgs --品牌专柜总数（本周入围）
      * */
    val query = spark.sql(
      s"""
       select
         |r.*,
         |nvl(t2.product_first_category," ") product_first_category,
         |nvl(t2.product_second_category," ") product_second_category
         |from
         |   (
         |    select
         |    t.brand_name,
         |    t.brand_id,
         |    t.yxsps,
         |    t.ppzgzs,
         |    nvl(t1.zgs,0) zgs,
         |    nvl(t1.yxs,0) yxs,
         |    nvl(t1.bz_zgs,0) bz_zgs,
         |    nvl(t1.bz_yxs,0) bz_yxs
         |    from
         |    (
         |      select
         |      c.name as brand_name,
         |      c.id as brand_id,
         |      count(distinct b.listing_id) as yxsps,
         |      count(distinct b.counter_id) as ppzgzs
         |        from dw.product a join dw.listing b join brand c
         |      on a.product_id = b.product_id
         |        and a.brand_id = c.id
         |        and c.is_on = 'true'
         |        and b.state = 'onshelf'
         |        and b.source = '1'
         |        and a.his_time = '${ysday}'
         |        and b.his_time = '${ysday}'
         |      group by c.id,c.name
         |    ) t
         |left join
         |    (
         |    select
         |    y.fk_brand_id,
         |    count(distinct y.fk_counter_id) zgs,
         |    count(distinct y.fk_item_id) yxs,
         |    count(distinct case when  y.create_time >= '${lastFriday}' and y.create_time < '${thisFriday}' then y.fk_counter_id end ) as bz_zgs,
         |    count(distinct case when  y.create_time >= '${lastFriday}' and y.create_time < '${thisFriday}' then y.fk_item_id end ) as bz_yxs
         |      from dw.listing x join counterSelected y join brand z
         |    on y.fk_item_id = x.listing_id
         |      and y.fk_brand_id =z.id
         |      and z.is_on = 'true'
         |      and x.state = 'onshelf'
         |      and x.source = '1'
         |      and x.his_time = '${ysday}'
         |      and y.selected = '1'
         |    group by y.fk_brand_id
         |    ) t1
         |on t.brand_id = t1.fk_brand_id
         |) r
         |left join
         |tmp_product t2
         |on r.brand_name = t2.brand_name
       """.stripMargin
    )

    query
  }

}
