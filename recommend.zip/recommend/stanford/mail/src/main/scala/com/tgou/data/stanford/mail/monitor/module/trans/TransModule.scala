package com.tgou.data.stanford.mail.monitor.module.trans

import org.apache.spark.sql.{DataFrame, SparkSession}
import org.joda.time.LocalDate

/**
  * Created by admin on 2017/9/29.
  */
object TransModule {

  /**
    * 天狗交易
    *
    * @param spark
    * @param date
    *
    * @return
    *
    * 字段：
    *  天狗交易额指标达成进度
    * - tgmisjem 天狗交易额(当月累计)
    * - zbje 当月指标
    * - dcl 达成率
    * - sjjd 时间进度(差额)
    *
    * 天狗交易额统计
    * - tgmisjed 当日总交易金额(去重)
    * - smje 扫码交易金额
    * - jje 券类交易金额
    * - ddje 订单交易金额
    * - smrs 扫码人数
    * - smbs 扫码笔数
    *
    * 天狗跨境购
    * - xdbs 当日下单笔数
    * - xdrs 当日下单人数
    * - xdsps 当日下单商品数量
    * - xdje 当日下单总金额
    * - zfbs 当日支付笔数
    * - zfrs 当日支付人数
    * - zfje 当日支付总金额
    * - psbs 当日配送订单笔数
    * - psje 当日配送订单金额
    * - xdjem 当月累计下单金额
    * - zfjem 当月累计支付金额
    *
    * */
  def getTansDF(spark:SparkSession, date: LocalDate): DataFrame = {

    val month = date.withDayOfMonth(1).toString("yyyy-MM-dd")
    val lastDayOfMonth = date.plusMonths(1).withDayOfMonth(1).minusDays(1).toString("yyyy-MM-dd")

    val   khzb = spark.read.format("csv")
      .option("delimiter","^")
      .option("qoute","")
      .option("nullValue","\\N")
      .load("hdfs://nameservice1/data/tg_mail_date/set_file/mis_kh_zb_2_t.txt")

    val khzbS = khzb.select("_c0","_c1","_c2").toDF("storecode",
      "kh_date","m_zb_je")


    khzbS.createOrReplaceTempView("kh_zb")

    /*
         * tgmisjem 天狗交易额(当月累计)
         * */
    val tgmisjem = spark.sql(
      s"""
         |select nvl(cast(sum(a.jyje) as decimal(18,2)),0)  as tgmisjem
         |from dw.pos_zz a
         |inner join kh_zb b
         |on a.storecode = b.storecode
         |and b.kh_date = concat('${month}', ' 00:00:00.0')
         |where a.his_time >= '${month}'
         |and a.his_time < date_format(date_sub('${date.toString("yyyy-MM-dd")}', -1), 'yyyy-MM-dd')
         |and a.storecode not in ('0001', '0204', '0368')
         |and a.jyje > 0
         |and (a.tgou_coupon = true or a.tgou_order = true
         |or a.thyy in ('04', '05', '06', '07', '08', '09'))
      """.stripMargin)

    /*
         * zbje 当月指标
         * */
    val zbje = spark.sql(
      s"""
         |select nvl(cast(sum(m_zb_je) as decimal(18,2)),0)  as zbje
         |from kh_zb
         |where kh_date = concat('${month}', ' 00:00:00.0')
         |and storecode not in ('0001', '0204', '0368')
      """.stripMargin)

    /*
        * dcl 达成率
        * */
    val dclr1m = zbje.first().get(0).toString.toDouble
    var dclr1 = 0.0
    if (dclr1m > 0) {
      dclr1 = tgmisjem.first().get(0).toString.toDouble/zbje.first().get(0).toString.toDouble * 100
    }
    val dclr2 = f"$dclr1%1.2f" .toString.concat("%")

    var dclrList =   List(DclClass(dclr2,"1"))

    val dcl = spark.createDataFrame(dclrList)



    /*
        * sjjd 时间进度(差额)
        * */
    val sjjd1 = spark.sql(
      s"""
         |select  round(day('${date.toString("yyyy-MM-dd")}')/day('${lastDayOfMonth}')*100,2) as sjjd
         |from kh_zb
         |where kh_date = concat('${month}', ' 00:00:00.0')
         |and storecode not in ('0001', '0204', '0368')
         |limit 1
      """.stripMargin)
    val sjjdNum1 = sjjd1.first().get(0).toString.toDouble
    val sjjdNum2 = dclr1 - sjjdNum1
    val sjjr1 = sjjd1.first().get(0).toString

    val sjjr = sjjr1.concat("%").concat("(").concat(f"$sjjdNum2%1.2f" .toString.concat("%")).concat(")")

    var sjjList =   List(SjjClass(sjjr,"1"))

    val sjjd = spark.createDataFrame(sjjList)


    /*
        * tgmisjed 当日总交易金额(去重)
        * */

    val tgmisjed =  spark.sql(
      s"""
         |select a1.je + a2.je as tgmisjed
         |from (select nvl(cast(sum(jyje) as decimal(18,2)),0)  as je,
         |1 as dt
         |from dw.pos_zz
         |where his_time = '${date.toString("yyyy-MM-dd")}'
         |and jyje > 0
         |and (tgou_coupon = true
         |or tgou_order = true
         |or thyy in ('04', '05', '06', '07', '08', '09'))) a1
         |join (select nvl(cast(sum(total_amount) as decimal(18,2)),0)  as je,
         |1 as dt
         |from dw.order_information
         |where his_time = '${date.toString("yyyy-MM-dd")}'
         |and ship_time >= concat('${date.toString("yyyy-MM-dd")}', ' 00:00:00')
         |and ship_time < concat(date_format(date_sub('${date.toString("yyyy-MM-dd")}', -1), 'yyyy-MM-dd'),' 00:00:00')
         |and order_source in ('3','4')) a2
         |on (
         |a1.dt = a2.dt
         |)
      """.stripMargin)



    /*smje 扫码交易金额
        * */
    val smje = spark.sql(
      s"""
         |select nvl(cast(sum(jyje) as decimal(18,2)),0) as smje
         |from dw.pos_zz
         |where his_time =  '${date.toString("yyyy-MM-dd")}'
         |and jyje > 0
         |and thyy in ('04', '05', '06', '07', '08', '09')
      """.stripMargin)

    /*jje 券类交易金额
       * */
    val jje = spark.sql(
      s"""
         |select nvl(cast(sum(jyje) as decimal(18,2)),0)  as jje
         |from dw.pos_zz where
         |his_time = '${date.toString("yyyy-MM-dd")}'
         |and jyje > 0
         |and tgou_coupon = true
      """.stripMargin)


    /*ddje 订单交易金额
     * */
    val ddje = spark.sql(
      s"""
         |select a1.je + a2.je as ddje
         |from(select nvl(cast(sum(total_amount) as decimal(18,2)),0) as je,
         |1 as dt
         |from dw.order_information
         |where his_time = '${date.toString("yyyy-MM-dd")}'
         |and ship_time >= concat('${date.toString("yyyy-MM-dd")}', ' 00:00:00')
         |and ship_time < concat(date_format(date_sub('${date.toString("yyyy-MM-dd")}', -1), 'yyyy-MM-dd'),' 00:00:00')
         |and order_source in ('1','2')) a1
         |join (select nvl(cast(sum(total_amount) as decimal(18,2)),0) as je,
         |1 as dt
         |from dw.order_information
         |where his_time = '${date.toString("yyyy-MM-dd")}'
         |and pay_time >= concat('${date.toString("yyyy-MM-dd")}', ' 00:00:00')
         |and pay_time < concat(date_format(date_sub('${date.toString("yyyy-MM-dd")}', -1), 'yyyy-MM-dd'),' 00:00:00')
         |and order_source in ('3','4')) a2
         |on a1.dt = a2.dt
      """.stripMargin)


    /*smrs 扫码人数
     * */
    val smrs = spark.sql(
      s"""
         |select count(distinct CID) as smrs
         | from dw.pos_zz
         |where his_time = '${date.toString("yyyy-MM-dd")}'
         |and jyje > 0
         |and thyy in ('04', '05', '06', '07', '08', '09')
      """.stripMargin)

    /*smbs 扫码笔数
     * */
    val smbs = spark.sql(
      s"""
         |select count(*) as smbs
         | from dw.pos_zz
         |where his_time = '${date.toString("yyyy-MM-dd")}'
         |and jyje > 0
         |and thyy in ('04', '05', '06', '07', '08', '09')
      """.stripMargin)
/**
    /*xdbs 当日下单笔数
   * xdrs 当日下单人数
   * xdsps 当日下单商品数量
   * xdje 当日下单总金额
   * */
    val tgxd = spark.sql(
      s"""
         |select a1.bs as xdbs,
         |a1.rs as xdrs ,
         |a2.sps as xdsps ,
         |nvl(cast(a1.je as decimal(18,2)),0)  as xdje
         |from (select count(order_id) bs,
         |count(distinct member_id) rs,
         |sum(total_amount) je,
         |1 as d
         |from dw.order_information t
         |where t.his_time = '${date.toString("yyyy-MM-dd")}'
         |and t.order_source in ('3','4')
         |and t.create_time >= concat('${date.toString("yyyy-MM-dd")}', ' 00:00:00')
         |and t.create_time < concat(date_format(date_sub('${date.toString("yyyy-MM-dd")}', -1), 'yyyy-MM-dd'),' 00:00:00')) a1
         | join (select sum(product_quantity) sps, 1 as d
         |from  dw.order_product b
         |where b.his_time = '${date.toString("yyyy-MM-dd")}'
         |and b.product_source in ('3','4')
         |and b.create_time >= concat('${date.toString("yyyy-MM-dd")}', ' 00:00:00')
         |and b.create_time < concat(date_format(date_sub('${date.toString("yyyy-MM-dd")}', -1), 'yyyy-MM-dd'),' 00:00:00')) a2
         |on a1.d = a2.d
      """.stripMargin)


    /*
   * zfbs 当日支付笔数
    *  zfrs 当日支付人数
    *  zfje 当日支付总金额
  * */
    val tgzf = spark.sql(
      s"""
         |select count(order_id) as  zfbs ,
         |count(distinct member_id) as  zfrs,
         |nvl(cast(sum(total_amount) as decimal(18,2)),0) as zfje
         |from dw.order_information t
         |where t.his_time = '${date.toString("yyyy-MM-dd")}'
         |and t.order_source in ('3','4')
         |and t.pay_time >= concat('${date.toString("yyyy-MM-dd")}', ' 00:00:00')
         |and t.pay_time < concat(date_format(date_sub('${date.toString("yyyy-MM-dd")}', -1), 'yyyy-MM-dd'),' 00:00:00')
      """.stripMargin)

    /*
   * psbs 当日配送订单笔数
    * psje 当日配送订单金额
  * */
    val tgps = spark.sql(
      s"""
         |select count(order_id) as psbs,
         |nvl(cast(sum(total_amount) as decimal(18,2)),0)  as psje
         |from dw.order_information t
         |where t.his_time =  '${date.toString("yyyy-MM-dd")}'
         |and t.order_source in ('3','4')
         |and t.ship_time >= concat('${date.toString("yyyy-MM-dd")}', ' 00:00:00')
         |and t.ship_time < concat(date_format(date_sub('${date.toString("yyyy-MM-dd")}', -1), 'yyyy-MM-dd'),' 00:00:00')
         |and t.receive_method = '10'
      """.stripMargin)

    /*
  * xdjem 当月累计下单金额
 * */
    val tgxdm = spark.sql(
      s"""
         |select
         |nvl(cast(sum(total_amount) as decimal(18,2)),0)  xdjem
         |from dw.order_information t
         |where t.his_time = '${date.toString("yyyy-MM-dd")}'
         |and t.order_source in ('3','4')
         |and t.create_time >= concat('${month}', ' 00:00:00')
         |and t.create_time < concat(date_format(date_sub('${date.toString("yyyy-MM-dd")}', -1), 'yyyy-MM-dd'),' 00:00:00')
      """.stripMargin)


    /*
   *  zfjem 当月累计支付金额
* */
    val tgzfm = spark.sql(
      s"""
         |select
         |nvl(cast(sum(total_amount) as decimal(18,2)),0)  zfjem
         |from dw.order_information t
         |where t.his_time = '${date.toString("yyyy-MM-dd")}'
         |and t.order_source in ('3','4')
         |and t.pay_time >= concat('${month}', ' 00:00:00')
         |and t.pay_time < concat(date_format(date_sub('${date.toString("yyyy-MM-dd")}', -1), 'yyyy-MM-dd'),' 00:00:00')
      """.stripMargin)

  **/

     val rs = tgmisjem.crossJoin(zbje)
       .crossJoin(dcl)
       .crossJoin(sjjd)
       .crossJoin(tgmisjed)
       .crossJoin(smje)
       .crossJoin(jje)
       .crossJoin(ddje)
       .crossJoin(smrs)
       .crossJoin(smbs)
  //     .crossJoin(tgxd)
  //    .crossJoin(tgzf)
  //    .crossJoin(tgps)
  //   .crossJoin(tgxdm)
  //    .crossJoin(tgzfm)
         .select("tgmisjem",
           "zbje",
           "dcl",
           "sjjd",
          "tgmisjed",
           "smje",
          "jje",
           "ddje",
           "smrs",
           "smbs"
  /**         "xdbs",
           "xdrs",
           "xdsps",
           "xdje",
           "zfbs",
           "zfrs",
           "zfje",
           "psbs",
           "psje",
           "xdjem",
           "zfjem"
    **/
     )
   return rs

  }

  /*
   达成率
    */

  case class DclClass(dcl:String,market_time:String)

  /*
 时间进度(差额)
  */

  case class SjjClass(sjjd:String,market_time:String)


}
