package com.tgou.data.stanford.mail.monitor.module.listing

import org.apache.spark.sql.{DataFrame, SparkSession}
import org.joda.time.LocalDate

/**
  * Created by 李震 on 2017/9/27.
  */
class ListingSource(spark: SparkSession) {

  /**
    * 获取最新的 listing 数仓层数据
    *
    * 业态：百货
    *
    * @param date
    *
    * @return
    *
    * 字段：
    *
    * - listing_id  营销品 ID
    * - product_id  基础品 ID
    * - state  状态
    * - is_fast_sales  是否为快捷品
    *
    * */
  def getUpdateListingDWDF(date: LocalDate): DataFrame = {
    spark.sql(
      s"""
         |select
         |  l.listing_id,
         |  l.product_id,
         |  l.state,
         |  l.download_time,
         |  l.binding_time,
         |  l.is_fast_sales
         |from dw.listing l
         |where l.his_time = '${date.toString("yyyy-MM-dd")}'
         |and l.source = '1'
      """.stripMargin)
  }

  /**
    * 获取最新的 product 数仓层数据
    *
    * @param date
    *
    * @return
    *
    * 字段：
    *
    * - product_id  基础品 ID
    * - brand_id  品牌 ID
    * - product_third_category  三级分类
    *
    * */
  def getUpdateProductDWDF(date: LocalDate): DataFrame = {
    spark.sql(
      s"""
        |select
        |  p.product_id,
        |  p.brand_id,
        |  p.product_third_category
        |from dw.product p
        |where p.his_time = '${date.toString("yyyy-MM-dd")}'
      """.stripMargin)
  }

}

object ListingSource {

  def apply(spark: SparkSession): ListingSource = new ListingSource(spark)

}
