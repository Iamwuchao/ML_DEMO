package com.tgou.data.stanford.mail.monitor.module.storeActivity.bean

import com.tgou.data.stanford.mail.core.BaseBean

object AdvPositionToStore extends BaseBean {

  override def list: List[(Any,String)] = {

    List(
      (0, "id"),
      (1, "fk_store_id"),
      (2, "fk_adv_position_id")
    )

  }

}
