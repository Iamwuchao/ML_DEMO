package com.tgou.data.stanford.mail.parkingLot.Bean

import com.tgou.data.stanford.mail.core.BaseBean
/**
  * Created by 李震 on 2017/9/27.
  *
  *
  id  主键 0
  fk_store_id 门店ID 1
  create_time 2
  fk_member_id  天狗会员ID 4
  park_name  停车场名称 7
  amount   收费金额 14

  */
object ParkingBill extends BaseBean {

  override def list: List[(Any,String)] = {

    List(
      (0, "id"),
      (1, "fk_store_id"),
      (2, "create_time"),
      (4, "fk_member_id"),
      (7, "park_name"),
      (14,"amount")
    )

  }
}