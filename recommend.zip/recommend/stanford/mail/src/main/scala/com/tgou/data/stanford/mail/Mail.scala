package com.tgou.data.stanford.mail

/**
  * Created by 李震 on 2017/9/26.
  */
object Mail {

}
