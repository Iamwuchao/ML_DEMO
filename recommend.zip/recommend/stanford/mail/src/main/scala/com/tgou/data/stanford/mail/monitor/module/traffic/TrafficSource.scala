package com.tgou.data.stanford.mail.monitor.module.traffic

import org.apache.spark.sql.{DataFrame, SparkSession}
import org.joda.time.LocalDate

/**
  * Created by 李震 on 2017/9/27.
  */
class TrafficSource(spark: SparkSession) {

  /**
    * 获取增量的 uba_page 数仓层数据
    *
    * @param date 日期
    *
    * @return
    *
    * 字段：
    *
    * - uuid  Server 端生成唯一标识
    *
    * */
  def getAppendUbaPageDWDF(date: LocalDate): DataFrame = {
    spark.sql(
      s"""
         |select
         |    up.uuid
         |from dw.uba_page up
         |where up.his_time = '${date.toString("yyyy-MM-dd")}'
      """.stripMargin)
  }

  /**
    * 获取增量的 search  ODS 层数据
    *
    * @param date 日期
    *
    * @return
    *
    * 字段：
    *
    * - uuid  Server 端生成唯一标识
    * - keyword  搜索关键词
    *
    * */
  def getAppendSearchODSDF(date: LocalDate): DataFrame = {
    spark.read.json(s"/tiangou/search/${date.toString("yyyy/MM/dd")}/*")
      .select("uuid", "keyword")
  }

}

object TrafficSource {

  def apply(spark: SparkSession): TrafficSource = new TrafficSource(spark)

}