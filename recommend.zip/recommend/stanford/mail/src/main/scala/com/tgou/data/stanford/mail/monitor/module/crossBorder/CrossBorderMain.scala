package com.tgou.data.stanford.mail.monitor.module.crossBorder

import com.tgou.data.stanford.mail.core.MailBootstrap
import org.apache.spark.sql.{SaveMode, SparkSession}
import org.joda.time.LocalDate


/**
  * Created by 刘洋 on 2017/11/13.
  */

object CrossBorderMain {


  def main(args: Array[String]): Unit = {
    MailBootstrap(args).bootstrap(execute)
  }

  def execute(spark: SparkSession, appName: String, date: LocalDate): Unit = {
          CrossBorderModule.getInternationalDF(spark,date).show()
          CrossBorderModule.getDomesticDF(spark,date).show()
  }
}