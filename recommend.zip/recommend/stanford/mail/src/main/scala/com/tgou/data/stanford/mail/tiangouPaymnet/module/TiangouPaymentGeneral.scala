package com.tgou.data.stanford.mail.tiangouPaymnet.module

import org.apache.spark.sql.{DataFrame, SparkSession, functions}
import org.joda.time.LocalDate


/**
  * Created by 李磊 on 2017/11/16.
  * 天狗支付概况
  */

object TiangouPaymentGeneral {
  /**
    * 字段：
    * - bh_xdbs  百货下单笔数
    * - bh_zfcgbs 百货支付成功笔数
    * - bh_zfcgl 百货支付成功率
    * - bh_xdje 百货下单金额
    * - bh_xdkdj 百货下单客单价
    * - bh_zfcgje 百货支付成功金额
    * - bh_zfcgkdj 百货支付成功客单价
    * - cs_xdbs  超市下单笔数
    * - cs_zfcgbs 超市支付成功笔数
    * - cs_zfcgl 超市支付成功率
    * - cs_xdje 超市下单金额
    * - cs_xdkdj 超市下单客单价
    * - cs_zfcgje 超市支付成功金额
    * - cs_zfcgkdj 超市支付成功客单价
    * - kjhw_xdbs  跨境海外下单笔数
    * - kjhw_zfcgbs 跨境海外支付成功笔数
    * - kjhw_zfcgl 跨境海外支付成功率
    * - kjhw_xdje 跨境海外下单金额
    * - kjhw_xdkdj 跨境海外下单客单价
    * - kjhw_zfcgje 跨境海外支付成功金额
    * - kjhw_zfcgkdj 跨境海外支付成功客单价
    * - kjsh_xdbs  跨境社会下单笔数
    * - kjsh_zfcgbs 跨境社会支付成功笔数
    * - kjsh_zfcgl 跨境社会支付成功率
    * - kjsh_xdje 跨境社会下单金额
    * - kjsh_xdkdj 跨境社会下单客单价
    * - kjsh_zfcgje 跨境社会支付成功金额
    * - kjsh_zfcgkdj 跨境社会支付成功客单价
    * - hj_xdbs  合计下单笔数
    * - hj_zfcgbs 合计支付成功笔数
    * - hj_zfcgl 合计支付成功率
    * - hj_xdje 合计下单金额
    * - hj_xdkdj 合计下单客单价
    * - hj_zfcgje 合计支付成功金额
    * - hj_zfcgkdj 合计支付成功客单价
    * */
  def getTansDF(spark:SparkSession, date: LocalDate): DataFrame = {


    /*
        * 百货统计
        * */
    val baihuo = spark.sql(
      s"""
         |select
         |count(distinct order_id) bh_xdbs ,
         |count(distinct case when t.pay_time >= concat('${date.toString("yyyy-MM-dd")}', ' 00:00:00')
         |and t.pay_time < concat(date_format(date_sub('${date.toString("yyyy-MM-dd")}', -1), 'yyyy-MM-dd'),' 00:00:00')
         |and isnull(cancel_time)
         |and pay_method != '010'
         |then order_id end ) bh_zfcgbs,
         |nvl(cast((count(distinct case when t.pay_time >= concat('${date.toString("yyyy-MM-dd")}', ' 00:00:00')
         |and t.pay_time < concat(date_format(date_sub('${date.toString("yyyy-MM-dd")}', -1), 'yyyy-MM-dd'),' 00:00:00')
         |and isnull(cancel_time)
         |and pay_method != '010'
         |then order_id end ) / count(distinct order_id) * 100) as decimal(18,2)),0)   as bh_zfcgl,
         | nvl(cast(sum( total_amount) as decimal(18,2)),0) bh_xdje ,
         |  avg( total_amount) bh_xdkdj ,
         |nvl(cast(sum( case when t.pay_time >= concat('${date.toString("yyyy-MM-dd")}', ' 00:00:00')
         |and t.pay_time < concat(date_format(date_sub('${date.toString("yyyy-MM-dd")}', -1), 'yyyy-MM-dd'),' 00:00:00')
         |and isnull(cancel_time)
         |and pay_method != '010'
         |then total_amount end ) as decimal(18,2)),0) bh_zfcgje,
         |avg( case when t.pay_time >= concat('${date.toString("yyyy-MM-dd")}', ' 00:00:00')
         |and t.pay_time < concat(date_format(date_sub('${date.toString("yyyy-MM-dd")}', -1), 'yyyy-MM-dd'),' 00:00:00')
         |and isnull(cancel_time)
         |and pay_method != '010'
         |then total_amount end ) bh_zfcgkdj
         |from dw.order_information t
         |where t.his_time = '${date.toString("yyyy-MM-dd")}'
         |and t.create_time >= concat('${date.toString("yyyy-MM-dd")}', ' 00:00:00')
         |and t.create_time < concat(date_format(date_sub('${date.toString("yyyy-MM-dd")}', -1), 'yyyy-MM-dd'),' 00:00:00')
         |and t.order_type = 0
         |and t.order_source = '1'
         |and pay_method != '000'
      """.stripMargin)

    /*
       * 超市统计
       * */
    val chaoshi = spark.sql(
      s"""
         |select
         |count(distinct order_id) cs_xdbs ,
         |count(distinct case when t.pay_time >= concat('${date.toString("yyyy-MM-dd")}', ' 00:00:00')
         |and t.pay_time < concat(date_format(date_sub('${date.toString("yyyy-MM-dd")}', -1), 'yyyy-MM-dd'),' 00:00:00')
         |and isnull(cancel_time)
         |and pay_method != '010'
         |then order_id end ) cs_zfcgbs,
         |nvl(cast((count(distinct case when t.pay_time >= concat('${date.toString("yyyy-MM-dd")}', ' 00:00:00')
         |and t.pay_time < concat(date_format(date_sub('${date.toString("yyyy-MM-dd")}', -1), 'yyyy-MM-dd'),' 00:00:00')
         |and isnull(cancel_time)
         |and pay_method != '010'
         |then order_id end ) / count(distinct order_id) * 100) as decimal(18,2)),0)   as cs_zfcgl,
         | nvl(cast(sum( total_amount) as decimal(18,2)),0) cs_xdje ,
         |  avg( total_amount) cs_xdkdj ,
         |nvl(cast(sum( case when t.pay_time >= concat('${date.toString("yyyy-MM-dd")}', ' 00:00:00')
         |and t.pay_time < concat(date_format(date_sub('${date.toString("yyyy-MM-dd")}', -1), 'yyyy-MM-dd'),' 00:00:00')
         |and isnull(cancel_time)
         |and pay_method != '010'
         |then total_amount end ) as decimal(18,2)),0) cs_zfcgje,
         |avg( case when t.pay_time >= concat('${date.toString("yyyy-MM-dd")}', ' 00:00:00')
         |and t.pay_time < concat(date_format(date_sub('${date.toString("yyyy-MM-dd")}', -1), 'yyyy-MM-dd'),' 00:00:00')
         |and isnull(cancel_time)
         |and pay_method != '010'
         |then total_amount end ) cs_zfcgkdj
         |from dw.order_information t
         |where t.his_time = '${date.toString("yyyy-MM-dd")}'
         |and t.create_time >= concat('${date.toString("yyyy-MM-dd")}', ' 00:00:00')
         |and t.create_time < concat(date_format(date_sub('${date.toString("yyyy-MM-dd")}', -1), 'yyyy-MM-dd'),' 00:00:00')
         |and t.order_type = 0
         |and t.order_source = '2'
         |and pay_method != '000'
      """.stripMargin)
    /*
        * 跨境统计-海外
        * */
    val kajin_haiwai = spark.sql(
      s"""
         |select
         |count(distinct order_id) kjhw_xdbs ,
         |count(distinct case when t.pay_time >= concat('${date.toString("yyyy-MM-dd")}', ' 00:00:00')
         |and t.pay_time < concat(date_format(date_sub('${date.toString("yyyy-MM-dd")}', -1), 'yyyy-MM-dd'),' 00:00:00')
         |and isnull(cancel_time)
         |and pay_method != '010'
         |then order_id end ) kjhw_zfcgbs,
         |nvl(cast((count(distinct case when t.pay_time >= concat('${date.toString("yyyy-MM-dd")}', ' 00:00:00')
         |and t.pay_time < concat(date_format(date_sub('${date.toString("yyyy-MM-dd")}', -1), 'yyyy-MM-dd'),' 00:00:00')
         |and isnull(cancel_time)
         |and pay_method != '010'
         |then order_id end ) / count(distinct order_id) * 100) as decimal(18,2)),0)   as kjhw_zfcgl,
         | nvl(cast(sum( total_amount) as decimal(18,2)),0) kjhw_xdje ,
         |  avg( total_amount) kjhw_xdkdj ,
         |nvl(cast(sum( case when t.pay_time >= concat('${date.toString("yyyy-MM-dd")}', ' 00:00:00')
         |and t.pay_time < concat(date_format(date_sub('${date.toString("yyyy-MM-dd")}', -1), 'yyyy-MM-dd'),' 00:00:00')
         |and isnull(cancel_time)
         |and pay_method != '010'
         |then total_amount end ) as decimal(18,2)),0) kjhw_zfcgje,
         |avg( case when t.pay_time >= concat('${date.toString("yyyy-MM-dd")}', ' 00:00:00')
         |and t.pay_time < concat(date_format(date_sub('${date.toString("yyyy-MM-dd")}', -1), 'yyyy-MM-dd'),' 00:00:00')
         |and isnull(cancel_time)
         |and pay_method != '010'
         |then total_amount end ) kjhw_zfcgkdj
         |from dw.order_information t
         |join dw.store s
         |on t.store_id = s.id
         |and s.his_time = '${date.toString("yyyy-MM-dd")}'
         |and s.state = 'onshelf'
         |and s.yt = 4
         |and isnull(s.is_international) = false
         |and s.is_international = '1'
         |where t.his_time = '${date.toString("yyyy-MM-dd")}'
         |and t.create_time >= concat('${date.toString("yyyy-MM-dd")}', ' 00:00:00')
         |and t.create_time < concat(date_format(date_sub('${date.toString("yyyy-MM-dd")}', -1), 'yyyy-MM-dd'),' 00:00:00')
         |and t.order_type = 0
         |and t.order_source = 4
         |and pay_method != '000'
      """.stripMargin)

    /*
       * 跨境统计-社会
       * */
    val kajin_shehui = spark.sql(
      s"""
         |select
         |count(distinct order_id) kjsh_xdbs ,
         |count(distinct case when t.pay_time >= concat('${date.toString("yyyy-MM-dd")}', ' 00:00:00')
         |and t.pay_time < concat(date_format(date_sub('${date.toString("yyyy-MM-dd")}', -1), 'yyyy-MM-dd'),' 00:00:00')
         |and isnull(cancel_time)
         |and pay_method != '010'
         |then order_id end ) kjsh_zfcgbs,
         |nvl(cast((count(distinct case when t.pay_time >= concat('${date.toString("yyyy-MM-dd")}', ' 00:00:00')
         |and t.pay_time < concat(date_format(date_sub('${date.toString("yyyy-MM-dd")}', -1), 'yyyy-MM-dd'),' 00:00:00')
         |and isnull(cancel_time)
         |and pay_method != '010'
         |then order_id end ) / count(distinct order_id) * 100) as decimal(18,2)),0)   as kjsh_zfcgl,
         | nvl(cast(sum( total_amount) as decimal(18,2)),0) kjsh_xdje ,
         |  avg( total_amount) kjsh_xdkdj ,
         |nvl(cast(sum( case when t.pay_time >= concat('${date.toString("yyyy-MM-dd")}', ' 00:00:00')
         |and t.pay_time < concat(date_format(date_sub('${date.toString("yyyy-MM-dd")}', -1), 'yyyy-MM-dd'),' 00:00:00')
         |and isnull(cancel_time)
         |and pay_method != '010'
         |then total_amount end ) as decimal(18,2)),0) kjsh_zfcgje,
         |avg( case when t.pay_time >= concat('${date.toString("yyyy-MM-dd")}', ' 00:00:00')
         |and t.pay_time < concat(date_format(date_sub('${date.toString("yyyy-MM-dd")}', -1), 'yyyy-MM-dd'),' 00:00:00')
         |and isnull(cancel_time)
         |and pay_method != '010'
         |then total_amount end ) kjsh_zfcgkdj
         |from dw.order_information t
         |join dw.store s
         |on t.store_id = s.id
         |and s.his_time = '${date.toString("yyyy-MM-dd")}'
         |and s.state = 'onshelf'
         |and s.yt = 4
         |and isnull(s.is_international) = false
         |and s.is_international = '0'
         |where t.his_time = '${date.toString("yyyy-MM-dd")}'
         |and t.create_time >= concat('${date.toString("yyyy-MM-dd")}', ' 00:00:00')
         |and t.create_time < concat(date_format(date_sub('${date.toString("yyyy-MM-dd")}', -1), 'yyyy-MM-dd'),' 00:00:00')
         |and t.order_type = 0
         |and t.order_source = 4
         |and pay_method != '000'
      """.stripMargin)

    /*
       * 合计统计
       * */
    val heji = spark.sql(
      s"""
         |select
         |count(distinct order_id) hj_xdbs ,
         |count(distinct case when t.pay_time >= concat('${date.toString("yyyy-MM-dd")}', ' 00:00:00')
         |and t.pay_time < concat(date_format(date_sub('${date.toString("yyyy-MM-dd")}', -1), 'yyyy-MM-dd'),' 00:00:00')
         |and isnull(cancel_time)
         |and pay_method != '010'
         |then order_id end ) hj_zfcgbs,
         |nvl(cast((count(distinct case when t.pay_time >= concat('${date.toString("yyyy-MM-dd")}', ' 00:00:00')
         |and t.pay_time < concat(date_format(date_sub('${date.toString("yyyy-MM-dd")}', -1), 'yyyy-MM-dd'),' 00:00:00')
         |and isnull(cancel_time)
         |and pay_method != '010'
         |then order_id end ) / count(distinct order_id) * 100) as decimal(18,2)),0)   as hj_zfcgl,
         | nvl(cast(sum( total_amount) as decimal(18,2)),0) hj_xdje ,
         |  avg( total_amount) hj_xdkdj ,
         |nvl(cast(sum( case when t.pay_time >= concat('${date.toString("yyyy-MM-dd")}', ' 00:00:00')
         |and t.pay_time < concat(date_format(date_sub('${date.toString("yyyy-MM-dd")}', -1), 'yyyy-MM-dd'),' 00:00:00')
         |and isnull(cancel_time)
         |and pay_method != '010'
         |then total_amount end ) as decimal(18,2)),0) hj_zfcgje,
         |avg( case when t.pay_time >= concat('${date.toString("yyyy-MM-dd")}', ' 00:00:00')
         |and t.pay_time < concat(date_format(date_sub('${date.toString("yyyy-MM-dd")}', -1), 'yyyy-MM-dd'),' 00:00:00')
         |and isnull(cancel_time)
         |and pay_method != '010'
         | then total_amount end ) hj_zfcgkdj
         |from dw.order_information t
         |where t.his_time = '${date.toString("yyyy-MM-dd")}'
         |and t.create_time >= concat('${date.toString("yyyy-MM-dd")}', ' 00:00:00')
         |and t.create_time < concat(date_format(date_sub('${date.toString("yyyy-MM-dd")}', -1), 'yyyy-MM-dd'),' 00:00:00')
         |and t.order_type = 0
         |and pay_method != '000'
      """.stripMargin)


    val rs = baihuo.crossJoin(chaoshi)
      .crossJoin(kajin_haiwai)
      .crossJoin(kajin_shehui)
      .crossJoin(heji)
      .select(
        "bh_xdbs",
        "bh_zfcgbs",
        "bh_zfcgl",
        "bh_xdje",
        "bh_xdkdj",
        "bh_zfcgje",
        "bh_zfcgkdj",
        "cs_xdbs",
        "cs_zfcgbs",
        "cs_zfcgl",
        "cs_xdje",
        "cs_xdkdj",
        "cs_zfcgje",
        "cs_zfcgkdj",
        "kjhw_xdbs",
        "kjhw_zfcgbs",
        "kjhw_zfcgl",
        "kjhw_xdje",
        "kjhw_xdkdj",
        "kjhw_zfcgje",
        "kjhw_zfcgkdj",
        "kjsh_xdbs",
        "kjsh_zfcgbs",
        "kjsh_zfcgl",
        "kjsh_xdje",
        "kjsh_xdkdj",
        "kjsh_zfcgje",
        "kjsh_zfcgkdj",
        "hj_xdbs",
        "hj_zfcgbs",
        "hj_zfcgl",
        "hj_xdje",
        "hj_xdkdj",
        "hj_zfcgje",
        "hj_zfcgkdj"
    )

    return rs
  }
}