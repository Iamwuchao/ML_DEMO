package com.tgou.data.stanford.mail.monitor2.module.listing

import com.tgou.data.stanford.mail.core.BaseBean

object CounterSelected extends BaseBean {

  override def list: List[(Any,String)] = {

    List(
      (0, "id"),
      (1, "fk_item_id"),
      (3, "selected")
    )

  }

}
