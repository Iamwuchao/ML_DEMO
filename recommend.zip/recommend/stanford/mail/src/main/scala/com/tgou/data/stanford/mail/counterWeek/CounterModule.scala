package com.tgou.data.stanford.mail.counterWeek

import com.tgou.data.stanford.mail.core.MailSource
import org.apache.spark.sql.types._
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.joda.time.LocalDate

/**
  * Created by 刘洋 on 2018/03/12.
  *
  */
object CounterModule {
  /**
    * 天狗专柜周操作统计
    *
    * @param spark
    * @param date
    *
    * @return
    *
    * */
  def queryDF(spark: SparkSession, date: LocalDate): DataFrame = {

    val ysday = date.toString("yyyy-MM-dd")
    val lastFriday= date.minusDays(6).toString("yyyy-MM-dd")
    val thisFriday = date.plusDays(1).toString("yyyy-MM-dd")

    val tmp = spark.read.format("csv")
      .option("delimiter", "^")
      .option("qoute", "")
      .option("nullValue", "\\N")
      .load(s"hdfs://nameservice1/tiangou/item/counter_dynamics/*/*/*").select("_c0","_c5","_c8","_c13").toDF("id","counter_id","create_time","modify_time")
      tmp.createTempView("counter")
    /**
      * area_name,--地区
      * store_name,--店铺名称
      * store_code,--店铺编码
      * sold_type_name,--业种
      * sold_area_name,--卖区
      * counter_name,--柜组
      * counter_id,--柜组id
      * lsgs,--历史创建动态个数
      * xjdt, --  一周内新建动态个数
      * gxdt,--  一周内更新动态个数
      * modify_time --上次更新动态时间
      * */
    val query = spark.sql(
      s"""
         |select
         |  c.area_name,
         |  a.store_name,
         |  c.store_code,
         |  a.sold_type_name,
         |  a.sold_area_name,
         |  a.counter_name,
         |  b.counter_id,
         |  count(distinct b.id) lsgs,
         |  COUNT(distinct CASE WHEN b.create_time >='${lastFriday}' AND b.create_time <'${thisFriday}'  THEN b.id END) xjdt,
         |  COUNT(distinct CASE WHEN b.modify_time >='${lastFriday}' AND b.modify_time <'${thisFriday}' THEN  b.id  END) gxdt,
         |  MAX(b.modify_time) modify_time
         |from counter b
         |    join dw.listing a join dw.store c
         |  on a.counter_id = b.counter_id
         |  and a.store_id = c.id
         |  and a.state = 'onshelf'
         |  and a.his_time = '${ysday}'
         |  and c.his_time = '${ysday}'
         | group by c.area_name,a.store_name,c.store_code,a.sold_type_name,a.sold_area_name,a.counter_name,b.counter_id
         | order by c.area_name,a.store_name,c.store_code,a.sold_type_name,a.sold_area_name,a.counter_name,b.counter_id
       """.stripMargin
    )

    query
  }

}
