package com.tgou.data.stanford.mail.discover

import com.tgou.data.stanford.mail.core.MailBootstrap
import org.apache.spark.sql.{SaveMode, SparkSession}
import org.joda.time.LocalDate

/**
  * Created by 刘洋 on 2017/12/26.
  *发现频道-改版
  */

object DiscoverMain {
  def main(args: Array[String]): Unit = {
    MailBootstrap(args).bootstrap(execute)
  }

  def execute(spark: SparkSession, appName: String, date: LocalDate): Unit = {

    /**
      * 第一步 获取数据
      * */
    val result = DiscoverModule.DiscoverQuery(spark, date)

    /**
      * 第二步 保存数据到HDFS上
      * */
    result.coalesce(1).write.mode(SaveMode.Overwrite).json(s"/data/mail/discover/$date/")

    spark.stop()

  }

}

