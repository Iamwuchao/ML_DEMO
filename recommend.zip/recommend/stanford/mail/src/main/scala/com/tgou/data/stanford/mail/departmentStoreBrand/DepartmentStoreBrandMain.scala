package com.tgou.data.stanford.mail.departmentStoreBrand

import com.tgou.data.stanford.mail.core.MailBootstrap
import org.apache.spark.sql.{SaveMode, SparkSession}
import org.joda.time.LocalDate

/**
  * Created by 刘洋 on 2017/11/3.
  * 百货品牌日报数据统计
  */

object DepartmentStoreBrandMain {
  def main(args: Array[String]): Unit = {
    MailBootstrap(args).bootstrap(execute)
  }

  def execute(spark: SparkSession, appName: String, date: LocalDate): Unit = {

    /**
      * 第一步 获取数据
      * */
    val result = DepStoreBrandOrderModule.depStoreBrandOrder(spark, date)

    /**
      * 第二步 保存数据到HDFS上
      * */
    result.coalesce(1).write.mode(SaveMode.Overwrite).json(s"/data/mail/dep_store_brand_order/$date/")

    spark.stop()

  }

}
