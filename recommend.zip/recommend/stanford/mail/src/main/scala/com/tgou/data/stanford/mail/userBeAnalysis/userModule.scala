package com.tgou.data.stanford.mail.userBeAnalysis

import com.tgou.data.stanford.mail.core.MailSource
import org.apache.spark.sql.types._
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.joda.time.LocalDate

/**
  * Created by 刘洋 on 2018/04/19.
  */
object userModule {
  /**
    * 用户分析
    * @param spark
    * @param date
    * @return
    * */

  def query_1(spark: SparkSession, date: LocalDate): DataFrame = {

    val ysday = date.toString("yyyy-MM-dd")
    val lastFriday= date.minusDays(6).toString("yyyy-MM-dd")
    val thisFriday = date.plusDays(1).toString("yyyy-MM-dd")

    val funnel_1 = spark.read.json(s"/data/market/funnel/funnel_1/*/*/*/*")
    funnel_1.createTempView("funnel_1")

    val query_1 = spark.sql(
      s"""
        |select * from funnel_1
        | where
        | date >= '${lastFriday}'
        | and date < '${thisFriday}'
        | order by date desc,yt
      """.stripMargin
    )
    query_1
  }

  def query_2(spark: SparkSession, date: LocalDate): DataFrame = {

    val ysday = date.toString("yyyy-MM-dd")
    val lastFriday= date.minusDays(6).toString("yyyy-MM-dd")
    val thisFriday = date.plusDays(1).toString("yyyy-MM-dd")

    val funnel_2 = spark.read.json(s"/data/market/funnel/funnel_2/*/*/*/*")
    funnel_2.createTempView("funnel_2")

    val query_2 = spark.sql(
      s"""
        |select * from funnel_2
        | where
        | date >= '${lastFriday}'
        | and date < '${thisFriday}'
        | order by date desc,yt
      """.stripMargin
    )
    query_2
  }

  def query_3(spark: SparkSession, date: LocalDate): DataFrame = {

    val ysday = date.toString("yyyy-MM-dd")

    val funnel_3 = spark.read.json(s"/data/market/funnel/funnel_3/*/*/*/*")
    funnel_3.createTempView("funnel_3")

    val query_3 = spark.sql(
      s"""
        |select
        |date,nvl(path,' ') path,uv,uv_ratio,yt
        | from funnel_3
        | where
        | date ='${ysday}'
        | order by date desc,yt,uv desc
      """.stripMargin
    )
    query_3
  }
}
