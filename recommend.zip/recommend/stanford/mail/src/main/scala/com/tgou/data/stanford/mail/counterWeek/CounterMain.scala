package com.tgou.data.stanford.mail.counterWeek

import com.tgou.data.stanford.mail.core.MailBootstrap
import org.apache.spark.sql.{SaveMode, SparkSession}
import org.joda.time.LocalDate

/**
  * Created by 刘洋 on 2018/03/12.
  */

object CounterMain {


  def main(args: Array[String]): Unit = {
    MailBootstrap(args).bootstrap(execute)
  }

  def execute(spark: SparkSession, appName: String, date: LocalDate): Unit = {

    /**
      * 第一步 获取数据
      * */
    val result = CounterModule.queryDF(spark,date)
    /**
      * 第二步 保存数据到HDFS上
      * */
    result.coalesce(1).write.mode(SaveMode.Overwrite).json(s"/data/mail/counter_query/$date/")

    spark.stop()
  }
}