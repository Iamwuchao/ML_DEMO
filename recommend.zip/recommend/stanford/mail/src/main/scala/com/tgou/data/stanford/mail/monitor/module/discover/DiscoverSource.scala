package com.tgou.data.stanford.mail.monitor.module.discover

import org.apache.spark.sql.types._
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.joda.time.LocalDate

/**
  * Created by 李震 on 2017/9/27.
  */
class DiscoverSource(spark: SparkSession) {

  /**
    * 获取增量的 uba_page 数仓层数据
    *
    * @param date 日期
    *
    * @return
    *
    * 字段：
    *
    * - uuid  Server 端生成唯一标识
    * - a_b  主站页面
    * - jr  入口
    *
    * */
  def getAppendUbaPageDWDF(date: LocalDate): DataFrame = {
    spark.sql(
      s"""
        |select
        |    up.uuid,
        |    up.a_b,
        |    up.jr
        |from dw.uba_page up
        |where up.his_time = '${date.toString("yyyy-MM-dd")}'
      """.stripMargin)
  }

  /**
    * 获取增量的 uba_scp 数仓层数据
    *
    * @param date 日期
    *
    * @return
    *
    * 字段：
    *
    * - scp
    *
    * */
  def getAppendSCPDWDF(date: LocalDate): DataFrame = {
    spark.sql(
      s"""
        |select
        |    s.scp
        |from dw.uba_scp s
        |where s.his_time = '${date.toString("yyyy-MM-dd")}'
      """.stripMargin)
  }


  /**
    * 获取增量的 discover DW 层数据
    *
    * @param date 日期
    *
    * @return
    *
    * 字段：
    *
    * - discover_id  主键
    * - create_time  创建时间
    *
    * */
  def getAppendDiscoverDWDF(date: LocalDate): DataFrame = {
    spark.read.json(s"/tiangou/etl/json/discover-information-etl/${date.toString("yyyy/MM/dd")}")
      .select("discover_id", "create_time")
  }

}

object DiscoverSource {

  def apply(spark: SparkSession): DiscoverSource = new DiscoverSource(spark)

}