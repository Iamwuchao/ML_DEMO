package com.tgou.data.stanford.mail.core

import com.tgou.data.stanford.mail.core.utils.HDFSUtils
import org.apache.spark.sql.functions.{column, max}
import org.apache.spark.sql.types.StructType
import org.apache.spark.sql.{DataFrame, Row, SparkSession}
import org.joda.time.LocalDate

/**
  * Created by 李震 on 2017/11/8.
  */
object MailSource {

  /**
    * 获取全部历史数据
    *
    * @param spark SparkSession
    * @param path 数据根目录
    * @param date 截止日期
    * @param schema 指定数据 Schema
    *
    * @return
    *
    * */
  def getCompleteDF(spark: SparkSession, path: String, date: LocalDate, schema: StructType): DataFrame = {
    var df: DataFrame = spark.createDataFrame(spark.sparkContext.emptyRDD[Row], schema)

    for (year <- 2014 until date.getYear) {
      val dataPath = s"${path}/${year}"
      if (HDFSUtils.exists(dataPath)) {
        val csvDF = spark.read
          .options(Map(
            "delimiter" -> "^",
            "nullValue" -> "\\N",
            "quote" -> ""
          ))
          .schema(schema)
          .csv(dataPath + "/*/*")
        df = df.union(csvDF)
      }
    }

    for (month <- 1 until date.getMonthOfYear) {
      val dataPath = s"${path}/${date.getYear}/${"%02d".format(month)}"
      if (HDFSUtils.exists(dataPath)) {
        val csvDF = spark.read
          .options(Map(
            "delimiter" -> "^",
            "nullValue" -> "\\N",
            "quote" -> ""
          ))
          .schema(schema)
          .csv(dataPath + "/*")
        df = df.union(csvDF)
      }
    }

    for (day <- 1 to date.getDayOfMonth) {
      val dataPath = s"${path}/${date.getYear}/${"%02d".format(date.getMonthOfYear)}/${"%02d".format(day)}"
      if (HDFSUtils.exists(dataPath)) {
        val csvDF = spark.read
          .options(Map(
            "delimiter" -> "^",
            "nullValue" -> "\\N",
            "quote" -> ""
          ))
          .schema(schema)
          .csv(dataPath + "/*")
        df = df.union(csvDF)
      }
    }

    if (df != null) df else df
  }


  /**
    * 获取增量数据
    *
    * @param spark SparkSession
    * @param path 数据根目录
    * @param date 日期
    * @param schema 指定数据 Schema
    *
    * @return
    *
    * */
  def getAppendDF(spark: SparkSession, path: String, date: LocalDate, schema: StructType): DataFrame = {
    spark.read
      .options(Map(
        "delimiter" -> "^",
        "nullValue" -> "\\N",
        "quote" -> ""
      ))
      .schema(schema)
      .csv(s"${path}/${date.toString("yyyy/MM/dd")}")
  }


  /**
    * 获取全部历史最新数据
    *
    * @param spark SparkSession
    * @param path 数据根目录
    * @param date 截止日期
    * @param primaryKey 主键字段名
    * @param timestamp 时间戳字段名
    * @param schema 指定数据 Schema
    *
    * @return
    *
    * */
  def getUpdateDF(spark: SparkSession, path: String, date: LocalDate, primaryKey: Seq[String], timestamp: String, schema: StructType): DataFrame = {
    val completeDF = getCompleteDF(spark, path, date, schema)
    getNewestDF(completeDF, primaryKey, timestamp)
  }


  /**
    * 获取指定时间范围数据
    *
    * @param spark SparkSession
    * @param path 数据根目录
    * @param startDate 开始日期
    * @param endDate 结束日期
    * @param schema 指定数据 Schema
    *
    * @return
    *
    * */
  def getDurationDF(spark: SparkSession, path: String, startDate: LocalDate, endDate: LocalDate, schema: StructType): DataFrame = {
    var df: DataFrame = spark.createDataFrame(spark.sparkContext.emptyRDD[Row], schema)

    var date = startDate
    while (date.compareTo(endDate) <= 0) {
      val dataPath = s"${path}/${date.toString("yyyy/MM/dd")}"
      if (HDFSUtils.exists(dataPath)) {
        val csvDF = spark.read
          .options(Map(
            "delimiter" -> "^",
            "nullValue" -> "\\N",
            "quote" -> ""
          ))
          .schema(schema)
          .csv(dataPath + "/*")
        df = df.union(csvDF)
      }

      date = date.plusDays(1)
    }

    df
  }


  /**
    * 获取最新数据
    *
    * @param df 数据集
    * @param primaryKey 主键字段名
    * @param timestamp 时间戳字段名
    *
    * @return
    *
    * */
  def getNewestDF(df: DataFrame, primaryKey: Seq[String], timestamp: String): DataFrame = {
    df.join(df.groupBy(primaryKey.map(column): _*).agg(max(timestamp) as timestamp), primaryKey :+ timestamp)
  }

}
