package com.tgou.data.stanford.mail.monitor2.module.customerService

import org.apache.spark.sql.{DataFrame, SparkSession, functions}
import org.joda.time.LocalDate


/**
  * Created by 李磊 on 2017/12/04.
  * 天狗售后概况
  */


object CustomerServiceModule {
  /**
    * 字段：
    * - qqg_ksl  全球购-客诉量
    * - qqg_72fhl 全球购-72h发货率
    * - qqg_thl 全球购-订单退货率
    * - qqg_48thsll 全球购-48h退货受理率
    * - pps_ksl  品牌商-客诉量
    * - pps_48fhl 品牌商-48h发货率
    * - pps_thl 品牌商-订单退货率
    * - pps_48thsll 品牌商-48h退货受理率
    * - stmdps_ksl  实体门店物流配送-客诉量
    * - stmdps_48fhl 实体门店物流配送-48h发货率
    * - stmdps_thl 实体门店物流配送-订单退货率
    * - stmdps_48thsll 实体门店物流配送-48h退货受理率
    * - stmdzt_ksl  实体门店到店⾃提-客诉量
    * - stmdzt_thl 实体门店到店⾃提-订单退货率
    * */
  def getTansDF(spark:SparkSession, date: LocalDate): DataFrame = {


    val advisory = spark.read.format("csv")
      .option("delimiter", "^")
      .option("qoute", "")
      .option("nullValue", "\\N")
      .load(s"hdfs://nameservice1/tiangou/tgouorder/advisory/*/*/*/*")

    val advisoryS = advisory.select("_c0","_c2","_c3","_c19").toDF("id","create_time","fk_tgou_order_id","modify_time")

    val advisoryMax = advisoryS.groupBy("id").agg(functions.max("modify_time") as "modify_time")

    val advisoryY = advisoryS.join(advisoryMax,
      advisoryS("id") === advisoryMax("id")
        &&  advisoryS("modify_time") === advisoryMax("modify_time")
      ,"inner"
    ).select(
      advisoryS("create_time") ,
      advisoryS("fk_tgou_order_id")
    )


    advisoryY.createOrReplaceTempView("advisory_lilei")


    val returnRequest = spark.read.format("csv")
      .option("delimiter", "^")
      .option("qoute", "")
      .option("nullValue", "\\N")
      .load(s"hdfs://nameservice1/tiangou/tgouorder/return_request/*/*/*/*")

    val returnRequestS = returnRequest.select("_c0","_c9","_c11","_c19").toDF("id","state","fk_tgou_order_id","modify_time")

    val returnRequestMax = returnRequestS.groupBy("id").agg(functions.max("modify_time") as "modify_time")

    val returnRequestY = returnRequestS.join(returnRequestMax,
      returnRequestS("id") === returnRequestMax("id")
        &&  returnRequestS("modify_time") === returnRequestMax("modify_time")
      ,"inner"
    ).select(
      returnRequestS("id") ,
      returnRequestS("state") ,
      returnRequestS("fk_tgou_order_id") ,
      returnRequestS("modify_time")
    )



    val returnRequestYYS = returnRequestY.groupBy("id").agg(functions.max("fk_tgou_order_id") as "fk_tgou_order_id")

    returnRequestYYS.createOrReplaceTempView("return_request_lilei")


    val returnRequestFsmLog = spark.read.format("csv")
      .option("delimiter", "^")
      .option("qoute", "")
      .option("nullValue", "\\N")
      .load(s"hdfs://nameservice1/tiangou/tgouorder/return_request_fsm_log/*/*/*/*")

    val returnRequestFsmLogS = returnRequestFsmLog.select("_c0","_c1","_c2","_c3","_c4").toDF("id","enter_time","object_id","state_to","modify_time")

    val returnRequestFsmLogMax = returnRequestFsmLogS.groupBy("id").agg(functions.max("modify_time") as "modify_time")

    val returnRequestFsmLogY = returnRequestFsmLogS.join(returnRequestFsmLogMax,
      returnRequestFsmLogS("id") === returnRequestFsmLogMax("id")
        &&  returnRequestFsmLogS("modify_time") === returnRequestFsmLogMax("modify_time")
      ,"inner"
    ).select(
      returnRequestFsmLogS("enter_time") ,
      returnRequestFsmLogS("object_id") ,
      returnRequestFsmLogS("state_to")
    )


    val returnRequestFsmLogP = returnRequestFsmLogY.filter("state_to = 'Pending'").groupBy("object_id").agg(functions.min("enter_time") as "enter_time")

    returnRequestFsmLogP.createOrReplaceTempView("return_request_fsm_log_p_lilei")

    val returnRequestFsmLogC = returnRequestFsmLogY.filter("state_to != 'Pending'").groupBy("object_id").agg(functions.min("enter_time") as "enter_time")

    returnRequestFsmLogC.createOrReplaceTempView("return_request_fsm_log_c_lilei")

    /*
        * 全球购-客诉量
        * */
    val qqg_ksl = spark.sql(
      s"""
         |select count(distinct fk_tgou_order_id) as qqg_ksl
         |from advisory_lilei a
         |join dw.order_information  b
         |on a.fk_tgou_order_id = b.order_id
         |and b.his_time = '${date.toString("yyyy-MM-dd")}'
         |and b.order_source = 4
         |and b.order_type = '0'
         |join dw.store s
         |on b.store_id = s.id
         |and s.his_time = '${date.toString("yyyy-MM-dd")}'
         |and s.state = 'onshelf'
         |and s.yt = '4'
         |and s.is_international = '1'
         |where a.create_time >= '${date.toString("yyyy-MM-dd")}'
         |and a.create_time < date_sub('${date.toString("yyyy-MM-dd")}', -1)
      """.stripMargin)


    /*
      * 全球购-72h发货率
      * */
    val qqg_72fhl = spark.sql(
      s"""
         |select
         |nvl(cast((count(distinct case
         |when (unix_timestamp(b.ship_time) - unix_timestamp(b.pay_time)) <= 259200
         |then b.order_id end) /count(distinct b.order_id) * 100)   as decimal(18,2)),0) as qqg_72fhl
         |from dw.order_information  b
         |join dw.store s
         |on b.store_id = s.id
         |and s.his_time = '${date.toString("yyyy-MM-dd")}'
         |and s.state = 'onshelf'
         |and s.yt = '4'
         |and s.is_international = '1'
         | where b.his_time = '${date.toString("yyyy-MM-dd")}'
         |and b.order_source = 4
         |and b.order_type = '0'
         |and b.pay_method != '000'
         |and b.pay_method != '010'
         |and b.pay_time >= date_sub('${date.toString("yyyy-MM-dd")}',3)
         |and b.pay_time < date_sub('${date.toString("yyyy-MM-dd")}',2)
         |and isnull(b.cancel_time) = true
      """.stripMargin)


    /*
      * 全球购-订单退货率
      * */
    val qqg_thl = spark.sql(
      s"""
         |select nvl(round((de1.bs / de2.bs ) * 100,2),0) as qqg_thl
         |from (select count(distinct fk_tgou_order_id) as bs, 1 as ff
         |from return_request_lilei  a
         |join return_request_fsm_log_p_lilei aa
         |on aa.object_id = a.id
         |and  aa.enter_time >= '${date.toString("yyyy-MM-dd")}'
         |and aa.enter_time < date_sub('${date.toString("yyyy-MM-dd")}', -1)
         |join dw.order_information  b
         |on a.fk_tgou_order_id = b.order_id
         |and b.his_time = '${date.toString("yyyy-MM-dd")}'
         |and b.order_source = 4
         |and b.order_type = '0'
         |and b.pay_method != '000'
         |and b.pay_method != '010'
         |join dw.store s
         |on b.store_id = s.id
         |and s.his_time = '${date.toString("yyyy-MM-dd")}'
         |and s.state = 'onshelf'
         |and s.yt = '4'
         |and s.is_international = '1') de1
         |join
         |(select count(distinct order_id) as bs, 1 as ff
         |from dw.order_information  b
         |join dw.store s
         |on b.store_id = s.id
         |and s.his_time = '${date.toString("yyyy-MM-dd")}'
         |and s.state = 'onshelf'
         |and s.yt = '4'
         |and s.is_international = '1'
         |where  b.his_time = '${date.toString("yyyy-MM-dd")}'
         |and b.order_source = 4
         |and b.order_type = '0'
         |and b.pay_method != '000'
         |and b.pay_method != '010'
         |and b.ship_time >= '${date.toString("yyyy-MM-dd")}'
         |and b.ship_time < date_sub('${date.toString("yyyy-MM-dd")}', -1)) de2
         |on de1.ff= de2.ff
      """.stripMargin)



    /*
      * 全球购-48h退货受理率
      * */
    val qqg_48thsll = spark.sql(
      s"""
         |select case when mm = 0 then '--' else nvl(cast(zz/mm * 100 as decimal(18,2)),0)  end  as qqg_48thsll
         |from (select count(distinct case
         |when (unix_timestamp(s1.enter_time) - unix_timestamp(s2.enter_time)) <= 172800
         |then s2.fk_tgou_order_id end) as zz,
         |count(distinct s2.fk_tgou_order_id) as mm
         |from(select aaa.fk_tgou_order_id,y1.enter_time
         |from (select object_id,max(a.enter_time) as enter_time
         |from return_request_fsm_log_p_lilei  a
         |where a.enter_time >= date_sub('${date.toString("yyyy-MM-dd")}',2)
         |and a.enter_time < date_sub('${date.toString("yyyy-MM-dd")}',1)
         |group by object_id) y1
         |join return_request_lilei aaa
         |on aaa.id = y1.object_id
         |join dw.order_information  b
         |on aaa.fk_tgou_order_id = b.order_id
         |and b.his_time = '${date.toString("yyyy-MM-dd")}'
         |and b.order_source = 4
         |and b.order_type = '0'
         |and b.pay_method != '000'
         |and b.pay_method != '010'
         |join dw.store s
         |on b.store_id = s.id
         |and s.his_time = '${date.toString("yyyy-MM-dd")}'
         |and s.state = 'onshelf'
         |and s.yt = '4'
         |and s.is_international = '1') s2
         |left join  (select aaa.fk_tgou_order_id,y2.enter_time
         |from (select object_id
         |from return_request_fsm_log_p_lilei  a
         |where a.enter_time >= date_sub('${date.toString("yyyy-MM-dd")}',2)
         |and a.enter_time < date_sub('${date.toString("yyyy-MM-dd")}',1)
         |group by object_id) y1
         |join (select object_id,min(a.enter_time) as enter_time
         |from return_request_fsm_log_c_lilei  a
         |where a.enter_time >= date_sub('${date.toString("yyyy-MM-dd")}',2)
         |group by object_id) y2
         |on y1.object_id = y2.object_id
         |join return_request_lilei aaa
         |on aaa.id = y2.object_id
         |join dw.order_information  b
         |on aaa.fk_tgou_order_id = b.order_id
         |and b.his_time = '${date.toString("yyyy-MM-dd")}'
         |and b.order_source = 4
         |and b.order_type = '0'
         |and b.pay_method != '000'
         |and b.pay_method != '010'
         |join dw.store s
         |on b.store_id = s.id
         |and s.his_time = '${date.toString("yyyy-MM-dd")}'
         |and s.state = 'onshelf'
         |and s.yt = '4'
         |and s.is_international = '1') s1
         |on s1.fk_tgou_order_id = s2.fk_tgou_order_id)
      """.stripMargin)


    /*
        * 品牌商-客诉量
        * */
    val pps_ksl = spark.sql(
      s"""
         |select count(distinct fk_tgou_order_id) as pps_ksl
         |from advisory_lilei a
         |join dw.order_information  b
         |on a.fk_tgou_order_id = b.order_id
         |and b.his_time = '${date.toString("yyyy-MM-dd")}'
         |and b.order_source = 4
         |and b.order_type = '0'
         |join dw.store s
         |on b.store_id = s.id
         |and s.his_time = '${date.toString("yyyy-MM-dd")}'
         |and s.state = 'onshelf'
         |and s.yt = '4'
         |and s.is_international = '0'
         |where a.create_time >= '${date.toString("yyyy-MM-dd")}'
         |and a.create_time < date_sub('${date.toString("yyyy-MM-dd")}', -1)
      """.stripMargin)


    /*
      * 品牌商-48h发货率
      * */
    val pps_48fhl = spark.sql(
      s"""
         |select
         |nvl(cast((count(distinct case
         |when (unix_timestamp(b.ship_time) - unix_timestamp(b.pay_time)) <= 172800
         |then b.order_id end) /count(distinct b.order_id) * 100)   as decimal(18,2)),0) as pps_48fhl
         |from dw.order_information  b
         |join dw.store s
         |on b.store_id = s.id
         |and s.his_time = '${date.toString("yyyy-MM-dd")}'
         |and s.state = 'onshelf'
         |and s.yt = '4'
         |and s.is_international = '0'
         | where b.his_time = '${date.toString("yyyy-MM-dd")}'
         |and b.order_source = 4
         |and b.order_type = '0'
         |and b.pay_method != '000'
         |and b.pay_method != '010'
         |and b.pay_time >= date_sub('${date.toString("yyyy-MM-dd")}',2)
         |and b.pay_time < date_sub('${date.toString("yyyy-MM-dd")}',1)
         |and isnull(b.cancel_time) = true
      """.stripMargin)


    /*
      * 品牌商-订单退货率
      * */
    val pps_thl = spark.sql(
      s"""
         |select nvl(round((de1.bs / de2.bs ) * 100,2),0) as pps_thl
         |from (select count(distinct fk_tgou_order_id) as bs, 1 as ff
         |from return_request_lilei  a
         |join return_request_fsm_log_p_lilei aa
         |on aa.object_id = a.id
         |and  aa.enter_time >= '${date.toString("yyyy-MM-dd")}'
         |and aa.enter_time < date_sub('${date.toString("yyyy-MM-dd")}', -1)
         |join dw.order_information  b
         |on a.fk_tgou_order_id = b.order_id
         |and b.his_time = '${date.toString("yyyy-MM-dd")}'
         |and b.order_source = 4
         |and b.order_type = '0'
         |and b.pay_method != '000'
         |and b.pay_method != '010'
         |join dw.store s
         |on b.store_id = s.id
         |and s.his_time = '${date.toString("yyyy-MM-dd")}'
         |and s.state = 'onshelf'
         |and s.yt = '4'
         |and s.is_international = '0') de1
         |join
         |(select count(distinct order_id) as bs, 1 as ff
         |from dw.order_information  b
         |join dw.store s
         |on b.store_id = s.id
         |and s.his_time = '${date.toString("yyyy-MM-dd")}'
         |and s.state = 'onshelf'
         |and s.yt = '4'
         |and s.is_international = '0'
         |where  b.his_time = '${date.toString("yyyy-MM-dd")}'
         |and b.order_source = 4
         |and b.order_type = '0'
         |and b.pay_method != '000'
         |and b.pay_method != '010'
         |and b.ship_time >= '${date.toString("yyyy-MM-dd")}'
         |and b.ship_time < date_sub('${date.toString("yyyy-MM-dd")}', -1)) de2
         |on de1.ff= de2.ff
      """.stripMargin)



    /*
      * 品牌商-48h退货受理率
      * */
    val pps_48thsll = spark.sql(
      s"""
         |select case when mm = 0 then '--' else nvl(cast(zz/mm * 100 as decimal(18,2)),0)  end as pps_48thsll
         |from (select count(distinct case
         |when (unix_timestamp(s1.enter_time) - unix_timestamp(s2.enter_time)) <= 172800
         |then s2.fk_tgou_order_id end) as zz,
         |count(distinct s2.fk_tgou_order_id) as mm
         |from(select aaa.fk_tgou_order_id,y1.enter_time
         |from (select object_id,max(a.enter_time) as enter_time
         |from return_request_fsm_log_p_lilei  a
         |where a.enter_time >= date_sub('${date.toString("yyyy-MM-dd")}',2)
         |and a.enter_time < date_sub('${date.toString("yyyy-MM-dd")}',1)
         |group by object_id) y1
         |join return_request_lilei aaa
         |on aaa.id = y1.object_id
         |join dw.order_information  b
         |on aaa.fk_tgou_order_id = b.order_id
         |and b.his_time = '${date.toString("yyyy-MM-dd")}'
         |and b.order_source = 4
         |and b.order_type = '0'
         |and b.pay_method != '000'
         |and b.pay_method != '010'
         |join dw.store s
         |on b.store_id = s.id
         |and s.his_time = '${date.toString("yyyy-MM-dd")}'
         |and s.state = 'onshelf'
         |and s.yt = '4'
         |and s.is_international = '0') s2
         |left join  (select aaa.fk_tgou_order_id,y2.enter_time
         |from (select object_id
         |from return_request_fsm_log_p_lilei  a
         |where a.enter_time >= date_sub('${date.toString("yyyy-MM-dd")}',2)
         |and a.enter_time < date_sub('${date.toString("yyyy-MM-dd")}',1)
         |group by object_id) y1
         |join (select object_id,min(a.enter_time) as enter_time
         |from return_request_fsm_log_c_lilei  a
         |where a.enter_time >= date_sub('${date.toString("yyyy-MM-dd")}',2)
         |group by object_id) y2
         |on y1.object_id = y2.object_id
         |join return_request_lilei aaa
         |on aaa.id = y2.object_id
         |join dw.order_information  b
         |on aaa.fk_tgou_order_id = b.order_id
         |and b.his_time = '${date.toString("yyyy-MM-dd")}'
         |and b.order_source = 4
         |and b.order_type = '0'
         |and b.pay_method != '000'
         |and b.pay_method != '010'
         |join dw.store s
         |on b.store_id = s.id
         |and s.his_time = '${date.toString("yyyy-MM-dd")}'
         |and s.state = 'onshelf'
         |and s.yt = '4'
         |and s.is_international = '0') s1
         |on s1.fk_tgou_order_id = s2.fk_tgou_order_id)
      """.stripMargin)

    /*
        * 实体门店物流配送-客诉量
        * */
    val stmdps_ksl = spark.sql(
      s"""
         |select count(distinct fk_tgou_order_id) as stmdps_ksl
         |from advisory_lilei a
         |join dw.order_information  b
         |on a.fk_tgou_order_id = b.order_id
         |and b.his_time = '${date.toString("yyyy-MM-dd")}'
         |and b.order_source in ( '1','2')
         |and b.order_type = '0'
         |and b.receive_method = '10'
         |where a.create_time >= '${date.toString("yyyy-MM-dd")}'
         |and a.create_time < date_sub('${date.toString("yyyy-MM-dd")}', -1)
      """.stripMargin)


    /*
      * 实体门店物流配送-48h发货率
      * */
    val stmdps_48fhl = spark.sql(
      s"""
         |select
         |nvl(cast((count(distinct case
         |when (unix_timestamp(b.ship_time) - unix_timestamp(b.pay_time)) <= 172800
         |then b.order_id end) /count(distinct b.order_id) * 100)   as decimal(18,2)),0) as stmdps_48fhl
         |from dw.order_information  b
         | where b.his_time = '${date.toString("yyyy-MM-dd")}'
         |and b.order_source in ( '1','2')
         |and b.order_type = '0'
         |and b.pay_method != '000'
         |and b.pay_method != '010'
         |and b.receive_method = '10'
         |and b.pay_time >= date_sub('${date.toString("yyyy-MM-dd")}',2)
         |and b.pay_time < date_sub('${date.toString("yyyy-MM-dd")}',1)
         |and isnull(b.cancel_time) = true
      """.stripMargin)


    /*
      * 实体门店物流配送-订单退货率
      * */
    val stmdps_thl = spark.sql(
      s"""
         |select nvl(round((de1.bs / de2.bs ) * 100,2),0) as stmdps_thl
         |from (select count(distinct fk_tgou_order_id) as bs, 1 as ff
         |from return_request_lilei  a
         |join return_request_fsm_log_p_lilei aa
         |on aa.object_id = a.id
         |and  aa.enter_time >= '${date.toString("yyyy-MM-dd")}'
         |and aa.enter_time < date_sub('${date.toString("yyyy-MM-dd")}', -1)
         |join dw.order_information  b
         |on a.fk_tgou_order_id = b.order_id
         |and b.his_time = '${date.toString("yyyy-MM-dd")}'
         |and b.order_source in ( '1','2')
         |and b.order_type = '0'
         |and b.pay_method != '000'
         |and b.pay_method != '010'
         |and b.receive_method = '10') de1
         |join
         |(select count(distinct order_id) as bs, 1 as ff
         |from dw.order_information  b
         |where  b.his_time = '${date.toString("yyyy-MM-dd")}'
         |and b.order_source in ( '1','2')
         |and b.order_type = '0'
         |and b.pay_method != '000'
         |and b.pay_method != '010'
         |and b.receive_method = '10'
         |and b.ship_time >= '${date.toString("yyyy-MM-dd")}'
         |and b.ship_time < date_sub('${date.toString("yyyy-MM-dd")}', -1)) de2
         |on de1.ff= de2.ff
      """.stripMargin)



    /*
      * 实体门店物流配送-48h退货受理率
      * */
    val stmdps_48thsll = spark.sql(
      s"""
         |select case when mm = 0 then '--' else nvl(cast(zz/mm * 100 as decimal(18,2)),0)  end  as stmdps_48thsll
         |from (select count(distinct case
         |when (unix_timestamp(s1.enter_time) - unix_timestamp(s2.enter_time)) <= 172800
         |then s2.fk_tgou_order_id end) as zz,
         |count(distinct s2.fk_tgou_order_id) as mm
         |from(select aaa.fk_tgou_order_id,y1.enter_time
         |from (select object_id,max(a.enter_time) as enter_time
         |from return_request_fsm_log_p_lilei  a
         |where a.enter_time >= date_sub('${date.toString("yyyy-MM-dd")}',2)
         |and a.enter_time < date_sub('${date.toString("yyyy-MM-dd")}',1)
         |group by object_id) y1
         |join return_request_lilei aaa
         |on aaa.id = y1.object_id
         |join dw.order_information  b
         |on aaa.fk_tgou_order_id = b.order_id
         |and b.his_time = '${date.toString("yyyy-MM-dd")}'
         |and b.order_source in ( '1','2')
         |and b.order_type = '0'
         |and b.pay_method != '000'
         |and b.pay_method != '010'
         |and b.receive_method = '10') s2
         |left join  (select aaa.fk_tgou_order_id,y2.enter_time
         |from (select object_id
         |from return_request_fsm_log_p_lilei  a
         |where a.enter_time >= date_sub('${date.toString("yyyy-MM-dd")}',2)
         |and a.enter_time < date_sub('${date.toString("yyyy-MM-dd")}',1)
         |group by object_id) y1
         |join (select object_id,min(a.enter_time) as enter_time
         |from return_request_fsm_log_c_lilei  a
         |where a.enter_time >= date_sub('${date.toString("yyyy-MM-dd")}',2)
         |group by object_id) y2
         |on y1.object_id = y2.object_id
         |join return_request_lilei aaa
         |on aaa.id = y2.object_id
         |join dw.order_information  b
         |on aaa.fk_tgou_order_id = b.order_id
         |and b.his_time = '${date.toString("yyyy-MM-dd")}'
         |and b.order_source in ( '1','2')
         |and b.order_type = '0'
         |and b.pay_method != '000'
         |and b.pay_method != '010'
         |and b.receive_method = '10') s1
         |on s1.fk_tgou_order_id = s2.fk_tgou_order_id)
      """.stripMargin)


    /*
        * 实体门店到店自提-客诉量
        * */
    val stmdzt_ksl = spark.sql(
      s"""
         |select count(distinct fk_tgou_order_id) as stmdzt_ksl
         |from advisory_lilei a
         |join dw.order_information  b
         |on a.fk_tgou_order_id = b.order_id
         |and b.his_time = '${date.toString("yyyy-MM-dd")}'
         |and b.order_source in ( '1','2')
         |and b.order_type = '0'
         |and b.receive_method in ('00', '01')
         |where a.create_time >= '${date.toString("yyyy-MM-dd")}'
         |and a.create_time < date_sub('${date.toString("yyyy-MM-dd")}', -1)
      """.stripMargin)

    /*
      * 实体门店到店自提-订单退货率
      * */
    val stmdzt_thl = spark.sql(
      s"""
         |select nvl(round((de1.bs / de2.bs ) * 100,2),0) as stmdzt_thl
         |from (select count(distinct fk_tgou_order_id) as bs, 1 as ff
         |from return_request_lilei  a
         |join return_request_fsm_log_p_lilei aa
         |on aa.object_id = a.id
         |and  aa.enter_time >= '${date.toString("yyyy-MM-dd")}'
         |and aa.enter_time < date_sub('${date.toString("yyyy-MM-dd")}', -1)
         |join dw.order_information  b
         |on a.fk_tgou_order_id = b.order_id
         |and b.his_time = '${date.toString("yyyy-MM-dd")}'
         |and b.order_source in ( '1','2')
         |and b.order_type = '0'
         |and b.pay_method != '000'
         |and b.pay_method != '010'
         |and b.receive_method in ('00', '01')) de1
         |join
         |(select count(distinct order_id) as bs, 1 as ff
         |from dw.order_information  b
         |where  b.his_time = '${date.toString("yyyy-MM-dd")}'
         |and b.order_source in ( '1','2')
         |and b.order_type = '0'
         |and b.pay_method != '000'
         |and b.pay_method != '010'
         |and b.receive_method in ('00', '01')
         |and b.ship_time >= '${date.toString("yyyy-MM-dd")}'
         |and b.ship_time < date_sub('${date.toString("yyyy-MM-dd")}', -1)) de2
         |on de1.ff= de2.ff
      """.stripMargin)

    val rs = qqg_ksl.crossJoin(qqg_72fhl)
      .crossJoin(qqg_thl)
      .crossJoin(qqg_48thsll)
      .crossJoin(pps_ksl)
      .crossJoin(pps_48fhl)
      .crossJoin(pps_thl)
      .crossJoin(pps_48thsll)
      .crossJoin(stmdps_ksl)
      .crossJoin(stmdps_48fhl)
      .crossJoin(stmdps_thl)
      .crossJoin(stmdps_48thsll)
      .crossJoin(stmdzt_ksl)
      .crossJoin(stmdzt_thl)
      .select(
        "qqg_ksl",
        "qqg_72fhl",
        "qqg_thl",
        "qqg_48thsll",
        "pps_ksl",
        "pps_48fhl",
        "pps_thl",
        "pps_48thsll",
        "stmdps_ksl",
        "stmdps_48fhl",
        "stmdps_thl",
        "stmdps_48thsll",
        "stmdzt_ksl",
        "stmdzt_thl"
      )

    return rs
  }
}