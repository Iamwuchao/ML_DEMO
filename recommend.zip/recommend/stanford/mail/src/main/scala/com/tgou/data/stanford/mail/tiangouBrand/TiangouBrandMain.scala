package com.tgou.data.stanford.mail.tiangouBrand

import com.tgou.data.stanford.mail.core.MailBootstrap
import com.tgou.data.stanford.mail.tiangouBrand.module.{TiangouBrandDetailSum, TiangouBrandSum, TiangouGroupSum}
import org.apache.spark.sql.{SaveMode, SparkSession}
import org.joda.time.LocalDate

/**
  * Created by 张少锐 on 2017/12/18.
  * 天狗品牌邮件报表周报，月报，月初第一周统计
  */

object TiangouBrandMain {

  def main(args: Array[String]): Unit = {
    MailBootstrap(args).bootstrap(execute)
  }

  def execute(spark: SparkSession, appName: String, date: LocalDate): Unit = {

    //啤酒，澳牛，茶叶，红酒
    val beerBrandID = "'34859'"
    val cowBrandID  = "'26638','28909','35080'"
    val teaStoreID  = "'1519'"
    val wineStoreID = "'1267'"

    /**
      * 第一步 获取数据
      * */

    //天狗百货品牌汇总表
    val brand = TiangouBrandSum.getTiangouBrandSum(spark,appName,date)

    //集团品牌/店铺销售数据
    val beerBrand = TiangouGroupSum.getTiangouBrandSum(spark,appName,date,beerBrandID,"啤酒")
    val cowBrand = TiangouGroupSum.getTiangouBrandSum(spark,appName,date,cowBrandID,"澳牛")
    val teaStore = TiangouGroupSum.getTiangouStoreSum(spark,appName,date,teaStoreID,"茶叶")
    val wineStore = TiangouGroupSum.getTiangouStoreSum(spark,appName,date,wineStoreID,"红酒")

    //百货品牌订单明细表
    val brandDetail = TiangouBrandDetailSum.getTiangouBrandDetailSum(spark,appName,date)

    /**
      * 第二步 保存数据到HDFS上
      * */
    brand.coalesce(1).write.mode(SaveMode.Overwrite).json(s"/data/mail/tiangou_brand/brand/${appName}/$date/")
    beerBrand.coalesce(1).write.mode(SaveMode.Overwrite).json(s"/data/mail/tiangou_brand/group/beer/${appName}/$date/")
    cowBrand.coalesce(1).write.mode(SaveMode.Overwrite).json(s"/data/mail/tiangou_brand/group/cow/${appName}/$date/")
    teaStore.coalesce(1).write.mode(SaveMode.Overwrite).json(s"/data/mail/tiangou_brand/group/tea/${appName}/$date/")
    wineStore.coalesce(1).write.mode(SaveMode.Overwrite).json(s"/data/mail/tiangou_brand/group/wine/${appName}/$date/")
    brandDetail.coalesce(1).write.mode(SaveMode.Overwrite).json(s"/data/mail/tiangou_brand/brandDetail/${appName}/$date/")

  }
}
