package com.tgou.data.stanford.mail.tiangouPaymnet

import com.tgou.data.stanford.mail.core.MailBootstrap
import com.tgou.data.stanford.mail.tiangouPaymnet.module.{TiangouPaymentGeneral, TiangouPaymentLogistics, TiangouPaymentMethod}
import org.apache.spark.sql.{SaveMode, SparkSession}
import org.joda.time.LocalDate

/**
  * Created by 李磊 on 2017/11/16.
  * 天狗支付
  */

object TiangouPaymentMain {
  def main(args: Array[String]): Unit = {
    MailBootstrap(args).bootstrap(execute)
  }

  def execute(spark: SparkSession, appName: String, date: LocalDate): Unit = {

    /**
      * 第一步 获取数据
      * */
    //天狗支付概况
    val paymentGeneral =  TiangouPaymentGeneral.getTansDF(spark, date)
    //天狗支付物流
    val paymentLogistics = TiangouPaymentLogistics.getTansDF(spark,date)
    //天狗支付方式
    val paymentMethod = TiangouPaymentMethod.getTansDF(spark,date)


    /**
      * 第二步 拼接数据
      * */
    val result = paymentGeneral
      .crossJoin(paymentLogistics)
      .crossJoin(paymentMethod)

    /**
      * 第三步 保存数据到HDFS上
      * */
    result.write.mode(SaveMode.Overwrite).json(s"/data/mail/payment/$date/")
    spark.stop()

  }
}