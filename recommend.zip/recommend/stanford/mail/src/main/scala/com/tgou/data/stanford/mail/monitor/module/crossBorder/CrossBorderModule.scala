package com.tgou.data.stanford.mail.monitor.module.crossBorder

import org.apache.spark.sql.{DataFrame, SparkSession}
import org.joda.time.LocalDate

/**
  * Created by 刘洋 on 2017/11/13.
  */
object CrossBorderModule {

  /**
    * 跨境交易
    *
    * @param spark
    * @param date
    *
    * @return
    *
    * 天狗跨境购--国外
    * - xdbs 当日下单笔数
    * - xdrs 当日下单人数
    * - xdsps 当日下单商品数量
    * - xdje 当日下单总金额
    * - zfbs 当日支付笔数
    * - zfrs 当日支付人数
    * - zfje 当日支付总金额
    * - psbs 当日配送订单笔数
    * - psje 当日配送订单金额
    * - xdjem 当月累计下单金额
    * - zfjem 当月累计支付金额
    *
    * */
    def getInternationalDF(spark:SparkSession, date: LocalDate): DataFrame = {

    val month = date.withDayOfMonth(1).toString("yyyy-MM-dd")
    val yesday = date.toString("yyyy-MM-dd")


    /* xdbs 当日下单笔数
     * xdrs 当日下单人数
     * xdsps 当日下单商品数量
     * xdje 当日下单总金额
     * */
    val tgxd = spark.sql(
      s"""
         |select a1.bs as xdbs,
         |a1.rs as xdrs,
         |nvl(cast(a1.je as decimal(18,2)),0)  as xdje
         |from (select count(order_id) bs,
         |count(distinct member_id) rs,
         |sum(total_amount) je,
         |1 as d
         |from dw.order_information t
         |inner join dw.store s
         |on t.store_id = s.id
         |and s.state = 'onshelf'
         |and s.is_international = '1'
         |and s.his_time = '${yesday}'
         |where t.his_time = '${yesday}'
         |and t.order_source in ('3','4')
         |and t.create_time >= concat('${yesday}', ' 00:00:00')
         |and t.create_time < concat(date_format(date_sub('${yesday}', -1), 'yyyy-MM-dd'),' 00:00:00')) a1
      """.stripMargin)

      /*
       * xdsps 当日下单商品数量
       * */
      val xdsps=spark.sql(
        s"""
           |select sum(b.product_quantity) xdsps
           |from  dw.order_product b
           |join dw.order_information t
           |on b.tgou_order_id = t.order_id
           |and t.his_time = '${yesday}'
           |and t.order_source in ('3','4')
           |and t.create_time >= concat('${yesday}', ' 00:00:00')
           |and t.create_time < concat(date_format(date_sub('${yesday}', -1), 'yyyy-MM-dd'),' 00:00:00')
           |join dw.store s
           |on t.store_id = s.id
           |and s.state = 'onshelf'
           |and s.is_international = '1'
           |and s.his_time = '${yesday}'
           |where b.his_time = '${yesday}'
           |and b.product_source in ('3','4')
           |and b.create_time >= concat('${yesday}', ' 00:00:00')
           |and b.create_time < concat(date_format(date_sub('${yesday}', -1), 'yyyy-MM-dd'),' 00:00:00')
         """.stripMargin
      )


    /*
     * zfbs 当日支付笔数
     *  zfrs 当日支付人数
     *  zfje 当日支付总金额
     * */
    val tgzf = spark.sql(
      s"""
         |select count(order_id) as  zfbs ,
         |count(distinct member_id) as  zfrs,
         |nvl(cast(sum(total_amount) as decimal(18,2)),0) as zfje
         |from dw.order_information t
         |inner join dw.store s
         |on t.store_id = s.id
         |and s.state = 'onshelf'
         |and s.is_international = '1'
         |and s.his_time = '${yesday}'
         |where t.his_time = '${yesday}'
         |and t.order_source in ('3','4')
         |and t.pay_time >= concat('${yesday}', ' 00:00:00')
         |and t.pay_time < concat(date_format(date_sub('${yesday}', -1), 'yyyy-MM-dd'),' 00:00:00')
      """.stripMargin)

    /*
     * psbs 当日配送订单笔数
     * psje 当日配送订单金额
     * */
    val tgps = spark.sql(
      s"""
         |select count(order_id) as psbs,
         |nvl(cast(sum(total_amount) as decimal(18,2)),0)  as psje
         |from dw.order_information t
         |inner join dw.store s
         |on t.store_id = s.id
         |and s.state = 'onshelf'
         |and s.is_international = '1'
         |and s.his_time = '${yesday}'
         |where t.his_time =  '${yesday}'
         |and t.order_source in ('3','4')
         |and t.ship_time >= concat('${yesday}', ' 00:00:00')
         |and t.ship_time < concat(date_format(date_sub('${yesday}', -1), 'yyyy-MM-dd'),' 00:00:00')
         |and t.receive_method = '10'
      """.stripMargin)

    /*
     * xdjem 当月累计下单金额
     * */
    val tgxdm = spark.sql(
      s"""
         |select
         |nvl(cast(sum(total_amount) as decimal(18,2)),0)  xdjem
         |from dw.order_information t
         |inner join dw.store s
         |on t.store_id = s.id
         |and s.state = 'onshelf'
         |and s.is_international = '1'
         |and s.his_time = '${yesday}'
         |where t.his_time = '${yesday}'
         |and t.order_source in ('3','4')
         |and t.create_time >= concat('${month}', ' 00:00:00')
         |and t.create_time < concat(date_format(date_sub('${yesday}', -1), 'yyyy-MM-dd'),' 00:00:00')
      """.stripMargin)


    /*
     *  zfjem 当月累计支付金额
     * */
    val tgzfm = spark.sql(
      s"""
         |select
         |nvl(cast(sum(total_amount) as decimal(18,2)),0)  zfjem
         |from dw.order_information t
         |inner join dw.store s
         |on t.store_id = s.id
         |and s.state = 'onshelf'
         |and s.is_international = '1'
         |and s.his_time = '${yesday}'
         |where t.his_time = '${yesday}'
         |and t.order_source in ('3','4')
         |and t.pay_time >= concat('${month}', ' 00:00:00')
         |and t.pay_time < concat(date_format(date_sub('${yesday}', -1), 'yyyy-MM-dd'),' 00:00:00')
      """.stripMargin)

     val crossBorderInternational = tgxd.crossJoin(tgzf)
       .crossJoin(xdsps)
       .crossJoin(tgps)
       .crossJoin(tgxdm)
       .crossJoin(tgzfm)
         .select("xdbs",
           "xdrs",
           "xdje",
           "xdsps",
           "zfbs",
           "zfrs",
           "zfje",
           "psbs",
           "psje",
           "xdjem",
           "zfjem"
     )

      crossBorderInternational
  }

  /**
       * - 天狗跨境购--国内
       * - gnxdbs 当日下单笔数
       * - gnxdrs 当日下单人数
       * - gnxdsps 当日下单商品数量
       * - gnxdje 当日下单总金额
       * - gnzfbs 当日支付笔数
       * - gnzfrs 当日支付人数
       * - gnzfje 当日支付总金额
       * - gnpsbs 当日配送订单笔数
       * - gnpsje 当日配送订单金额
       * - gnxdjem 当月累计下单金额
       * - gnzfjem 当月累计支付金额
       **/

  def getDomesticDF(spark:SparkSession, date: LocalDate): DataFrame = {

    val month = date.withDayOfMonth(1).toString("yyyy-MM-dd")
    val yesday = date.toString("yyyy-MM-dd")

    /* *
   * gnxdbs 当日下单笔数
   * gnxdrs 当日下单人数
   * gnxdje 当日下单总金额
   * */
    val tgxd = spark.sql(
      s"""
         |select a1.bs as gnxdbs,
         |a1.rs as gnxdrs ,
         |nvl(cast(a1.je as decimal(18,2)),0)  as gnxdje
         |from (select count(order_id) bs,
         |count(distinct member_id) rs,
         |sum(total_amount) je,
         |1 as d
         |from dw.order_information t
         |inner join dw.store s
         |on t.store_id = s.id
         |and s.state = 'onshelf'
         |and s.is_international = '0'
         |and s.his_time = '${yesday}'
         |where t.his_time = '${yesday}'
         |and t.order_source in ('3','4')
         |and t.create_time >= concat('${yesday}', ' 00:00:00')
         |and t.create_time < concat(date_format(date_sub('${yesday}', -1), 'yyyy-MM-dd'),' 00:00:00')) a1
      """.stripMargin)

    /*
     * gnxdsps 当日下单商品数量
     * */
    val gnxdsps=spark.sql(
      s"""
         |select sum(b.product_quantity) gnxdsps
         |from  dw.order_product b
         |join dw.order_information t
         |on b.tgou_order_id = t.order_id
         |and t.his_time = '${yesday}'
         |and t.order_source in ('3','4')
         |and t.create_time >= concat('${yesday}', ' 00:00:00')
         |and t.create_time < concat(date_format(date_sub('${yesday}', -1), 'yyyy-MM-dd'),' 00:00:00')
         |join dw.store s
         |on t.store_id = s.id
         |and s.state = 'onshelf'
         |and s.is_international = '0'
         |and s.his_time = '${yesday}'
         |where b.his_time = '${yesday}'
         |and b.product_source in ('3','4')
         |and b.create_time >= concat('${yesday}', ' 00:00:00')
         |and b.create_time < concat(date_format(date_sub('${yesday}', -1), 'yyyy-MM-dd'),' 00:00:00')
         """.stripMargin
    )


    /*
    *  gnzfbs 当日支付笔数
    *  gnzfrs 当日支付人数
    *  gnzfje 当日支付总金额
    * */
    val tgzf = spark.sql(
      s"""
         |select count(order_id) as  gnzfbs ,
         |count(distinct member_id) as  gnzfrs,
         |nvl(cast(sum(total_amount) as decimal(18,2)),0) as gnzfje
         |from dw.order_information t
         |inner join dw.store s
         |on t.store_id = s.id
         |and s.state = 'onshelf'
         |and s.is_international = '0'
         |and s.his_time = '${yesday}'
         |where t.his_time = '${yesday}'
         |and t.order_source in ('3','4')
         |and t.pay_time >= concat('${yesday}', ' 00:00:00')
         |and t.pay_time < concat(date_format(date_sub('${yesday}', -1), 'yyyy-MM-dd'),' 00:00:00')
      """.stripMargin)

    /*
    * gnpsbs 当日配送订单笔数
    * gnpsje 当日配送订单金额
    * */
    val tgps = spark.sql(
      s"""
         |select count(order_id) as gnpsbs,
         |nvl(cast(sum(total_amount) as decimal(18,2)),0)  as gnpsje
         |from dw.order_information t
         |inner join dw.store s
         |on t.store_id = s.id
         |and s.state = 'onshelf'
         |and s.is_international = '0'
         |and s.his_time = '${yesday}'
         |where t.his_time =  '${yesday}'
         |and t.order_source in ('3','4')
         |and t.ship_time >= concat('${yesday}', ' 00:00:00')
         |and t.ship_time < concat(date_format(date_sub('${yesday}', -1), 'yyyy-MM-dd'),' 00:00:00')
         |and t.receive_method = '10'
      """.stripMargin)

    /*
     * gnxdjem 当月累计下单金额
     * */
    val tgxdm = spark.sql(
      s"""
         |select
         |nvl(cast(sum(total_amount) as decimal(18,2)),0)  gnxdjem
         |from dw.order_information t
         |inner join dw.store s
         |on t.store_id = s.id
         |and s.state = 'onshelf'
         |and s.is_international = '0'
         |and s.his_time = '${yesday}'
         |where t.his_time = '${yesday}'
         |and t.order_source in ('3','4')
         |and t.create_time >= concat('${month}', ' 00:00:00')
         |and t.create_time < concat(date_format(date_sub('${yesday}', -1), 'yyyy-MM-dd'),' 00:00:00')
      """.stripMargin)


    /*
     *  gnzfjem 当月累计支付金额
     * */
    val tgzfm = spark.sql(
      s"""
         |select
         |nvl(cast(sum(total_amount) as decimal(18,2)),0)  gnzfjem
         |from dw.order_information t
         |inner join dw.store s
         |on t.store_id = s.id
         |and s.state = 'onshelf'
         |and s.is_international = '0'
         |and s.his_time = '${yesday}'
         |where t.his_time = '${yesday}'
         |and t.order_source in ('3','4')
         |and t.pay_time >= concat('${month}', ' 00:00:00')
         |and t.pay_time < concat(date_format(date_sub('${yesday}', -1), 'yyyy-MM-dd'),' 00:00:00')
      """.stripMargin)

    val crossBorderDomestic = tgxd.crossJoin(tgzf)
      .crossJoin(gnxdsps)
      .crossJoin(tgps)
      .crossJoin(tgxdm)
      .crossJoin(tgzfm)
      .select("gnxdbs",
        "gnxdrs",
        "gnxdje",
        "gnxdsps",
        "gnzfbs",
        "gnzfrs",
        "gnzfje",
        "gnpsbs",
        "gnpsje",
        "gnxdjem",
        "gnzfjem"
      )
    crossBorderDomestic
  }
}


