package com.tgou.data.stanford.mail.monitor.module.eleticket

import org.apache.spark.sql.{DataFrame, SparkSession}
import org.joda.time.LocalDate

/**
  * Created by 李震 on 2017/9/29.
  */
object EleTicketModule {

  /**
    * 天狗电子小票
    *
    * @param spark
    * @param date
    *
    * @return
    *
    * 字段：
    *
    * - eleticket_create_bs  当日下单笔数
    * - eleticket_create_rs  当日下单人数
    * - eleticket_create_sps  当日下单商品数量
    * - eleticket_create_je  当日下单总金额
    * - eleticket_pay_bs  当日支付笔数
    * - eleticket_pay_rs  当日支付人数
    * - eleticket_pay_je  当日支付总金额
    * - eleticket_month_create_je  当月累计下单金额
    * - eleticket_month_pay_je  当月累计下单（支付）金额
    *
    * */
  def getEleTicketDF(spark: SparkSession, date: LocalDate): DataFrame = {
    val source = EleTicketSource(spark)
    source.getUpdateOrderInformationDWDF(date).createOrReplaceTempView("order_information")
    source.getUpdateOrderProductDWDF(date).createOrReplaceTempView("order_product")

    val currentDayCreateDF = spark.sql(
      s"""
         |select
         |  count(o.order_id) as eleticket_create_bs,
         |  count(distinct o.member_id) as eleticket_create_rs,
         |  round(sum(op.product_discount), 2) as eleticket_create_je,
         |  sum(op.product_quantity) as eleticket_create_sps
         |from order_information o
         | join (
         |  select
         |    sum(op.product_quantity) as product_quantity,
         |    op.tgou_order_id,
         |    sum(op.product_discount) as product_discount
         |  from order_product op
         |  group by op.tgou_order_id
         |) op
         |on o.order_id = op.tgou_order_id
         |where o.create_time >= '${date.toString("yyyy-MM-dd")}'
         |and o.create_time < '${date.plusDays(1).toString("yyyy-MM-dd")}'
         |and o.pay_method is not null
         |and o.pay_method != '000'
         |and o.receive_method is not null
         |and o.receive_method in ('00', '01')
         |and o.pay_time is not null
         |and o.ship_time is not null
         |and to_date(o.pay_time) = to_date(o.ship_time)
      """.stripMargin)

    val currentDayPayDF = spark.sql(
      s"""
         |select
         |  count(o.order_id) as eleticket_pay_bs,
         |  count(distinct o.member_id) as eleticket_pay_rs,
         |  round(sum(op.product_discount), 2) as eleticket_pay_je
         |from order_information o
         | join (
         |  select
         |    op.tgou_order_id,
         |    sum(op.product_discount) as product_discount
         |  from order_product op
         |  group by op.tgou_order_id
         |) op
         |on o.order_id = op.tgou_order_id
         |where o.pay_time >= '${date.toString("yyyy-MM-dd")}'
         |and o.pay_time < '${date.plusDays(1).toString("yyyy-MM-dd")}'
         |and o.pay_method is not null
         |and o.pay_method != '000'
         |and o.receive_method is not null
         |and o.receive_method in ('00', '01')
         |and o.pay_time is not null
         |and o.ship_time is not null
         |and to_date(o.pay_time) = to_date(o.ship_time)
      """.stripMargin)

    val currentMonthCreateDF = spark.sql(
      s"""
         |select
         |  round(sum(op.product_discount), 2) as eleticket_month_create_je
         |from order_information o
         | join (
         |  select
         |    op.tgou_order_id,
         |    sum(op.product_discount) as product_discount
         |  from order_product op
         |  group by op.tgou_order_id
         |) op
         |on o.order_id = op.tgou_order_id
         |where o.create_time >= '${date.withDayOfMonth(1).toString("yyyy-MM-dd")}'
         |and o.create_time < '${date.plusDays(1).toString("yyyy-MM-dd")}'
         |and o.pay_method is not null
         |and o.pay_method != '000'
         |and o.receive_method is not null
         |and o.receive_method in ('00', '01')
         |and o.pay_time is not null
         |and o.ship_time is not null
         |and to_date(o.pay_time) = to_date(o.ship_time)
      """.stripMargin)

    val currentMonthPayDF = spark.sql(
      s"""
         |select
         |  round(sum(op.product_discount), 2) as eleticket_month_pay_je
         |from order_information o
         | join (
         |  select
         |    op.tgou_order_id,
         |    sum(op.product_discount) as product_discount
         |  from order_product op
         |  group by op.tgou_order_id
         |) op
         |on o.order_id = op.tgou_order_id
         |where o.pay_time >= '${date.withDayOfMonth(1).toString("yyyy-MM-dd")}'
         |and o.pay_time < '${date.plusDays(1).toString("yyyy-MM-dd")}'
         |and o.pay_method is not null
         |and o.pay_method != '000'
         |and o.receive_method is not null
         |and o.receive_method in ('00', '01')
         |and o.pay_time is not null
         |and o.ship_time is not null
         |and to_date(o.pay_time) = to_date(o.ship_time)
      """.stripMargin)

    currentDayCreateDF.crossJoin(currentDayPayDF).crossJoin(currentMonthCreateDF).crossJoin(currentMonthPayDF)
  }

}
