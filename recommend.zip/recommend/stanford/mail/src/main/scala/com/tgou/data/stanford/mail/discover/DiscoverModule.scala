package com.tgou.data.stanford.mail.discover

import org.apache.spark.sql.{DataFrame, SparkSession}
import org.joda.time.LocalDate

/**
  * Created by 刘洋 on 2017/12/27.
  * 发现频道-改版
  */

object DiscoverModule {

  def DiscoverQuery(spark: SparkSession, date: LocalDate): DataFrame = {

    val yesDay = date.toString("yyyy-MM-dd")
    val toDay = date.plusDays(1).toString("yyyy-MM-dd")

    /**
      * 读取集市层表discover-detail-market中当天的数据
      * */
    val discoverDetailMarketDF = spark.read.json(s"/tiangou/market/json/discover-detail-market/*/*/*/*")
    discoverDetailMarketDF.createTempView("discover_detail_market")
    /**
      * 读取集市层表uba-platform-page-flow-market中当天的数据
      * */
    val ubaPlatformDF = spark.read.json(s"/tiangou/market/json/uba-platform-page-flow-market/*/*/*/*")
    ubaPlatformDF.createTempView("platform_flow_market")

    /**
      * 频道总PV --pv
      * */
    val discoverPV = spark.sql(
      s"""
         |select
         |    sum(t.pv) as pv
         | from platform_flow_market t
         | where t.a_b in ('01.like',
         |                 '01.nat',
         |                 '01.hisfind',
         |                 '01.ct',
         |                 '01.place',
         |                 '01.fx',
         |                 '01.myfind')
         |   and t.market_time = '${yesDay} 00:00:00'
      """.stripMargin
    )
    /**
      * 频道总UV --find_uv
      * */
    val discoverUV = spark.sql(
      s"""
         |select
         |  count(1) AS find_pv,
         |  count(distinct up.uuid) AS find_uv
         |from dw.uba_page up
         |where up.a_b IN ("01.like","01.nat", "01.hisfind", "01.place", "01.fx", "01.myfind", "01.pfind")
         |and up.his_time='${yesDay}'
      """.stripMargin
    )
    /**
      * 贡献下游浏览量 --downstream_count
      * */
    val discoverDownstream = spark.sql(
      s"""
         |select
         |    sum(t.donwstream_count) as downstream_count
         | from platform_flow_market t
         | where t.a_b in ('01.like',
         |                 '01.nat',
         |                 '01.hisfind',
         |                 '01.ct',
         |                 '01.place',
         |                 '01.fx',
         |                 '01.myfind')
         |and t.market_time = '${yesDay} 00:00:00'
      """.stripMargin
    )
    /**
      * 新访客UV -- new_guest_uv
      * */
    val discoverNewMember = spark.sql(
      s"""
         |SELECT
         |  count(distinct up.uuid) AS new_guest_uv
         |FROM dw.uba_page up
         |where up.a_b IN ("01.like","01.nat", "01.hisfind", "01.place", "01.fx", "01.myfind", "01.pfind")
         |AND up.is_new_guest=true
         |and up.his_time='${yesDay}'
      """.stripMargin
    )

    /**
      * 平均访问时长 --discover_avg_time
      * */
    val discoverAvgTime = spark.sql(
      s"""
         |select
         |    round(sum(t.sum_stay_time) / sum(t.pv),2) as discover_avg_time
         |from platform_flow_market t
         |where t.a_b in ('01.like',
         |                '01.nat',
         |                '01.hisfind',
         |                '01.ct',
         |                '01.place',
         |                '01.fx',
         |                '01.myfind')
         |and t.market_time = '${yesDay} 00:00:00'
      """.stripMargin
    )
    /**
      * 发布内容数 --discover_fs
      * */
    val discoverFS = spark.sql(
      s"""
         |select
         |    nvl(count(distinct t.id), 0) as discover_fs
         |from discover_detail_market t
         |where t.create_time >= '${yesDay} 00:00:00'
         |  and t.create_time <  '${toDay} 00:00:00'
      """.stripMargin
    )
    /**
      * 分享次数 --share_times
      * */
    val discoverShareTimes = spark.sql(
      s"""
         |SELECT
         |  count(1) as share_times
         |FROM dw.uba_scp s
         |WHERE (
         |lower(s.scp) regexp '01\\.pfind\\.pyqkz.*'
         |or lower(s.scp) regexp '01\\.pfind\\.wxkz.*'
         |or lower(s.scp) regexp '01\\.pfind\\.pyq.*'
         |or lower(s.scp) regexp '01\\.pfind\\.wx.*'
         |or lower(s.scp) regexp '01\\.place\\.fsnapshot.*'
         |or lower(s.scp) regexp '01\\.place\\.wsnapshot.*'
         |or lower(s.scp) regexp '01\\.place\\.fcircle.*'
         |or lower(s.scp) regexp '01\\.place\\.wechat.*'
         |)
         |and s.his_time='${yesDay}'
      """.stripMargin
    )
    /**
     * 回流PV UV --backflow_pv backflow_uv
     * */
    val backflowUbaDF = spark.sql(
      s"""
         |SELECT
         |  count(1) AS backflow_pv,
         |  count(distinct up.uuid) AS backflow_uv
         |FROM dw.uba_page up
         |WHERE (lower(up.jr) REGEXP 'sr\\.cfs\\.fd.*'
         |or lower(up.jr) REGEXP 'sr\\.wts\\.fd.*'
         |or lower(up.jr) REGEXP 'sr\\.cf\\.fd.*'
         |or lower(up.jr) REGEXP 'sr\\.wt\\.fd.*')
         |and up.his_time='${yesDay}'
      """.stripMargin)
    /**
      * 运营用户发布内容数量 --  release_user_fs
      * */
    val releaseUserFS = spark.sql(
      s"""
         |select
         |     nvl(count(distinct t.id), 0) as release_user_fs
         |from discover_detail_market t
         |where t.role_type != 0
         |   and t.create_time >= '${yesDay} 00:00:00'
         |   and t.create_time <  '${toDay} 00:00:00'
      """.stripMargin
    )
    /**
      * 普通用户发布内容数量 --release_pt_user_fs
      * */
    val ptUserFS = spark.sql(
      s"""
         |select
         |      nvl(count(distinct t.id), 0) as release_pt_user_fs
         | from discover_detail_market t
         | where t.role_type = '0'
         |   and t.create_time >= '${yesDay} 00:00:00'
         |   and t.create_time <  '${toDay} 00:00:00'
      """.stripMargin
    )
    val query = discoverPV.crossJoin(discoverUV)
      .crossJoin(discoverDownstream)
      .crossJoin(discoverNewMember)
      .crossJoin(discoverAvgTime)
      .crossJoin(discoverFS)
      .crossJoin(discoverShareTimes)
      .crossJoin(backflowUbaDF)
      .crossJoin(releaseUserFS)
      .crossJoin(ptUserFS)
      .select("pv",
        "find_pv",
        "find_uv",
        "downstream_count",
        "new_guest_uv",
        "discover_avg_time",
        "discover_fs",
        "share_times",
        "backflow_pv",
        "backflow_uv",
        "release_user_fs",
        "release_pt_user_fs"
      )
    query
  }
}