package com.tgou.data.stanford.mail.dogFood.module

import com.tgou.data.stanford.mail.core.MailSource
import org.apache.spark.sql.types._
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.joda.time.LocalDate

/**
  * Created by 张少锐 on 2018/01/19.
  * 页面访问和签到数据
  */
object DogFoodSum {

  def getDogFoodSum(spark: SparkSession, date: LocalDate): DataFrame = {

    val yesterday = date.toString("yyyy-MM-dd")
    var start: String = null

    // 周统计的开始日期
    if(date.toString("yyyy-MM-dd") < date.withDayOfWeek(5).toString("yyyy-MM-dd")){
      start = date.withDayOfWeek(5).minusDays(7).toString("yyyy-MM-dd")
    }
    else{
      start = date.withDayOfWeek(5).toString("yyyy-MM-dd")
    }
    System.out.println("周统计开始日期是：" + start + "结束日期：" + yesterday)

    /*
     * 加载数据源
     * */

    // 活动售卖规则
    val asr = StructType(
      StructField("id", StringType, false) ::
        StructField("fk_activity_id", StringType, true) ::
        StructField("delivery_rule", StringType, true) ::
        StructField("pay_rule", StringType, true) ::
        StructField("pick_up_rule", StringType, true) ::
        StructField("free_shipping", StringType, true) ::
        StructField("activity_type", StringType, true) ::
        StructField("price", StringType, true) ::
        StructField("promotion_rule", StringType, true) ::
        StructField("modify_time", StringType, true) ::
        StructField("tag_image_url", StringType, true) ::Nil
    )
    MailSource.getUpdateDF(spark,"/tiangou/tgou/activity_selling_rule",date,Seq("id"),"modify_time",asr)
      .filter("get_json_object(promotion_rule,'$.needPoint') = 'true'").distinct().createOrReplaceTempView("activity_selling_rule")

    // 抽奖奖品表
    val mli = StructType(
      StructField("id", StringType, false) ::
        StructField("version", StringType, true) ::
        StructField("title", StringType, true) ::
        StructField("type", StringType, true) ::
        StructField("object_id", StringType, true) ::
        StructField("fk_activity_id", StringType, true) ::
        StructField("total_qty", LongType, true) ::
        StructField("remain_qty", LongType, true) ::
        StructField("sort_order", StringType, true) ::
        StructField("hit_rate", StringType, true) ::
        StructField("item_daily_limity_qty", StringType, true) ::
        StructField("modify_time", StringType, true) ::
        StructField("state", StringType, true) ::Nil
    )
    MailSource.getUpdateDF(spark,"/tiangou/tgou/mall_lottery_item",date,Seq("id"),"modify_time",mli)
        .filter("state = '0'").distinct().createOrReplaceTempView("mall_lottery_item")

    // 抽奖奖品日志表
    val mlh = StructType(
      StructField("id", StringType, false) ::
        StructField("create_date", StringType, true) ::
        StructField("fk_member_id", StringType, true) ::
        StructField("fk_mall_lottery_item_id", StringType, true) ::
        StructField("hit", StringType, true) ::
        StructField("modify_time", StringType, true) ::
        StructField("award_id", StringType, true) ::
        StructField("award_state", StringType, true) ::Nil
    )
    MailSource.getUpdateDF(spark,"/tiangou/tgou/mall_lottery_history",date,Seq("id"),"modify_time",mlh).distinct()
      .createOrReplaceTempView("mall_lottery_history")

    // 会员积分（狗粮）
    val mp = StructType(
      StructField("id", StringType, false) ::
        StructField("fk_member_id", StringType, true) ::
        StructField("point", LongType, true) ::
        StructField("create_time", StringType, true) ::
        StructField("modify_time", StringType, true) ::
        StructField("version", StringType, true) ::Nil
    )
    MailSource.getUpdateDF(spark,"/tiangou/plat/member_points",date,Seq("id"),"modify_time",mp).distinct()
      .createOrReplaceTempView("member_points")

    // 会员签到日志（狗粮）
    val msl = StructType(
      StructField("id", StringType, false) ::
        StructField("fk_member_id", StringType, true) ::
        StructField("combo_time", LongType, true) ::
        StructField("change_point", LongType, true) ::
        StructField("point", LongType, true) ::
        StructField("create_time", StringType, true) ::
        StructField("modify_time", StringType, true) ::
        StructField("version", StringType, true) ::Nil
    )
    MailSource.getUpdateDF(spark,"/tiangou/plat/member_sign_logs",date,Seq("id"),"modify_time",msl).distinct()
      .createOrReplaceTempView("member_sign_logs")

    // 获取券信息表coupon_information
    spark.sql(
      s"""
         |select id,coupon_id,type,name,pay_type,pay_amount,fk_activity_id
         |from dw.coupon c
         |where c.his_time = '$yesterday'
       """.stripMargin).createOrReplaceTempView("coupon_information")

    // 获取劵核销信息表coupon_code
    spark.sql(
      s"""
         |select id,coupon_code_id,coupon_code,member_id,create_time,use_time,use_tag,fk_activity_id,fk_coupon_id
         |from dw.coupon_code cc
         |where cc.his_time = '$yesterday'
       """.stripMargin).createOrReplaceTempView("coupon_code")

    /**
      * 狗粮签到日统计
      *
      * 字段:
      *  - point_count 当前狗粮余额总数
      *  - sign_pv 签到页PV
      *  - sign_uv 签到页UV
      *  - prize_pv 抽奖页PV
      *  - prize_uv 抽奖页UV
      *  - coupon_pv 换券页PV
      *  - coupon_uv 换券页UV
      *  - sign_member_count 签到人数
      *  - sign_point_count 签到获得狗粮
      *  - Day1 连续第1天签到人数
      *  - Day2 连续第2天签到人数
      *  - Day3 连续第3天签到人数
      *  - Day4 连续第4天签到人数
      *  - Day5 连续第5天签到人数
      *  - Day6 连续第6天签到人数
      *  - Day7 连续第7天签到人数
      *  - prize_count 抽奖次数
      *  - prize_member 抽奖人数
      *  - prize_point 抽奖消耗狗粮
      *  - coupon_count 换券次数
      *  - coupon_member 换券人数
      *  - coupon_point 换券消耗狗粮
      *  - week_1Day 周签到1次人数
      *  - week_2Day 周签到2次人数
      *  - week_3Day 周签到3次人数
      *  - week_4Day 周签到4次人数
      *  - week_5Day 周签到5次人数
      *  - week_6Day 周签到6次人数
      *  - week_7Day 周签到7次人数
      *  - week_total_member 周签到合计人数
      **/

    /*
     * - point_count 当前狗粮余额总数
     * */
    val pointDF = spark.sql(
      s"""
         |select
         |   sum(mp.point) as point_count
         |from member_points mp
         |where to_date(mp.modify_time) <= '${yesterday}'
       """.stripMargin)

     /*
      *  - prize_pv 抽奖页PV
      *  - prize_uv 抽奖页UV
      * */
    val prizePUDF = spark.sql(
      s"""
         |select
         |    count(case when us.scp like '05.tgsign.ad_318.0.%' then us.id end) as prize_pv,
         |    count(distinct case when us.scp like '05.tgsign.ad_318.0.%' then us.uuid end) as prize_uv
         |from dw.uba_scp us
         |where us.his_time = '${yesterday}'
       """.stripMargin)

    /*
      *  - sign_pv 签到页PV
      *  - sign_uv 签到页UV
      *  - coupon_pv 换券页PV
      *  - coupon_uv 换券页UV
      * */
    val pageDF = spark.sql(
      s"""
         |select
         |    count(case when up.page = '05.tgsign' then up.id end) as sign_pv,
         |    count(distinct case when up.page = '05.tgsign' then up.uuid end) as sign_uv,
         |    count(case when up.page = '05.forcpn' then up.id end) as coupon_pv,
         |    count(distinct case when up.page = '05.forcpn' then up.uuid end) as coupon_uv
         |from dw.uba_page up
         |where up.his_time = '${yesterday}'
       """.stripMargin)

    /*
      *  - sign_member_count 签到人数
      *  - sign_point_count 签到获得狗粮
      *  - Day1 连续第1天签到人数
      *  - Day2 连续第2天签到人数
      *  - Day3 连续第3天签到人数
      *  - Day4 连续第4天签到人数
      *  - Day5 连续第5天签到人数
      *  - Day6 连续第6天签到人数
      *  - Day7 连续第7天签到人数
      * */
    val signDF = spark.sql(
      s"""
         |select
         |    count(distinct msl.fk_member_id) as sign_member_count,
         |    sum(msl.change_point) as sign_point_count,
         |    count(distinct case when msl.combo_time%7=1 then msl.fk_member_id end) as Day1,
         |    count(distinct case when msl.combo_time%7=2 then msl.fk_member_id end) as Day2,
         |    count(distinct case when msl.combo_time%7=3 then msl.fk_member_id end) as Day3,
         |    count(distinct case when msl.combo_time%7=4 then msl.fk_member_id end) as Day4,
         |    count(distinct case when msl.combo_time%7=5 then msl.fk_member_id end) as Day5,
         |    count(distinct case when msl.combo_time%7=6 then msl.fk_member_id end) as Day6,
         |    count(distinct case when msl.combo_time%7=0 then msl.fk_member_id end) as Day7
         |from member_sign_logs msl
         |where to_date(msl.create_time) = '${yesterday}'
       """.stripMargin)

    /*
      *  - prize_count 抽奖次数
      *  - prize_member 抽奖人数
      *  - prize_point 抽奖消耗狗粮
      * */
    val ss = "$.point"
    val prizeDF = spark.sql(
      s"""
         |select
         |    sum(t.prize_count) as prize_count,
         |    sum(t.prize_point) as prize_point
         |from (
         |    select
         |         mli.fk_activity_id,
         |         count(mlh.id) as prize_count,
         |         count(mlh.id)*max(get_json_object(asr.promotion_rule,'${ss}')) as prize_point
         |    from mall_lottery_history mlh
         |    join mall_lottery_item mli
         |    on mlh.fk_mall_lottery_item_id = mli.id
         |    and to_date(mlh.create_date) = '${yesterday}'
         |    join activity_selling_rule asr
         |    on mli.fk_activity_id = asr.fk_activity_id
         |    group by mli.fk_activity_id
         |) t
       """.stripMargin)

    /*
     *  - prize_member 抽奖人数
     * */
    val prizeMemberDF = spark.sql(
      s"""
         |select
         |     count(distinct mlh.fk_member_id) as prize_member
         |from mall_lottery_history mlh
         |join mall_lottery_item mli
         |on mlh.fk_mall_lottery_item_id = mli.id
         |and to_date(mlh.create_date) = '${yesterday}'
         |join activity_selling_rule asr
         |on mli.fk_activity_id = asr.fk_activity_id
       """.stripMargin)

    /*
      *  - coupon_count 换券次数
      *  - coupon_member 换券人数
      *  - coupon_point 换券消耗狗粮
      * */
    val couponDF = spark.sql(
      s"""
         |select
         |    count(cc.coupon_code_id) as coupon_count,
         |    count(distinct cc.member_id) as coupon_member,
         |    sum(ci.pay_amount) as coupon_point
         |from coupon_information ci
         |join coupon_code cc
         |on ci.coupon_id = cc.fk_coupon_id
         |where ci.pay_type = '3'
         |and ci.type in('1','2','3')
         |and to_date(cc.create_time) = '${yesterday}'
       """.stripMargin)

    /*
      *  - week_1Day 周签到1次人数
      *  - week_2Day 周签到2次人数
      *  - week_3Day 周签到3次人数
      *  - week_4Day 周签到4次人数
      *  - week_5Day 周签到5次人数
      *  - week_6Day 周签到6次人数
      *  - week_7Day 周签到7次人数
      *  - week_total_member 周签到合计人数
      * */
    val weekSignDF = spark.sql(
      s"""
         |select
         |    count(distinct case when msl.combo_time%7=1 then msl.fk_member_id end) as week_1Day,
         |    count(distinct case when msl.combo_time%7=2 then msl.fk_member_id end) as week_2Day,
         |    count(distinct case when msl.combo_time%7=3 then msl.fk_member_id end) as week_3Day,
         |    count(distinct case when msl.combo_time%7=4 then msl.fk_member_id end) as week_4Day,
         |    count(distinct case when msl.combo_time%7=5 then msl.fk_member_id end) as week_5Day,
         |    count(distinct case when msl.combo_time%7=6 then msl.fk_member_id end) as week_6Day,
         |    count(distinct case when msl.combo_time%7=0 then msl.fk_member_id end) as week_7Day,
         |    count(distinct msl.fk_member_id) as week_total_member
         |from member_sign_logs msl
         |join (
         |    select
         |        msl.fk_member_id,
         |        max(msl.create_time) as create_time
         |    from member_sign_logs msl
         |    where to_date(msl.create_time) >= '${start}'
         |    and  to_date(msl.create_time) <= '${yesterday}'
         |    group by msl.fk_member_id
         |    ) a
         |on msl.fk_member_id = a.fk_member_id
         |and msl.create_time = a.create_time
       """.stripMargin)

    pointDF.crossJoin(pageDF)
      .crossJoin(signDF)
      .crossJoin(prizePUDF)
      .crossJoin(prizeDF)
      .crossJoin(prizeMemberDF)
      .crossJoin(couponDF)
      .crossJoin(weekSignDF)
  }
}
