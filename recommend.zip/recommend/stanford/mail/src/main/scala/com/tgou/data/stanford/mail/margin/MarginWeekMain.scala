package  com.tgou.data.stanford.mail.margin

import com.tgou.data.stanford.mail.core.MailBootstrap
import com.tgou.data.stanford.mail.margin.module.{MarginWeek}
import org.apache.spark.sql.{SaveMode, SparkSession}
import org.joda.time.LocalDate

/**
  * Created by 李磊 on 2017/11/16.
  * 每天天狗财务
  */

object MarginWeekMain {

  def main(args: Array[String]): Unit = {
    MailBootstrap(args).bootstrap(execute)
  }

  def execute(spark: SparkSession, appName: String, date: LocalDate): Unit = {

    /**
      * 第一步 获取数据
      * */
    //天狗支付概况
    val marginDay =  MarginWeek.getTansDF(spark, date)


    /**
      * 第二步 拼接数据
      * */
    val result = marginDay

    /**
      * 第三步 保存数据到HDFS上
      * */
    result.coalesce(1).write.mode(SaveMode.Overwrite).json(s"/data/mail/margin/week/$date/")
    spark.stop()

  }
}