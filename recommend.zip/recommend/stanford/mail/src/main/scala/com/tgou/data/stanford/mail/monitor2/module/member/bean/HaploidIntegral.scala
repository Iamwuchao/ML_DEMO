package com.tgou.data.stanford.mail.monitor2.module.member.bean

/**
  * Created by 李震 on 2017/12/4.
  */
case class HaploidIntegral (
                            storecode: String,
                            cid: String,
                            lasttime: String,
                            ttlamount: Double,
                            ttlintegral: Double,
                            ttlpay: Double,
                            ttlgift: Double,
                            ttlclear: Double,
                            savintegral: Double,
                            cyamount: Double,
                            yiamount: Double,
                            haploidintegral: Double
                           )
