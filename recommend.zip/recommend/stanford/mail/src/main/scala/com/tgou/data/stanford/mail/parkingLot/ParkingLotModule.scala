package com.tgou.data.stanford.mail.parkingLot

import com.tgou.data.stanford.mail.core.MailSource
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.joda.time.LocalDate
import com.tgou.data.stanford.mail.parkingLot.Bean._
import org.apache.spark.sql.types._

/**
  * Created by 刘洋 on 2017/12/12.
  * 停车场邮件报表周报
  */

object ParkingLotModule {
  /**
    * 字段：
    * - area_name 地区
    * - yt 业态 --3，4不能出现在park_bill表里
    * - name 店名
    * - dpbm 店铺编码
    * - park_name 停车场名称
    * - tcbs 停车订单数
    * - bill_quantity 总订单数
    * - ddzb 线上订单数占比
    * - cphys 绑定车牌会员数
    * - ljcphys 累计绑定车牌会员数
    * - jfrs 缴费用户总数（人数）
    * - jfhys 缴费会员数
    * - jfycrs 缴费1次用户数
    * - jflcrs 缴费2次及以上用户数
    * - cfyh71 用户7天重复使用率(缴费1次用户)
    * - cfyh72 用户7天重复使用率(缴费2次用户)
    * - jfje  缴费金额(元)
    * - yhje  会员优惠金额
    * - jfenje  积分金额
    * - jje   停车券金额
    * - wxje  微信支付金额
    * - zfbje 支付宝支付金额
    * */

  def parkingLotQuery(spark: SparkSession, date: LocalDate): DataFrame = {

    val thisThursday = date.plusDays(1).toString("yyyy-MM-dd")
    val lastFriday= date.minusDays(6).toString("yyyy-MM-dd")
    val yesday = date.toString("yyyy-MM-dd")

    /**
      * 读取抽取层park_bill表中当天的数据
      * */
    val parkBillDF = spark.read
      .options(Map(
        "delimiter" -> "^",
        "nullValue" -> "\\N",
        "quote" -> ""
      ))
      .csv(s"/tiangou/tgouorder/park_bill/*/*/*/*")
      .select(ParkingBill.columns: _*)
      .toDF(ParkingBill.title: _*)

    parkBillDF.createTempView("park_bill")
    /**
      * 读取抽取层park_pay_detail表中当天的数据
      * */
    val parkPayDetailDF = spark.read
      .options(Map(
        "delimiter" -> "^",
        "nullValue" -> "\\N",
        "quote" -> ""
      ))
      .csv(s"/tiangou/tgouorder/park_pay_detail/*/*/*/*")
      .select(ParkPayDetail.columns: _*)
      .toDF(ParkPayDetail.title: _*)

    parkPayDetailDF.createTempView("park_pay_detail")

    /**
      * 读取抽取层bill_quantity_count表中当天的数据
      * */
    val schema = StructType(
          StructField("id", LongType, false) ::
            StructField("startTime", StringType, true) ::
            StructField("endTime", StringType, true) ::
            StructField("bill_quantity", IntegerType, true) ::
            StructField("park_code", StringType, true) ::
            StructField("version", StringType, true) ::
            StructField("create_time", StringType, true) ::
            StructField("modify_time", StringType, true) ::  Nil
        )
        val query = MailSource.getUpdateDF(spark,"/tiangou/park/bill_quantity_count",date,Seq("id"),"modify_time",schema)
        query.createTempView("bill_quantity_count")
    /**
      * 读取抽取层park表中当天的数据
      * */
    val tmp=spark.read.format("csv")
      .option("delimiter", "^")
      .option("qoute", "")
      .option("nullValue", "\\N")
      .csv(s"/tiangou/park/park/*/*/*/*")
      .select("_c0","_c1","_c2")
      .toDF("id","name","code")
    tmp.createTempView("park")
    /**
      * 读取抽取层car表中当天的数据
      * */
    val tmpcar = spark.read.format("csv")
      .option("delimiter", "^")
      .option("qoute", "")
      .option("nullValue", "\\N")
      .load(s"/tiangou/tgouorder/car/*/*/*").select("_c0","_c1","_c2","_c3","_c4").toDF("id","car_number","fk_member_id","version","modify_time")
    tmpcar.createTempView("car")

    val parkingLot = spark.sql(
      s"""
         |select
         |       y1.area_name as area_name,
         |       y1.yt as yt,
         |       y1.name as name,
         |       y1.dpbm as dpbm,
         |       y1.park_name as park_name,
         |       y1.bs as tcbs,
         |       y1.rs as jfrs,
         |       nvl(y3.rs,0) as jfhys,
         |       y6.cphys as cphys,
         |       y6.ljcphys as ljcphys,
         |       nvl(y7.bill_quantity,0) as bill_quantity,
         |       case when
         |       y7.bill_quantity is not null and y7.bill_quantity != '0' then round(nvl(y1.bs/y7.bill_quantity,0) * 100,2)
         |       else '0' end ddzb,
         |       round(nvl(y4.rs,0),2) as jfycrs,
         |       round(nvl(y5.rs,0),2) as jflcrs,
         |       round(nvl(y4.rs/y1.rs,0) * 100,2) cfyh71,
         |       round(nvl(y5.rs/y1.rs,0) * 100,2) cfyh72,
         |       y1.je as jfje,
         |       y2.yhje as yhje,
         |       round(nvl(y2.jfje,0),2) as jfenje,
         |       round(nvl(y2.jje,0),2) as jje,
         |       round(nvl(y2.wxje,0),2) as wxje,
         |       round(nvl(y2.zfbje,0),2) as zfbje
         |  from (select s.area_name as area_name,
         |        case s.yt when '1' then '百货' else '超市' end yt,
         |        s.store_name as name,
         |        s.store_code as dpbm,
         |        x1.fk_store_id as fk_store_id,
         |        x1.park_name as park_name,
         |        x1.bs as bs,
         |        x1.rs as rs,
         |        x1.je as je
         |  from (select fk_store_id,
         |        park_name ,
         |        count(id) as  bs,
         |        count(distinct fk_member_id) as rs,
         |        sum(amount) as je
         |  from park_bill
         |  where create_time >= '${lastFriday}'
         |  and create_time < '${thisThursday}'
         |  group by fk_store_id, park_name) x1
         |  left join dw.store s
         |  on x1.fk_store_id = s.id
         |  and s.state = 'onshelf'
         |  and s.his_time = '${yesday}'
         | ) y1
         |left join (
         |  select a.fk_store_id as fk_store_id,
         |         a.park_name as park_name,
         |         nvl(sum(case b.pay_method when '704' then b.amount end),0) yhje,
         |         sum(case b.pay_method when '901' then b.amount end) jfje,
         |         sum(case b.pay_method when '702' then b.amount end) jje,
         |         sum(case when b.pay_method = '301' or b.pay_method = '302' then b.amount end) wxje,
         |         sum(case when b.pay_method = '601' or b.pay_method = '602' or b.pay_method = '603' or b.pay_method = '604' then b.amount end) zfbje
         |  from park_bill a
         |  inner join park_pay_detail b
         |  on a.id = b.fk_park_bill_id
         |  where a.create_time >= '${lastFriday}'
         |  and a.create_time < '${thisThursday}'
         |  and b.create_time >= '${lastFriday}'
         |  and b.create_time < '${thisThursday}'
         |  group by a.fk_store_id, a.park_name
         | ) y2
         |  on y1.fk_store_id = y2.fk_store_id
         |  and y1.park_name = y2.park_name
         |left join (
         |        select a.fk_store_id as fk_store_id,
         |        a.park_name as park_name ,
         |        count(distinct a.fk_member_id) rs
         |  from park_bill a
         |  inner join dw.ds_card_bind b
         |  on a.fk_member_id = b.member_id
         |  and b.his_time = '${yesday}'
         |  where a.create_time >= '${lastFriday}'
         |  and a.create_time < '${thisThursday}'
         |  group by fk_store_id, park_name
         | ) y3
         |  on y1.fk_store_id = y3.fk_store_id
         |  and y1.park_name = y3.park_name
         |left join (
         |  select t.fk_store_id as fk_store_id,
         |         t.park_name as park_name,
         |         sum(t.rs) as rs
         |   from (select a.fk_store_id as fk_store_id,
         |        a.park_name as park_name,
         |        count(distinct a.fk_member_id) rs
         |   from park_bill a                        --park_bill
         |   where a.create_time >= '${lastFriday}'
         |   and a.create_time < '${thisThursday}'
         |   group by a.fk_store_id, a.park_name,a.fk_member_id having count(a.id) = 1) t
         |   group by fk_store_id, park_name
         |   ) y4
         |    on y1.fk_store_id = y4.fk_store_id
         |    and y1.park_name = y4.park_name
         |left join (
         |   select t.fk_store_id as fk_store_id,
         |          t.park_name as park_name,
         |          sum(t.rs) as rs
         |   from (select a.fk_store_id as fk_store_id,
         |        a.park_name as park_name,
         |        count(distinct a.fk_member_id) rs
         |   from  park_bill a                       --park_bill
         |   where a.create_time >= '${lastFriday}'
         |   and a.create_time < '${thisThursday}'
         |   group by a.fk_store_id, a.park_name,a.fk_member_id having count(a.id) > 1) t
         |   group by fk_store_id, park_name
         |   ) y5
         |   on y1.fk_store_id = y5.fk_store_id
         |   and y1.park_name = y5.park_name
         |left join (
         |      select
         |      b.fk_store_id,
         |      b.park_name,
         |      count(distinct case when a.modify_time >= '${lastFriday} 00:00:00' and a.modify_time < '${thisThursday} 00:00:00' then c.member_id end) cphys,
         |      count(distinct case when a.modify_time < '${thisThursday} 00:00:00' then c.member_id end) ljcphys
         |   from park_bill b
         |   left join car a
         |  on a.fk_member_id = b.fk_member_id
         |   join dw.ds_card_bind c
         |  on b.fk_member_id = c.member_id
         |  and c.his_time = '${yesday}'
         |  group by b.fk_store_id,b.park_name
         |   ) y6
         |  on y1.fk_store_id = y6.fk_store_id
         |  and y1.park_name = y6.park_name
         |left join (
         |      select
         |      b.name,
         |      sum(distinct a.bill_quantity) as bill_quantity
         |    from bill_quantity_count a
         |    left join park b
         |    on a.park_code = b.code
         |    where
         |        a.create_time >= '${lastFriday} 00:00:00'
         |    and a.create_time <'${thisThursday} 00:00:00'
         |    group by b.name
         |   ) y7
         |  on y1.park_name = y7.name
      """.stripMargin
    )
     parkingLot
  }
}