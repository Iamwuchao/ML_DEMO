package com.tgou.data.stanford.mail.departmentStoreBrand

import org.apache.spark.sql.{DataFrame, SparkSession}
import org.joda.time.LocalDate

/**
  * Created by 刘洋 on 2017/11/3.
  */

object DepStoreBrandOrderModule {
  /**
    * 字段：
    * - brand_name 品牌名
    * - brand_id   品牌ID
    * - psljje     配送金额累计（月）
    * - zgs        专柜数
    * - ks         在售商品款数
    * - hdks       参与活动款数
    * - xdbs       订单数
    * - zfbs       已支付订单数
    * - zfje       已支付订单金额
    * - zfks       已支付商品款数
    * - zfsps      已支付商品数
    * - zfkdj      客单价
    * - zfcgl      配送订单-支付成功率
    * - psdzb      配送订单占比
    * - zfpsbs     已支付配送订单数
    * - zfpsje     已支付配送订单金额
    * - zfpsks     已支付配送商品款数
    * - zfpssps    已支付配送商品数
    * - zfpsdj     已支付配送客单价
    * - psthbs     配送退货笔数（月）
    * - psthje     配送退货金额（月）
    * - qxbs       配送已取消已支付订单数
    * - qxje       配送已取消已支付订单金额
    * - zfrs1      客单价-支付人数
    * - zfrs2      已支付配送客单价-支付人数
    * */

  def depStoreBrandOrder(spark: SparkSession, date: LocalDate): DataFrame = {
    val ysday = date.toString("yyyy-MM-dd")
    val today = date.plusDays(1).toString("yyyy-MM-dd")
    val month = date.withDayOfMonth(1).toString("yyyy-MM-dd")

    //从HDFS上面读取brand_id
    val brand_id = spark.read
      .format("csv")
      .option("delimiter",",")
      .option("qoute","")
      .option("nullValue","\\N")
      .load("hdfs://nameservice1/app/mail/brand_id.txt").collect().mkString(",").replace("[","").replace("]","")

    val orderBrand = spark.sql(
      s"""
         |select
         |	z1.brand_name as brand_name,
         |	z1.brand_id as brand_id,
         |	case when isnull(z2.psljje) = true then 0 else  z2.psljje end as psljje,
         |	case when isnull(z1.zgs) = true then 0 else  z1.zgs end as zgs,
         |	case when isnull(z1.ks) = true then 0 else  z1.ks end as ks,
         |	case when isnull(z1.hdks) = true then 0 else  z1.hdks end as hdks,
         |
         |	case when isnull(z4.xdbs) = true then 0 else  z4.xdbs end as xdbs,
         |	case when isnull(z3.zfbs) = true then 0 else  z3.zfbs end as zfbs,
         |	case when isnull(z3.zfje) = true then 0 else  z3.zfje end as zfje,
         |	case when isnull(z3.zfks) = true then 0 else  z3.zfks end as zfks,
         |	case when isnull(z3.zfsps) = true then 0 else  z3.zfsps end as zfsps,
         |	case when z3.zfrs1 <= 0 or isnull(z3.zfrs1) = true then 0 else round(z3.zfje/z3.zfrs1,2) end as zfkdj,
         |  case when z4.xdbs = 0 or isnull(z5.zfpsbs/z4.xdbs) = true then concat(0,'%') else concat(round(round(z5.zfpsbs/z4.xdbs,5)*100,2),'%') end as zfcgl,
         |  case when z3.zfbs = 0 or isnull(z5.zfpsbs/z3.zfbs) = true then concat(0,'%') else concat(round(round(z5.zfpsbs/z3.zfbs,5)*100,2),'%') end as psdzb,
         |
         |  case when isnull(z5.zfpsbs) = true then 0 else  z5.zfpsbs end as  zfpsbs,
         |	case when isnull(z5.zfpsje) = true then 0 else  z5.zfpsje end as zfpsje,
         |	case when isnull(z5.zfpsks) = true then 0 else  z5.zfpsks end as zfpsks,
         |	case when isnull(z5.zfpssps) = true then 0 else  z5.zfpssps end as zfpssps,
         |	case when z5.zfrs2 <= 0 or isnull(z5.zfrs2) = true then 0 else round(z5.zfpsje/z5.zfrs2,2) end as zfpsdj,
         |
         |	case when isnull(z6.psthbs) = true then 0 else  z6.psthbs end as psthbs,
         |	case when isnull(z6.psthje) = true then 0 else  z6.psthje end as psthje,
         |
         |	case when isnull(z7.qxbs) = true then 0 else  z7.qxbs end as qxbs,
         |	case when isnull(z7.qxje) = true then 0 else  z7.qxje end as qxje
         |from(
         |  select
         |		a.brand_name,
         |		a.brand_id,
         |		count(distinct b.counter_id) as zgs,
         |		count(distinct b.listing_id) as ks,
         |		count(distinct c.fk_listing_id) as hdks
         |	from dw.product a
         |	join dw.listing b
         |	on a.product_id = b.product_id
         |	and b.his_time = '${ysday}'
         |	and b.source in ('1','2','4')
         |	and b.state='onshelf'
         |	left join dw.activity_product c
         |  on b.listing_id = c.fk_listing_id
         |  and c.state='onshelf'
         |  and c.start_time <= '${ysday} 00:00:00'
         |  and c.stop_time >= '${today} 00:00:00'
         |  and c.his_time = '${ysday}'
         |	where a.his_time= '${ysday}'
         |	and a.brand_id in (${brand_id})
         |	group by a.brand_name,a.brand_id) z1
         |left join
         |	(select
         |		a.brand_id,
         |		sum(a.product_discount) as psljje
         |	from dw.order_product a
         |	inner join dw.order_information b
         |	on b.order_id = a.tgou_order_id
         |	and b.his_time = '${ysday}'
         |	and b.receive_method = '10'
         |	where a.his_time = '${ysday}'
         |	and a.product_source in ('1','2','4')
         |	and a.ship_time >= '${month} 00:00:00'
         |	and a.ship_time < '${today} 00:00:00'
         |	group by a.brand_id) z2
         |	on z1.brand_id = z2.brand_id
         |  left join
         |	(select
         |		a.brand_id,
         |		count(distinct a.tgou_order_id) as  zfbs,
         |    count(distinct b.member_id) as zfrs1,
         |		sum(a.product_discount) as zfje,
         |		count(distinct a.mall_product_id) as zfks,
         |		sum(a.product_quantity) as zfsps
         |	from dw.order_product a
         |  join dw.order_information b
         |  on b.order_id = a.tgou_order_id
         |	where a.his_time = '${ysday}'
         |  and b.his_time = '${ysday}'
         |	and a.product_source in ('1','2','4')
         |	and a.pay_time >= '${ysday} 00:00:00'
         |	and a.pay_time < '${today} 00:00:00'
         |	group by a.brand_id) z3
         |	on z1.brand_id = z3.brand_id
         |left join
         |	(select
         |		a.brand_id,
         |		count(distinct a.tgou_order_id) as xdbs
         |	from dw.order_product a
         |	where a.his_time = '${ysday}'
         |	and a.product_source in ('1','2','4')
         |	and a.create_time >= '${ysday} 00:00:00'
         |	and a.create_time < '${today} 00:00:00'
         |	group by a.brand_id) z4
         |	on z1.brand_id = z4.brand_id
         |left join
         |	(select
         |		a.brand_id,
         |		count(distinct a.tgou_order_id) as zfpsbs,
         |    count(distinct b.member_id)  as zfrs2,
         |		sum(a.product_discount) as zfpsje,
         |		count(distinct a.mall_product_id) as zfpsks,
         |		sum(a.product_quantity) as zfpssps
         |	from dw.order_product a
         |	inner join dw.order_information b
         |	on b.order_id = a.tgou_order_id
         |	and b.his_time = '${ysday}'
         |	and b.receive_method = '10'
         |	where a.his_time = '${ysday}'
         |	and a.product_source in ('1','2','4')
         |	and a.pay_time >= '${ysday} 00:00:00'
         |	and a.pay_time < '${today} 00:00:00'
         |	group by a.brand_id) z5
         |	on z1.brand_id = z5.brand_id
         |left join
         |	(select
         |		a.brand_id,
         |		count(distinct a.tgou_order_id) as psthbs,
         |		sum(a.product_discount) as psthje
         |	from dw.order_product a
         |  inner join dw.order_information b
         |  on  a.tgou_order_id= b.order_id
         |  and b.his_time = '${ysday}'
         |  and b.receive_method = '10'
         |	where a.his_time = '${ysday}'
         |	and a.product_source in ('1','2','4')
         |	and a.state = 'Returned'
         |	and a.etl_time >= '${month} 00:00:00'
         |	and a.etl_time < '${today} 00:00:00'
         |	group by a.brand_id) z6
         |	on z1.brand_id = z6.brand_id
         |left join
         |	(select
         |		a.brand_id,
         |		count(distinct a.tgou_order_id) as qxbs,
         |		sum(a.product_discount) as qxje
         |	from dw.order_product a
         |  inner join dw.order_information b
         |  on  a.tgou_order_id= b.order_id
         |  and b.his_time = '${ysday}'
         |  and b.receive_method = '10'
         |	where a.his_time = '${ysday}'
         |	and a.product_source in ('1','2','4')
         |	and a.state = 'Canceled'
         |	and a.pay_time >= '${ysday} 00:00:00'
         |	and a.pay_time < '${today} 00:00:00'
         |	and isnull(a.pay_time) = false
         |	group by a.brand_id) z7
         |	on z1.brand_id = z7.brand_id
         |order by z1.brand_name
      """.stripMargin
    )
    orderBrand
  }
}