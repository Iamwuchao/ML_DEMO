package com.tgou.data.stanford.mail.dogFood.module

import org.apache.spark.sql.{DataFrame, SparkSession}
import org.joda.time.LocalDate

/**
  * Created by 张少锐 on 2018/01/19.
  * 狗粮抽奖明细数据
  */
object DogFoodPrizeSum {

  def getDogFoodPrizeSum(spark: SparkSession, date: LocalDate): DataFrame = {

    val yesterday = date.toString("yyyy-MM-dd")

    // 获取劵核销信息表coupon_code
    spark.sql(
      s"""
         |select id,coupon_code_id,coupon_code,member_id,create_time,use_time,use_tag,fk_activity_id,fk_coupon_id
         |from dw.coupon_code cc
         |where cc.his_time = '$yesterday'
       """.stripMargin).createOrReplaceTempView("coupon_code")

    /*
      *  - prize_id 抽奖活动ID
      *  - prize_name 奖品名称
      *  - prize_type 类型
      *  - prize_count 中奖次数
      *  - prize_member 中奖人数
      * */
    val prizeDF = spark.sql(
      s"""
         |select
         |     mli.fk_activity_id,
         |     mli.title,
         |     mli.type,
         |     count(mlh.id) as prize_count,
         |     count(distinct mlh.fk_member_id) as prize_member
         |from mall_lottery_history mlh
         |join mall_lottery_item mli
         |on mlh.fk_mall_lottery_item_id = mli.id
         |and to_date(mlh.create_date) = '${yesterday}'
         |join activity_selling_rule asr
         |on mli.fk_activity_id = asr.fk_activity_id
         |group by mli.fk_activity_id,mli.title,mli.type
       """.stripMargin)

    /*
      *  - ship_count 核销次数
      *  - ship_member 核销人数
      * */
    val shipDF = spark.sql(
      s"""
         |select
         |     mli.fk_activity_id,
         |     mli.title,
         |     mli.type,
         |     count(1) as ship_count,
         |     count(distinct cc.member_id) as ship_member
         |from mall_lottery_history mlh
         |join mall_lottery_item mli
         |on mlh.fk_mall_lottery_item_id = mli.id
         |and to_date(mlh.create_date) = '${yesterday}'
         |and mli.type = '1'
         |join activity_selling_rule asr
         |on mli.fk_activity_id = asr.fk_activity_id
         |join coupon_code cc
         |on mli.fk_activity_id = cc.fk_activity_id
         |and mlh.award_id = cc.coupon_code_id
         |and mlh.fk_member_id = cc.member_id
         |where to_date(cc.use_time) = '${yesterday}'
         |and cc.use_tag = '2'
         |group by mli.fk_activity_id,mli.title,mli.type
       """.stripMargin)

    spark.udf.register("getTypeName", (i:String)=>{if(i.equals("1")){"券"}else if(i.equals("3")){"狗粮"}else if(i.equals("4")){"奖品"}else{null}})

    val fields = Map("prize_count"->0,"prize_member"->0,"ship_count"->0,"ship_member"->0)

    prizeDF.join(shipDF,Seq("fk_activity_id","title","type"),"full")
      .selectExpr(
        "fk_activity_id as prize_id",
        "title as prize_name",
        "getTypeName(type) as prize_type",
        "prize_count",
        "prize_member",
        "ship_count",
        "ship_member"
      ).na.fill(fields)
  }
}
