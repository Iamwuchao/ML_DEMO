package com.tgou.data.stanford.mail.timeLimitActivity.module

import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.storage.StorageLevel
import org.joda.time.LocalDate

class TableProcessor protected(spark: SparkSession, date: LocalDate){

  val yesterday:String = date.toString("yyyy-MM-dd")
  val today:String = date.plusDays(1).toString("yyyy-MM-dd")

  // 获取store信息表
  lazy val store:DataFrame = spark.sql(
    s"""
       |select
       |      s.id,
       |      s.yt,
       |      s.is_international
       |from  dw.store s
       |where s.his_time = '${yesterday}'
       |and s.state = 'onshelf'
       """.stripMargin).persist(StorageLevel.MEMORY_AND_DISK)
  store.createOrReplaceTempView("store")

  // 获取order_information信息表
  lazy val orderInformation:DataFrame = spark.sql(
    s"""
       |select
       |     oi.order_id,
       |     oi.member_id,
       |     oi.pay_method,
       |     oi.receive_method,
       |     oi.store_id,
       |     oi.order_source,
       |     oi.order_type,
       |     cast(oi.`total_amount` as double) as total_amount,
       |     oi.create_time,
       |     oi.pay_time
       |from dw.order_information oi
       |where oi.his_time = '${yesterday}'
       """.stripMargin).persist(StorageLevel.MEMORY_AND_DISK)
  orderInformation.createOrReplaceTempView("order_information")

  // 获取order_product信息表
  lazy val orderProduct:DataFrame = spark.sql(
    s"""
       |select
       |      op.tgou_order_id,
       |      op.product_source,
       |      op.mall_product_id,
       |      op.product_quantity
       |from  dw.order_product op
       |where op.his_time = '${yesterday}'
       """.stripMargin).persist(StorageLevel.MEMORY_AND_DISK)
  orderProduct.createOrReplaceTempView("order_product")

  // 获取listing信息表
  lazy val listing:DataFrame = spark.sql(
    s"""
       |select
       |      l.listing_id,
       |      l.store_id
       |from  dw.listing l
       |where l.his_time = '${yesterday}'
       """.stripMargin).persist(StorageLevel.MEMORY_AND_DISK)
  listing.createOrReplaceTempView("listing")

  // 获取activity信息表
  lazy val activity:DataFrame = spark.sql(
    s"""
       |select
       |    a.activity_id,
       |    a.type,
       |    a.group_id,
       |    a.state,
       |    a.create_time,
       |    a.start_time,
       |    a.stop_time
       |from dw.activity a
       |where a.his_time = '${yesterday}'
       """.stripMargin).persist(StorageLevel.MEMORY_AND_DISK)
  activity.createOrReplaceTempView("activity")

  // 获取activity_product信息表
  lazy val activityProduct:DataFrame = spark.sql(
    s"""
       |select
       |    ap.fk_activity_id,
       |    ap.fk_listing_id,
       |    ap.start_time,
       |    ap.stop_time
       |from dw.activity_product ap
       |where ap.his_time = '${yesterday}'
       """.stripMargin).persist(StorageLevel.MEMORY_AND_DISK)
  activityProduct.createOrReplaceTempView("activity_product")
}

object TableProcessor{

  def apply(spark: SparkSession, date: LocalDate): TableProcessor = new TableProcessor(spark, date)

}
