package com.tgou.data.stanford.mail.goodsOnlinePay

import com.tgou.data.stanford.mail.core.MailBootstrap
import org.apache.spark.sql.{SaveMode, SparkSession}
import org.joda.time.LocalDate

/**
  * Created by 张少锐 on 2017/10/20.
  * 百货订单商品邮件报表周报，月报，月初第一周统计
  */
object GoodsOnlinePayMain {
  def main(args: Array[String]): Unit = {
    MailBootstrap(args).bootstrap(execute)
  }

  def execute(spark: SparkSession, appName: String, date: LocalDate): Unit = {
    /**
      * 第一步 获取数据
      * */
    val result = GoodsOnlinePaySum.getGoodsOnlinePaySum(spark,appName,date)

    /**
      * 第二步 保存数据到HDFS上
      * */
    if(appName.equals("weekcount")){
      result.write.mode(SaveMode.Overwrite).json(s"/data/mail/goods_online_pay/${appName}/$date/")
    }else if(appName.equals("monthcount")){
      result.write.mode(SaveMode.Overwrite).json(s"/data/mail/goods_online_pay/${appName}/$date/")
    }else{
      result.write.mode(SaveMode.Overwrite).json(s"/data/mail/goods_online_pay/${appName}/$date/")
    }

    spark.stop()
  }
}
