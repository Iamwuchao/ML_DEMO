package com.tgou.data.stanford.mail.monitor.module.listing

import com.tgou.data.stanford.mail.core.MailBootstrap
import org.apache.spark.sql.SparkSession
import org.joda.time.LocalDate

/**
  * Created by 李震 on 2017/9/30.
  */
object ListingMain {

  def main(args: Array[String]): Unit = {
    MailBootstrap(args).bootstrap(execute)
  }

  def execute(spark: SparkSession, appName: String, date: LocalDate): Unit = {
    ListingModule.getListingDF(spark, date).show()
  }

}
