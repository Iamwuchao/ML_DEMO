package com.tgou.data.stanford.mail.crossBorder

import com.tgou.data.stanford.mail.core.MailSource
import org.apache.spark.sql.types._
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.joda.time.LocalDate
import org.apache.spark.sql.functions._


object CrossBorderStore {

  def getCrossBorderMember(spark: SparkSession,appName:String, date: LocalDate): DataFrame = {
    //时间
    val yesterday = date.toString("yyyy-MM-dd")
    var lastDay :String= null
    if(appName.equals("week")){
       lastDay = date.minusDays(6).toString("yyyy-MM-dd")
    }else if (appName.equals("day")){
       lastDay = date.toString("yyyy-MM-dd")
    }
    val today = date.plusDays(1).toString("yyyy-MM-dd")

    //供应商和sku关系表 三代数仓
    spark.table("wms.supplier_product").filter(s"ods_date = '${today}'").createOrReplaceTempView("supplier_product")
    //供应商信息表 三代数仓
    spark.table("wms.supplier").filter(s"ods_date = '${today}'").createOrReplaceTempView("supplier")
    //订单信息表 二代数仓
    spark.table("dw.order_information").filter(s"his_time = '${yesterday}'").createOrReplaceTempView("order_information")
    //订单商品表 二代数仓
    spark.table("dw.order_product").filter(s"his_time = '${yesterday}'").createOrReplaceTempView("order_product")
    //店铺信息表 二代数仓
    spark.table("dw.store").filter(s"his_time = '${yesterday}'").createOrReplaceTempView("store")
    //营销商品表 二代数仓
    spark.table("dw.listing").filter(s"his_time = '${yesterday}'").createOrReplaceTempView("listing")
    //线上订单退货请求记录流水表 三代数仓
    MailSource.getNewestDF(spark.table("tgouorder.return_request"),Seq("id"),"modify_time").createOrReplaceTempView("return_request")

        /*
        * - store_name 店铺名称
        * - name 供货商名称
        * - onshelf_products 在线商品数
        */
      val query_a = spark.sql(
      s"""
         |    select
         |        l.store_id,
         |        sr.name,
         |        max(s.store_name) as store_name,
         |        count(distinct l.listing_id) as onshelf_products
         |    from dw.listing l
         |      join store s
         |     on l.store_id = s.id
         |      join order_product op
         |     on l.product_id = op.product_id
         |      join supplier_product sp
         |     on op.sku_id = sp.fk_product_sku_id
         |      join supplier sr
         |     on sr.id = sp.fk_supplier_id
         |     where
         |      l.state = 'onshelf'
         |      and l.source = '4'
         |      and s.is_international = '1'
         |    group by l.store_id,sr.name
         """.stripMargin)
        /*
        * - orders      订单数
        * - total_amt  订单金额
        */
      val query_b = spark.sql(
      s"""
         |   select
         |        oi.store_id,
         |        sr.name,
         |        count(distinct
         |          case when oi.create_time >= '${lastDay} 00:00:00' and oi.create_time < '${today} 00:00:00'
         |        then oi.order_id end) as orders,
         |        round(sum(
         |          case when oi.pay_time >= '${lastDay} 00:00:00' and oi.pay_time < '${today} 00:00:00' then
         |        oi.product_amount+oi.ship_amount end),2) as total_amt
         |    from order_information oi
         |       join store s
         |      on oi.store_id = s.id
         |       join order_product op
         |      on oi.id = op.fk_order_information_id
         |       join supplier_product sp
         |      on op.sku_id = sp.fk_product_sku_id
         |       join supplier sr
         |      on sr.id = sp.fk_supplier_id
         |    where
         |      s.is_international = '1'
         |      and oi.order_source = '4'
         |    group by oi.store_id,sr.name
         """.stripMargin)
        /*
        * - sku_count        售出SKU数
        * - product_count    售出商品数量
        */
      val query_c = spark.sql(
      s"""
         |    select
         |        oi.store_id,
         |        sr.name,
         |        count(distinct p.sku_id) as sku_count,--售出SKU数
         |        count(p.product_quantity) as product_count  --售出商品数量
         |    from order_information oi
         |      join order_product p
         |     on oi.id = p.fk_order_information_id
         |      join supplier_product sp
         |     on p.sku_id = sp.fk_product_sku_id
         |      join supplier sr
         |     on sr.id = sp.fk_supplier_id
         |      join store s
         |     on oi.store_id = s.id
         |    where
         |      s.is_international = '1'
         |      and oi.order_source = '4'
         |      and oi.pay_time >= '${lastDay} 00:00:00'
         |      and oi.pay_time  < '${today} 00:00:00'
         |    group by oi.store_id,sr.name
         """.stripMargin)
        /*
        * - return_sku       退货商品sku数
        * - return_quantity  退货商品总数
        */
      val query_d = spark.sql(
      s"""
         |   select
         |        oi.store_id,
         |        sr.name,
         |        count(distinct oi.order_id) as return_cnt,
         |        cast(sum(oi.product_amount+oi.ship_amount) as decimal(18,2)) as return_amt
         |    from order_information oi
         |      join return_request rr
         |     on oi.order_id = rr.fk_tgou_order_id
         |      join order_product op
         |     on oi.id = op.fk_order_information_id
         |      join supplier_product sp
         |     on op.sku_id = sp.fk_product_sku_id
         |      join supplier sr
         |     on sr.id = sp.fk_supplier_id
         |      join store s
         |     on oi.store_id = s.id
         |    where
         |     s.is_international = '1'
         |     and oi.order_source = '4'
         |     and rr.state = 'End'
         |     and rr.create_time >= '${lastDay} 00:00:00'
         |     and rr.create_time <= '${today} 00:00:00'
         |   group by oi.store_id,sr.name
         """.stripMargin)
        /*
        * - return_cnt   退货订单总数
        * - return_amt   退货订单金额
        */
      val query_e = spark.sql(
      s"""
         |    select
         |        oi.store_id,
         |        sr.name,
         |        count(distinct op.sku_id) as return_sku,
         |        cast(sum(op.product_quantity) as decimal(18,0)) as return_quantity
         |    from order_information oi
         |    join return_request rr
         |   on oi.order_id = rr.fk_tgou_order_id
         |    join store s
         |   on oi.store_id = s.id
         |    join order_product op
         |   on oi.id = op.fk_order_information_id
         |    join supplier_product sp
         |   on op.sku_id = sp.fk_product_sku_id
         |    join supplier sr
         |   on sr.id = sp.fk_supplier_id
         |    where
         |     s.is_international = '1'
         |     and oi.order_source = '4'
         |     and rr.state = 'End'
         |     and rr.create_time >= '${lastDay} 00:00:00'
         |     and rr.create_time <  '${today} 00:00:00'
         |    group by oi.store_id,sr.name
         """.stripMargin)

      query_a.join(query_b,Seq("store_id","name"),"left")
      .join(query_c,Seq("store_id","name"),"left")
      .join(query_d,Seq("store_id","name"),"left")
      .join(query_e,Seq("store_id","name"),"left")
      .selectExpr("store_name",
        "name",
        "nvl(onshelf_products,0) as onshelf_products",
        "nvl(orders,0) as orders",
        "nvl(total_amt,0) as total_amt",
        "nvl(sku_count,0) as sku_count",
        "nvl(product_count,0) as product_count",
        "nvl(return_cnt,0) as return_cnt",
        "nvl(return_amt,0) as return_amt",
        "nvl(return_sku,0) as return_sku",
        "nvl(return_quantity,0) as return_quantity").sort(desc("orders")).sort("store_name","name")
  }
}
