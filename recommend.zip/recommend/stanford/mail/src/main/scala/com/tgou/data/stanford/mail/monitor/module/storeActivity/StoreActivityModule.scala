package com.tgou.data.stanford.mail.monitor.module.storeActivity

import com.tgou.data.stanford.mail.monitor.module.storeActivity.bean._
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.joda.time.{LocalDate, LocalTime}

/**
  * Created by 张少锐 on 2017/9/26.
  * 店铺活动统计
  */
object StoreActivityModule {


  def getStoreActivity(spark: SparkSession, date: LocalDate): DataFrame = {

    val yesterday = date.toDateTime(new LocalTime(0, 0, 0, 0)).toString("yyyy-MM-dd HH:mm:ss")
    val today = date.plusDays(1).toDateTime(new LocalTime(0, 0, 0, 0)).toString("yyyy-MM-dd HH:mm:ss")

    /**
      * 加载数据源
      *
      **/

    /*
     * 读取抽取层activity表中最新的数据
     * */
    val totalActivityDF = spark.read
      .options(Map(
        "delimiter" -> "^",
        "nullValue" -> "\\N",
        "quote" -> ""
      ))
      .csv(s"/tiangou/tgou/activity/*/*/*/*")
      .select(Activity.columns: _*)
      .toDF(Activity.title: _*)

    val modifyActivityDF = totalActivityDF.join(totalActivityDF.groupBy("id").agg("modify_time" -> "max").toDF("id","modify_time"), Seq("id","modify_time"), "inner")
    modifyActivityDF.createTempView("modifyActivity")

    /*
     * 读取抽取层counter_dynamics表中最新的数据
     * */
    val totalCounterDynamicsDF = spark.read
      .options(Map(
        "delimiter" -> "^",
        "nullValue" -> "\\N",
        "quote" -> ""
      ))
      .csv(s"/tiangou/item/counter_dynamics/*/*/*/*")
      .select(CounterDynamics.columns: _*)
      .toDF(CounterDynamics.title: _*)

    val modifyCounterDynamicsDF = totalCounterDynamicsDF.join(totalCounterDynamicsDF.groupBy("id").agg("modify_time" -> "max").toDF("id","modify_time"), Seq("id","modify_time"), "inner")
    modifyCounterDynamicsDF.createTempView("counterDynamics")

    /*
     * 读取抽取层adv_position表中当天的数据
     * */
    val totalAdvPositionDF = spark.read
      .options(Map(
        "delimiter" -> "^",
        "nullValue" -> "\\N",
        "quote" -> ""
      ))
      .csv(s"/tiangou/tgou/adv_position/${date.toString("yyyy/MM/dd")}")
      .select(AdvPosition.columns: _*)
      .toDF(AdvPosition.title: _*)

    totalAdvPositionDF.createTempView("advPosition")

    /*
     * 读取抽取层adv_module表中当天的数据
     * */
    val totalAdvModuleDF = spark.read
      .options(Map(
        "delimiter" -> "^",
        "nullValue" -> "\\N",
        "quote" -> ""
      ))
      .csv(s"/tiangou/tgou/adv_module/${date.toString("yyyy/MM/dd")}")
      .select(AdvModule.columns: _*)
      .toDF(AdvModule.title: _*)

    totalAdvModuleDF.createTempView("advModule")

    /*
     * 读取抽取层adv_template表中当天的数据
     * */
    val totalAdvTemplateDF = spark.read
      .options(Map(
        "delimiter" -> "^",
        "nullValue" -> "\\N",
        "quote" -> ""
      ))
      .csv(s"/tiangou/tgou/adv_template/${date.toString("yyyy/MM/dd")}")
      .select(AdvTemplate.columns: _*)
      .toDF(AdvTemplate.title: _*)

    totalAdvTemplateDF.createTempView("advTemplate")

    /*
     * 读取抽取层adv_position_to_store表中当天的数据
     * */
    val totalAdvPTSDF = spark.read
      .options(Map(
        "delimiter" -> "^",
        "nullValue" -> "\\N",
        "quote" -> ""
      ))
      .csv(s"/tiangou/tgou/adv_position_to_store/${date.toString("yyyy/MM/dd")}")
      .select(AdvPositionToStore.columns: _*)
      .toDF(AdvPositionToStore.title: _*)

    totalAdvPTSDF.createTempView("advPositionToStore")

    /**
      * 店铺活动统计
      * 字段
      * - processing_activity_count 百货在线活动总数
      * - counter_dynamics_count 专柜动态创建数
      * - flash_processing_count 百货店铺快讯在线活动数
      * - carousel_processing_count 百货店铺轮播在线活动数
      * - activity_forum_count 百货店铺活动版块区在线活动数
      *
      * - sm_processing_activity_count 超市在线活动总数
      * - sm_flash_processing_count 超市店铺快讯在线活动数
      * - sm_carousel_processing_count 超市店铺轮播在线活动数
      * - sm_activity_forum_count 超市店铺活动版块区在线活动数
      **/

    /*
      * processing_activity_count 百货在线活动总数
      *
      * */
    val processingActivityDF = spark.sql(
      s"""
         |select
         |      count(1) as processing_activity_count
         |from modifyActivity m
         |where m.source = "1"
         |and   m.start_time <= '${yesterday}'
         |and   m.end_time >= '${yesterday}'
         |and   m.state = "processing"
       """.stripMargin)

    /*
      *  counter_dynamics_count 专柜动态创建数
      *
      * */
    val counterDynamicsDF = spark.sql(
      s"""
         |select
         |      count(1) as counter_dynamics_count
         |from counterDynamics c
         |where c.create_time >= '${yesterday}'
         |and c.create_time < '${today}'
       """.stripMargin)

    /*
      *  flash_processing_count 百货店铺快讯在线活动数
      *
      * */
    val flashProcessingDF = spark.sql(
      s"""
         |select
         |      count(1) as flash_processing_count
         |from advPosition a
         |where a.fk_adv_module_id = "154"
         |and   a.start_time <= '${yesterday}'
         |and   a.end_time >= '${yesterday}'
         |and   a.state = "processing"
         """.stripMargin)

    /*
      *  carousel_processing_count 百货店铺轮播在线活动数
      *
      * */
    val carouselProcessingDF = spark.sql(
      s"""
         |select
         |      count(1) as carousel_processing_count
         |from advPosition a
         |where a.fk_adv_module_id = "150"
         |and   a.start_time <= '${yesterday}'
         |and   a.end_time >= '${yesterday}'
         |and   a.state = "processing"
         """.stripMargin)

    /*
      *  activity_forum_count 百货店铺活动版块区在线活动数
      *
      * */
    val activityForumDF = spark.sql(
      s"""
         |select
         |    (x1.s1 + x2.s2) as activity_forum_count
         |from
         |(   select
         |         count(distinct apt.id) as s1,
         |         1 as flag
         |    from
         |         advPosition as apt
         |    left join advModule as am
         |    on   apt.fk_adv_module_id = am.id
         |    left join advTemplate as atm
         |    on   am.style_type = atm.id
         |    left join advPositionToStore apts
         |    on   apts.fk_adv_position_id = apt.id
         |    where apt.start_time <= '${yesterday}'
         |	  and apt.end_time >= '${yesterday}'
         |	  and apt.state = "processing"
         |	  and am.id = "206"
         |) x1
         |join
         |(   select
         |          count(1) as s2,
         |          1 as flag
         |    from (
         |      select a.id
         |      from (
         |          select max(apt.id) as id
         |          from
         |               advPosition as apt
         |          left join advModule as am
         |          on   apt.fk_adv_module_id = am.id
         |          left join advTemplate as atm
         |          on   am.style_type = atm.id
         |          left join advPositionToStore apts
         |          on   apts.fk_adv_position_id = apt.id
         |          where apt.start_time <= '${yesterday}'
         |	        and apt.end_time >= '${yesterday}'
         |	        and apt.state = "processing"
         |	        and am.id in ("155","187","188","189","231")
         |          group by apts.fk_store_id,am.id,apt.standard_sort
         |            ) a
         |            group by a.id
         |         ) b
         |) x2
         |on x1.flag = x2.flag
         """.stripMargin)

    /*
      * sm_processing_activity_count 超市在线活动总数
      *
      * */
    val smProcessingActivityDF = spark.sql(
      s"""
         |select
         |      count(1) as sm_processing_activity_count
         |from modifyActivity m
         |where m.source = "2"
         |and   m.start_time <= '${yesterday}'
         |and   m.end_time >= '${yesterday}'
         |and   m.state = "processing"
       """.stripMargin)

    /*
      *  sm_flash_processing_count 超市店铺快讯在线活动数
      *
      * */
    val smFlashProcessingDF = spark.sql(
      s"""
         |select
         |      count(1) as sm_flash_processing_count
         |from advPosition a
         |where a.fk_adv_module_id = "153"
         |and   a.start_time <= '${yesterday}'
         |and   a.end_time >= '${yesterday}'
         |and   a.state = "processing"
         """.stripMargin)

    /*
      *  sm_carousel_processing_count 超市店铺轮播在线活动数
      *
      * */
    val smCarouselProcessingDF = spark.sql(
      s"""
         |select
         |      count(1) as sm_carousel_processing_count
         |from advPosition a
         |where a.fk_adv_module_id = "149"
         |and   a.start_time <= '${yesterday}'
         |and   a.end_time >= '${yesterday}'
         |and   a.state = "processing"
         """.stripMargin)

    /*
     *  sm_activity_forum_count 超市店铺活动版块区在线活动数
     *
     * */
    val smActivityForumDF = spark.sql(
      s"""
         |select
         |      count(1) as sm_activity_forum_count
         |from advPosition a
         |where a.fk_adv_module_id = "196"
         |and   a.start_time <= '${yesterday}'
         |and   a.end_time >= '${yesterday}'
         |and   a.state = "processing"
       """.stripMargin)

    processingActivityDF.crossJoin(counterDynamicsDF)
      .crossJoin(flashProcessingDF)
      .crossJoin(carouselProcessingDF)
      .crossJoin(activityForumDF)
      .crossJoin(smProcessingActivityDF)
      .crossJoin(smFlashProcessingDF)
      .crossJoin(smCarouselProcessingDF)
      .crossJoin(smActivityForumDF)
      .select(
        "processing_activity_count",
        "counter_dynamics_count",
        "flash_processing_count",
        "carousel_processing_count",
        "activity_forum_count",
        "sm_processing_activity_count",
        "sm_flash_processing_count",
        "sm_carousel_processing_count",
        "sm_activity_forum_count"
      )

  }
}
