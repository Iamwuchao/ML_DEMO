package com.tgou.data.stanford.mail.monitor2.module.traffic

import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.sql.functions._
import org.joda.time.LocalDate

/**
  * Created by 李震 on 2017/12/4.
  */
object TrafficModule {

  val DISCOVER_A_B_REGEXP = Seq(
    "01\\.fx.*", // 发现频道首页
    "01\\.place.*", // 发现详情
    "01\\.myfind.*", // 我的发现
    "01\\.hisfind.*", // 别人的发现
    "01\\.like.*", // 点赞的人
    "01\\.pfind.*", // 发布发现
    "01\\.code.*" // 二维码关注
  )

  /**
    * 流量
    *
    * @return
    *
    * 字段：
    *
    * - pv 平台 PV
    * - uv 平台 UV
    * - discover_uv 发现频道 UV
    *
    * */
  def getTrafficDF(spark: SparkSession, date: LocalDate): DataFrame = {
    val ubaPageDF = spark.sql(
      s"""
        |select
        |    up.uuid,
        |    up.a_b
        |from dw.uba_page up
        |where up.his_time = '${date.toString("yyyy-MM-dd")}'
      """.stripMargin)

    ubaPageDF.agg(count("uuid") as "pv", countDistinct("uuid") as "uv")
      .crossJoin(ubaPageDF.filter(DISCOVER_A_B_REGEXP.map(regexp => s"lower(a_b) regexp '${regexp}'").mkString(" or ")).agg(countDistinct("uuid") as "discover_uv"))
  }

}
