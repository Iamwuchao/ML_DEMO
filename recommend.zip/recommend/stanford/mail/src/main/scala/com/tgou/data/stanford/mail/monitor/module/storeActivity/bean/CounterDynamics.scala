package com.tgou.data.stanford.mail.monitor.module.storeActivity.bean

import com.tgou.data.stanford.mail.core.BaseBean

object CounterDynamics extends BaseBean {

  override def list: List[(Any,String)] = {

    List(
      (0, "id"),
      (8, "create_time"),
      (13, "modify_time")
    )

  }

}
