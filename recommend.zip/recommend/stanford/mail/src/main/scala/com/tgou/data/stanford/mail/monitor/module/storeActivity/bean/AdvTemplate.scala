package com.tgou.data.stanford.mail.monitor.module.storeActivity.bean

import com.tgou.data.stanford.mail.core.BaseBean

object AdvTemplate extends BaseBean {

  override def list: List[(Any,String)] = {

    List(
      (0, "id")
    )

  }

}
