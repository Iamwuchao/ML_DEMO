package  com.tgou.data.stanford.mail.clickFlow.module

import org.apache.spark.sql.{DataFrame, SparkSession}
import org.joda.time.LocalDate

/**
  * Created by 李磊 on 2017/11/16.
  * 每周点击流量转换
  */
object ClickFlowWeek{

  /**
    * 字段：
    * - click	                 点击位
    * - pv                     PV
    * - pvhb                   PV环比增长率
    * - uv                     UV
    * - uvhb                   UV环比增长率
    * */
  def getTansDF(spark:SparkSession, date: LocalDate): DataFrame = {


    /*
        * 每天点击流量转换
        * */
    val click = spark.sql(
      s"""
         |select  n.djw as click,
         |n.pv,
         |concat(nvl(cast(case
         |  when nvl(o.pv,0) = 0 then
         |      ''
         |   else
         |    (n.pv - nvl(o.pv,0) )/ o.pv * 100
         |  end as decimal(18,2)),0),'%') pvhb,
         |n.uv,
         |concat(nvl(cast(case
         |  when nvl(o.uv,0) = 0 then
         |      ''
         |   else
         |    (n.uv - nvl(o.uv,0) ) / o.uv * 100
         |  end as decimal(18,2)),0),'%')  uvhb
         |from (select y.djw,
         |sum(y.pv) as pv ,
         |sum(y.uv) as uv
         |from (select
         |    case
         |     when a.a_b_c in ('02.sp.navm' , '14.sp.navm' )	then '底部按钮-我的'
         | when a.a_b_c in ('02.sp.navh' , '14.sp.navh' )	then '底部按钮-逛店'
         | when a.a_b_c in ('02.sp.search' , '14.sp.search' )	then '搜索'
         | when a.a_b_c in ('02.sp.fe' , '14.sp.fe' ) then '快捷入口-全部'
         | when a.a_b_c in ('02.sp.ad' , '14.sp.ad' ) then '一宫格广告位'
         | when a.a_b_c in ('02.sp.ad00' , '14.sp.ad00' ) then '四宫格广告位'
         | when a.a_b_c in ('02.sp.nave' , '14.sp.nave' ) then '底部按钮-全球购'
         | when a.a_b_c in ('02.sp.mr' , '14.sp.mr' ) then '购物车'
         | when a.a_b_c in ('02.sp.bn'	 , '14.sp.bn'	 ) then '轮播'
         | when a.a_b_c in ('02.sp.navc' , '14.sp.navc' ) then '底部按钮-发现'
         | when a.a_b_c in ('02.sp.aapp' , '14.sp.aapp' ) then '活动品'
         | when a.a_b_c in ('02.sp.aapa' , '14.sp.aapa' ) then '促销活动大图'
         | when a.a_b_c in ('02.sp.fsmr1' , '14.sp.fsmr1' )	then '限时特卖-more'
         | when a.a_b_c in ('02.sp.noti' , '14.sp.noti' ) then '消息'
         | when a.a_b_c in ('02.sp.fspro1' , '14.sp.fspro1' )	then '限时特卖-单品'
         | when a.a_b_c in ('02.sp.kx' , '14.sp.kx' ) then '天狗快讯'
         | when a.a_b_c in ('02.sp.uscode' , '14.sp.uscode' )	then '结算码'
         | when a.a_b_c in ('02.sp.barcode' ,'14.sp.barcode' ) then '结算码弹窗按钮'
         | when a.a_b_c in ('02.sp.gtop' , '14.sp.gtop' )	then '返回顶部按钮'
         | when a.a_b_c in ('02.sp.navs' , '14.sp.navs' )	then '底部按钮-购物'
         | when a.a_b_c in ('02.sp.ylike' , '14.sp.ylike' )	then '猜你喜欢'
         | when a.a_b_c in ('02.sp.adc' , '14.sp.adc' )	then '大促'
         | when a.a_b_c in ('02.sp.ad01' , '14.sp.ad01' )	then '活动+品广告位1'
         | when a.a_b_c in ('02.sp.ad02' , '14.sp.ad02' )	then '活动+品广告位2'
         |    else '其它'
         |    end as djw,
         |    count(*) as pv,
         |    count(distinct a.uuid) as uv
         |
         |from
         |    dw.uba_scp a
         |where a.his_time>= date_format(date_sub('${date.toString("yyyy-MM-dd")}', 6), 'yyyy-MM-dd')
         |and (a.scp like '02.sp%' or a.scp like '14.sp%')
         |group by case
         | when a.a_b_c in ('02.sp.navm' , '14.sp.navm' )	then '底部按钮-我的'
         | when a.a_b_c in ('02.sp.navh' , '14.sp.navh' )	then '底部按钮-逛店'
         | when a.a_b_c in ('02.sp.search' , '14.sp.search' )	then '搜索'
         | when a.a_b_c in ('02.sp.fe' , '14.sp.fe' ) then '快捷入口-全部'
         | when a.a_b_c in ('02.sp.ad' , '14.sp.ad' ) then '一宫格广告位'
         | when a.a_b_c in ('02.sp.ad00' , '14.sp.ad00' ) then '四宫格广告位'
         | when a.a_b_c in ('02.sp.nave' , '14.sp.nave' ) then '底部按钮-全球购'
         | when a.a_b_c in ('02.sp.mr' , '14.sp.mr' ) then '购物车'
         | when a.a_b_c in ('02.sp.bn'	 , '14.sp.bn'	 ) then '轮播'
         | when a.a_b_c in ('02.sp.navc' , '14.sp.navc' ) then '底部按钮-发现'
         | when a.a_b_c in ('02.sp.aapp' , '14.sp.aapp' ) then '活动品'
         | when a.a_b_c in ('02.sp.aapa' , '14.sp.aapa' ) then '促销活动大图'
         | when a.a_b_c in ('02.sp.fsmr1' , '14.sp.fsmr1' )	then '限时特卖-more'
         | when a.a_b_c in ('02.sp.noti' , '14.sp.noti' ) then '消息'
         | when a.a_b_c in ('02.sp.fspro1' , '14.sp.fspro1' )	then '限时特卖-单品'
         | when a.a_b_c in ('02.sp.kx' , '14.sp.kx' ) then '天狗快讯'
         | when a.a_b_c in ('02.sp.uscode' , '14.sp.uscode' )	then '结算码'
         | when a.a_b_c in ('02.sp.barcode' ,'14.sp.barcode' ) then '结算码弹窗按钮'
         | when a.a_b_c in ('02.sp.gtop' , '14.sp.gtop' )	then '返回顶部按钮'
         | when a.a_b_c in ('02.sp.navs' , '14.sp.navs' )	then '底部按钮-购物'
         | when a.a_b_c in ('02.sp.ylike' , '14.sp.ylike' )	then '猜你喜欢'
         | when a.a_b_c in ('02.sp.adc' , '14.sp.adc' )	then '大促'
         | when a.a_b_c in ('02.sp.ad01' , '14.sp.ad01' )	then '活动+品广告位1'
         | when a.a_b_c in ('02.sp.ad02' , '14.sp.ad02' )	then '活动+品广告位2'
         |    else '其它'
         |    end,DATE_FORMAT(a.his_time,'Y/MM/dd')
         |union all
         |select
         |    case
         |     when aa.scp in ('02.sp.fe.00','02.sp.fe.0.','14.sp.fe.00','14.sp.fe.0.') then '快捷入口-大商农场'
         |    when aa.scp in ('02.sp.fe.01','02.sp.fe.1.','14.sp.fe.01','14.sp.fe.1.') then '快捷入口-情感保鲜'
         |    when aa.scp in ('02.sp.fe.02','02.sp.fe.2.','14.sp.fe.02','14.sp.fe.2.') then '快捷入口-情感全球好货'
         |    when aa.scp in ('02.sp.fe.03','02.sp.fe.3.','14.sp.fe.03','14.sp.fe.3.') then '快捷入口-品牌直供'
         |    else '快捷入口-其他' end as djw,
         |    sum(aa.pv) as pv,
         |    sum(aa.uv) as uv
         |
         |from
         |    (
         |    select
         |    SUBSTRING(a.scp,1,11) as scp ,count(*) as pv,count(distinct a.uuid) as uv
         |    from
         |    dw.uba_scp a
         |    where a.his_time>=date_format(date_sub('${date.toString("yyyy-MM-dd")}', 6), 'yyyy-MM-dd')
         |    and (a.scp like '02.sp.fe%' or a.scp like '14.sp.fe%')
         |    group by SUBSTRING(a.scp,1,11),DATE_FORMAT(a.his_time,'Y/MM/dd')
         |    )aa
         |group by case
         |      when aa.scp in ('02.sp.fe.00','02.sp.fe.0.','14.sp.fe.00','14.sp.fe.0.') then '快捷入口-大商农场'
         |    when aa.scp in ('02.sp.fe.01','02.sp.fe.1.','14.sp.fe.01','14.sp.fe.1.') then '快捷入口-情感保鲜'
         |    when aa.scp in ('02.sp.fe.02','02.sp.fe.2.','14.sp.fe.02','14.sp.fe.2.') then '快捷入口-情感全球好货'
         |    when aa.scp in ('02.sp.fe.03','02.sp.fe.3.','14.sp.fe.03','14.sp.fe.3.') then '快捷入口-品牌直供'
         |    else '快捷入口-其他' end) y
         |   group by y.djw) n
         | left join (
         |select y.djw,
         |sum(y.pv) as pv ,
         |sum(y.uv) as uv
         |from (select
         |    case
         |     when a.a_b_c in ('02.sp.navm' , '14.sp.navm' )	then '底部按钮-我的'
         | when a.a_b_c in ('02.sp.navh' , '14.sp.navh' )	then '底部按钮-逛店'
         | when a.a_b_c in ('02.sp.search' , '14.sp.search' )	then '搜索'
         | when a.a_b_c in ('02.sp.fe' , '14.sp.fe' ) then '快捷入口-全部'
         | when a.a_b_c in ('02.sp.ad' , '14.sp.ad' ) then '一宫格广告位'
         | when a.a_b_c in ('02.sp.ad00' , '14.sp.ad00' ) then '四宫格广告位'
         | when a.a_b_c in ('02.sp.nave' , '14.sp.nave' ) then '底部按钮-全球购'
         | when a.a_b_c in ('02.sp.mr' , '14.sp.mr' ) then '购物车'
         | when a.a_b_c in ('02.sp.bn'	 , '14.sp.bn'	 ) then '轮播'
         | when a.a_b_c in ('02.sp.navc' , '14.sp.navc' ) then '底部按钮-发现'
         | when a.a_b_c in ('02.sp.aapp' , '14.sp.aapp' ) then '活动品'
         | when a.a_b_c in ('02.sp.aapa' , '14.sp.aapa' ) then '促销活动大图'
         | when a.a_b_c in ('02.sp.fsmr1' , '14.sp.fsmr1' )	then '限时特卖-more'
         | when a.a_b_c in ('02.sp.noti' , '14.sp.noti' ) then '消息'
         | when a.a_b_c in ('02.sp.fspro1' , '14.sp.fspro1' )	then '限时特卖-单品'
         | when a.a_b_c in ('02.sp.kx' , '14.sp.kx' ) then '天狗快讯'
         | when a.a_b_c in ('02.sp.uscode' , '14.sp.uscode' )	then '结算码'
         | when a.a_b_c in ('02.sp.barcode' ,'14.sp.barcode' ) then '结算码弹窗按钮'
         | when a.a_b_c in ('02.sp.gtop' , '14.sp.gtop' )	then '返回顶部按钮'
         | when a.a_b_c in ('02.sp.navs' , '14.sp.navs' )	then '底部按钮-购物'
         | when a.a_b_c in ('02.sp.ylike' , '14.sp.ylike' )	then '猜你喜欢'
         | when a.a_b_c in ('02.sp.adc' , '14.sp.adc' )	then '大促'
         | when a.a_b_c in ('02.sp.ad01' , '14.sp.ad01' )	then '活动+品广告位1'
         | when a.a_b_c in ('02.sp.ad02' , '14.sp.ad02' )	then '活动+品广告位2'
         |    else '其它'
         |    end as djw,
         |    count(*) as pv,
         |    count(distinct a.uuid) as uv
         |
         |from
         |    dw.uba_scp a
         |where a.his_time>=date_format(date_sub('${date.toString("yyyy-MM-dd")}', 13), 'yyyy-MM-dd')
         |    and a.his_time<date_format(date_sub('${date.toString("yyyy-MM-dd")}', 6), 'yyyy-MM-dd')
         |and (a.scp like '02.sp%' or a.scp like '14.sp%')
         |group by case
         |     when a.a_b_c in ('02.sp.navm' , '14.sp.navm' )	then '底部按钮-我的'
         | when a.a_b_c in ('02.sp.navh' , '14.sp.navh' )	then '底部按钮-逛店'
         | when a.a_b_c in ('02.sp.search' , '14.sp.search' )	then '搜索'
         | when a.a_b_c in ('02.sp.fe' , '14.sp.fe' ) then '快捷入口-全部'
         | when a.a_b_c in ('02.sp.ad' , '14.sp.ad' ) then '一宫格广告位'
         | when a.a_b_c in ('02.sp.ad00' , '14.sp.ad00' ) then '四宫格广告位'
         | when a.a_b_c in ('02.sp.nave' , '14.sp.nave' ) then '底部按钮-全球购'
         | when a.a_b_c in ('02.sp.mr' , '14.sp.mr' ) then '购物车'
         | when a.a_b_c in ('02.sp.bn'	 , '14.sp.bn'	 ) then '轮播'
         | when a.a_b_c in ('02.sp.navc' , '14.sp.navc' ) then '底部按钮-发现'
         | when a.a_b_c in ('02.sp.aapp' , '14.sp.aapp' ) then '活动品'
         | when a.a_b_c in ('02.sp.aapa' , '14.sp.aapa' ) then '促销活动大图'
         | when a.a_b_c in ('02.sp.fsmr1' , '14.sp.fsmr1' )	then '限时特卖-more'
         | when a.a_b_c in ('02.sp.noti' , '14.sp.noti' ) then '消息'
         | when a.a_b_c in ('02.sp.fspro1' , '14.sp.fspro1' )	then '限时特卖-单品'
         | when a.a_b_c in ('02.sp.kx' , '14.sp.kx' ) then '天狗快讯'
         | when a.a_b_c in ('02.sp.uscode' , '14.sp.uscode' )	then '结算码'
         | when a.a_b_c in ('02.sp.barcode' ,'14.sp.barcode' ) then '结算码弹窗按钮'
         | when a.a_b_c in ('02.sp.gtop' , '14.sp.gtop' )	then '返回顶部按钮'
         | when a.a_b_c in ('02.sp.navs' , '14.sp.navs' )	then '底部按钮-购物'
         | when a.a_b_c in ('02.sp.ylike' , '14.sp.ylike' )	then '猜你喜欢'
         | when a.a_b_c in ('02.sp.adc' , '14.sp.adc' )	then '大促'
         | when a.a_b_c in ('02.sp.ad01' , '14.sp.ad01' )	then '活动+品广告位1'
         | when a.a_b_c in ('02.sp.ad02' , '14.sp.ad02' )	then '活动+品广告位2'
         |    else '其它'
         |    end,DATE_FORMAT(a.his_time,'Y/MM/dd')
         |union all
         |select
         |    case
         |     when aa.scp in ('02.sp.fe.00','02.sp.fe.0.','14.sp.fe.00','14.sp.fe.0.') then '快捷入口-大商农场'
         |    when aa.scp in ('02.sp.fe.01','02.sp.fe.1.','14.sp.fe.01','14.sp.fe.1.') then '快捷入口-情感保鲜'
         |    when aa.scp in ('02.sp.fe.02','02.sp.fe.2.','14.sp.fe.02','14.sp.fe.2.') then '快捷入口-情感全球好货'
         |    when aa.scp in ('02.sp.fe.03','02.sp.fe.3.','14.sp.fe.03','14.sp.fe.3.') then '快捷入口-品牌直供'
         |    else '快捷入口-其他' end as djw,
         |    sum(aa.pv) as pv,
         |    sum(aa.uv) as uv
         |
         |from
         |    (
         |    select
         |    SUBSTRING(a.scp,1,11) as scp ,count(*) as pv,count(distinct a.uuid) as uv
         |    from
         |    dw.uba_scp a
         |    where a.his_time>=date_format(date_sub('${date.toString("yyyy-MM-dd")}', 13), 'yyyy-MM-dd')
         |    and a.his_time<date_format(date_sub('${date.toString("yyyy-MM-dd")}', 6), 'yyyy-MM-dd')
         |    and (a.scp like '02.sp.fe%' or a.scp like '14.sp.fe%')
         |    group by SUBSTRING(a.scp,1,11),DATE_FORMAT(a.his_time,'Y/MM/dd')
         |    )aa
         |group by case
         |      when aa.scp in ('02.sp.fe.00','02.sp.fe.0.','14.sp.fe.00','14.sp.fe.0.') then '快捷入口-大商农场'
         |    when aa.scp in ('02.sp.fe.01','02.sp.fe.1.','14.sp.fe.01','14.sp.fe.1.') then '快捷入口-情感保鲜'
         |    when aa.scp in ('02.sp.fe.02','02.sp.fe.2.','14.sp.fe.02','14.sp.fe.2.') then '快捷入口-情感全球好货'
         |    when aa.scp in ('02.sp.fe.03','02.sp.fe.3.','14.sp.fe.03','14.sp.fe.3.') then '快捷入口-品牌直供'
         |    else '快捷入口-其他' end) y
         |   group by y.djw) o
         |   on n.djw = o.djw
         |
      """.stripMargin)




    return click

  }

}