package com.tgou.data.stanford.mail.monitor.module.listing.bean

/**
  * Created by 李震 on 2017/9/27.
  */
case class Listing(
                    listing_id: String,
                    product_id: String,
                    state: String,
                    download_time: String,
                    binding_time: String,
                    is_fast_sales: Boolean,
                    brand_id: String,
                    product_third_category: String
                  )
