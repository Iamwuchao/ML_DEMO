package com.tgou.data.stanford.mail.tiangouStore

import org.apache.spark.sql.{DataFrame, SparkSession}
import org.joda.time.LocalDate

/**
  * Created by 张少锐 on 2017/12/12.
  * 天狗店铺邮件报表周报，月报，月初第一周统计
  */

object TiangouStoreSum {

  def getTiangouStoreSum(spark: SparkSession, appName: String, date: LocalDate): DataFrame = {

    val yesterday = date.toString("yyyy-MM-dd")
    var yesterdayPlus1: String = null
    var yesterdayMinus7: String = null

    if (appName.equals("weekcount")) {
      //周统计
      yesterdayMinus7 = date.minusDays(6).toString("yyyy-MM-dd")
      yesterdayPlus1 = date.plusDays(1).toString("yyyy-MM-dd")

    } else if (appName.equals("monthcount")) {
      //月统计
      yesterdayMinus7 = date.withDayOfMonth(1).toString("yyyy-MM-dd")
      yesterdayPlus1 = date.plusMonths(1).withDayOfMonth(1).toString("yyyy-MM-dd")

    } else {
      //每个月的周五都运行,但是限制每个月的周五在2号到8号才执行
      if(2<=date.plusDays(1).getDayOfMonth&&date.plusDays(1).getDayOfMonth<=8){
        //月初第一周统计
        yesterdayMinus7 = date.withDayOfMonth(1).toString("yyyy-MM-dd")
        yesterdayPlus1 = date.withDayOfWeek(5).toString("yyyy-MM-dd")
      }else{
        //让程序报错，不运行
        System.out.println("当前统计日期是"+date+",不符合月初第一周")
        spark.close()
      }

    }

    //统计的时间范围是
    System.out.println("统计的时间范围是(左闭右开)：" + yesterdayMinus7 + "至" + yesterdayPlus1)

    /*
      * 加载数据源
      * */
    spark.sql(
      s"""
         |select
         |     oi.order_id,
         |     oi.store_id,
         |     oi.receive_method,
         |     cast(oi.`total_amount` as double) as total_amount,
         |     to_date(oi.create_time) as create_time,
         |     to_date(oi.pay_time) as pay_time,
         |     to_date(oi.ship_time) as ship_time
         |from dw.order_information oi
         |where
         |     oi.his_time = '${yesterday}'
         |and  oi.order_source = '1'
       """.stripMargin).createOrReplaceTempView("order_information")

    spark.sql(
      s"""
         |select
         |     op.tgou_order_id,
         |     op.state,
         |     op.sku_id,
         |     op.product_quantity,
         |     to_date(op.etl_time) as etl_time,
         |     to_date(op.create_time) as create_time,
         |     to_date(op.ship_time) as ship_time,
         |     cast(op.`product_discount` as double) as product_discount
         |from dw.order_product op
         |where
         |     op.his_time = '${yesterday}'
       """.stripMargin).createOrReplaceTempView("order_product")

    spark.sql(
      s"""
         |select
         |     s.id,
         |     s.store_code,
         |     s.store_name
         |from dw.store s
         |where
         |    s.his_time = '$yesterday'
         |and s.state = 'onshelf'
         |and s.yt = '1'
       """.stripMargin).createOrReplaceTempView("store")

    /**
      * 天狗店铺统计
      *
      * 字段:
      *  - store_name 店铺名称
      *  - store_code 店铺编码
      *  - xdbs 下单笔数
      *  - xdje 下单金额
      *  - xdpsbs 下单配送笔数
      *  - xdpsje 下单配送金额
      *  - hxbs 核销笔数
      *  - hxje 核销金额
      *  - psbs 配送笔数
      *  - psje 配送金额
      *  - zfpsbs 支付配送笔数
      *  - zfpsje 支付配送金额
      *  - thbs 退货笔数
      *  - thje 退货金额
      *  - skus SKU数
      *  - sps 商品数
      *  - xdpsskus 下单配送SKU数
      *  - xdpssps 下单配送商品数
      **/

    val storeDF = spark.sql(
      s"""
         |select
         |     s.id as store_id,
         |     s.store_code,
         |     s.store_name
         |from store s
       """.stripMargin)

    val createDF = spark.sql(
      s"""
         |select
         |    oi.store_id,
         |    count(distinct oi.order_id) as xdbs,
         |    nvl(cast(sum(oi.total_amount) as decimal(18,2)),0) as xdje
         |from order_information oi
         |where oi.create_time >= '$yesterdayMinus7'
         |and oi.create_time < '$yesterdayPlus1'
         |group by oi.store_id
       """.stripMargin)

    val createSendDF = spark.sql(
      s"""
         |select
         |    oi.store_id,
         |    count(distinct oi.order_id) as xdpsbs,
         |    nvl(cast(sum(oi.total_amount) as decimal(18,2)),0) as xdpsje
         |from order_information oi
         |where oi.receive_method = '10'
         |and oi.create_time >= '$yesterdayMinus7'
         |and oi.create_time < '$yesterdayPlus1'
         |group by oi.store_id
       """.stripMargin)

    val shipDF = spark.sql(
      s"""
         |select
         |    oi.store_id,
         |    count(distinct oi.order_id) as hxbs,
         |    nvl(cast(sum(oi.total_amount) as decimal(18,2)),0) as hxje
         |from order_information oi
         |where  oi.ship_time >= '$yesterdayMinus7'
         |and oi.ship_time < '$yesterdayPlus1'
         |group by oi.store_id
       """.stripMargin)

    val shipSendDF = spark.sql(
      s"""
         |select
         |    oi.store_id,
         |    count(distinct oi.order_id) as psbs,
         |    nvl(cast(sum(oi.total_amount) as decimal(18,2)),0) as psje
         |from order_information oi
         |where  oi.receive_method = '10'
         |and oi.ship_time >= '$yesterdayMinus7'
         |and oi.ship_time < '$yesterdayPlus1'
         |group by oi.store_id
       """.stripMargin)

    val payDF = spark.sql(
      s"""
         |select
         |    oi.store_id,
         |    count(distinct oi.order_id) as zfpsbs,
         |    nvl(cast(sum(oi.total_amount) as decimal(18,2)),0) as zfpsje
         |from order_information oi
         |where  oi.receive_method = '10'
         |and oi.pay_time >= '$yesterdayMinus7'
         |and oi.pay_time < '$yesterdayPlus1'
         |group by oi.store_id
       """.stripMargin)

    val returnedDF = spark.sql(
      s"""
         |select
         |    oi.store_id,
         |    count(distinct op.tgou_order_id) as thbs,
         |    nvl(cast(sum(op.product_discount) as decimal(18,2)),0) as thje
         |from order_product op
         |join order_information oi
         |on oi.order_id = op.tgou_order_id
         |where op.etl_time >= '$yesterdayMinus7'
         |and op.etl_time < '$yesterdayPlus1'
         |and op.state = 'Returned'
         |group by oi.store_id
       """.stripMargin)

    val skuDF = spark.sql(
      s"""
         |select
         |    oi.store_id,
         |    count(distinct op.sku_id) as skus,
         |    nvl(cast(sum(op.product_quantity) as decimal(18,0)),0) as sps
         |from order_product op
         |join order_information oi
         |on oi.order_id = op.tgou_order_id
         |where op.ship_time >= '$yesterdayMinus7'
         |and op.ship_time < '$yesterdayPlus1'
         |group by oi.store_id
       """.stripMargin)

    val skuCreateDF = spark.sql(
      s"""
         |select
         |    oi.store_id,
         |    count(distinct op.sku_id) as xdpsskus,
         |    nvl(cast(sum(op.product_quantity) as decimal(18,0)),0) as xdpssps
         |from order_product op
         |join order_information oi
         |on oi.order_id = op.tgou_order_id
         |where oi.receive_method = '10'
         |and op.create_time >= '$yesterdayMinus7'
         |and op.create_time < '$yesterdayPlus1'
         |group by oi.store_id
       """.stripMargin)

    val fields = Map("xdbs"->0,"xdje"->0.0,"xdpsbs"->0,"xdpsje"->0.0,"hxbs"->0,"hxje"->0.0,
                     "psbs"->0,"psje"->0.0,"zfpsbs"->0,"zfpsje"->0.0,"thbs"->0,"thje"->0.0,
                     "skus"->0,"sps"->0,"xdpsskus"->0,"xdpssps"->0)

    storeDF.join(createDF,Seq("store_id"),"left").
      join(createSendDF,Seq("store_id"),"left").
      join(shipDF,Seq("store_id"),"left").
      join(shipSendDF,Seq("store_id"),"left").
      join(payDF,Seq("store_id"),"left").
      join(returnedDF,Seq("store_id"),"left").
      join(skuDF,Seq("store_id"),"left").
      join(skuCreateDF,Seq("store_id"),"left").
      select(
            "store_name",
            "store_code",
            "xdbs",
            "xdje",
            "xdpsbs",
            "xdpsje",
            "hxbs",
            "hxje",
            "psbs",
            "psje",
            "zfpsbs",
            "zfpsje",
            "thbs",
            "thje",
            "skus",
            "sps",
            "xdpsskus",
            "xdpssps"
    ).na.fill(fields)

  }
}
