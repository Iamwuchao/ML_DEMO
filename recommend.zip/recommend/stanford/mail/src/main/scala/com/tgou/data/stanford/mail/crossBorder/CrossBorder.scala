package  com.tgou.data.stanford.mail.crossBorder

import com.tgou.data.stanford.mail.core.MailSource
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.joda.time.LocalDate

/**
  * Created by 李磊 on 2018/01/08.
  * 每天跨境分类
  */

object CrossBorder {
  /**
    * 字段：
    * - name	                 分类名称
    * - product_onshelfs       在线商品数
    * - product_uploads        新上线商品数
    * - order_bill_count       下单数
    * - pay_bill_count         下单并支付数
    * - pay_product_count      支付商品数量
    * - pay_sku_count          支付SKU数量
    * - pay_bill_amount        支付订单金额
    * - pay_bill_avgs          支付订单客单价
    * - pay_bill_member        支付订单用户数
    * - pay_old_count          老用户支付订单数
    * - pay_old_amount         老用户支付订单额
    * - pay_old_member         老用户支付用户数
    * - pay_new_count          新用户支付订单数
    * - pay_new_amount         新用户支付订单额
    * - pay_new_member         新用户支付用户数
    * */

  def getTansDF(spark:SparkSession,appName:String, date: LocalDate): DataFrame = {

    var date_s = date.toString("yyyy-MM-dd")
    var date_e = date.plusDays(1).toString("yyyy-MM-dd")
//*******************新加字段 实销金额
    //订单品运费 三代数仓
    MailSource.getNewestDF(spark.table("tgouorder.order_item_ship"),Seq("id"),"modify_time").createOrReplaceTempView("order_item_ship")
    //订单品税 三代数仓
    MailSource.getNewestDF(spark.table("tgouorder.order_item_tax"),Seq("id"),"modify_time").createOrReplaceTempView("order_item_tax")
    //获取product_id
    spark.udf.register("product_id", (i:String)=>{val a= i.split("_")
      a(0)})
    //获取sku_id
    spark.udf.register("sku_id", (i:String)=>{val a= i.split("_")
      a(1)})
    //注册新表 order_item_ship_new
    spark.sql(
      s"""
         |  select fk_tgou_order_id, product_id(product_key) as product_id, sku_id(product_key) as sku_id, total_amount
         |  from order_item_ship
       """.stripMargin).createOrReplaceTempView("order_item_ship_new")
    //注册新表 order_item_tax_new
    spark.sql(
      s"""
         |select fk_tgou_order_id, sku_id, round(amount * quantity,2) as amount
         |from order_item_tax
       """.stripMargin).createOrReplaceTempView("order_item_tax_new")
    //商品金额
   val amount_sp = spark.sql(
  s"""
     |select
     |    b.product_second_category,
     |    sum(ordi.total_amount) as sp_amount
     |from  dw.order_product ord
     |  join dw.order_information ordi
     |    on ord.tgou_order_id = ordi.order_id
     |    and  ordi.his_time = '${date_s}'
     |    and ordi.pay_time >= '${date_s}'
     |    and ordi.pay_time < '${date_e}'
     |    and ordi.order_type = 0
     |  join dw.store s
     |    on ordi.store_id = s.id
     |    and s.his_time = '${date_s}'
     |    and s.yt = '4'
     |    and s.state = 'onshelf'
     |    and s.is_international = '1'
     |  join dw.listing a
     |    on a.listing_id = ord.mall_product_id
     |    and a.his_time = '${date_s}'
     |  join dw.product b
     |    on a.product_id = b.product_id
     |    and b.his_time = '${date_s}'
     |    and b.product_first_category  in ('101798','101761')
     |  left join dw.category ca
     |    on b.product_second_category = ca.id
     |    and ca.his_time = '${date_s}'
     |  where ord.his_time = '${date_s}'
     |    and ord.pay_time >= '${date_s}'
     |    and ord.pay_time < '${date_e}'
     | group by b.product_second_category
     |
   """.stripMargin)
    //税费
    val amount_sui = spark.sql(
      s"""
         |select
         |  b.product_second_category,
         |  sum(oix.amount) as sui_amount
         |from dw.order_product ord
         |  join dw.order_information ordi
         |    on ord.tgou_order_id = ordi.order_id
         |  join order_item_tax oix
         |    on ord.tgou_order_id = oix.fk_tgou_order_id
         |    and ord.sku_id = oix.sku_id
         |    and  ordi.his_time = '${date_s}'
         |    and ordi.pay_time >= '${date_s}'
         |    and ordi.pay_time < '${date_e}'
         |    and ordi.order_type = 0
         |  join dw.store s
         |    on ordi.store_id = s.id
         |    and s.his_time = '${date_s}'
         |    and s.yt = '4'
         |    and s.state = 'onshelf'
         |    and s.is_international = '1'
         |  join dw.listing a
         |    on a.listing_id = ord.mall_product_id
         |    and a.his_time = '${date_s}'
         |  join dw.product b
         |    on a.product_id = b.product_id
         |    and b.his_time = '${date_s}'
         |    and b.product_first_category  in ('101798','101761')
         |  left join dw.category ca
         |    on b.product_second_category = ca.id
         |    and ca.his_time = '${date_s}'
         |  where ord.his_time = '${date_s}'
         |    and ord.pay_time >= '${date_s}'
         |    and ord.pay_time < '${date_e}'
         |  group by b.product_second_category
   """.stripMargin)
    //运费
    val amount_yun = spark.sql(
      s"""
         |  select
         |      b.product_second_category,
         |      sum(oisn.total_amount) as yun_amount
         |  from  dw.order_product ord
         |    join dw.order_information ordi
         |      on ord.tgou_order_id = ordi.order_id
         |    join order_item_ship_new oisn --运费
         |      on ord.tgou_order_id = oisn.fk_tgou_order_id --运费
         |      and ord.sku_id = oisn.sku_id --运费
         |      and  ordi.his_time = '${date_s}'
         |      and ordi.pay_time >= '${date_s}'
         |      and ordi.pay_time < '${date_e}'
         |      and ordi.order_type = 0
         |    join dw.store s
         |      on ordi.store_id = s.id
         |      and s.his_time = '${date_s}'
         |      and s.yt = '4'   --you
         |      and s.state = 'onshelf'  --you
         |      and s.is_international = '1'
         |    join dw.listing a
         |      on a.listing_id = ord.mall_product_id
         |      and a.his_time = '${date_s}'
         |    join dw.product b
         |      on a.product_id = b.product_id
         |      and b.his_time = '${date_s}'
         |      and b.product_first_category  in ('101798','101761')
         |    left join dw.category ca
         |      on b.product_second_category = ca.id
         |      and ca.his_time = '${date_s}'
         |    where ord.his_time = '${date_s}'
         |      and ord.pay_time >= '${date_s}'
         |      and ord.pay_time < '${date_e}'
         |    group by b.product_second_category
   """.stripMargin)
    val crossBorder1_x = amount_sp.join(amount_sui,Seq("product_second_category"),"left")
      .join(amount_yun,Seq("product_second_category"),"left")
      .selectExpr("product_second_category",
        "round(sp_amount+nvl(sui_amount,0)+nvl(yun_amount,0),2) as amount")
    //*******************新加字段 实销金额

/*
跨境分类
* */
    /*
      * 每天跨境分类
      *  * - name	                 分类名称
      * - product_onshelfs       在线商品数
      * - product_uploads        新上线商品数
      * */

    val crossBorder1_1 = spark.sql(
      s"""
         |select b.product_second_category,
         |max(ca.name)  as name,
         |count(distinct a.listing_id) as product_onshelfs,
         |count(distinct
         |case
         |when a.onshelf_time >= '${date_s}'
         |and a.onshelf_time < '${date_e}'
         |then
         |a.listing_id end) as product_uploads
         |from dw.listing a
         |join dw.store s
         |on a.store_id = s.id
         |and s.his_time = '${date_s}'
         |and s.yt = '4'
         |and s.state = 'onshelf'
         |and s.is_international = '1'
         |join dw.product b
         |on a.product_id = b.product_id
         |and b.his_time = '${date_s}'
         |and b.product_first_category in ('101798','101761')
         |left join dw.category ca
         |on b.product_second_category = ca.id
         |and ca.his_time = '${date_s}'
         |where a.his_time = '${date_s}'
         |and a.state = 'onshelf'
         |group by b.product_second_category
      """.stripMargin)

    /*
      * 每天跨境分类
      * - order_bill_count       下单数
      * */

    val crossBorder1_2 = spark.sql(
      s"""
         |select b.product_second_category,
         |count(distinct ord.tgou_order_id) as order_bill_count
         |from  dw.order_product ord
         |join dw.order_information ordi
         |on ord.tgou_order_id = ordi.order_id
         |and ordi.his_time = '${date_s}'
         |and ordi.create_time >= '${date_s}'
         |and ordi.create_time < '${date_e}'
         |and ordi.order_type = 0
         |join dw.store s
         |on ordi.store_id = s.id
         |and s.his_time = '${date_s}'
         |and s.yt = '4'
         |and s.state = 'onshelf'
         |and s.is_international = '1'
         |join dw.listing a
         |on a.listing_id = ord.mall_product_id
         |and a.his_time = '${date_s}'
         |join dw.product b
         |on a.product_id = b.product_id
         |and b.his_time = '${date_s}'
         |and b.product_first_category  in ('101798','101761')
         |left join dw.category ca
         |on b.product_second_category = ca.id
         |and ca.his_time = '${date_s}'
         |where ord.his_time = '${date_s}'
         |and ord.create_time >= '${date_s}'
         |and ord.create_time < '${date_e}'
         |group by b.product_second_category
      """.stripMargin)

    /*
         * 每天跨境分类
         * - pay_bill_count         下单并支付数
         * - pay_product_count      支付商品数量
         * - pay_sku_count          支付SKU数量
         * - pay_bill_amount        支付订单金额
         * - pay_bill_avgs          支付订单客单价
         * - pay_bill_member        支付订单用户数
         * */

    val crossBorder1_3 = spark.sql(
      s"""
         |select b.product_second_category,
         |count(distinct ord.tgou_order_id ) as pay_bill_count,
         |nvl(cast(sum(ord.product_quantity) as decimal(18,0)),0) as pay_product_count,
         |count(distinct ord.sku_id ) as pay_sku_count,
         |nvl(cast(sum( ord.product_discount ) as decimal(18,2)),0) as pay_bill_amount,
         |round(sum(ord.product_discount )/
         |(case count(distinct ord.tgou_order_id )
         |when 0 then 1
         |else count(distinct ord.tgou_order_id)  end),2 ) as pay_bill_avgs,
         |count(distinct ordi.member_id ) AS pay_bill_member
         |from  dw.order_product ord
         |join dw.order_information ordi
         |on ord.tgou_order_id = ordi.order_id
         |and ordi.his_time = '${date_s}'
         |and ordi.pay_method != '010'
         |and ordi.pay_time >= '${date_s}'
         |and ordi.pay_time < '${date_e}'
         |and ordi.create_time >= '${date_s}'
         |and ordi.create_time < '${date_e}'
         |and ordi.order_type = 0
         |join dw.store s
         |on ordi.store_id = s.id
         |and s.his_time = '${date_s}'
         |and s.yt = '4'
         |and s.state = 'onshelf'
         |and s.is_international = '1'
         |join dw.listing a
         |on a.listing_id = ord.mall_product_id
         |and a.his_time = '${date_s}'
         |join dw.product b
         |on a.product_id = b.product_id
         |and b.his_time = '${date_s}'
         |and b.product_first_category  in ('101798','101761')
         |left join dw.category ca
         |on b.product_second_category = ca.id
         |and ca.his_time = '${date_s}'
         |where ord.his_time = '${date_s}'
         |and ord.create_time >= '${date_s}'
         |and ord.create_time < '${date_e}'
         |and ord.pay_time >= '${date_s}'
         |and ord.pay_time < '${date_e}'
         |group by b.product_second_category
      """.stripMargin)

    /*
         * 每天跨境分类
         * - pay_old_count          老用户支付订单数
         * - pay_old_amount         老用户支付订单额
         * - pay_old_member         老用户支付用户数
         * - pay_new_count          新用户支付订单数
         * - pay_new_amount         新用户支付订单额
         * - pay_new_member         新用户支付用户数
         * */

    val crossBorder1_4 = spark.sql(
      s"""
         |select
         |yd.product_second_category,
         |nvl(count(distinct case when isnull(ordi.member_id) = false then  yd.tgou_order_id end),0) as pay_old_count,
         |nvl(cast(sum( case when isnull(ordi.member_id) = false then  yd.product_discount end) as decimal(18,2)),0) as pay_old_amount,
         |nvl(count(distinct case when isnull(ordi.member_id) = false then  yd.member_id end),0) as pay_old_member,
         |nvl(count(distinct case when isnull(ordi.member_id) = true then  yd.tgou_order_id end),0) as pay_new_count,
         |nvl(cast(sum( case when isnull(ordi.member_id) = true then  yd.product_discount end) as decimal(18,2)),0) as pay_new_amount,
         |nvl(count(distinct case when isnull(ordi.member_id) = true then  yd.member_id end),0) as pay_new_member
         |from(select b.product_second_category,
         |ord.tgou_order_id,
         |ord.product_discount,
         |ordi.member_id,
         |ord.mall_product_id
         |from  dw.order_product ord
         |join dw.order_information ordi
         |on ord.tgou_order_id = ordi.order_id
         |and ordi.his_time = '${date_s}'
         |and ordi.pay_method != '010'
         |and ordi.pay_time >= '${date_s}'
         |and ordi.pay_time < '${date_e}'
         |and ordi.create_time >= '${date_s}'
         |and ordi.create_time < '${date_e}'
         |and ordi.order_type = 0
         |join dw.store s
         |on ordi.store_id = s.id
         |and s.his_time = '${date_s}'
         |and s.yt = '4'
         |and s.state = 'onshelf'
         |and s.is_international = '1'
         |join dw.listing a
         |on a.listing_id = ord.mall_product_id
         |and a.his_time = '${date_s}'
         |join dw.product b
         |on a.product_id = b.product_id
         |and b.his_time = '${date_s}'
         |and b.product_first_category  in ('101798','101761')
         |left join dw.category ca
         |on b.product_second_category = ca.id
         |and ca.his_time = '${date_s}'
         |where ord.his_time = '${date_s}'
         |and ord.create_time >= '${date_s}'
         |and ord.create_time < '${date_e}'
         |and ord.pay_time >= '${date_s}'
         |and ord.pay_time < '${date_e}'
         |group by b.product_second_category,
         |ord.tgou_order_id,
         |ord.product_discount,
         |ordi.member_id,
         |ord.mall_product_id) yd
         |left join (select ordi.member_id
         |from  dw.order_information ordi
         |join dw.store s
         |on ordi.store_id = s.id
         |and s.his_time = '${date_s}'
         |and s.yt = '4'
         |and s.state = 'onshelf'
         |and s.is_international = '1'
         |where ordi.his_time = '${date_s}'
         |and ordi.pay_time < '${date_s}'
         |and ordi.pay_method != '010'
         |and ordi.order_type = 0
         |group by ordi.member_id) ordi
         |on yd.member_id = ordi.member_id
         |group by yd.product_second_category
      """.stripMargin)

    val crossBorder1 = crossBorder1_1.join(crossBorder1_2,crossBorder1_1("product_second_category") === crossBorder1_2("product_second_category"),"left")
      .join(crossBorder1_3,crossBorder1_1("product_second_category") === crossBorder1_3("product_second_category"),"left")
      .join(crossBorder1_4,crossBorder1_1("product_second_category") === crossBorder1_4("product_second_category"),"left")
      .join(crossBorder1_x,crossBorder1_1("product_second_category") === crossBorder1_x("product_second_category"),"left")
      .select(crossBorder1_1("product_second_category"),
        crossBorder1_1("name"),
        crossBorder1_1("product_onshelfs"),
        crossBorder1_1("product_uploads"),
        crossBorder1_2("order_bill_count"),
        crossBorder1_3("pay_bill_count"),
        crossBorder1_3("pay_product_count"),
        crossBorder1_3("pay_sku_count"),
        crossBorder1_3("pay_bill_amount"),
        crossBorder1_3("pay_bill_avgs"),
        crossBorder1_3("pay_bill_member"),
        crossBorder1_4("pay_old_count"),
        crossBorder1_4("pay_old_amount"),
        crossBorder1_4("pay_old_member"),
        crossBorder1_4("pay_new_count"),
        crossBorder1_4("pay_new_amount"),
        crossBorder1_4("pay_new_member"),
        crossBorder1_x("amount")
      )

    val crossBorder = crossBorder1.selectExpr("product_second_category",
      "name",
      "product_onshelfs",
      "product_uploads",
      "nvl(order_bill_count,0) as order_bill_count",
      "nvl(pay_bill_count,0) as pay_bill_count",
      "nvl(pay_product_count,0) as pay_product_count",
      "nvl(pay_sku_count,0) as pay_sku_count",
      "nvl(pay_bill_amount,0) as pay_bill_amount",
      "nvl(pay_bill_avgs,0) as pay_bill_avgs",
      "nvl(pay_bill_member,0) as pay_bill_member",
      "nvl(pay_old_count,0) as pay_old_count",
      "nvl(pay_old_amount,0) as pay_old_amount",
      "nvl(pay_old_member,0) as pay_old_member",
      "nvl(pay_new_count,0) as pay_new_count",
      "nvl(pay_new_amount,0) as pay_new_amount",
      "nvl(pay_new_member,0) as pay_new_member",
      "nvl(amount,0) as sx_amount"
    )

    return crossBorder

  }
}

