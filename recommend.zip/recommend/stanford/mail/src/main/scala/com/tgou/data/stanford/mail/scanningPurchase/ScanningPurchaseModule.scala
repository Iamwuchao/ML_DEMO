package  com.tgou.data.stanford.mail.scanningPurchase

import org.apache.spark.sql.{DataFrame, SparkSession, functions}
import org.joda.time.LocalDate


/**
  * Created by 李磊 on 2018/05/10.
  * 扫码购
  */

object ScanningPurchaseModule {
  /**
    * 字段：
    * - store_name                     店铺名称+店铺编码
    * - area_name                      地区
    * - bsz                            全店交易笔数
    * - jez                            全店交易金额
    * - bs5                            全店5类以下笔数
    * - je5                            全店5类以下金额
    * - bs5lv                          全店5类以下数量占比
    * - je5lv                          全店5类以下金额占比
    * - jes                            扫码购总金额
    *  - bss                           扫码购交易笔数
    *  - sls                           扫码购商品总数
    *  - pls                           扫码购品类数量
    *  - pps                           扫码购品牌数量
    *  - bst                           扫码购退货笔数
    *  - jet                           扫码购退货金额
    *  - zflv                          扫码购支付率
    *  - wclv                          扫码购完成率
    * */
  def getTansDF(spark:SparkSession, date: LocalDate): DataFrame = {

    val dateT = date.toString("yyyy-MM-dd")

    val dateTE = date.plusDays(1).toString("yyyy-MM-dd")



    /*
    * 扫码购
    * */

    val returngoods = spark.sql(
      s"""
         |select concat(z1.store_name,z1.store_code) as store_name,
         |z1.area_name,
         |z2.bsz,
         |nvl(cast(z2.jez as decimal(18,2)),0) as jez,
         |z2.bs5,
         |nvl(cast(z2.je5 as decimal(18,2)),0) as je5,
         |cast(z2.bs5/z2.bsz as decimal(3,2))  * 100  as bs5lv,
         |cast(z2.je5/z2.jez as decimal(3,2))  * 100 as je5lv,
         |nvl(cast(z1.je as decimal(18,2)),0) as jes,
         |z1.bs as bss,
         |z1.sl as sls,
         |z3.pls,
         |z3.pps,
         |nvl(z4.bs,0) as bst,
         |nvl(cast(z4.je as decimal(18,2)),0) as jet,
         |cast(z1.bs/z5.bs as decimal(3,2)) * 100  as zflv,
         |cast(z6.bs/z1.bs as decimal(3,2)) * 100 as wclv
         |from (select max(a.area_name) as area_name,
         |max(a.store_name) as store_name,
         |a.store_id,
         |max(a.store_code) as store_code,
         |count(a.order_id) as bs,
         |sum(a.je) as je,
         |sum(a.sl) as sl
         |from (select max(b.area_name) as area_name,
         |max(b.store_name) as store_name,
         |a.store_id,
         |max(b.store_code) as store_code,
         |a.order_id,
         |max(a.order_actual_sales_amount) as je,
         |sum(quantity) as sl
         |from tgdw.order_item_fact a
         |left join tgdw.store_dim b
         |on a.store_id = b.store_id
         |and b.store_state = 'onshelf'
         |where substr(order_origin_fixed_tags,10,1) = '1'
         |and a.order_pay_time >= '${dateT}'
         |and a.order_pay_time < '${dateTE}'
         |and a.order_pay_method != 'NOT_PAY'
         |group by a.store_id,a.order_id) a
         |group by a.store_id) z1
         |left join(select zz.storecode,
         |count(zz.JYSBM) as bsz,
         |sum(zz.JYJE) as jez,
         |count(case when isnull(z.storecode) = false then zz.JYSBM end) as bs5,
         |sum(case when isnull(z.storecode) = false then zz.JYJE end) as je5
         |from dw.pos_zz zz
         |left join (select mx.storecode,mx.JYSBM
         |from dw.pos_mx mx
         |where mx.his_time >= '${dateT}'
         |and mx.his_time < '${dateTE}'
         |group by mx.storecode,mx.JYSBM
         |having count(distinct mx.FLH4) < 6) z
         |on zz.storecode = z.storecode
         |and zz.JYSBM = z.JYSBM
         |where zz.his_time >= '${dateT}'
         |and zz.his_time < '${dateTE}'
         |group by zz.storecode) z2
         |on z1.store_code = z2.storecode
         |left join(select a.store_id,
         |count(distinct b.FLH4) as pls,
         |count(distinct b.PPBM) as pps
         |from tgdw.order_item_fact a
         |join dw.pos_mx b
         |on a.order_id=  b.TGOU_ORDER_ID
         |and b.his_time >= '${dateT}'
         |and b.his_time < '${dateTE}'
         |where substr(a.order_origin_fixed_tags,10,1) = '1'
         |and a.order_pay_time >= '${dateT}'
         |and a.order_pay_time < '${dateTE}'
         |and a.order_pay_method != 'NOT_PAY'
         |group by a.store_id) z3
         |on z1.store_id = z3.store_id
         |left join(select a.store_id,
         |count(a.order_id) as bs,
         |sum(a.je) as je
         |from (select a.store_id,
         |a.order_id,
         |max(a.order_actual_sales_amount) as je
         |from tgdw.order_item_fact a
         |where substr(order_origin_fixed_tags,10,1) = '1'
         |and a.order_return_time >= '${dateT}'
         |and a.order_return_time < '${dateTE}'
         |group by a.store_id,a.order_id) a
         |group by a.store_id) z4
         |on z1.store_id = z4.store_id
         |left join(select a.store_id,
         |count(a.order_id) as bs,
         |sum(a.je) as je
         |from (select a.store_id,
         |a.order_id,
         |max(a.order_actual_sales_amount) as je
         |from tgdw.order_item_fact a
         |where substr(order_origin_fixed_tags,10,1) = '1'
         |and a.order_create_time >= '${dateT}'
         |and a.order_create_time < '${dateTE}'
         |group by a.store_id,a.order_id) a
         |group by a.store_id) z5
         |on z1.store_id = z5.store_id
         |left join(select a.store_id,
         |count(a.order_id) as bs,
         |sum(a.je) as je
         |from (select a.store_id,
         |a.order_id,
         |max(a.order_actual_sales_amount) as je
         |from tgdw.order_item_fact a
         |where substr(order_origin_fixed_tags,10,1) = '1'
         |and a.order_ship_time >= '${dateT}'
         |and a.order_ship_time < '${dateTE}'
         |group by a.store_id,a.order_id) a
         |group by a.store_id) z6
         |on z1.store_id = z6.store_id
      """.stripMargin)

    return returngoods
  }
}