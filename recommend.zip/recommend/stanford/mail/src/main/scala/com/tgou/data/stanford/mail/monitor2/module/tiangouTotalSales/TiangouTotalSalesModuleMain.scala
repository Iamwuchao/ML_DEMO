package com.tgou.data.stanford.mail.monitor2.module.tiangouTotalSales

import com.tgou.data.stanford.mail.core.MailBootstrap
import org.apache.spark.sql.SparkSession
import org.joda.time.LocalDate


object TiangouTotalSalesModuleMain {
  def main(args: Array[String]): Unit = {
    MailBootstrap(args).bootstrap(execute)
  }

  def execute(spark: SparkSession, appName: String, date: LocalDate): Unit = {
    TiangouTotalSalesModule.getTansDF(spark, date).show()
  }
}