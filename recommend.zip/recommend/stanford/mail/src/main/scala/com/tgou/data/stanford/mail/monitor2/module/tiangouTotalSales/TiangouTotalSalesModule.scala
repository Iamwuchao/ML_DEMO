package com.tgou.data.stanford.mail.monitor2.module.tiangouTotalSales

import com.tgou.data.stanford.mail.core.MailSource
import org.apache.spark.sql.types._
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.joda.time.LocalDate

/**
  * Created by 李磊 on 2017/12/04.
  * 天狗总销
  */

object TiangouTotalSalesModule {
  /**
    * 字段：
    * - tiangou_shh_jye  天狗订单交易额（社会化）
    * - tiangou_std_jye 天狗订单交易额（实体店）
    * - tiangou_sm_jye   扫结算码交易额
    * - tiangou_juan_ldjye 券核销连带交易额
    * - tiangou_juan_yjye  天狗总销-⽉累计
    * - tiangou_juan_hbjye 天狗总销-环比
    * - tiangou_zxbs_month 天狗总销笔数（月累计）
    * - tiangou_zxrs_month 天狗总销人数（月累计）
    * */

  def getTansDF(spark:SparkSession, date: LocalDate): DataFrame = {


    //本月的第一天
    val month = date.withDayOfMonth(1).toString("yyyy-MM-dd")
    //本月的昨天
    val yesterday = date.toString("yyyy-MM-dd")
    //上个月的第一天
    val lastMonthFirstDay = date.minusMonths(1).withDayOfMonth(1).toString("yyyy-MM-dd")
    //上个月的昨天
    var lastMonthYesterday = date.minusMonths(1).toString("yyyy-MM-dd")

    // 订单其他金额（除订单金额外订单金额）
    val oa = StructType(
      StructField("id", StringType, false) ::
        StructField("fk_tgou_order_id", StringType, true) ::
        StructField("name", StringType, true) ::
        StructField("type", StringType, true) ::
        StructField("sub_type", StringType, true) ::
        StructField("biz_id", StringType, true) ::
        StructField("amount", DoubleType, true) ::
        StructField("frozen_amount", DoubleType, true) ::
        StructField("balance", DoubleType, true) ::
        StructField("quantity", LongType, true) ::
        StructField("state", StringType, true) ::
        StructField("pay_method", StringType, true) ::
        StructField("mis_amount_code", StringType, true) ::
        StructField("exchange_rate", StringType, true) ::
        StructField("currency_code", StringType, true) ::
        StructField("create_time", StringType, true) ::
        StructField("modify_time", StringType, true) ::
        StructField("ext", StringType, true) ::
        StructField("version", StringType, true) ::
        StructField("paid_payment_id", StringType, true) ::
        StructField("card_no", StringType, true) ::Nil
    )
    MailSource.getUpdateDF(spark,"/tiangou/tgouorder/order_amount",date,Seq("id"),"modify_time",oa).distinct()
      .createOrReplaceTempView("order_amount")

    /*
        * 天狗订单交易额（社会化）
        * */
    val tiangou_shh_jye = spark.sql(
      s"""
         |select sum(nvl(a.product_discount,0))+sum(nvl(b.amount,0)) as tiangou_shh_jye
         |from(
         |  select
         |      b.order_id,
         |      nvl(cast(sum(a.product_discount) as decimal(18,2)),0) as product_discount
         |   from dw.order_information  b
         |   join dw.order_product a
         |   on b.order_id  = a.tgou_order_id
         |   and a.his_time = '${yesterday}'
         |   where b.his_time = '${yesterday}'
         |   and b.order_source = '4'
         |   and b.order_type = '0'
         |   and b.pay_method != '000'
         |   and b.pay_method != '010'
         |   and b.pay_time >= '${yesterday}'
         |   and b.pay_time < date_sub('${yesterday}', -1)
         |   group by b.order_id
         |) a
         |left join(
         |   select
         |       oa.fk_tgou_order_id,
         |       nvl(cast(sum(oa.amount) as decimal(18,2)),0) as amount
         |    from order_amount oa
         |    where oa.type in('4','5')
         |    group by oa.fk_tgou_order_id
         |) b
         |on a.order_id = b.fk_tgou_order_id
      """.stripMargin)

    /*
       * 天狗订单交易额（实体店）
       * */
    val tiangou_std_jye = spark.sql(
      s"""
         |select sum(nvl(a.product_discount,0))+sum(nvl(b.amount,0)) as tiangou_std_jye
         |from(
         |   select
         |      b.order_id,
         |      nvl(cast(sum(a.product_discount) as decimal(18,2)),0) as product_discount
         |   from dw.order_information  b
         |   join dw.order_product a
         |   on b.order_id  = a.tgou_order_id
         |   and a.his_time = '${yesterday}'
         |   where b.his_time = '${yesterday}'
         |   and b.order_source in ('1','2')
         |   and b.order_type = '0'
         |   and b.pay_method != '010'
         |   and b.pay_time >= '${yesterday}'
         |   and b.pay_time < date_sub('${yesterday}', -1)
         |   group by b.order_id
         |) a
         |left join(
         |    select
         |       oa.fk_tgou_order_id,
         |       nvl(cast(sum(oa.amount) as decimal(18,2)),0) as amount
         |    from order_amount oa
         |    where oa.type in('4','5')
         |    group by oa.fk_tgou_order_id
         |) b
         |on a.order_id = b.fk_tgou_order_id
      """.stripMargin)

    /*
       * 扫结算码交易额
       * */
    val tiangou_sm_jye = spark.sql(
      s"""
         |select nvl(cast(sum(jyje) as decimal(18,2)),0) as tiangou_sm_jye
         |from dw.pos_zz  a
         |where a.his_time >= '${yesterday}'
         |and a.his_time < date_sub('${yesterday}', -1)
         |and a.thyy in ('03', '04', '05', '06', '07', '09')
         |and tgou_coupon = false
         |and tgou_order = false
         |and jyje > 0
      """.stripMargin)

    /*
       * 券核销连带交易额
       * */
    val tiangou_juan_ldjye = spark.sql(
      s"""
         |select nvl(cast(sum(jyje) as decimal(18,2)),0) as tiangou_juan_ldjye
         |from dw.pos_zz  a
         |where a.his_time >= '${yesterday}'
         |and a.his_time < date_sub('${yesterday}', -1)
         |and tgou_coupon = true
         |and jyje > 0
      """.stripMargin)

    /*
      * 天狗总销-⽉累计
      * */

    val tiangou_juan_yjye1 = spark.sql(
      s"""
         |select sum(nvl(a.product_discount,0))+sum(nvl(b.amount,0)) as tiangou_shh_jye1
         |from(
         |  select
         |      b.order_id,
         |      nvl(cast(sum(a.product_discount) as decimal(18,2)),0) as product_discount
         |  from dw.order_information  b
         |  join dw.order_product a
         |  on b.order_id  = a.tgou_order_id
         |  and a.his_time = '${yesterday}'
         |  where b.his_time = '${yesterday}'
         |  and b.order_source = '4'
         |  and b.order_type = '0'
         |  and b.pay_method != '000'
         |  and b.pay_method != '010'
         |  and b.pay_time >= '${month}'
         |  and b.pay_time < date_sub('${yesterday}', -1)
         |  group by b.order_id
         |)a
         |left join(
         |    select
         |       oa.fk_tgou_order_id,
         |       nvl(cast(sum(oa.amount) as decimal(18,2)),0) as amount
         |    from order_amount oa
         |    where oa.type in('4','5')
         |    group by oa.fk_tgou_order_id
         |) b
         |on a.order_id = b.fk_tgou_order_id
      """.stripMargin)

    val tiangou_juan_yjye2 = spark.sql(
      s"""
         |select sum(nvl(a.product_discount,0))+sum(nvl(b.amount,0))  as tiangou_std_jye2
         |from(
         |   select
         |      b.order_id,
         |      nvl(cast(sum(a.product_discount) as decimal(18,2)),0) as product_discount
         |   from dw.order_information  b
         |   join dw.order_product a
         |   on b.order_id  = a.tgou_order_id
         |   and a.his_time = '${yesterday}'
         |   where b.his_time = '${yesterday}'
         |   and b.order_source in ('1','2')
         |   and b.order_type = '0'
         |   and b.pay_method != '010'
         |   and b.pay_time >= '${month}'
         |   and b.pay_time < date_sub('${yesterday}', -1)
         |   group by b.order_id
         |) a
         |left join(
         |    select
         |       oa.fk_tgou_order_id,
         |       nvl(cast(sum(oa.amount) as decimal(18,2)),0) as amount
         |    from order_amount oa
         |    where oa.type in('4','5')
         |    group by oa.fk_tgou_order_id
         |) b
         |on a.order_id = b.fk_tgou_order_id
      """.stripMargin)



    val tiangou_juan_yjye3 = spark.sql(
      s"""
         |select nvl(cast(sum(jyje) as decimal(18,2)),0) as tiangou_sm_jye3
         |from dw.pos_zz  a
         |where a.his_time >= '${month}'
         |and a.his_time < date_sub('${yesterday}', -1)
         |and (a.thyy in ('03', '04', '05', '06', '07', '09') or tgou_coupon = true )
         |and tgou_order = false
         |and jyje > 0
      """.stripMargin)




    val yjye = tiangou_juan_yjye1.first().get(0).toString.toDouble + tiangou_juan_yjye2.first().get(0).toString.toDouble + tiangou_juan_yjye3.first().get(0).toString.toDouble

    val yjyeList =   List(YjyeClass(yjye))


    val tiangou_juan_yjye = spark.createDataFrame(yjyeList).selectExpr("nvl(cast( tiangou_juan_yjye as decimal(18,2)),0) as tiangou_juan_yjye")

    /*
      * 天狗总销-环比
      * */
    val hbjye1 = spark.sql(
      s"""
         |select sum(nvl(a.product_discount,0))+sum(nvl(b.amount,0)) as tiangou_shh_jye
         |from(
         |   select
         |      b.order_id,
         |      nvl(cast(sum(a.product_discount) as decimal(18,2)),0) as product_discount
         |   from dw.order_information  b
         |   join dw.order_product a
         |   on b.order_id  = a.tgou_order_id
         |   and a.his_time = '${yesterday}'
         |   where b.his_time = '${yesterday}'
         |   and b.order_source = '4'
         |   and b.order_type = '0'
         |   and b.pay_method != '000'
         |   and b.pay_method != '010'
         |   and b.pay_time >= '${lastMonthFirstDay}'
         |   and b.pay_time < date_sub('${lastMonthYesterday}', -1)
         |   group by b.order_id
         |) a
         |left join(
         |    select
         |       oa.fk_tgou_order_id,
         |       nvl(cast(sum(oa.amount) as decimal(18,2)),0) as amount
         |    from order_amount oa
         |    where oa.type in('4','5')
         |    group by oa.fk_tgou_order_id
         |) b
         |on a.order_id = b.fk_tgou_order_id
      """.stripMargin)


    val hbjye2 = spark.sql(
      s"""
         |select sum(nvl(a.product_discount,0))+sum(nvl(b.amount,0))  as tiangou_std_jye2
         |from(
         |   select
         |      b.order_id,
         |      nvl(cast(sum(a.product_discount) as decimal(18,2)),0) as product_discount
         |   from dw.order_information  b
         |   join dw.order_product a
         |   on b.order_id  = a.tgou_order_id
         |   and a.his_time = '${yesterday}'
         |   where b.his_time = '${yesterday}'
         |   and b.order_source in ('1','2')
         |   and b.order_type = '0'
         |   and b.pay_method != '010'
         |   and b.pay_time >= '${lastMonthFirstDay}'
         |   and b.pay_time < date_sub('${lastMonthYesterday}', -1)
         |   group by b.order_id
         |) a
         |left join(
         |    select
         |       oa.fk_tgou_order_id,
         |       nvl(cast(sum(oa.amount) as decimal(18,2)),0) as amount
         |    from order_amount oa
         |    where oa.type in('4','5')
         |    group by oa.fk_tgou_order_id
         |) b
         |on a.order_id = b.fk_tgou_order_id
      """.stripMargin)


    val hbjye3 = spark.sql(
      s"""
         |select nvl(cast(sum(jyje) as decimal(18,2)),0) as tiangou_sm_jye3
         |from dw.pos_zz  a
         |where a.his_time >= '${lastMonthFirstDay}'
         |and a.his_time < date_sub('${lastMonthYesterday}', -1)
         |and (a.thyy in ('03', '04', '05', '06', '07', '09') or tgou_coupon = true )
         |and tgou_order = false
         |and jyje > 0
      """.stripMargin)

    var hbjye = hbjye1.first().get(0).toString.toDouble + hbjye2.first().get(0).toString.toDouble + hbjye3.first().get(0).toString.toDouble

    var tiangou_juan_hbjye1 = 0.0

    if (hbjye > 0) {
      tiangou_juan_hbjye1 = (yjye - hbjye) / hbjye * 100
    }
    val tiangou_juan_hbjye2 = f"$tiangou_juan_hbjye1%1.2f"
    var hbjyeList =   List(HbjyeClass(tiangou_juan_hbjye2))

    val tiangou_juan_hbjye = spark.createDataFrame(hbjyeList)

    /*
      *  天狗总销笔数（月累计）
      * */
    val tiangou_zxbs_month = spark.sql(
      s"""
         |select
         |    sum(count_order) as tiangou_zxbs_month
         |from(
         |   select
         |      count(distinct b.order_id) as count_order
         |   from dw.order_information  b
         |   join dw.order_product a
         |   on b.order_id  = a.tgou_order_id
         |   and a.his_time = '${yesterday}'
         |   where b.his_time = '${yesterday}'
         |   and
         |   (
         |     (b.order_source = '4'
         |     and b.order_type = '0'
         |     and b.pay_method != '000'
         |     and b.pay_method != '010')
         |     or
         |     (b.order_source in ('1','2')
         |     and b.order_type = '0'
         |     and b.pay_method != '010')
         |   )
         |   and to_date(b.pay_time) >= '${month}'
         |   and to_date(b.pay_time) < date_sub('${yesterday}', -1)
         |union
         |  select
         |      count(distinct a.JYSBM) as count_order
         |  from dw.pos_zz  a
         |  where a.his_time >= '${month}'
         |  and a.his_time < date_sub('${yesterday}', -1)
         |  and
         |  (
         |    (a.thyy in ('03', '04', '05', '06', '07', '09')
         |    and a.tgou_coupon = false)
         |    or
         |    (a.tgou_coupon = true)
         |  )
         |  and a.tgou_order = false
         |  and a.jyje > 0
         |)
       """.stripMargin)

    /*
      *  天狗总销人数（月累计）
      * */
    val tiangou_zxrs_month = spark.sql(
      s"""
         |select count(distinct member_id) as tiangou_zxrs_month
         |from (
         |    select
         |        b.member_id
         |    from dw.order_information  b
         |    join dw.order_product a
         |    on b.order_id  = a.tgou_order_id
         |    and a.his_time = '${yesterday}'
         |    where b.his_time = '${yesterday}'
         |    and
         |    (
         |     (b.order_source = '4'
         |     and b.order_type = '0'
         |     and b.pay_method != '000'
         |     and b.pay_method != '010')
         |     or
         |     (b.order_source in ('1','2')
         |     and b.order_type = '0'
         |     and b.pay_method != '010')
         |   )
         |   and to_date(b.pay_time) >= '${month}'
         |   and to_date(b.pay_time) < date_sub('${yesterday}', -1)
         |union
         |    select
         |        b.member_id
         |    from(
         |      select
         |           a.cid
         |      from dw.pos_zz  a
         |      where a.his_time >= '${month}'
         |      and a.his_time < date_sub('${yesterday}', -1)
         |      and a.thyy in ('03', '04', '05', '06', '07', '09')
         |      and a.tgou_coupon = false
         |      and a.tgou_order = false
         |      and a.jyje > 0) a
         |    join (
         |        select
         |            pm.card_id,
         |            pm.member_id
         |        from dw.ds_card_bind pm
         |        where pm.his_time = '${yesterday}'
         |    ) b
         |    on a.cid = b.card_id
         |union
         |   select
         |      c.member_id
         |   from dw.pos_fk f
         |   left join dw.coupon_code c
         |   on  c.coupon_code_id = f.coupon_code
         |   and c.his_time ='${yesterday}'
         |   inner join dw.pos_zz a
         |   on a.jysbm=f.jysbm
         |   and a.jyje>0
         |   and a.his_time >= '${month}'
         |   and a.his_time < date_sub('${yesterday}', -1)
         |   where 1=1
         |   and f.fkfsh in('81','83','86')
         |   and f.his_time >= '${month}'
         |   and f.his_time < date_sub('${yesterday}', -1)
         |)
       """.stripMargin)

    val rs = tiangou_shh_jye.crossJoin(tiangou_std_jye)
      .crossJoin(tiangou_sm_jye)
      .crossJoin(tiangou_juan_ldjye)
      .crossJoin(tiangou_juan_yjye)
      .crossJoin(tiangou_juan_hbjye)
      .crossJoin(tiangou_zxbs_month)
      .crossJoin(tiangou_zxrs_month)
      .select(
        "tiangou_shh_jye",
        "tiangou_std_jye",
        "tiangou_sm_jye",
        "tiangou_juan_ldjye",
        "tiangou_juan_yjye",
        "tiangou_juan_hbjye",
        "tiangou_zxbs_month",
        "tiangou_zxrs_month"
      )

    return rs
  }

  /*
  ⽉累计
   */

  case class YjyeClass(tiangou_juan_yjye:Double)

  /*
 环比
  */

  case class HbjyeClass(tiangou_juan_hbjye:String)
}