package com.tgou.data.stanford.mail.counterSummary

import com.tgou.data.stanford.mail.core.MailSource
import org.apache.spark.sql.types._
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.joda.time.LocalDate

/**
  * Created by 刘洋 on 2018/02/27.
  */
object SummaryModule {
  /**
    * @param spark
    * @param date
    *
    * @return
    *
    * */
  def queryDF(spark: SparkSession, date: LocalDate): DataFrame = {

    val ysday = date.toString("yyyy-MM-dd")

    /**
      *读取抽取层counter表中当天的数据
      * */
    val tmp = spark.read.format("csv")
      .option("delimiter", "^")
      .option("qoute", "")
      .option("nullValue", "\\N")
      .load(s"hdfs://nameservice1/tiangou/tgou/counter/*/*/*")
      .select("_c0","_c1","_c2","_c6","_c8","_c9","_c10","_c19").toDF("id","name","fk_store_id","fk_brand_id","mis_code","fk_sold_area_id","state","modify_time")
      tmp.createTempView("counter1")
    /**
      * area_name  地区
      * store_name 店铺
      * store_code  店铺编码
      * sold_type_name   业种
      * sold_area_name  卖区
      * counter_name  专柜
      * mis_code 专柜MIS编码
      * brand_name 品牌
      * zsps 在售款数
      * kjps 快捷品数
      * */
    val query = spark.sql(
      s"""
         |select
         |  distinct
         |  s.area_name,
         |  x.store_name,
         |  s.store_code,
         |  nvl(x.yzm," ") as yzm,
         |  nvl(x.mqm," ") as mqm,
         |  nvl(x.zgm," ") as zgm,
         |  nvl(y.mis," ") as mis,
         |  nvl(y.ppm," ") as ppm,
         |  x.zsps,
         |  z.kjps
         |from (
         |  select
         |    distinct
         |    a.store_id,
         |    a.counter_id,
         |    a.counter_name as zgm,
         |    a.sold_area_name as mqm,
         |    a.sold_type_name as yzm,
         |    a.store_name,
         |    max(a.fk_product_id) as fk_product_id,
         |    nvl(count(id),0) as zsps
         |  from dw.listing a
         |    where
         |    1=1
         |    and a.his_time = '${ysday}'
         |    and a.state = 'onshelf'
         |    and a.source = '1'
         |  group by a.store_id,a.counter_id,a.counter_name,a.sold_area_name,a.sold_type_name,a.store_name
         |    ) x
         |left join (
         |  select
         |    distinct
         |    a.store_id,
         |    a.counter_id,
         |    a.counter_name as zgm,
         |    a.sold_area_name as mqm,
         |    a.sold_type_name as yzm,
         |    a.store_name,
         |    count(distinct case when a.is_fast_sales = TRUE then listing_id end ) as kjps
         |  from dw.listing a
         |    where
         |    1=1
         |    and a.his_time = '${ysday}'
         |    and a.source = '1'
         |  group by a.store_id,a.counter_id,a.counter_name,a.sold_area_name,a.sold_type_name,a.store_name
         |    ) z
         |  on x.store_id = z.store_id
         |  and x.counter_id = z.counter_id
         |  and x.zgm = z.zgm
         |  and x.mqm = z.mqm
         |  and x.yzm = z.yzm
         |  and x.store_name = z.store_name
         |left join
         |  dw.store s
         |    on x.store_id = s.id
         |    and s.his_time = '${ysday}'
         |    and s.state = 'onshelf'
         |left join
         |(
         |  select
         |    a.id,
         |    b.brand_name as ppm,
         |    max(a.mis_code) as mis
         |  from counter1 a
         |  join
         |  (
         |    select
         |        brand_id,
         |        max(brand_name) as brand_name
         |    from dw.product
         |      where
         |      1=1
         |      and his_time = '${ysday}'
         |    group by brand_id
         |   ) b
         |    on a.fk_brand_id = b.brand_id
         |    and a.state = '1'
         |  group by a.id,b.brand_name
         |) y
         | on x.counter_id = y.id
         | group by s.area_name,x.store_name,s.store_code,x.yzm,x.mqm,x.zgm,y.mis,y.ppm,x.zsps,z.kjps
       """.stripMargin
    )
    query
  }

}
