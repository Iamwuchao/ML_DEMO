package com.tgou.data.stanford.ods.core;

/**
 * Created by 李震 on 2018/3/1.
 */
public enum ODSMode {

    COMPLETED, // 全量
    APPEND, // 增量
    UPDATE // 修改

}
