package com.tgou.data.stanford.ods.core;

/**
 * Created by 李震 on 2018/3/1.
 */
public interface Constants {

    String JOB_CONF_BASE_PATH = "/app/tgods/conf/job"; // 任务配置根目录

    String DB_CONF_BASE_PATH = "/app/tgods/conf/db"; // 数据库配置根目录

    String CACHE_CONF_BASE_PATH = "/app/tgods/conf/cache/redis.json"; // 缓存配置目录

}
