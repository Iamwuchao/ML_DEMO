package com.tgou.data.stanford.ods

import com.google.inject.AbstractModule
import com.google.inject.name.Names
import com.tgou.data.stanford.ods.core.{ODSConf, ODSDataSource, ODSMetadata}
import org.apache.spark.sql.SparkSession

/**
  * Created by 李震 on 2018/3/1.
  */
class ApplicationModule(spark: SparkSession, appName: String) extends AbstractModule {

  override def configure(): Unit = {
    bind(classOf[SparkSession]).toInstance(spark)
    bind(classOf[String]).annotatedWith(Names.named("appName")).toInstance(appName)
    bind(classOf[ODSConf])
    bind(classOf[ODSMetadata])
    bind(classOf[ODSDataSource])
  }

}
