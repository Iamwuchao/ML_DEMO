package com.tgou.data.stanford.dw.order_item_uba.bean

case class OrderItemAndTgs (
                        order_item_id: String,
                        tgou_order_id: String,
                        mall_product_id: String,
                        shop_cart_id: String,
                        order_item_create_time: String,
                        shop_cart_create_time: String,
                        member_id: String,
                        source_jr: String,
                        source_global: String,
                        global: String,
                        jr: String,
                        page: String,
                        scp: String,
                        time: String
                      )
