package com.tgou.data.stanford.dw.order_wide_column

import com.tgou.data.stanford.dw.core.{DWBootstrap, ODSSink}
import org.apache.spark.sql.SparkSession
import org.joda.time.LocalDate

/**
  * Created by 李震 on 2018/4/21.
  */
object Application {

  def main(args: Array[String]): Unit = {
    DWBootstrap(args).bootstrapWithCassandra(execute)
  }

  def execute(spark: SparkSession, appName: String, date: LocalDate): Unit = {
    /*
     * 1. 维度表写入 Cassandra
     * */
    val storeDimDF = spark.table("tgdw.store_dim") // 店铺维度表
    ODSSink.sink2Cassandra(storeDimDF, "store_dim")

    val memberDimDF = spark.table("tgdw.member_dim") // 会员维度表
    ODSSink.sink2Cassandra(memberDimDF, "member_dim")

    val skuDimDF = spark.table("tgdw.sku_dim") // SKU 维度表
    ODSSink.sink2Cassandra(skuDimDF, "sku_dim")

    /*
     * 2. 事实表写入 Cassandra
     * */
    val orderItemFactDF = spark.sql(
      """
        |select
        |  oi.sku_id,
        |  oi.order_id,
        |  oi.brand_id,
        |  oi.level_one_category_code,
        |  oi.level_two_category_code,
        |  oi.level_three_category_code,
        |  oi.level_four_category_code,
        |  oi.price,
        |  oi.quantity
        |from tgdw.order_item_fact oi
      """.stripMargin) // 订单品粒度表
    ODSSink.sink2Cassandra(orderItemFactDF, "order_item_fact")

    val orderFactDF = spark.sql(
      """
        |select
        |  oi.order_id,
        |  max(oi.store_id) as store_id,
        |  max(oi.source) as source,
        |  max(oi.member_id) as member_id,
        |  max(oi.order_type) as order_type,
        |  max(oi.order_pay_method) as order_pay_method,
        |  max(oi.order_delivery_method) as order_delivery_method,
        |  max(oi.order_create_time) as order_create_time,
        |  max(oi.order_cancel_time) as order_cancel_time,
        |  max(oi.order_pay_time) as order_pay_time,
        |  max(oi.order_ship_time) as order_ship_time,
        |  max(oi.order_return_time) as order_return_time,
        |  max(oi.order_finish_time) as order_finish_time,
        |  max(oi.order_amount) as order_amount,
        |  max(oi.order_tax) as order_tax,
        |  max(oi.order_shipping_costs) as order_shipping_costs,
        |  max(oi.order_coupon_amount) as order_coupon_amount,
        |  max(oi.order_activity_amount) as order_activity_amount,
        |  max(oi.order_return_amount) as order_return_amount,
        |  max(oi.order_net_sales_amount) as order_net_sales_amount
        |from tgdw.order_item_fact oi
        |group by oi.order_id
      """.stripMargin) // 订单维度表
    ODSSink.sink2Cassandra(orderFactDF, "order_fact")

    /*
     * 3. 基础品品牌映射
     * */
    val productBrandDF = spark.sql(
      """
        |select
        |    p.id as product_id,
        |    p.fk_brand_id as brand_id
        |from item.product p
        |join (
        |  select
        |    p.id,
        |    max(p.modify_time) as last_modify_time
        |  from item.product p
        |  group by p.id
        |) f
        |on p.id = f.id
        |and p.modify_time = f.last_modify_time
      """.stripMargin)
    ODSSink.sink2Cassandra(productBrandDF, "product")

    /*
     * 4. 订单品宽表写入 Cassandra
     * */
    val orderItemWideColumnDF = spark.sql(
      """
        |select
        |  oi.order_id,
        |  oi.sku_id,
        |  oi.price,
        |  oi.quantity,
        |  oi.order_amount,
        |  oi.order_tax,
        |  oi.order_shipping_costs,
        |  oi.order_coupon_amount,
        |  oi.order_activity_amount,
        |  oi.order_return_amount,
        |  oi.order_net_sales_amount,
        |  oi.order_actual_sales_amount,
        |  oi.order_type,
        |  oi.order_pay_method,
        |  oi.order_delivery_method,
        |  oi.order_create_time,
        |  oi.order_cancel_time,
        |  oi.order_pay_time,
        |  oi.order_ship_time,
        |  oi.order_return_time,
        |  oi.order_finish_time,
        |  sku.item_is_selected,
        |  oi.brand_id,
        |  oi.level_one_category_code,
        |  oi.level_two_category_code,
        |  oi.level_three_category_code,
        |  oi.level_four_category_code,
        |  oi.store_id,
        |  s.store_name,
        |  oi.city_id,
        |  s.city_name,
        |  oi.area_id,
        |  s.area_name,
        |  oi.source,
        |  s.source_name,
        |  oi.member_id,
        |  m.first_shopping_time,
        |  m.first_market_shopping_time,
        |  m.first_mall_shopping_time,
        |  m.first_supplier_shopping_time,
        |  m.first_oversea_shopping_time
        |from tgdw.order_item_fact oi
        |left join tgdw.store_dim s
        |on oi.store_id = s.store_id
        |left join tgdw.sku_dim sku
        |on oi.sku_id = sku.sku_id
        |left join tgdw.member_dim m
        |on oi.member_id = m.member_id
      """.stripMargin) // 订单品宽表
    ODSSink.sink2Cassandra(orderItemWideColumnDF, "order_item_wide_column")
  }

}
