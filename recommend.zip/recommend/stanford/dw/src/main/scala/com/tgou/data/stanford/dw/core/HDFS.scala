package com.tgou.data.stanford.dw.core

import org.apache.hadoop.conf.Configuration
import org.apache.hadoop.fs.{FileSystem, Path}

/**
  * Created by 李震 on 2017/9/12.
  */
object HDFS {

  def exists(path: String): Boolean = {
    try {
      val fs = FileSystem.get(new Configuration())
      fs.exists(new Path(path))
    } catch {
      case e: Exception => {
        e.printStackTrace()
        false
      }
    }
  }

}
