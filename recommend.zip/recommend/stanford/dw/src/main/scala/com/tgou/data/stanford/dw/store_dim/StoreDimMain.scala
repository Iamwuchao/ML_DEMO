package com.tgou.data.stanford.dw.store_dim

import com.tgou.data.stanford.dw.core.{DWBootstrap, ODSSink}
import org.apache.spark.sql. SparkSession
import org.joda.time.LocalDate

/**
  * Created by 张少锐 on 2018/03/07.
  * 店铺维度表
  */

object StoreDimMain {

  def main(args: Array[String]): Unit = {
    DWBootstrap(args).bootstrap(execute)
  }

  def execute(spark: SparkSession, appName: String, date: LocalDate): Unit = {

    /*
     * 获取数据
     * */
    val storeDim = StoreDimProcess.getStoreDimDF(spark)

    /*
     * 持久化到hive表
     * */
    ODSSink.sink2Hive(storeDim,"store_dim")

  }
}
