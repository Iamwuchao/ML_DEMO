package com.tgou.data.stanford.dw.search.bean

/**
  * Created by 李震 on 2017/9/21.
  */
case class UbaPageDW (
                       id: String,
                       uuid: String,
                       a_b: String,
                       time: String
                     )
