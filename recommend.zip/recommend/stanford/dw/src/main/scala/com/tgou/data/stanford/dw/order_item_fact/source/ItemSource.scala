package com.tgou.data.stanford.dw.order_item_fact.source

import org.apache.spark.sql.DataFrame

/**
  * Created by 李震 on 2018/3/10.
  */
trait ItemSource {

  /**
    * 获取 ODS 层 product 数据
    * */
  def getODSProductDF(): DataFrame

  /**
    * 获取 ODS 层 category 数据
    * */
  def getODSCategoryDF(): DataFrame

}
