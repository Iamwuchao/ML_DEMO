package com.tgou.data.stanford.dw.order_item_uba.bean

case class ScpCase(
               order_item_id: String,
               scp: String,
               traceId: String,
               sScp: String
              )
