package com.tgou.data.stanford.dw.action.bean

import com.tgou.data.stanford.core.base.BaseBean

object ShopCart extends BaseBean {
  override def list: List[(Any,String)] = {
    List(
      (8 , "create_time"),
      (7 , "member_id"),
      (4 , "activity_product_id")
    )
  }
}
