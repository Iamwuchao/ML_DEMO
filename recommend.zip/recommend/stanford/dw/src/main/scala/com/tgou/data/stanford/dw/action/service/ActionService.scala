package com.tgou.data.stanford.dw.action.service

import java.time.LocalDate

import com.tgou.data.stanford.core.utils.{ETLUtils, HDFSConfig}
import com.tgou.data.stanford.dw.action.bean.ShopCart
import org.apache.spark.sql.{DataFrame, SparkSession}

object ActionService {

  def getPageViewAction(spark: SparkSession, date: LocalDate): DataFrame ={
    val sqlTest =
      s"""
         | SELECT substr(page,12) as item_id,
         |  member_id,
         |  2 as action_type,
         |  time as action_time
         |  FROM dw.uba_page
         | WHERE his_time >= '$date'
         | AND bk like 'item-%'
         | AND member_id != ''
       """.stripMargin
    spark.sql(sqlTest)
  }

  def getTransferAction(spark: SparkSession): DataFrame ={
    val date = LocalDate.now().plusDays(-1)
    val sqlTest =
      s"""
         | SELECT op.mall_product_id as item_id,
         |  oi.member_id,
         |  3 as action_type,
         |  oi.pay_time as action_time
         |  FROM dw.order_product op
         |  INNER JOIN dw.order_information oi
         |  ON oi.his_time = '$date'
         |  AND op.tgou_order_id = oi.order_id
         | WHERE op.his_time = '$date'
         | AND op.onshelf_type = '1'
         | AND oi.pay_time is not null
       """.stripMargin
    spark.sql(sqlTest)
  }

  def getCollectionAction(spark: SparkSession): DataFrame ={
    val date = LocalDate.now().plusDays(-1)
    val sqlTest =
      s"""
         | SELECT mall_activity_product_id as item_id,
         |  fk_member_id,
         |  5 as action_type,
         |  create_time as action_time
         |  FROM dw.collection_info
         | WHERE his_time = '$date'
       """.stripMargin
    spark.sql(sqlTest)
  }

  def getShopCartAction(spark: SparkSession,namenode: String): DataFrame ={
    val fansTotalOriginDF = ETLUtils.getTotal(spark,namenode,HDFSConfig.DW_SQOOP_ROOT+"/tiangou/tgouorder/shop_cart_log","2018/02/23",ShopCart)
    fansTotalOriginDF.createOrReplaceTempView("shop_cart")
    val sqlTest =
      s"""
         | SELECT activity_product_id as item_id,
         |  member_id,
         |  4 as action_type,
         |  create_time as action_time
         |  FROM shop_cart
       """.stripMargin
    spark.sql(sqlTest)
  }

}
