package com.tgou.data.stanford.dw.sku_dim

import com.tgou.data.stanford.dw.core.ODSSource
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.joda.time.LocalDate

/**
  * Created by 张少锐 on 2018/03/07.
  * SKU维度表
  */

object SkuDimProcess {

  def getSkuDimDF(spark: SparkSession): DataFrame = {

    val today = LocalDate.now().toString("yyyy-MM-dd")

    /**
      * 加载数据源
      * */
    // 获取全量最新的SKU表
    ODSSource.getNewestDF(spark.table("item.mall_activity_sku"),Seq("id"),"modify_time").createOrReplaceTempView("mall_activity_sku")

    // 获取全量最新的活动商品表
    ODSSource.getNewestDF(spark.table("item.mall_activity_product"),Seq("id"),"modify_time").createOrReplaceTempView("mall_activity_product")

    // 获取全量活动商品入围表
    spark.table("item.counter_item_selected").filter(s"ods_date = '${today}'").createOrReplaceTempView("counter_item_selected")

    // 获取全量最新的商品表
    ODSSource.getNewestDF(spark.table("item.product"),Seq("id"),"modify_time").createOrReplaceTempView("product")

    // 获取全量品牌表
    spark.table("base.brand").filter(s"ods_date = '${today}'").createOrReplaceTempView("brand")

    // 获取全量分类表
    spark.table("item.category").filter(s"ods_date = '${today}'").createOrReplaceTempView("category")

    // 获取全量最新的业种信息表
    ODSSource.getNewestDF(spark.table("base.sold_type"),Seq("id"),"modify_time").createOrReplaceTempView("sold_type")

    // 获取全量最新的卖区信息表
    ODSSource.getNewestDF(spark.table("base.sold_area"),Seq("id"),"modify_time").createOrReplaceTempView("sold_area")

    // 获取全量最新的柜组信息表
    ODSSource.getNewestDF(spark.table("base.counter"),Seq("id"),"modify_time").createOrReplaceTempView("counter")

    /**
      * sku_dim表
      *
      *  @return
      *
      * - sku_id SKU ID
      * - item_id 营销品ID
      * - item_name 营销品名称
      * - item_state 营销品状态
      * - item_is_selected 营销品是否入围
      * - product_name 商品名称
      * - brand_name 品牌名称
      * - level_one_category_name 一级分类名
      * - level_two_category_name 二级分类名
      * - level_three_category_name 三级分类名
      * - level_four_category_name 四级分类名
      * - sold_type_name 业种名称
      * - sold_area_name 卖区名称
      * - counter_name 柜组名称
      *
      * */
    spark.sql(
      s"""
         |select
         |    mas.fk_product_sku_id as sku_id,
         |    map.id as item_id,
         |    map.product_name as item_name,
         |    map.state as item_state,
         |    cis.selected as item_is_selected,
         |    p.name as product_name,
         |    b.name as brand_name,
         |    c1.name as level_one_category_name,
         |    c2.name as level_two_category_name,
         |    c3.name as level_three_category_name,
         |    c4.name as level_four_category_name,
         |    st.name as sold_type_name,
         |    sa.name as sold_area_name,
         |    c.name as counter_name
         |from mall_activity_sku mas
         |left join mall_activity_product map
         |on mas.fk_item_id = map.id
         |left join counter_item_selected cis
         |on cis.fk_item_id = mas.fk_item_id
         |left join product p
         |on map.fk_product_id = p.id
         |left join brand b
         |on p.fk_brand_id = b.id
         |left join category c4
         |on p.fk_category_id = c4.id
         |left join category c3
         |on substr(c4.code, 1, 6) = c3.code
         |left join category c2
         |on substr(c4.code, 1, 4) = c2.code
         |left join category c1
         |on substr(c4.code, 1, 2) = c1.code
         |left join counter c
         |on map.fk_counter_id = c.id
         |left join sold_area sa
         |on c.fk_sold_area_id = sa.id
         |left join sold_type st
         |on sa.fk_sold_type_id = st.id
       """.stripMargin)
  }
}
