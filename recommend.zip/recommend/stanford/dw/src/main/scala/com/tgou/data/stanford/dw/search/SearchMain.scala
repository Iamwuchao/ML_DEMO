package com.tgou.data.stanford.dw.search

import com.tgou.data.stanford.dw.core.DWBootstrap
import org.apache.spark.sql.SparkSession
import org.joda.time.LocalDate

/**
  * Created by 李震 on 2017/9/18.
  */
object SearchMain {

  def main(args: Array[String]): Unit = {
    DWBootstrap(args).bootstrap(execute)
  }


  def execute(spark: SparkSession, appName: String, date: LocalDate): Unit = {

    /*
     * 加载数据
     * */
    val source = SearchSource(spark)

    // 增量 search ODS 层数据
    val searchODSDs = source.getSearchODSDs(date)
    // 增量 scp_table ODS 层数据
    val scpTableODSDF = source.getScpTableODSDF(date)
    // 增量 uba_page DW 层数据
    val ubaPageDWDs = source.getUbaPageDWDs(date)

    /*
     * 处理数据
     * */

    val searchDWDs = SearchProcess(spark).process(searchODSDs, scpTableODSDF, ubaPageDWDs)

    /*
     * 数据持久化
     * */
    SearchSink(spark).persist(searchDWDs, date)

  }

}
