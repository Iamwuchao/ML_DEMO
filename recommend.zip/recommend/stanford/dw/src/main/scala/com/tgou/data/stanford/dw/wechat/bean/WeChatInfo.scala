package com.tgou.data.stanford.dw.wechat.bean

import com.tgou.data.stanford.core.base.BaseBean

/**
  * Created by xinghailong on 2017/8/21.
  */
object WeChatInfo extends BaseBean {

  override def list: List[(Any,String)] = {
    List(
      (0 , "id"),
      (2 , "name"),
      (3 , "wechat_id"),
      (4 , "origin_id"),
      (7 , "fk_store_id"),
      (8 , "appid"),
      (15 , "bridage_state"),
      (16 , "wechat_info_type"),
      (17 , "info_state")
    )
  }
}
