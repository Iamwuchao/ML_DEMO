package com.tgou.data.stanford.dw.order_item_fact.source.impl

import com.google.inject.Inject
import com.tgou.data.stanford.dw.Constants._
import com.tgou.data.stanford.dw.order_item_fact.source.BaseSource
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.joda.time.LocalDate

/**
  * Created by 李震 on 2018/3/10.
  */
class BaseSourceImpl extends BaseSource {

  @Inject
  var spark: SparkSession = _

  override def getODSStoreDF(): DataFrame = {
    spark.table(TABLE_STORE).filter(s"ods_date = '${LocalDate.now().toString("yyyy-MM-dd")}'")
  }

  override def getODSStoreAddress(): DataFrame = {
    spark.table(TABLE_STORE_ADDRESS).filter(s"ods_date = '${LocalDate.now().toString("yyyy-MM-dd")}'")
  }

}
