package com.tgou.data.stanford.dw.wechat.bean

import com.tgou.data.stanford.core.base.BaseBean

/**
  * Created by xinghailong on 2017/8/21.
  */

object Fans extends BaseBean {

  override def list: List[(Any,String)] = {

    List(
      (0 , "id"),
      (1 , "subscribe"),
      (2 , "subscribe_time"),
      (3 , "nickname"),
      (4 , "sex"),
      (5 , "country"),
      (6 , "province"),
      (7 , "city"),
      (9 , "openid"),
      (11 , "fk_wechat_info_id"),
      (15 , "modify_time")
    )

  }
}

