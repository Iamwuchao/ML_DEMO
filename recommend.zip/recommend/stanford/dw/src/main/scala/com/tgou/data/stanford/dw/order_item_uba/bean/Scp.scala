package com.tgou.data.stanford.dw.order_item_uba.bean

case class Scp (
                 storeId: String,
                 uuid: String,
                 k: String,
                 global: String,
                 traceId: String,
                 mi: String,
                 scp: String,
                 time: String,
                 bk: String
               )

