package com.tgou.data.stanford.dw.order_item_uba

import com.tgou.data.stanford.dw.core.{DWBootstrap, ODSSource}
import com.tgou.data.stanford.dw.order_item_uba.bean._
import org.apache.spark.sql.{DataFrame, SaveMode, SparkSession}
import org.apache.spark.storage.StorageLevel
import org.joda.time.format.DateTimeFormat

import scala.util.control.Breaks._
import org.joda.time.{LocalDate, LocalDateTime}

import scala.collection.mutable
import org.apache.commons.lang3.StringUtils

object OrderProductUBA {

  def main(args: Array[String]): Unit = {
    DWBootstrap(args).bootstrap(execute)
  }
  def execute(spark: SparkSession, appName: String, date: LocalDate): Unit = {
    OrderProductUBA(spark, date)
  }
  def apply(spark: SparkSession, date: LocalDate): OrderProductUBA = new OrderProductUBA(spark, date)
}

class OrderProductUBA protected(spark: SparkSession, date: LocalDate) {

  val yesterday: String = date.toString("yyyy-MM-dd")

  //自定义UDF函数
  spark.udf.register("isInvalidateParentOrder", (i: String) => { i.length() >= 8 && i.charAt(7) == '1' })
  spark.udf.register("processNull", (i: String) => {
    val s = if(i == null || "".equals(i)) "normal" else i
    s.toLowerCase
  })
  spark.udf.register("processTraceId", (i: String) => {
    if(i == null || "".equals(i)) "normal" else i
  })
  spark.udf.register("getJr", (tgsJR: String,sourceJR: String) => {
    if (sourceJR == null)  tgsJR
    else if ("normal" == tgsJR || tgsJR == null)  sourceJR
    else tgsJR
  })
  spark.udf.register("getGlobal", (tgsGlobal: String,sourceGlobal: String) => {
    if (sourceGlobal == null)  tgsGlobal
    else if ("normal" == tgsGlobal || tgsGlobal == null)  sourceGlobal
    else tgsGlobal
  })

  //ODS层数据预处理
  ODSSource.getNewestDF(spark.table("tgouorder.order_item"), Seq("id"), "modify_time").createOrReplaceTempView("order_item_new")
  ODSSource.getNewestDF(spark.table("tgouorder.tgou_order"), Seq("id"), "modify_time").createOrReplaceTempView("tgou_order_new")
  ODSSource.getNewestDF(spark.table("tgouorder.order_source"), Seq("id"), "modify_time").createOrReplaceTempView("order_source_new")

  //步骤一：获取增量的order_item数据
  spark.sql(
    s"""
       |select
       |    a.*,
       |    b.fk_member_id as member_id
       |from (
       |    select
       |        id,
       |        fk_tgou_order_id,
       |        activity_to_product_id as mall_product_id,
       |        shop_cart_id,
       |        state,
       |        create_time,
       |        modify_time
       |    from order_item_new
       |    where to_date(create_time) = '$yesterday'
       |) a
       |join(
       |    select
       |        id,
       |        fk_member_id,
       |        fixed_tags,
       |        create_time,
       |        modify_time
       |    from tgou_order_new
       |    where to_date(modify_time) = '$yesterday'
       |    and isInvalidateParentOrder(fixed_tags) = false
       |) b
       |on a.fk_tgou_order_id = b.id
   """.stripMargin).createOrReplaceTempView("order_item")

  //步骤二：获取shop_cart_log全量数据
  val sclDF = spark.sql("select * from tgouorder.shop_cart_log")
  sclDF.join(sclDF.groupBy("fk_shop_cart_id").agg("id" -> "max").toDF("fk_shop_cart_id", "id"), Seq("fk_shop_cart_id", "id"), "inner")
    .createOrReplaceTempView("shop_cart_log")

  //步骤三：order_item、shop_cart_id、order_source三个表进行拼接
  val orderItemShopCartDF = spark.sql(
    s"""
       |select
       |    oi.id as order_item_id,
       |    oi.fk_tgou_order_id as tgou_order_id,
       |    oi.mall_product_id as mall_product_id,
       |    oi.shop_cart_id as shop_cart_id,
       |    oi.create_time as order_item_create_time,
       |    scl.create_time as shop_cart_create_time,
       |    oi.member_id as member_id,
       |    os.json as source_jr,
       |    os.global as source_global
       |from order_item oi
       |left join shop_cart_log scl
       |on oi.shop_cart_id = scl.fk_shop_cart_id
       |left join order_source_new os
       |on oi.fk_tgou_order_id = os.fk_order_id
       |where oi.create_time is not null
   """.stripMargin)
  orderItemShopCartDF.persist(StorageLevel.MEMORY_AND_DISK).createOrReplaceTempView("order_item_shop_cart")

  //步骤四:获取当天tgs和scp相关的行为数据（增量）,并过滤time为空的脏数据
  val tgsDF = spark.read.json(s"/tiangou/access/${date.toString("yyyy/MM/dd")}/*").selectExpr("*","'' as jr").filter("time is not null")
  val scpDF = spark.read.json(s"/tiangou/scp/${date.toString("yyyy/MM/dd")}/*").filter("time is not null")

  //对tgsRDD进行处理：（1）按用户分组 -> （2）组内记录按时间排序，并填充member_id、jr -> （3）过滤没有member_id的记录 -> （4）筛选关键字段 -> （5）注册为DataFrame
  manageTgsDF(tgsDF).persist(StorageLevel.MEMORY_AND_DISK).createOrReplaceTempView("tgs")
  //对scpRDD进行处理：（1）按用户分组 -> （2）组内记录按时间排序，并填充member_id -> （3）过滤没有member_id的记录 -> （4）筛选关键字段 -> （5）注册为DataFrame
  manageScpDF(scpDF).persist(StorageLevel.MEMORY_AND_DISK).createOrReplaceTempView("scp")

  //tgs表和scp表进行关联，寻找距离tgs.time最近的scpTime时间点的traceId，形成traceId_tgs表,添加scpTime只是为了核对该算法正确性
  import spark.implicits._
  val traceIdTgsDF = spark.sql(
    s"""
       |select
       |    t.*,
       |    s.traceId,
       |    s.scp as sScp,
       |    s.time as scpTime
       |from tgs t
       |left join scp s
       |on t.member_id = s.mi
   """.stripMargin).as[TraceIdTgs]
    .groupByKey(r => (r.member_id,r.time))
    .mapGroups((k,vs) => {
      val sortedList = vs.toList.sortBy(r => r.time)
      val aa = sortedList(0)
      var traceIdTgs = TraceIdTgs(k._1,aa.jr,aa.scp,aa.global,aa.page,k._2,"normal","normal","normal")
      var flag:Boolean = false

      for(jo <- sortedList.reverse if !flag){
        if(jo.time != null && jo.scpTime != null){
          try{
            val time = LocalDateTime.parse(jo.time, DateTimeFormat.forPattern("yyyy-MM-dd HH:mm:ss"))
            val scpTime = LocalDateTime.parse(jo.scpTime, DateTimeFormat.forPattern("yyyy-MM-dd HH:mm:ss"))
            //此处主要是获取scp表中与tgs中相同的scp字段
            if(scpTime.compareTo(time) <= 0){
              val aa = jo.scp.split("\\.")
              val bb = jo.sScp.split("\\.")
              if(aa.length > 1 && bb.length > 1 && aa(0)+'.'+aa(1)+'.'+aa(2)+'.'+aa(3) == bb(0)+'.'+bb(1)+'.'+bb(2)+'.'+bb(3)){
                flag = true
                traceIdTgs = TraceIdTgs(k._1,jo.jr,jo.scp,jo.global,jo.page,k._2,jo.traceId,jo.sScp,jo.scpTime)
              }
            }
          }catch {
            case e: Exception => flag = true
          }
        }
      }

      traceIdTgs
    })
  traceIdTgsDF.select("member_id", "jr", "scp", "global", "page", "time","traceId","sScp")
    .persist(StorageLevel.MEMORY_AND_DISK).createOrReplaceTempView("traceId_tgs")

  //步骤五：让order_item_shop_cart与tgs进行左外连接（member_id维度），即获取每个order_item对应的用户行为记录 ，并对每组内的行为记录按时间进行排序
  //计算jr、global： 寻找距离create_time最近的那条记录的jr、global

  val jrAndGlobalDF = spark.sql(
    s"""
       |select
       |    o.*,
       |    t.global,
       |    t.jr,
       |    t.page,
       |    t.scp,
       |    t.time
       |from order_item_shop_cart o
       |left join tgs t
       |on o.member_id = t.member_id
       |where o.member_id is not null
       |and o.member_id > 0
       """.stripMargin).as[OrderItemAndTgs]
    .groupByKey(r => (r.order_item_id, r.mall_product_id))
    .mapGroups((k, vs) => {
      val id:String = k._1
      val sortedList = vs.toList.sortBy(r => r.time)
      val jrAndGlobal = JrAndGlobal(id,"normal","normal")

      for(jo <- sortedList){
        if(jo.time != null && jo.order_item_create_time != null){
          try{
            val time = LocalDateTime.parse(jo.time, DateTimeFormat.forPattern("yyyy-MM-dd HH:mm:ss"))
            val createTime = LocalDateTime.parse(jo.order_item_create_time, DateTimeFormat.forPattern("yyyy-MM-dd HH:mm:ss"))
            breakable {
              if(time.compareTo(createTime) <= 0){
                jrAndGlobal.jr = jo.jr
                jrAndGlobal.global = jo.global
              }else break()
             }
          }catch {
            case e: Exception => break()
          }
        }
      }
      jrAndGlobal
    })

  /**
    * 计算“普通订单行”对应的scp，针对“立即购买”场景
    * */
  //步骤六：让order_item_shop_cart与traceId_tgs进行左外连接（member_id维度），即获取每个order_item对应的用户行为记录 ，主要是出scp和traceId这两个字段
  val oiTraceIdTgsDF = spark.sql(
    s"""
       |select
       |    o.*,
       |    t.global,
       |    t.jr,
       |    t.page,
       |    t.scp,
       |    t.time,
       |    t.traceId,
       |    t.sScp
       |from order_item_shop_cart o
       |left join traceId_tgs t
       |on o.member_id = t.member_id
       |where o.member_id is not null
       |and o.member_id > 0
       """.stripMargin).as[OrderItemAndTraceIdTgs]
  oiTraceIdTgsDF.persist(StorageLevel.MEMORY_AND_DISK)

  //（member_id维度，并且shop_cart_id为空的记录），即获取每个“普通订单行”对应的用户行为记录 ，并对每组内的行为记录进行排序
  val scpNormalDF = oiTraceIdTgsDF.filter("shop_cart_id is null")
    .groupByKey(r => (r.order_item_id, r.mall_product_id))
    .mapGroups((k, vs) => {
      val order_item_id:String = k._1
      val mall_product_id:String = k._2
      val sortedList = vs.toList.sortBy(r => r.time)
      var scpNormal:ScpCase = null
      var flag:Boolean = false

      //从后往前找距离最近的单品详情页，返回其scp
      for(jo <- sortedList.reverse if !flag) {
        if (jo.time != null) {
          val time = LocalDateTime.parse(jo.time, DateTimeFormat.forPattern("yyyy-MM-dd HH:mm:ss"))
          val createTime = LocalDateTime.parse(jo.order_item_create_time, DateTimeFormat.forPattern("yyyy-MM-dd HH:mm:ss"))
          if (time.compareTo(createTime) < 0) {
            val page: String = jo.page.toLowerCase()
            if (page.startsWith("10.pd") && page.endsWith(mall_product_id)) {
              flag = true
              scpNormal = ScpCase(order_item_id, jo.scp,jo.traceId,jo.sScp)
            }
          }
        }
      }
      //如果单品详情页中未找到，则从后往前找最近的确认订单页中，返回其scp
      for(jo <- sortedList.reverse if !flag) {
        if (jo.time != null) {
          val time = LocalDateTime.parse(jo.time, DateTimeFormat.forPattern("yyyy-MM-dd HH:mm:ss"))
          val createTime = LocalDateTime.parse(jo.order_item_create_time, DateTimeFormat.forPattern("yyyy-MM-dd HH:mm:ss"))
          if (time.compareTo(createTime) < 0) {
            val page: String = jo.page.toLowerCase()
            if (page.startsWith("10.conmorder")) {
              flag = true
              scpNormal = ScpCase(order_item_id, jo.scp,jo.traceId,jo.sScp)
            }
          }
        }
      }
      scpNormal
    }).filter(t => t != null && !"".equals(t.scp))

  /**
    * 购物车订单行算法思想：
    * （1）找到该订单行对应的购物车记录的创建时间shop_cart_create_time，遍历寻找该时间之前的第一个10.page.***结尾的记录（走tgs）
    * （2）找到该订单行对应的购物车记录的创建时间shop_cart_create_time，找到它最近的那个scp记录（走scp）
    */
  //步骤七：让order_item_shop_cart与traceId_tgs进行左外连接(member_id维度，并且shop_cart_id不为空的记录），即获取每个“购物车订单行”对应的tgs用户行为记录，并对每组内的tgs行为记录进行排序
  //计算”普通购物车订单行”对应的scp
  val scpNormalShopCartDF = oiTraceIdTgsDF.filter("shop_cart_id is not null")
    .groupByKey(r => (r.order_item_id, r.mall_product_id))
    .mapGroups((k, vs) => {
      val order_item_id:String = k._1
      val mall_product_id:String = k._2
      val sortedList = vs.toList.sortBy(r => r.time)
      var scpNormal:ScpCase = null
      var flag:Boolean = false

      //从单品详情页查找
      for(jo <- sortedList.reverse if !flag) {
        if (jo.time != null && jo.shop_cart_create_time != null) {
          val time = LocalDateTime.parse(jo.time, DateTimeFormat.forPattern("yyyy-MM-dd HH:mm:ss"))
          val createTime = LocalDateTime.parse(jo.shop_cart_create_time, DateTimeFormat.forPattern("yyyy-MM-dd HH:mm:ss"))
          if (time.compareTo(createTime) < 0) {
            val page: String = jo.page.toLowerCase()
            if (page.startsWith("10.pd") && page.endsWith(mall_product_id)) {
              flag = true
              scpNormal = ScpCase(order_item_id,jo.scp,jo.traceId,jo.sScp)
            }
          }
        }
      }
      scpNormal
    }).filter(t => t != null)

  //步骤九：让order_item_shop_cart与scp进行左外连接（member_id维度），即获取每个“购物车订单行”对应的scp行为记录，并对每组内的scp行为记录进行排序
  val shopCartOrderItemScpGroupDF = spark.sql(
    s"""
       |select
       |    o.order_item_id,
       |    o.mall_product_id,
       |    o.member_id,
       |    o.shop_cart_id,
       |    o.shop_cart_create_time,
       |    s.scp,
       |    s.time,
       |    s.traceId
       |from order_item_shop_cart o
       |left join scp s
       |on o.member_id = s.mi
       |where o.shop_cart_id is not null
       |and o.member_id is not null
       |and o.member_id > 0
       """.stripMargin).as[OrderItemAndScp].groupByKey(r => r.order_item_id)
    .flatMapGroups((k, vs) => {
      vs.toList.sortBy(r => r.time)
    })

  //步骤十：从shopCartOrderItemScpGroupDF中去除掉scpNormalShopCartDF中包含的order_item记录，即只找到“非普通购物车订单行“对应的记录
  //计算“非普通购物车订单行”对应的scp
  scpNormalShopCartDF.createOrReplaceTempView("scp_normal")
  shopCartOrderItemScpGroupDF.createOrReplaceTempView("shop_cart")
  val scpUnNormalShopCartDF = spark.sql(
    s"""
       |select
       |    sc.*
       |from shop_cart sc
       |left join scp_normal sn
       |on sc.order_item_id = sn.order_item_id
       |where sn.order_item_id is null
     """.stripMargin).as[OrderItemAndScp].groupByKey(r => r.order_item_id)
    .mapGroups((k, vs) => {
      val order_item_id:String = k
      val sortedList = vs.toList.sortBy(r => r.time)
      var scpUnNormal:ScpCase = null
      var flag:Boolean = false

      if(sortedList.size > 0){
        for(jo <- sortedList.reverse if !flag) {
          if (jo.time != null && jo.shop_cart_create_time != null) {
            val time = LocalDateTime.parse(jo.time, DateTimeFormat.forPattern("yyyy-MM-dd HH:mm:ss"))
            val createTime = LocalDateTime.parse(jo.shop_cart_create_time, DateTimeFormat.forPattern("yyyy-MM-dd HH:mm:ss"))
            if (time.compareTo(createTime) < 0) {
              flag = true
              scpUnNormal = ScpCase(order_item_id,"normal",jo.traceId,jo.scp)
            }
          }
         }
       }
      scpUnNormal
    }).filter(t => t != null)

  //步骤十一：三个DF进行合并
  jrAndGlobalDF.join(scpUnNormalShopCartDF.union(scpNormalShopCartDF).union(scpNormalDF),Seq("order_item_id"),"full_outer")
    .createOrReplaceTempView("total")
  spark.sql(
    s"""
       |select
       |  order_item_id,
       |  processNull(global) as global,
       |  processNull(jr) as jr,
       |  processNull(scp) as scp,
       |  processTraceId(traceId) as traceId,
       |  processNull(sScp) as sScp
       |from total
     """.stripMargin).createOrReplaceTempView("origin_order_item_uba")

  //步骤十二：计算order_item_uba的值,将order_item对应的uba信息存入HDFS，到此结束
  val orderItemUbaResultDF = spark.sql(
    s"""
       |select
       |    oo.order_item_id,
       |    oi.tgou_order_id as order_id,
       |    getJr(oo.jr,oi.source_jr) as jr,
       |    getGlobal(oo.global,oi.source_global) as global,
       |    oo.scp as tgs_scp,
       |    oo.sScp as scp_scp,
       |    oo.traceId as trace_id,
       |    '$yesterday' as etl_time
       |from origin_order_item_uba oo
       |join order_item_shop_cart oi
       |on oo.order_item_id = oi.order_item_id
     """.stripMargin)
  orderItemUbaResultDF.distinct().coalesce(1).write.mode(SaveMode.Overwrite).json(s"/data/tgdw/order_item_uba/$yesterday/")

  /**
    * 自定义的方法
    * 填充member_id，往前面填充，可能之前未登录
    * 填充jr，向后填充，直到碰到新的jr，因为jr填写了之后后续的操作不会再带着该jr
    * */
  def manageTgsDF(tgsDF: DataFrame): DataFrame = {
    tgsDF.as[Tgs]
    .groupByKey(i => (i.uuid, i.session_id))
    .flatMapGroups((k, vs) => {
      val sortedTgsList = vs.toList.sortBy(r => r.time)
      var member_id: String = null

      breakable {
        for (i <- 0 until sortedTgsList.length) {
          val tgs = sortedTgsList(i)

          if (StringUtils.isNotBlank(tgs.member_id)) {
            member_id = tgs.member_id
            break
          }
        }
      }

      var r = new mutable.MutableList[Tgs]()
      for (i <- 0 until sortedTgsList.length) {
        val tgs = sortedTgsList(i)

        if (StringUtils.isBlank(tgs.member_id)) {
          r += tgs.copy(member_id = member_id)
        } else {
          member_id = tgs.member_id
          r += tgs
        }
      }
      r
    }).groupByKey(i => (i.uuid, i.session_id))
    .flatMapGroups((k, vs) => {
      var jrStr: String = null
      val jrList = vs.toList.sortBy(r => r.time)
      var r = new mutable.MutableList[Tgs]()

      for (v <- jrList) {
        var jr: String = null
        jr = try {
          v.orgin.toLowerCase.split("jr" + "=")(1).split("&")(0).split("#")(0)
        }catch {
          case e: Exception => null
        }
        if (StringUtils.isNotBlank(jr)) jrStr = jr
        if (StringUtils.isNotBlank(jrStr)) v.jr = jrStr
        else v.jr = "normal"
        r += v
      }

      r
    }).filter("member_id is not null").select("member_id", "jr", "scp", "global", "page", "time")
  }

  def manageScpDF(scpDF:DataFrame): DataFrame = {
    scpDF.as[Scp]
      .groupByKey(i => i.uuid)
      .flatMapGroups((k, vs) => {
        val sortedScpList = vs.toList.sortBy(r => r.time)
        var member_id: String = null

        breakable {
          for (i <- 0 until sortedScpList.length) {
            val scp = sortedScpList(i)

            if (StringUtils.isNotBlank(scp.mi)) {
              member_id = scp.mi
              break
            }
          }
        }

        var r = new mutable.MutableList[Scp]()
        for (i <- 0 until sortedScpList.length) {
          val scp = sortedScpList(i)

          if (StringUtils.isBlank(scp.mi)) {
            r += scp.copy(mi = member_id)
          } else {
            member_id = scp.mi
            r += scp
          }
        }
        r
      }).filter("mi is not null").select("uuid", "global", "traceId", "mi", "scp", "time")
  }
}