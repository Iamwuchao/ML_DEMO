package com.tgou.data.stanford.dw.search.bean

/**
  * Created by 李震 on 2017/9/21.
  */
case class SearchODS (
                       cityId: String,
                       counterId: String,
                       global: String,
                       k: String,
                       keyword: String,
                       memberId: String,
                       referrer: String,
                       results: String,
                       sessionId: String,
                       source: String,
                       storeId: String,
                       time: String,
                       url: String,
                       uuid: String,
                       whereabouts: String
                     )
