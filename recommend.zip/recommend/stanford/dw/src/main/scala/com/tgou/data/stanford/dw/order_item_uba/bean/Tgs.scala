package com.tgou.data.stanford.dw.order_item_uba.bean

case class Tgs(
                member_id: String,
                k: String,
                lon: String,
                orgin: String,
                url: String,
                time: String,
                platform: String,
                page: String,
                session_id: String,
                openid: String,
                agent: String,
                scp: String,
                city_id: String,
                uuid: String,
                lat: String,
                store_id: String,
                first_time: String,
                counter_id: String,
                referrer: String,
                ip: String,
                global: String,
                var jr: String
              )
