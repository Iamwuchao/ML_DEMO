package com.tgou.data.stanford.dw.wechat

import com.tgou.data.stanford.core.udaf.MergeUDAF
import com.tgou.data.stanford.core.utils.{DateUtils, HDFSConfig}
import org.apache.spark.sql.{SaveMode, SparkSession}

/**
  * 微信数据仓库
  *
  * 业务模型：
  *  1 fans 表在关注公众号时会生成，但是有的openid会对应两条记录（有一条记录数据为null）采取的方式，直接取max()即可。出现的原因不明
  *  2 bind_login_memebr 该表在用户在微信端登录或者退出天狗网时，会员系统都会发送登录或退出的消息到mq中。微信这端基于登录信息创建bind_login_member的记录，如果收到退出信息会删除该记录
  *  3 fans_to_member 每次用户在微信端登录帐号时，会产生一条记录。如果已经存在则什么都不做
  *  4 wechat_info 这个是我们系统生成的，门店可以修改某些字段，但是这些字段修改后无太多影响。有的修改就会报错，因此数仓可以忽略该表的修改。
  *
  * 算法思路与总结：
  *  1 读取数据：
  *    ●  读取当天增量的fans，fans_to_member，bind_login_member，wechat_info(其实是全量)
  *    ●  读取全量并且取最新的fans，fans_to_member，bind_login_member
  *  2 筛选有效增量的fans数据：
  *    ● 通过当天增量的bind_login_member反向关联全量的fans
  *    ● 通过当天增量的fans_to_member反向关联全量的fans
  *    ● 当天增量的fans
  *    ● 三部分取并集 ---->得到当天有效的修改的fansRDD
  *  3 关联其他两个表，打通数据
  *    ● fansRDD
  *    ● left join全量的bind_login_member,
  *    ● left join全量的fans_to_member
  *    ● left join全量的wechat_info
  *    ● 打通数据
  *
  * Created by xinghailong on 2017/8/21.
  */
object WeChatMain {
  def main(args: Array[String]) {

    System.setProperty("hive.metastore.uris", "thrift://hnode1:9083") // 配置元数据库
    var builder = SparkSession.builder()

    if(args == null || args.length == 0){
      builder = builder.master("local")
    }

    val spark = builder
      .appName("wechat-main")
      .config("spark.storage.memoryFraction","0.3")
      .config("spark.shuffle.memoryFraction","0.4")
      .enableHiveSupport()
      .getOrCreate()

    spark.sparkContext.setLogLevel("WARN")// 日志级别

    val datePath = DateUtils.getDateString(args(1), "yyyy/MM/dd")
    val date     = DateUtils.getDateString(args(1), "yyyy-MM-dd")
    val namenode = args(0)

    spark.udf.register("merge_len",(line:String) => line.split(",").length)
    spark.udf.register("merge",new MergeUDAF())

    // 第一步，读取数据
    WeChatLoader.load(spark, namenode, datePath)

    // 第二步，获取有效的fans
    WeChatLoader.fetchFans(spark)

    // 第三步，拼接各种数据
    var result = WeChatLoader.detail(spark,date)

    // 第四步，保存
    result.coalesce(10).write.mode(SaveMode.Overwrite).json(s"${HDFSConfig.DW_ROOT}/wechat/$datePath/")

    spark.stop()
  }
}
