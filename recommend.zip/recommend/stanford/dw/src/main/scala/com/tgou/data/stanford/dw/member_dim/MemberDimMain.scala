package com.tgou.data.stanford.dw.member_dim

import com.tgou.data.stanford.dw.core.{DWBootstrap, ODSSink}
import org.apache.spark.sql. SparkSession
import org.joda.time.LocalDate

/**
  * Created by 张少锐 on 2018/03/07.
  * 会员维度表
  */

object MemberDimMain {
  def main(args: Array[String]): Unit = {
    DWBootstrap(args).bootstrap(execute)
  }

  def execute(spark: SparkSession, appName: String, date: LocalDate): Unit = {

    /*
     * 获取数据
     * */
    val memberDim = MemberDimProcess.getMemberDimDF(spark)

    /*
     * 持久化到hive表
     * */
    ODSSink.sink2Hive(memberDim,"member_dim")

  }
}
