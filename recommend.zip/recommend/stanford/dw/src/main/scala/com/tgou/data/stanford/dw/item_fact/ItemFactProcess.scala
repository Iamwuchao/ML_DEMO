package com.tgou.data.stanford.dw.item_fact

import com.tgou.data.stanford.dw.core.ODSSource
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.storage.StorageLevel
import org.joda.time.LocalDate

object ItemFactProcess {

  def getItemFactDF(spark: SparkSession): DataFrame = {

    val today = LocalDate.now().toString("yyyy-MM-dd")

    // 自定义UDF函数
    spark.udf.register("generateIsFastSales", (i: String) => {
      if(  "offline".equals(i)
        || "offline".equals(i)
        || "pending".equals(i)
        || "rejected".equals(i)
      ) true
      else false
    })

    /**
      * 第一步：加载数据源
      **/

    /**
      * base库
      **/
    // 获取全量品牌表
    spark.table("base.brand").filter(s"ods_date = '${today}'").select("id").createOrReplaceTempView("brand")

    // 获取全量店铺表
    spark.table("base.store").filter(s"ods_date = '${today}'").createOrReplaceTempView("store")

    // 获取全量最新的卖区信息表
    ODSSource.getNewestDF(spark.table("base.sold_area"),Seq("id"),"modify_time").select("id","fk_sold_type_id").createOrReplaceTempView("sold_area")

    // 获取全量最新的柜组信息表
    ODSSource.getNewestDF(spark.table("base.counter"),Seq("id"),"modify_time").select("id","fk_sold_area_id").createOrReplaceTempView("counter")

    /**
      * item库
      **/
    // 获取全量最新的SKU表
    ODSSource.getNewestDF(spark.table("item.mall_activity_sku"),Seq("id"),"modify_time").select("id","fk_product_sku_id","fk_item_id","remain_qty","state").createOrReplaceTempView("mall_activity_sku")

    // 获取全量最新的活动商品表
    ODSSource.getNewestDF(spark.table("item.mall_activity_product"),Seq("id"),"modify_time").createOrReplaceTempView("mall_activity_product")

    // 获取全量最新的单品二维码下载时间表
    ODSSource.getNewestDF(spark.table("item.item_qr_code_record"),Seq("id"),"create_time").select("fk_item_id","create_time").createOrReplaceTempView("item_qr_code_record")

    // 获取全量最新的营销品状态转换日志表
    ODSSource.getNewestDF(spark.table("item.mall_activity_product_fsm_log"),Seq("id"),"modify_time").filter("state_to != '-'")
      .select("object_id","state_to","enter_time")
      .persist(StorageLevel.MEMORY_AND_DISK)
      .createOrReplaceTempView("mall_activity_product_fsm_log")

    // 获取全量最新的营销品上传日志表
    ODSSource.getNewestDF(spark.table("item.mall_product_operation"),Seq("id"),"modify_time").select("fk_mall_activity_product_id","create_time","source_id").createOrReplaceTempView("mall_product_operation")

    // 获取全量最新的商品表
    ODSSource.getNewestDF(spark.table("item.product"),Seq("id"),"modify_time")
      .select("id","state","create_time","barcode","fk_brand_id","fk_category_id").createOrReplaceTempView("product")

    // 获取全量分类表
    spark.table("item.category").filter(s"ods_date = '${today}'").select("id","code").createOrReplaceTempView("category")

    // 获取全量营销商品组合品关系表
    spark.table("item.mall_activity_product_to_group").filter(s"ods_date = '${today}'").select("fk_mall_parent_id","fk_mall_sub_id").createOrReplaceTempView("mall_activity_product_to_group")

    /**
      * tgou库
      **/
    // 获取全量最新的专柜二维码绑定商品表
    ODSSource.getNewestDF(spark.table("tgou.qr_route"),Seq("id"),"update_time").select("biz_id","biz_type","update_time").createOrReplaceTempView("qr_route")


    /**
      * 第二步：数据预处理
      **/
    // 对mall_activity_product_fsm_log进行行列转换
    spark.sql(
      s"""
         |select
         |    aa.object_id,
         |    max(aa.item_submit_time) as item_submit_time,
         |    max(aa.item_onshelf_time) as item_onshelf_time,
         |    max(aa.item_offshelf_time) as item_offshelf_time,
         |    max(aa.item_redo_time) as item_redo_time,
         |    max(aa.item_delete_time) as item_delete_time
         |from (
         |select
         |    mapfl.object_id,
         |    (case when mapfl.state_to = 'pending' then enter_time else null end) as item_submit_time,
         |    (case when mapfl.state_to = 'onshelf' then enter_time else null end) as item_onshelf_time,
         |    (case when mapfl.state_to = 'offshelf' then enter_time else null end) as item_offshelf_time,
         |    (case when mapfl.state_to = 'rejected' then enter_time else null end) as item_redo_time,
         |    (case when mapfl.state_to = 'deleted' then enter_time else null end)  as item_delete_time
         |from  mall_activity_product_fsm_log mapfl
         |) aa group by aa.object_id
       """.stripMargin).createOrReplaceTempView("mall_activity_product_fsm_log_time")

    // 获取每个item_id二维码最后的下载时间
    spark.sql(
      s"""
         |select
         |    fk_item_id,
         |    max(create_time) as create_time
         |from item_qr_code_record
         |group by fk_item_id
       """.stripMargin).createOrReplaceTempView("item_qr_code_record_time")

    // 获取每个item_id二维码最后的绑定时间
    spark.sql(
      s"""
         |select
         |    biz_id,
         |    max(update_time) as update_time
         |from qr_route
         |where biz_type = 1
         |group by biz_id
       """.stripMargin).createOrReplaceTempView("qr_route_time")

    // 对mall_activity_product_to_group组合品进行处理
    spark.sql(
      s"""
         |select
         |    fk_mall_parent_id,
         |    concat_ws(',',collect_set(cast(fk_mall_sub_id as string))) as fk_mall_sub_id
         |from mall_activity_product_to_group
         |group by fk_mall_parent_id
       """.stripMargin).createOrReplaceTempView("mall_activity_product_to_group_process")

    // 对store的业态进行处理
    spark.sql(
      """
        |select
        |  s.id as store_id,
        |  case
        |    when s.type = 1 then 'MALL'
        |    when s.type = 2 then 'MARKET'
        |    when s.type = 3 then 'OVERSEA'
        |    when s.type = 4 and s.is_international = 1 then 'OVERSEA'
        |    when s.type = 4 and s.is_international = 0 then 'SUPPLIER'
        |  end as source
        |from store s
      """.stripMargin).createOrReplaceTempView("store_source")

    /**
      * 第三步：合成item_fact表
      **/
    spark.sql(
      s"""
         |select
         |    mas.fk_product_sku_id as sku_id,
         |    map.id as item_id,
         |    map.fk_product_id as product_id,
         |    mas.remain_qty as sku_remain_qty,
         |    (case
         |    when mas.state = 1 then 'ONSHELF'
         |    when mas.state = 0 then 'OFFSHELF'
         |    else null
         |    end) as sku_state,
         |    map.original_price as item_original_price,
         |    map.price as item_price,
         |    map.state as item_state,
         |    mpo.create_time as item_create_time,
         |    (case
         |    when mpo.source_id = 1 then 'TIANGOU'
         |    when mpo.source_id = 2 then 'SELLER_STORE'
         |    when mpo.source_id = 3 then 'SELLER_COUNTER'
         |    when mpo.source_id = 4 then 'SUPPLIER'
         |    when mpo.source_id = 5 then 'AIR_GUIDE'
         |    else null
         |    end) as item_come_from,
         |    mapflt.item_submit_time,
         |    mapflt.item_onshelf_time,
         |    mapflt.item_offshelf_time,
         |    mapflt.item_redo_time,
         |    mapflt.item_delete_time,
         |    iqcrt.create_time as item_download_time,
         |    qrt.update_time as item_binding_time,
         |    map.modify_time as item_last_modify_time,
         |    (case
         |    when map.type = 0 or map.type is null then 'UNAPPOINT'
         |    when map.type = 1 then 'LIMIT_TIME_ROB'
         |    when map.type = 2 then 'NEW'
         |    when map.type = 3 then 'SALE'
         |    when map.type = 4 then 'COMPOSITE'
         |    when map.type = 5 or map.type = 6 or map.type = 7 then 'HISTORY'
         |    end) as item_type,
         |    ss.source as item_source,
         |    bin(map.tags) as item_origin_tags,
         |    map.fk_merchant_id as item_merchant_id,
         |    map.fk_store_id as item_store_id,
         |    c.fk_sold_area_id as item_sold_area_id,
         |    sa.fk_sold_type_id as item_sold_type_id,
         |    map.fk_counter_id as item_counter_id,
         |    generateIsFastSales(map.state) as item_is_fast_sales,
         |    maptgp.fk_mall_sub_id as item_child_item_id,
         |    b.id as brand_id,
         |    p.state as product_state,
         |    p.create_time as product_create_time,
         |    p.barcode as product_barcode,
         |    substr(ca.code, 0, 2) as level_one_category_code,
         |    substr(ca.code, 0, 4) as level_two_category_code,
         |    substr(ca.code, 0, 6) as level_three_category_code,
         |    ca.code as level_four_category_code
         |from mall_activity_sku mas
         |left join mall_activity_product map
         |on map.id = mas.fk_item_id
         |left join mall_product_operation mpo
         |on map.id = mpo.fk_mall_activity_product_id
         |left join mall_activity_product_fsm_log_time mapflt
         |on map.id = mapflt.object_id
         |left join item_qr_code_record_time iqcrt
         |on map.id = iqcrt.fk_item_id
         |left join qr_route_time qrt
         |on map.id = qrt.biz_id
         |left join mall_activity_product_to_group_process maptgp
         |on map.id = maptgp.fk_mall_parent_id
         |left join store_source ss
         |on map.fk_store_id = ss.store_id
         |left join counter c
         |on map.fk_counter_id = c.id
         |left join sold_area sa
         |on c.fk_sold_area_id = sa.id
         |left join product p
         |on map.fk_product_id = p.id
         |left join brand b
         |on p.fk_brand_id = b.id
         |left join category ca
         |on p.fk_category_id = ca.id
       """.stripMargin)

  }

}
