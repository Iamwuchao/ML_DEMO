package com.tgou.data.stanford.dw.member_dim

import com.tgou.data.stanford.dw.core.ODSSource
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.joda.time.LocalDate

/**
  * Created by 张少锐 on 2018/03/07.
  * 会员维度表
  */

object MemberDimProcess {

  def getMemberDimDF(spark: SparkSession): DataFrame = {

    val today = LocalDate.now().toString("yyyy-MM-dd")

    /**
      * 加载数据源
      **/
    // 获取全量最新的会员表
      ODSSource.getNewestDF(spark.table("member.member"), Seq("id"), "modify_time").createOrReplaceTempView("member")

    // 获取全量最新的订单表
    ODSSource.getNewestDF(spark.table("tgouorder.tgou_order"), Seq("id"), "modify_time").filter(s"pay_method != '000' and pay_method != '010' and receive_type = '10'").createOrReplaceTempView("tgou_order")

    // 获取全量最新的支付表
    ODSSource.getNewestDF(spark.table("tgouorder.tgou_order_fsm_log"), Seq("id"), "modify_time").filter(s"event = 'Pay'").createOrReplaceTempView("tgou_order_fsm_log")

    // 获取全量店铺表
    spark.table("base.store").filter(s"ods_date = '${today}'").createOrReplaceTempView("store")

    /**
      * member_dim表
      *
      * @return
      *
      * - member_id ID
      * - phone 手机号码
      * - first_shopping_time 首次购物时间
      * - first_market_shopping_time 超市首次购物时间
      * - first_mall_shopping_time 百货首次购物时间
      * - first_supplier_shopping_time 供应商首次购物时间
      * - first_oversea_shopping_time 跨境首次购物时间
      *
      **/
    spark.sql(
      s"""
         |select
         |    m.id as member_id,
         |    m.cell_phone as phone,
         |    min(tofl.enter_time) as first_shopping_time,
         |    min(case when to.source = '2' then tofl.enter_time end) as first_market_shopping_time,
         |    min(case when to.source = '1' then tofl.enter_time end) as first_mall_shopping_time,
         |    min(case when to.source = '4' and s.is_international = '0' then tofl.enter_time end) as first_supplier_shopping_time,
         |    min(case when (to.source = '4' and s.is_international = '1') or (to.source = '3') then tofl.enter_time end) as first_oversea_shopping_time
         |from member m
         |left join tgou_order to
         |on m.id = to.fk_member_id
         |left join store s
         |on to.store_id = s.id
         |left join tgou_order_fsm_log tofl
         |on tofl.object_id = to.id
         |group by m.id,m.cell_phone
       """.stripMargin)
  }
}
