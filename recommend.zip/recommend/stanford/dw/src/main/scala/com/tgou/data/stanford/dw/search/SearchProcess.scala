package com.tgou.data.stanford.dw.search

import com.tgou.data.stanford.dw.search.bean.{SearchDW, SearchODS, SearchODSExtend, UbaPageDW}
import org.apache.spark.sql.{DataFrame, Dataset, SparkSession}
import org.apache.spark.sql.functions._
import org.joda.time.LocalDateTime
import org.joda.time.format.DateTimeFormat

import scala.collection._
import scala.util.control.Breaks._

/**
  * Created by 李震 on 2017/9/21.
  */
class SearchProcess(spark: SparkSession) extends Serializable {


  def process(searchODSDs: Dataset[SearchODS], scpTableODSDF: DataFrame, ubaPageDWDs: Dataset[UbaPageDW]): Dataset[SearchDW] = {
    import spark.implicits._

    val searchDs = searchODSDs.map((s) => {

      // 去哪儿
      var goto: String = null
      var goto_a: String = null
      var goto_b: String = null
      var goto_bk: String = null
      if (s.whereabouts != null && s.whereabouts.length > 0) {
        if (s.whereabouts.startsWith("02.sd")) {
          // 专柜
          goto = s.whereabouts
          goto_a = "02"
          goto_b = "sd"
          goto_bk = s.whereabouts.split("-").last
        } else if (s.whereabouts.startsWith("06.seaamoy")) {
          // 跨境
          goto = s.whereabouts
          goto_a = "06"
          goto_b = "seaamoy"
        } else {
          // 单品
          if (s.whereabouts.startsWith("10.pd")) {
            goto = s.whereabouts
            goto_a = "10"
            goto_b = "pd"
            goto_bk = s.whereabouts.split("-").last
          } else {
            val id = getIdFromUrl(s.whereabouts)
            if (!id.isEmpty) {
              goto = "10.pd-" + id.get
              goto_a = "10"
              goto_b = "pd"
              goto_bk = id.get
            }
          }
        }
      }

      // SCP
      var scp: String = null
      var a: String = null
      var b: String = null
      var c: String = null
      var a_b: String = null
      if (s.url != null && s.url.length > 0) {
        scp = getSCPFromUrl(s.url).getOrElse(null)

        if (scp != null && scp.count(_ == '.') > 2) {
          val s = scp.split("\\.")
          a = s(0).toLowerCase
          b = s(1).toLowerCase
          c = s(2).toLowerCase
          a_b = a + "." + b
        }
      }

      SearchODSExtend(
        s.uuid,
        s.referrer,
        s.url,
        s.keyword,
        s.results,
        goto,
        goto_a,
        goto_b,
        goto_bk,
        s.source,
        s.memberId,
        s.time,
        s.storeId,
        s.global,
        scp,
        a,
        b,
        c,
        a_b,
        null
      )
    }).join(broadcast(scpTablePreprocess(scpTableODSDF)), "a_b").as[SearchDW]
      .groupByKey(_.uuid)
      .flatMapGroups((k, ss) => {

        val sortSearchs = ss.toList.sortWith((x, y) => {
          val xDT = LocalDateTime.parse(x.time, DateTimeFormat.forPattern("yyyy-MM-dd HH:mm:ss"))
          val yDT = LocalDateTime.parse(y.time, DateTimeFormat.forPattern("yyyy-MM-dd HH:mm:ss"))
          xDT.compareTo(yDT) > 0
        })

        val r = new mutable.ListBuffer[SearchDW]

        var memberId: String = null
        for (s <- sortSearchs) {
          if (s.member_id == null) {
            if (memberId != null) {
              r += s.copy(member_id = memberId)
            } else {
              r += s
            }
          } else {
            if (memberId == null) memberId = s.member_id
            r += s
          }
        }

        r
      })

    val groupSearchDs = searchDs.groupByKey((s: SearchDW) => (s.uuid, s.a_b))
    val groupUbaPageDs = ubaPageDWDs.groupByKey((up: UbaPageDW) => (up.uuid, up.a_b))

    val rDs = groupSearchDs.cogroup(groupUbaPageDs)((k, ss, ups) => {
      val orderUPs = ups.toList.sortWith((x, y) => {
        val xDT = LocalDateTime.parse(x.time, DateTimeFormat.forPattern("yyyy-MM-dd HH:mm:ss"))
        val yDT = LocalDateTime.parse(y.time, DateTimeFormat.forPattern("yyyy-MM-dd HH:mm:ss"))
        xDT.compareTo(yDT) > 0
      }).reverse

      val r = new mutable.ListBuffer[SearchDW]

      for (s <- ss) {
        try {
          var sWithPageId: SearchDW = null
          val sDT = LocalDateTime.parse(s.time, DateTimeFormat.forPattern("yyyy-MM-dd HH:mm:ss"))
          breakable {
            if (orderUPs.length == 1) {
              for (i <- 0 until orderUPs.length) {
                val orderUP = orderUPs(i)
                val upDT = LocalDateTime.parse(orderUP.time, DateTimeFormat.forPattern("yyyy-MM-dd HH:mm:ss"))
                if (upDT.compareTo(sDT) > 0) {
                  if (i > 0) {
                    val lastOrderUp = orderUPs(i - 1)
                    sWithPageId = s.copy(page_id = lastOrderUp.id)
                    break
                  }
                }
              }
            } else if(orderUPs.length > 1) {
              val orderUP = orderUPs(0)
              sWithPageId = s.copy(page_id = orderUP.id)
            }
          }
          if (sWithPageId == null) r += s
          else r += sWithPageId
        } catch {
          case e: Exception => e.printStackTrace()
        }
      }
      r
    })

    rDs
  }


  private def scpTablePreprocess(scpTableDF: DataFrame): DataFrame = {
    scpTableDF.groupBy("zzcode", "ymcode")
      .agg(
        max("zz") as "zz",
        max("ym") as "ym",
        max("yt") as "yt",
        max("attach") as "attach"
      ).select(
      concat(lower(column("zzcode")), lit("."), lower(column("ymcode"))) as "a_b",
      column("zz") as "a_name",
      column("ym") as "b_name",
      column("yt") as "scp_table_yt",
      column("attach")
    )
  }

  private def getIdFromUrl(url: String): Option[String] = {
    val m = "id=([^&]+)".r.findFirstMatchIn(url)
    if (!m.isEmpty) {
      Option(m.get.subgroups(0))
    } else None
  }

  private def getSCPFromUrl(url: String): Option[String] = {
    val m = "scp=([^&]+)".r.findFirstMatchIn(url)
    if (!m.isEmpty) {
      Option(m.get.subgroups(0))
    } else None
  }

}

object SearchProcess {

  def apply(spark: SparkSession): SearchProcess = new SearchProcess(spark)

}