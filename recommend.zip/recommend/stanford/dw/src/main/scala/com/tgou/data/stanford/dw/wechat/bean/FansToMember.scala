package com.tgou.data.stanford.dw.wechat.bean

import com.tgou.data.stanford.core.base.BaseBean

/**
  * Created by xinghailong on 2017/8/21.
  */
object FansToMember extends BaseBean {

  override def list: List[(Any,String)] = {
    List(
      (0 , "id"),
      (1 , "openid"),
      (2 , "fk_member_id")
    )
  }
}
