package com.tgou.data.stanford.dw.core

import scala.collection.JavaConversions._
import com.datastax.spark.connector.cql.CassandraConnector
import org.apache.spark.sql.{DataFrame, SaveMode}
import org.apache.spark.sql.functions._
import org.apache.spark.sql.cassandra._


/**
  * Created by 李震 on 2018/3/10.
  */
object ODSSink {

  def sink2Hive(df: DataFrame, dbName: String, tableName: String): Unit = {
    df.createOrReplaceTempView("ods")

    val spark = df.sparkSession

    spark.sql(
      s"""
         |create table if not exists ${dbName}.${tableName}
         |using PARQUET
         |as select * from ods
      """.stripMargin)

    spark.sql(
      s"""
         |insert overwrite table ${dbName}.${tableName}
         |select * from ods
      """.stripMargin)
  }

  def sink2Hive(df: DataFrame, tableName: String): Unit = {
    sink2Hive(df, "tgdw", tableName)
  }

  def sink2Cassandra(df: DataFrame, keyspaceName: String, tableName: String): Unit = {
    /*
     * 1. 获取目标 Cassandra 表 Schema
     * */
    val spark = df.sparkSession
    val connector = CassandraConnector(spark.sparkContext.getConf)
    val session = connector.openSession()
    val rs = session.execute(
      s"""
         |select *
         |from ${keyspaceName}.${tableName}
         |limit 1""".stripMargin)
    val cassandraTableDefinitions = rs.getColumnDefinitions

    /*
     * 2. DataFrame 仅保留目标 Cassandra 表存在的列
     * */
    val columns = cassandraTableDefinitions.toList.map(definitioin => col(definitioin.getName))
    val sink2CassandraDF = df.select(columns:_*)

    /*
     * 3. 写入数据到目标 Cassandra 表
     * */
    sink2CassandraDF.write
      .mode(SaveMode.Overwrite) // truncate table
      .format("org.apache.spark.sql.cassandra")
      .options(Map(
        "table" -> tableName,
        "keyspace" -> keyspaceName,
        "cluster" -> "BI Cluster",
        "pushdown" -> true.toString,
        "confirm.truncate" -> true.toString, // confirm truncate table
        "spark.cassandra.output.consistency.level" -> "ONE" // consistency level one
      ))
      .save()
  }

  def sink2Cassandra(df: DataFrame, tableName: String): Unit = {
    sink2Cassandra(df, "market", tableName)
  }

}
