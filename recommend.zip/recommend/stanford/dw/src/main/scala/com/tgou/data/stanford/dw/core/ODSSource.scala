package com.tgou.data.stanford.dw.core

import org.apache.spark.sql.functions.{column, max}
import org.apache.spark.sql.DataFrame

/**
  * Created by 张少锐 on 2018/03/07.
  */
object ODSSource {

  /**
    * 获取最新数据
    *
    * @param df 数据集
    * @param primaryKey 主键字段名
    * @param timestamp 时间戳字段名
    *
    * @return
    *
    * */
  def getNewestDF(df: DataFrame, primaryKey: Seq[String], timestamp: String): DataFrame = {
    df.join(df.groupBy(primaryKey.map(column): _*).agg(max(timestamp) as timestamp), primaryKey :+ timestamp)
  }

}
