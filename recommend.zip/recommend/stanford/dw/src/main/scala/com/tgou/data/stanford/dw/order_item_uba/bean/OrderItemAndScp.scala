package com.tgou.data.stanford.dw.order_item_uba.bean

case class OrderItemAndScp (
                       order_item_id: String,
                       mall_product_id: String,
                       member_id: String,
                       shop_cart_id: String,
                       shop_cart_create_time: String,
                       scp: String,
                       time: String,
                       traceId: String
                      )
