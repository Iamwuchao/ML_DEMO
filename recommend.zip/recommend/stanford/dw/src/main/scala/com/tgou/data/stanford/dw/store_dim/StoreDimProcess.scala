package com.tgou.data.stanford.dw.store_dim

import org.apache.spark.sql.{DataFrame, SparkSession}
import org.joda.time.LocalDate

/**
  * Created by 张少锐 on 2018/03/07.
  * 店铺维度表
  */

object StoreDimProcess {

  def getStoreDimDF(spark: SparkSession): DataFrame = {

    val today = LocalDate.now().toString("yyyy-MM-dd")

    /**
      * 加载数据源
      **/
    // 获取全量店铺表
    spark.table("base.store").filter(s"ods_date = '${today}' and state = 'onshelf'").createOrReplaceTempView("store")

    // 获取全量省份表
    spark.table("base.province").filter(s"ods_date = '${today}'").createOrReplaceTempView("province")

    // 获取全量城市表
    spark.table("base.city").filter(s"ods_date = '${today}'").createOrReplaceTempView("city")

    // 获取全量区域表
    spark.table("base.area").filter(s"ods_date = '${today}'").createOrReplaceTempView("area")

    // 获取全量店铺地址表
    spark.table("base.store_address").filter(s"ods_date = '${today}' and type = '0'").createOrReplaceTempView("store_address")

    /**
      * store_dim表
      *
      * @return
      *
      * - store_id 店铺 ID
      * - store_code 店铺编码
      * - store_name 店铺名称
      * - store_state 店铺状态
      * - province_code 省份编码
      * - province_name 省份名称
      * - city_code 城市编码
      * - city_name 城市名称
      * - area_code 区域编码
      * - area_name 区域名称
      * - store_closed 前台不显示
      * - store_is_on 是否开启
      * - source_name 业态名称
      *
      **/
    spark.sql(
      s"""
         |select
         |    s.id as store_id,
         |    s.code as store_code,
         |    s.name as store_name,
         |    s.state as store_state,
         |    p.code as province_code,
         |    p.name as province_name,
         |    c.code as city_code,
         |    c.name as city_name,
         |    a.code as area_code,
         |    a.name as area_name,
         |    s.closed as store_closed,
         |    s.is_on as store_is_on,
         |    case when s.type = '1' then '百货'
         |         when s.type = '2' then '超市'
         |         when s.type = '4' and s.is_international = '0' then '品牌商'
         |         when s.type = '4' and s.is_international = '1' then '全球购'
         |         end as source_name
         |from store s
         |left join store_address sa
         |on s.id = sa.fk_store_id
         |left join province p
         |on p.id = sa.fk_province_id
         |left join city c
         |on c.id = sa.fk_city_id
         |left join area a
         |on s.fk_area_id = a.id
       """.stripMargin)
  }
}
