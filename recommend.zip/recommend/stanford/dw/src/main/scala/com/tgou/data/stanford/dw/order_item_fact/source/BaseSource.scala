package com.tgou.data.stanford.dw.order_item_fact.source

import org.apache.spark.sql.DataFrame

/**
  * Created by 李震 on 2018/3/10.
  */
trait BaseSource {

  /**
    * 获取 ODS 层 store 数据
    * */
  def getODSStoreDF(): DataFrame

  /**
    * 获取 ODS 层 store_address 数据
    * */
  def getODSStoreAddress(): DataFrame

}
