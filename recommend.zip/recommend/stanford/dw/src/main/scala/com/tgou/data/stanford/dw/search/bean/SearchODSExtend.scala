package com.tgou.data.stanford.dw.search.bean

/**
  * Created by 李震 on 2017/9/21.
  */
case class SearchODSExtend (
                        uuid: String,
                        referrer: String,
                        url: String,
                        keyword: String,
                        results: String,
                        goto_page: String,
                        goto_a: String,
                        goto_b: String,
                        goto_bk: String,
                        source: String,
                        member_id: String,
                        time: String,
                        store_id: String,
                        global: String,
                        scp: String,
                        a: String,
                        b: String,
                        c: String,
                        a_b: String,
                        page_id: String
                      )
