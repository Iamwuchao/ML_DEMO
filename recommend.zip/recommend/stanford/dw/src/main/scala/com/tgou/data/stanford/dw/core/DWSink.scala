package com.tgou.data.stanford.dw.core

import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.types._

import scala.collection.JavaConverters._
import scala.collection.mutable

/**
  * Created by 李震 on 2017/9/12.
  */
object DWSink {

  def generateCreateTableSQL(df: DataFrame, path:String, tableName: String): String = {

    var fieldDelareList = mutable.MutableList[String]()

    for (field <- df.schema.fields) {
      val columnName = field.name
      field.dataType match {
        case IntegerType => fieldDelareList += s"${columnName} INT"
        case LongType => fieldDelareList += s"${columnName} BIGINT"
        case FloatType | DoubleType => fieldDelareList += s"${columnName} DOUBLE"
        case BooleanType => fieldDelareList += s"${columnName} BOOLEAN"
        case StringType => fieldDelareList += s"${columnName} STRING"
        case _ => fieldDelareList += s"${columnName} STRING"
      }
    }

    val fieldDeclare = String.join(", ", fieldDelareList.asJava)

    s"""
       |CREATE EXTERNAL TABLE IF NOT EXISTS odw.${tableName}
       |(
       |  ${fieldDeclare}
       |)
       |PARTITIONED BY (etl_time STRING)
       |STORED AS PARQUET
       |LOCATION '${path}/${tableName}'
     """.stripMargin
  }

  def generateAddPartitionSQL(tableName:String, date: String): String = {
    s"""
       |ALTER TABLE odw.${tableName} ADD IF NOT EXISTS PARTITION (etl_time='${date}')
     """.stripMargin
  }

}
