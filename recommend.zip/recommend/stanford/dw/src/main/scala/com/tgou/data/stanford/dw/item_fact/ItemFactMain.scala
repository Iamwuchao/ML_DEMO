package com.tgou.data.stanford.dw.item_fact
import com.tgou.data.stanford.dw.core.{DWBootstrap, ODSSink}
import org.apache.spark.sql. SparkSession
import org.joda.time.LocalDate

object ItemFactMain {

  def main(args: Array[String]): Unit = {
    DWBootstrap(args).bootstrap(execute)
  }

  def execute(spark: SparkSession, appName: String, date: LocalDate): Unit = {

    /*
    * 获取数据
    * */
    val itemFact = ItemFactProcess.getItemFactDF(spark)

    /*
     * 持久化到hive表
     * */
    ODSSink.sink2Hive(itemFact,"item_fact")

  }
}
