package com.tgou.data.stanford.dw.wechat

import com.tgou.data.stanford.core.utils.{ETLUtils, HDFSConfig}
import com.tgou.data.stanford.dw.wechat.bean.{BindLoginMember, Fans, FansToMember, WeChatInfo}
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.storage.StorageLevel


/**
  * Created by xinghailong on 2017/8/21.
  */
object WeChatLoader {

  val FANS_PATH               = "wechat/fans"
  val FANS_TO_MEMBER_PATH     = "wechat/fans_to_member"
  val BIND_LOGIN_MEMBER_PATH  = "wechat/bind_login_member"
  val WECHAT_INFO_PATH        = "wechat/wechat_info"

  def detail(spark: SparkSession, etl_time: String): DataFrame = {

    val fansToMemberDF = spark.sql(
      s"""
         |select * from (
         |  select
         |    openid,
         |    case when merge_len(history_member_ids) > 10 then 1 else 0 end as state,
         |    case when merge_len(history_member_ids) > 10 then "" else history_member_ids end as history_member_ids
         |  from (
         |    select openid,merge(fk_member_id) as history_member_ids from total_fans_to_member group by openid
         |  ) t1
         |) t2
         |where history_member_ids is not null
       """.stripMargin)

    fansToMemberDF.createOrReplaceTempView("merge_fans_to_member")

    val df = spark.sql(
      s"""
         |select
         |  nvl(concat(f.openid,"_","$etl_time"),'') as id,
         |  nvl(ftm.history_member_ids,'') as history_member_ids,
         |  nvl(ftm.state,'')         as state,
         |  nvl(blm.fk_member_id,'')  as member_id,
         |  nvl(f.openid,'')          as openid,
         |  nvl(f.subscribe,'')       as subscribe,
         |  nvl(f.subscribe_time,'')  as subscribe_time,
         |  nvl(f.nickname,'')        as nickname,
         |  nvl(f.sex,'')             as sex,
         |  nvl(f.country,'')         as country,
         |  nvl(f.province,'')        as province,
         |  nvl(f.city,'')            as city,
         |  nvl(f.fk_wechat_info_id,'') as fk_wechat_info_id,
         |  nvl(mwi.name,'')          as wechat_info_name,
         |  nvl(mwi.wechat_id,'')     as wechat_id,
         |  nvl(mwi.origin_id,'')     as origin_id,
         |  nvl(mwi.fk_store_id,'')   as fk_store_id,
         |  nvl(mwi.appid,'')         as appid,
         |  nvl(mwi.bridage_state,'') as bridage_state,
         |  nvl(mwi.wechat_info_type,'') as wechat_info_type,
         |  nvl(mwi.info_state,'')    as info_state,
         |  concat("$etl_time"," 00:00:00") as etl_time
         |from fetch_fans f
         |left join merge_fans_to_member ftm
         |  on f.openid = ftm.openid
         |left join total_bind_login_member blm
         |  on f.openid = blm.openid
         |left join modify_wechat_info mwi
         |  on f.fk_wechat_info_id = mwi.id
       """.stripMargin)
    df
  }

  def fetchFans(spark: SparkSession) = {
    val part1 = spark.sql(
      s"""
         |select tf.* from total_fans tf inner join modify_bind_login_member mblm on tf.openid = mblm.openid
       """.stripMargin)
    part1.createOrReplaceTempView("part1")

    val part2 = spark.sql(
      s"""
         |select tf.* from total_fans tf inner join modify_fans_to_member mftm on tf.openid = mftm.openid
       """.stripMargin)
    part2.createOrReplaceTempView("part2")

    val fansDF = spark.sql(
      s"""
         |select * from modify_fans
         |UNION ALL
         |select * from part1
         |UNION ALL
         |select * from part2
       """.stripMargin).distinct()

    fansDF.createOrReplaceTempView("fetch_fans")
  }

  def load(spark:SparkSession, namenode: String, date:String) = {
    //读取当天增量的：fans，fans_to_member，bind_login_member，wechat_info

    // 这个表这样读完，还是又重复哈！
    val fansModifyDF = ETLUtils.getModify(spark,namenode,HDFSConfig.DW_SQOOP_ROOT+HDFSConfig.WECHAT+"/fans",date,Fans)
    fansModifyDF.createOrReplaceTempView("modify_fans")

    val fansToMemberModifyDF = ETLUtils.getModify(spark,namenode,HDFSConfig.DW_SQOOP_ROOT+HDFSConfig.WECHAT+"/fans_to_member",date,FansToMember)
    fansToMemberModifyDF.createOrReplaceTempView("modify_fans_to_member")

    val bindLoginMemberModifyDF = ETLUtils.getModify(spark,namenode,HDFSConfig.DW_SQOOP_ROOT+HDFSConfig.WECHAT+"/bind_login_member",date,BindLoginMember)
    bindLoginMemberModifyDF.createOrReplaceTempView("modify_bind_login_member")

    val weChatInfoModifyDF = ETLUtils.getModify(spark,namenode,HDFSConfig.DW_SQOOP_ROOT+HDFSConfig.WECHAT+"/wechat_info",date,WeChatInfo)
    weChatInfoModifyDF.createOrReplaceTempView("modify_wechat_info")

    //读取全量且最新的：fans，fans_to_member，bind_login_member

    // 这个表这样读完,应该只剩下最新的数据了
    val fansTotalOriginDF = ETLUtils.getTotal(spark,namenode,HDFSConfig.DW_SQOOP_ROOT+HDFSConfig.WECHAT+"/fans",date,Fans)
    val fansTotalDF = ETLUtils.getNewestDF(spark,fansTotalOriginDF,"openid","modify_time")
    fansTotalDF.createOrReplaceTempView("total_fans")
    fansTotalDF.persist(StorageLevel.MEMORY_AND_DISK)

    // 这个表不需要取最新，直接读全部就可以了
    val fansToMemberTotalDF = ETLUtils.getTotal(spark,namenode,HDFSConfig.DW_SQOOP_ROOT+HDFSConfig.WECHAT+"/fans_to_member",date,FansToMember)
    fansToMemberTotalDF.createOrReplaceTempView("total_fans_to_member")

    // 这个表会删数据，按照open_id取最新，可能读出来已经删掉的数据
    val bindLoginMemberTotalOriginDF = ETLUtils.getTotal(spark,namenode,HDFSConfig.DW_SQOOP_ROOT+HDFSConfig.WECHAT+"/bind_login_member",date,BindLoginMember)
    val bindLoginMemberTotalDF = ETLUtils.getNewestDF(spark,bindLoginMemberTotalOriginDF,"openid","modify_time")
    bindLoginMemberTotalDF.createOrReplaceTempView("total_bind_login_member")
  }
}
