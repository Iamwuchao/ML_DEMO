package com.tgou.data.stanford.dw.search

import com.tgou.data.stanford.dw.core.DWSink
import com.tgou.data.stanford.dw.search.bean.SearchDW
import org.apache.spark.sql.{Dataset, SaveMode, SparkSession}
import org.joda.time.LocalDate

/**
  * Created by 李震 on 2017/9/21.
  */
class SearchSink(spark: SparkSession) extends Serializable {

  def persist(result: Dataset[SearchDW], date: LocalDate): Unit = {
    result.createTempView("search_t")

    val r = spark.sql(
      s"""
         |select
         |    md5(concat_ws('_', t.uuid, t.keyword, t.time)) as id,
         |    t.*
         |from search_t t
      """.stripMargin)

    spark.sql(DWSink.generateCreateTableSQL(r, "/data/dw", "search"))

    r.coalesce(8).write.mode(SaveMode.Overwrite).parquet(s"/data/dw/search/etl_time=${date.toString("yyyy-MM-dd")}")

    spark.sql(DWSink.generateAddPartitionSQL("search", date.toString("yyyy-MM-dd")))
  }

}

object SearchSink {

  def apply(spark: SparkSession): SearchSink = new SearchSink(spark)

}