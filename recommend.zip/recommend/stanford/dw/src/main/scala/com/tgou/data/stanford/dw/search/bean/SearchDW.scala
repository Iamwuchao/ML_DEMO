package com.tgou.data.stanford.dw.search.bean

/**
  * Created by 李震 on 2017/9/21.
  */
case class SearchDW (
                      uuid: String,
                      referrer: String,
                      url: String,
                      keyword: String,
                      results: String,
                      goto_page: String,
                      goto_a: String,
                      goto_b: String,
                      goto_bk: String,
                      source: String,
                      member_id: String,
                      time: String,
                      store_id: String,
                      global: String,
                      scp: String,
                      a: String,
                      a_name: String,
                      b: String,
                      b_name: String,
                      c: String,
                      a_b: String,
                      scp_table_yt: String,
                      attach: String,
                      page_id: String
                    )
