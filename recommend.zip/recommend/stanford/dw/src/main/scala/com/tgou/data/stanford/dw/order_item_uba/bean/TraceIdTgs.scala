package com.tgou.data.stanford.dw.order_item_uba.bean

case class TraceIdTgs (
                        member_id: String,
                        jr: String,
                        scp: String,
                        global: String,
                        page: String,
                        time: String,
                        traceId: String,
                        sScp: String,
                        scpTime: String
                      )
