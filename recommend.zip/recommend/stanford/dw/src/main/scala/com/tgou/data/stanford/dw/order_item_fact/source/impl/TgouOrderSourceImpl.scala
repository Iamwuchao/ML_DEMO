package com.tgou.data.stanford.dw.order_item_fact.source.impl

import com.google.inject.Inject
import com.tgou.data.stanford.dw.Constants._
import com.tgou.data.stanford.dw.core.ODSSource
import com.tgou.data.stanford.dw.order_item_fact.source.TgouOrderSource
import org.apache.spark.sql.{DataFrame, SparkSession}

/**
  * Created by 李震 on 2018/3/9.
  */
class TgouOrderSourceImpl extends TgouOrderSource {

  @Inject
  var spark: SparkSession = _

  override def getODSOrderItemDF(): DataFrame = {
    ODSSource.getNewestDF(spark.table(TABLE_ORDER_ITEM), Seq("id"), "modify_time")
  }

  override def getODSTgouOrderDF(): DataFrame = {
    ODSSource.getNewestDF(spark.table(TABLE_TGOU_ORDER), Seq("id"), "modify_time")
  }

  override def getODSOrderAmountDF(): DataFrame = {
    ODSSource.getNewestDF(spark.table(TABLE_ORDER_AMOUNT), Seq("id"), "modify_time")
  }

  override def getODSReturnRequestDF(): DataFrame = {
    ODSSource.getNewestDF(spark.table(TABLE_RETURN_REQUEST), Seq("id"), "modify_time")
  }

  override def getODSPaymentDF(): DataFrame = {
    ODSSource.getNewestDF(spark.table(TABLE_PAYMENT), Seq("id"), "modify_time")
  }

  override def getODSTgouOrderFSMLogDF(): DataFrame = {
    spark.table(TABLE_TGOU_ORDER_FSM_LOG)
  }

  override def getODSOrderPreferentialDF(): DataFrame = {
    spark.table(TABLE_ORDER_PREFERENTIAL)
  }
}
