package com.tgou.data.stanford.dw.core

import org.apache.spark.sql.SparkSession
import org.joda.time.LocalDate

/**
  * Created by 李震 on 2017/9/12.
  */
class DWBootstrap(args: Array[String]) {

  val appName = args(0)
  val date = LocalDate.now().plusDays(args(1).toInt)

  def bootstrap(execute: (SparkSession, String, LocalDate) => Unit): Unit = {
    // 配置元数据库
    System.setProperty("hive.metastore.uris", "thrift://hnode1:9083")

    val spark = if (appName.startsWith("test") || appName.endsWith("test")) {
      val spark = SparkSession.builder()
        .master("local[2]")
        .appName(appName)
        .config("spark.eventLog.enabled", false)
        .enableHiveSupport()
        .getOrCreate()

      // 日志级别
      spark.sparkContext.setLogLevel("DEBUG")

      spark
    } else {
      val spark = SparkSession.builder()
        .master("yarn")
        .appName(appName)
        .config("spark.eventLog.enabled", true)
        .config("spark.eventLog.dir", "hdfs://nameservice1/user/spark/applicationHistory")
        .config("spark.yarn.historyServer.address", "http://hnode10:18080")
        .config("spark.sql.parquet.writeLegacyFormat", true)
        .config("spark.sql.broadcastTimeout", 3600)
        .enableHiveSupport()
        .getOrCreate()

      // 日志级别
      spark.sparkContext.setLogLevel("WARN")

      spark
    }

    try {
      execute(spark, appName, date)
    } catch {
      case e: Exception => throw new RuntimeException(e)
    } finally {
      spark.close()
    }
  }

  def bootstrapWithCassandra(execute: (SparkSession, String, LocalDate) => Unit): Unit = {
    // 配置元数据库
    System.setProperty("hive.metastore.uris", "thrift://hnode1:9083")

    val spark = if (appName.startsWith("test")) {
      // Debug 模式
      SparkSession.builder()
        .master("local")
        .appName(appName)
        .enableHiveSupport()
        .config("spark.sql.parquet.writeLegacyFormat", true)
        .config("spark.cassandra.connection.keep_alive_ms", 10000) // 空闲时段保持链接10秒
        .config("spark.cassandra.connection.host", "172.16.3.9,172.16.3.10,172.16.3.11")
        .config("spark.cassandra.auth.username", "tiangou")
        .config("spark.cassandra.auth.password", "K09Kccrx]")
        .getOrCreate()
    } else {
      SparkSession.builder()
        .master("yarn")
        .appName(appName)
        .enableHiveSupport()
        .config("spark.eventLog.enabled", true)
        .config("spark.eventLog.dir", "hdfs://nameservice1/user/spark/applicationHistory")
        .config("spark.yarn.historyServer.address", "http://hnode10:18080")
        .config("spark.sql.parquet.writeLegacyFormat", true)
        .config("spark.cassandra.connection.keep_alive_ms", 10000) // 空闲时段保持链接10秒
        .config("spark.cassandra.connection.host", "172.16.3.9,172.16.3.10,172.16.3.11")
        .config("spark.cassandra.auth.username", "tiangou")
        .config("spark.cassandra.auth.password", "K09Kccrx]")
        .getOrCreate()
    }

    // 日志级别
    spark.sparkContext.setLogLevel("WARN")

    try {
      // 执行
      execute(spark, appName, date)
    } catch {
      case e: Exception => throw new RuntimeException(e)
    } finally {
      spark.close()
    }
  }

}

object DWBootstrap {

  def apply(args: Array[String]): DWBootstrap = new DWBootstrap(args)

}
