package com.tgou.data.stanford.dw.order_item_fact.source.impl

import com.google.inject.Inject
import com.tgou.data.stanford.dw.Constants._
import com.tgou.data.stanford.dw.core.ODSSource
import com.tgou.data.stanford.dw.order_item_fact.source.ItemSource
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.joda.time.LocalDate

/**
  * Created by 李震 on 2018/3/10.
  */
class ItemSourceImpl extends ItemSource {

  @Inject
  var spark: SparkSession = _

  override def getODSProductDF(): DataFrame = {
    ODSSource.getNewestDF(spark.table(TABLE_PRODUCT), Seq("id"), "modify_time")
  }

  override def getODSCategoryDF(): DataFrame = {
    spark.table(TABLE_CATEGORY).filter(s"ods_date = '${LocalDate.now().toString("yyyy-MM-dd")}'")
  }

}
