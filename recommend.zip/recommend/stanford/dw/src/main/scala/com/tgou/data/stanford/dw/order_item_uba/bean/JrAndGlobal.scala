package com.tgou.data.stanford.dw.order_item_uba.bean

case class JrAndGlobal (
                    order_item_id: String,
                    var global: String,
                    var jr: String
                  )
