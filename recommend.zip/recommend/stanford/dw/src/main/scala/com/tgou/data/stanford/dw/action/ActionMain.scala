package com.tgou.data.stanford.dw.action

import java.time.LocalDate

import com.tgou.data.stanford.dw.action.service.ActionService
import org.apache.spark.sql.{SaveMode, SparkSession}

object ActionMain {
  def main(args: Array[String]) {
    val namenode = args(0)
    val spark = SparkSession.builder()
      .enableHiveSupport()
      .appName("action_main")
      .config("hive.metastore.uris","thrift://hnode1:9083")
      .getOrCreate()
    spark.sparkContext.setLogLevel("WARN")// 日志级别
    val dateTime: LocalDate = LocalDate.parse("2017-01-01")
    val result = ActionService.getTransferAction(spark)
          .union(ActionService.getCollectionAction(spark))
          .union(ActionService.getPageViewAction(spark,dateTime))
          .union(ActionService.getShopCartAction(spark,namenode))
    result.write.mode(SaveMode.Overwrite).format("com.databricks.spark.csv").option("header", "true").save("/tmp/caoz/action_csv")
  }
}
