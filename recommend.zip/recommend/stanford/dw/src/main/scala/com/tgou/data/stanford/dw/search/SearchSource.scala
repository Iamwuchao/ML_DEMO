package com.tgou.data.stanford.dw.search

import com.tgou.data.stanford.dw.search.bean.{SearchODS, UbaPageDW}
import org.apache.spark.sql.{DataFrame, Dataset, SparkSession}
import org.joda.time.LocalDate

/**
  * Created by 李震 on 2017/9/21.
  */
class SearchSource(spark: SparkSession) extends Serializable {

  /**
    * 获取增量的 search ODS 层数据
    *
    * @param date
    *
    * @return
    *
    * 字段详见 [[com.tgou.data.stanford.dw.search.bean.SearchODS]]
    *
    * */
  def getSearchODSDs(date: LocalDate): Dataset[SearchODS] = {
    import spark.implicits._
    spark.read.json(s"/tiangou/search/${date.toString("yyyy/MM/dd")}/*/*").as[SearchODS]
  }


  /**
    * 获取增量的 scp_table ODS 层数据
    *
    * @param date
    *
    * @return
    *
    * zz  主站
    * zzcode  主站编码
    * ym  页面
    * ymcode  页面编码
    * yt  业态
    * attach  部门
    *
    * */
  def getScpTableODSDF(date: LocalDate): DataFrame = {
    spark.read
      .option("delimiter", "^")
      .option("quote", "")
      .option("nullValue", "\\N")
      .option("inferSchema", true)
      .csv(s"/tiangou/standford/scp_table/${date.minusDays(1).toString("yyyy/MM/dd")}/*")
      .toDF(
        "id",
        "zz",
        "zzcode",
        "ym",
        "ymcode",
        "page",
        "qk",
        "qkcode",
        "description",
        "bk",
        "remark",
        "state",
        "modify_time",
        "user",
        "yt",
        "attach"
      ).select(
        "zz",
        "zzcode",
        "ym",
        "ymcode",
        "yt",
        "attach"
      )
  }


  /**
    * 获取增量的 uba_page 数仓层数据
    *
    * @param date
    *
    * @return
    *
    * 字段详见 [[com.tgou.data.stanford.dw.search.bean.UbaPageDW]]
    *
    * */
  def getUbaPageDWDs(date: LocalDate): Dataset[UbaPageDW] = {
    import spark.implicits._
    spark.read.json(s"/tiangou/etl/json/uba-page-etl/${date.toString("yyyy/MM/dd")}/*")
        .select("id", "uuid", "a_b", "time").as[UbaPageDW]
  }

}

object SearchSource {

  def apply(spark: SparkSession): SearchSource = new SearchSource(spark)

}