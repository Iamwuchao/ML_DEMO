package com.tgou.data.stanford.dw.order_item_fact.source

import org.apache.spark.sql.DataFrame

/**
  * Created by 李震 on 2018/3/9.
  */
trait TgouOrderSource {

  /**
    * 获取 ODS 层 order_item 数据
    * */
  def getODSOrderItemDF(): DataFrame

  /**
    * 获取 ODS 层 tgou_order 数据
    * */
  def getODSTgouOrderDF(): DataFrame

  /**
    * 获取 ODS 层 order_amount 数据
    * */
  def getODSOrderAmountDF(): DataFrame

  /**
    * 获取 ODS 层 return_request 数据
    * */
  def getODSReturnRequestDF(): DataFrame

  /**
    * 获取 ODS 层 payment 数据
    * */
  def getODSPaymentDF(): DataFrame

  /**
    * 获取 ODS 层 tgou_order_fsm_log 数据
    * */
  def getODSTgouOrderFSMLogDF(): DataFrame

  /**
    * 获取 ODS 层 order_preferential 数据
    * */
  def getODSOrderPreferentialDF(): DataFrame

}
