package com.tgou.data.stanford.dw.order_item_fact

import com.google.inject.name.Named
import com.google.inject.{Guice, Inject}
import com.tgou.data.stanford.dw.core.{DWBootstrap, ODSSink}
import com.tgou.data.stanford.dw.order_item_fact.source.{BaseSource, ItemSource, TgouOrderSource}
import org.apache.spark.sql.types._
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.storage.StorageLevel
import org.joda.time.LocalDate

/**
  * Created by 李震 on 2018/3/6.
  */
object Application {

  val HISTORY_ORDER_START_TIME = "2017-01-01 00:00:00"
  val HISTORY_ORDER_END_TIME = "2017-12-31 23:59:59"
  val ORDER_START_TIME = "2018-01-01 00:00:00"

  def main(args: Array[String]): Unit = {
    DWBootstrap(args).bootstrap(execute)
  }

  def execute(spark: SparkSession, appName: String, date: LocalDate): Unit = {
    val injector = Guice.createInjector(new ApplicationModule(spark, appName, date))
    injector.getInstance(classOf[Application]).run()
  }

}

class Application {

  @Inject
  var spark: SparkSession = _

  @Inject
  @Named("appName")
  var appName: String = _

  @Inject
  var tgouOrderSource: TgouOrderSource = _

  @Inject
  var baseSource: BaseSource = _

  @Inject
  var itemSource: ItemSource = _


  private def historyOrderAmountDF: DataFrame = {
    spark.sql(
      s"""
        |select
        |  o.product_amount as order_amount,
        |  o.receive_amount as order_cash_amount,
        |  p.order_points,
        |  op.order_tax,
        |  op.order_shipping_costs,
        |  op.order_coupon_amount,
        |  op.order_activity_amount,
        |  o.id as order_id
        |from tgou_order o
        |left join (
        |  select
        |    o.id,
        |    sum(p.amount) as order_points
        |  from tgou_order o
        |  left join payment p
        |  on o.id = p.fk_tgou_order_id
        |  and p.type regexp '\u4ed8\u6b3e' -- 付款
        |  and p.pay_method = 901
        |  and o.create_time >= '${Application.HISTORY_ORDER_START_TIME}'
        |  and o.create_time <= '${Application.HISTORY_ORDER_END_TIME}'
        |  and (length(o.fixed_tags) < 8 or (length(o.fixed_tags) >= 8 and substr(o.fixed_tags, 8, 1) = '0'))
        |  group by o.id
        |) p
        |on o.id = p.id
        |and o.create_time >= '${Application.HISTORY_ORDER_START_TIME}'
        |and o.create_time <= '${Application.HISTORY_ORDER_END_TIME}'
        |and (length(o.fixed_tags) < 8 or (length(o.fixed_tags) >= 8 and substr(o.fixed_tags, 8, 1) = '0'))
        |left join (
        |  select
        |    o.id,
        |    sum(case
        |      when type in (2, 9, 10, 11) then op.amount
        |    end) as order_tax,
        |    sum(case
        |      when type = 1 then op.amount
        |    end) - sum(case
        |      when type = 5 then op.amount
        |    end) as order_shipping_costs,
        |    sum(case
        |      when type = 3 then op.amount
        |    end) as order_coupon_amount,
        |    sum(case
        |      when type in (4, 12, 13, 14, 15) then op.amount
        |    end) as order_activity_amount
        |  from tgou_order o
        |  left join order_preferential op
        |  on o.id = op.fk_tgou_order_id
        |  and o.create_time >= '${Application.HISTORY_ORDER_START_TIME}'
        |  and o.create_time <= '${Application.HISTORY_ORDER_END_TIME}'
        |  and (length(o.fixed_tags) < 8 or (length(o.fixed_tags) >= 8 and substr(o.fixed_tags, 8, 1) = '0'))
        |  group by o.id
        |) op
        |on o.id = op.id
      """.stripMargin)
  }


  /**
    * 获取订单金额
    *
    * @return
    *
    * - order_amount 订单商品金额
    * - order_cash_amount 订单现金支付金额
    * - order_points 订单积分
    * - order_tax 订单税金
    * - order_shipping_costs 订单运费
    * - order_coupon_amount 订单券优惠金额
    * - order_activity_amount 订单活动优惠金额
    * - order_id 订单 ID
    *
    * */
  private def orderAmountDF: DataFrame = {
    spark.sql(
      """
        |select
        |  sum(case when oa.type=6 then amount else 0.0 end) as order_amount,
        |  sum(case when oa.type=1 and currency_code='CNY' then amount else 0.0 end) as order_cash_amount,
        |  sum(case when oa.type=1 and currency_code='TGF' then amount else 0.0 end) as order_points,
        |  sum(case when oa.type=4 then amount else 0.0 end) as order_tax,
        |  sum(case when oa.type=5 then amount else 0.0 end) as order_shipping_costs,
        |  sum(case when oa.type=2 then amount else 0.0 end) as order_coupon_amount,
        |  sum(case when oa.type=3 then amount else 0.0 end) as order_activity_amount,
        |  oa.fk_tgou_order_id as order_id
        |from order_amount oa
        |group by oa.fk_tgou_order_id
      """.stripMargin)
  }

  /**
    * 获取订单退款金额
    *
    * @return
    *
    * - order_return_amount 订单退款金额
    * - order_id 订单 ID
    *
    * */
  private def orderReturnAmountDF: DataFrame = {
    spark.sql(
      """
        |select
        |  sum(rr.amount) as order_return_amount,
        |  rr.fk_tgou_order_id as order_id
        |from return_request rr
        |where rr.state = 'End'
        |group by rr.fk_tgou_order_id
      """.stripMargin)
  }

  /**
    * 获取订单状态时间
    *
    * @return
    *
    * - order_cancel_time 订单取消时间
    * - order_return_time 订单退货时间
    * - order_finish_time 订单完成时间
    * - order_id 订单 ID
    *
    * */
  private def orderFSMTimeDF: DataFrame = {
    spark.sql(
      """
        |select
        |  max(case
        |    when ofl.state_to = 'Canceled' then ofl.enter_time
        |  end) as order_cancel_time,
        |  max(case
        |    when ofl.event = 'Pay' then ofl.enter_time
        |  end) as order_pay_time,
        |  max(case
        |    when ofl.state_to = 'Returned' then ofl.enter_time
        |  end) as order_return_time,
        |  max(case
        |    when ofl.state_to = 'End' then ofl.enter_time
        |  end) as order_finish_time,
        |  ofl.object_id as order_id
        |from tgou_order_fsm_log ofl
        |group by ofl.object_id
      """.stripMargin)
  }

  /**
    * 获取订单尚品
    *
    * @return
    *
    * - brand_id 品牌 ID
    * - level_one_category_code 一级分类编码
    * - level_two_category_code 二级分类编码
    * - level_three_category_code 三级分类编码
    * - level_four_category_code 四级分类编码
    * - product_id 商品 ID
    *
    * */
  private def orderProductDF: DataFrame = {
    spark.sql(
      """
        |select
        |  p.id as product_id,
        |  p.fk_brand_id as brand_id,
        |  c.level_one_category_code,
        |  c.level_two_category_code,
        |  c.level_three_category_code,
        |  c.level_four_category_code
        |from product p
        |join (
        |  select
        |    c1.code as level_one_category_code,
        |    c2.code as level_two_category_code,
        |    c3.code as level_three_category_code,
        |    c4.code as level_four_category_code,
        |    c4.id as category_id
        |  from category c4
        |  join category c3
        |  on substr(c4.code, 0, 6) = c3.code
        |  join category c2
        |  on substr(c4.code, 0, 4) = c2.code
        |  join category c1
        |  on substr(c4.code, 0, 2) = c1.code
        |) c
        |on p.fk_category_id = c.category_id
      """.stripMargin)
  }

  private def orderStoreDF: DataFrame = {
    spark.sql(
      """
        |select
        |  s.id as store_id,
        |  sa.fk_city_id as city_id,
        |  s.fk_area_id as area_id,
        |  case
        |    when s.type = '1' then 'MALL'
        |    when s.type = '2' then 'MARKET'
        |    when s.type = '3' then 'OVERSEA'
        |    when s.type = '4' and s.is_international = '1' then 'OVERSEA'
        |    when s.type = '4' and s.is_international = '0' then 'SUPPLIER'
        |  end as source
        |from store s
        |left join store_address sa
        |on s.id = sa.fk_store_id
        |and sa.type = 0
      """.stripMargin)
  }

  def run(): Unit = {
    /*
     * 加载临时表
     * */
    tgouOrderSource.getODSOrderItemDF().createOrReplaceTempView("order_item")
    tgouOrderSource.getODSTgouOrderDF().createOrReplaceTempView("tgou_order")
    tgouOrderSource.getODSOrderAmountDF().createOrReplaceTempView("order_amount")
    tgouOrderSource.getODSReturnRequestDF().createOrReplaceTempView("return_request")
    tgouOrderSource.getODSTgouOrderFSMLogDF().createOrReplaceTempView("tgou_order_fsm_log")
    tgouOrderSource.getODSPaymentDF().createOrReplaceTempView("payment")
    tgouOrderSource.getODSOrderPreferentialDF().createOrReplaceTempView("order_preferential")

    itemSource.getODSProductDF().createOrReplaceTempView("product")
    itemSource.getODSCategoryDF().createOrReplaceTempView("category")

    baseSource.getODSStoreDF().createOrReplaceTempView("store")
    baseSource.getODSStoreAddress().createOrReplaceTempView("store_address")

    //关联订单品UBA表
    val oiuDF = spark.read.json("/data/tgdw/order_item_uba/*/*")
    oiuDF.persist(StorageLevel.MEMORY_AND_DISK).createOrReplaceTempView("order_item_uba")

    /*
     * 预处理
     * */
    historyOrderAmountDF.createOrReplaceTempView("history_order_amount")
    orderAmountDF.createOrReplaceTempView("order_amount")
    orderReturnAmountDF.createOrReplaceTempView("order_return_amount")
    orderFSMTimeDF.createOrReplaceTempView("order_fsm_time")
    orderProductDF.createOrReplaceTempView("order_product")
    orderStoreDF.createOrReplaceTempView("order_store")

    val oifDF = spark.sql(
      s"""
        |select
        |  oi.*
        |from (
        |select
        |  oi.id as order_item_id,
        |  oi.fk_tgou_order_id as order_id,
        |  oi.sku_id as sku_id,
        |  oi.price,
        |  oi.quantity,
        |  nvl(oa.order_amount, 0.0) as order_amount,
        |  nvl(oa.order_cash_amount, 0.0) as order_cash_amount,
        |  nvl(oa.order_points, 0.0) as order_points,
        |  nvl(oa.order_tax, 0.0) as order_tax,
        |  nvl(oa.order_shipping_costs, 0.0) as order_shipping_costs,
        |  nvl(oa.order_coupon_amount, 0.0) as order_coupon_amount,
        |  nvl(oa.order_activity_amount, 0.0) as order_activity_amount,
        |  nvl(ora.order_return_amount, 0.0) as order_return_amount,
        |  o.total_amount as order_net_sales_amount,
        |  (oa.order_amount + nvl(oa.order_tax, 0.0) + nvl(oa.order_shipping_costs, 0.0)) as order_actual_sales_amount,
        |  (case
        |    when substr(o.fixed_tags, 0, 1) = '0' then 'PRODUCT'
        |    else 'COUPON'
        |  end) as order_type,
        |  o.fixed_tags as order_origin_fixed_tags,
        |  o.state as order_state,
        |  o.create_time as order_create_time,
        |  oft.order_cancel_time,
        |  coalesce(oft.order_pay_time, o.ship_time) as order_pay_time,
        |  o.ship_time as order_ship_time,
        |  oft.order_return_time,
        |  oft.order_finish_time,
        |  (case
        |    when substr(o.pay_method, 0, 2) = '00' then 'OFFLINE'
        |    when o.pay_method = '010' then 'NOT_PAY'
        |    when substr(o.pay_method, 0, 2) = '10' then 'DASHANG_CARD'
        |    when substr(o.pay_method, 0, 2) = '20' then 'POS'
        |    when substr(o.pay_method, 0, 2) = '30' then 'WECHAT'
        |    when substr(o.pay_method, 0, 2) = '50' then 'APPLE'
        |    when substr(o.pay_method, 0, 2) = '60' then 'ALIPAY'
        |    when substr(o.pay_method, 0, 2) = '90' then 'TIANGOU'
        |    else 'OTHER'
        |  end) as order_pay_method,
        |  o.pay_method as order_origin_pay_method,
        |  (case
        |    when o.receive_type = '00' or o.receive_type = '01' or o.receive_type = '02' then 'SELF_PICKUP'
        |    when o.receive_type = '10' then 'LOGISTICS'
        |    when o.receive_type = '99' then 'VIRTUAL'
        |    else 'OTHER'
        |  end) as order_delivery_method,
        |  oi.activity_to_product_id as item_id,
        |  oi.product_id,
        |  (case
        |    when substr(o.fixed_tags, 0, 1) = '0' then op.brand_id
        |    else null
        |  end) as brand_id,
        |  (case
        |    when substr(o.fixed_tags, 0, 1) = '0' then op.level_one_category_code
        |    else null
        |  end) as level_one_category_code,
        |  (case
        |    when substr(o.fixed_tags, 0, 1) = '0' then op.level_two_category_code
        |    else null
        |  end) as level_two_category_code,
        |  (case
        |    when substr(o.fixed_tags, 0, 1) = '0' then op.level_three_category_code
        |    else null
        |  end) as level_three_category_code,
        |  (case
        |    when substr(o.fixed_tags, 0, 1) = '0' then op.level_four_category_code
        |    else null
        |  end) as level_four_category_code,
        |  o.store_id,
        |  os.city_id,
        |  os.area_id,
        |  os.source,
        |  o.fk_member_id as member_id
        |from order_item oi
        |join tgou_order o
        |on oi.fk_tgou_order_id = o.id
        |and o.create_time >= '${Application.HISTORY_ORDER_START_TIME}'
        |and o.create_time <= '${Application.HISTORY_ORDER_END_TIME}'
        |and (length(o.fixed_tags) < 8 or (length(o.fixed_tags) >= 8 and substr(o.fixed_tags, 8, 1) = '0'))
        |left join history_order_amount oa
        |on oi.fk_tgou_order_id = oa.order_id
        |left join order_return_amount ora
        |on oi.fk_tgou_order_id = ora.order_id
        |left join order_fsm_time oft
        |on oi.fk_tgou_order_id = oft.order_id
        |left join order_product op
        |on oi.product_id = op.product_id
        |left join order_store os
        |on o.store_id = os.store_id
        |union
        |select
        |  oi.id as order_item_id,
        |  oi.fk_tgou_order_id as order_id,
        |  oi.sku_id as sku_id,
        |  oi.price,
        |  oi.quantity,
        |  nvl(oa.order_amount, 0.0) as order_amount,
        |  nvl(oa.order_cash_amount, 0.0) as order_cash_amount,
        |  nvl(oa.order_points, 0.0) as order_points,
        |  nvl(oa.order_tax, 0.0) as order_tax,
        |  nvl(oa.order_shipping_costs, 0.0) as order_shipping_costs,
        |  nvl(oa.order_coupon_amount, 0.0) as order_coupon_amount,
        |  nvl(oa.order_activity_amount, 0.0) as order_activity_amount,
        |  nvl(ora.order_return_amount, 0.0) as order_return_amount,
        |  o.total_amount as order_net_sales_amount,
        |  (oa.order_amount + nvl(oa.order_tax, 0.0) + nvl(oa.order_shipping_costs, 0.0)) as order_actual_sales_amount,
        |  (case
        |    when substr(o.fixed_tags, 0, 1) = '0' then 'PRODUCT'
        |    else 'COUPON'
        |  end) as order_type,
        |  o.fixed_tags as order_origin_fixed_tags,
        |  o.state as order_state,
        |  o.create_time as order_create_time,
        |  oft.order_cancel_time,
        |  coalesce(oft.order_pay_time, o.ship_time) as order_pay_time,
        |  o.ship_time as order_ship_time,
        |  oft.order_return_time,
        |  oft.order_finish_time,
        |  (case
        |    when substr(o.pay_method, 0, 2) = '00' then 'OFFLINE'
        |    when o.pay_method = '010' then 'NOT_PAY'
        |    when substr(o.pay_method, 0, 2) = '10' then 'DASHANG_CARD'
        |    when substr(o.pay_method, 0, 2) = '20' then 'POS'
        |    when substr(o.pay_method, 0, 2) = '30' then 'WECHAT'
        |    when substr(o.pay_method, 0, 2) = '50' then 'APPLE'
        |    when substr(o.pay_method, 0, 2) = '60' then 'ALIPAY'
        |    when substr(o.pay_method, 0, 2) = '90' then 'TIANGOU'
        |    else 'OTHER'
        |  end) as order_pay_method,
        |  o.pay_method as order_origin_pay_method,
        |  (case
        |    when o.receive_type = '00' or o.receive_type = '01' or o.receive_type = '02' then 'SELF_PICKUP'
        |    when o.receive_type = '10' then 'LOGISTICS'
        |    when o.receive_type = '99' then 'VIRTUAL'
        |    else 'OTHER'
        |  end) as order_delivery_method,
        |  oi.activity_to_product_id as item_id,
        |  oi.product_id,
        |  (case
        |    when substr(o.fixed_tags, 0, 1) = '0' then op.brand_id
        |    else null
        |  end) as brand_id,
        |  (case
        |    when substr(o.fixed_tags, 0, 1) = '0' then op.level_one_category_code
        |    else null
        |  end) as level_one_category_code,
        |  (case
        |    when substr(o.fixed_tags, 0, 1) = '0' then op.level_two_category_code
        |    else null
        |  end) as level_two_category_code,
        |  (case
        |    when substr(o.fixed_tags, 0, 1) = '0' then op.level_three_category_code
        |    else null
        |  end) as level_three_category_code,
        |  (case
        |    when substr(o.fixed_tags, 0, 1) = '0' then op.level_four_category_code
        |    else null
        |  end) as level_four_category_code,
        |  o.store_id,
        |  os.city_id,
        |  os.area_id,
        |  os.source,
        |  o.fk_member_id as member_id
        |from order_item oi
        |join tgou_order o
        |on oi.fk_tgou_order_id = o.id
        |and o.create_time >= '${Application.ORDER_START_TIME}'
        |and (length(o.fixed_tags) < 8 or (length(o.fixed_tags) >= 8 and substr(o.fixed_tags, 8, 1) = '0'))
        |left join order_amount oa
        |on oi.fk_tgou_order_id = oa.order_id
        |left join order_return_amount ora
        |on oi.fk_tgou_order_id = ora.order_id
        |left join order_fsm_time oft
        |on oi.fk_tgou_order_id = oft.order_id
        |left join order_product op
        |on oi.product_id = op.product_id
        |left join order_store os
        |on o.store_id = os.store_id
        |) oi
      """.stripMargin)
    oifDF.persist(StorageLevel.MEMORY_AND_DISK).createOrReplaceTempView("order_item_fact")

    val df = spark.sql(
      s"""
         |select
         |    oif.*,
         |    nvl(oiu.jr,"normal") as jr,
         |    nvl(oiu.global,"normal") as global,
         |    nvl(oiu.scp_scp,"normal") as scp,
         |    nvl(oiu.trace_id,"normal") as trace_id
         |from order_item_fact oif
         |left join order_item_uba oiu
         |on oif.order_item_id = oiu.order_item_id
         |and oif.order_id = oiu.order_id
       """.stripMargin)

    /*
     * 保存
     * */
    ODSSink.sink2Hive(df, appName)
  }

}
