package com.tgou.data.stanford.dw.order_item_fact

import com.google.inject.AbstractModule
import com.google.inject.name.Names
import com.tgou.data.stanford.dw.order_item_fact.source.{ItemSource, TgouOrderSource, BaseSource}
import com.tgou.data.stanford.dw.order_item_fact.source.impl.{ItemSourceImpl, TgouOrderSourceImpl, BaseSourceImpl}
import org.apache.spark.sql.SparkSession
import org.joda.time.LocalDate

/**
  * Created by 李震 on 2018/3/7.
  */
class ApplicationModule(spark: SparkSession, appName: String, date: LocalDate) extends AbstractModule {

  override def configure(): Unit = {
    bind(classOf[SparkSession]).toInstance(spark)
    bind(classOf[String]).annotatedWith(Names.named("appName")).toInstance(appName)
    bind(classOf[LocalDate]).toInstance(date)
    bind(classOf[TgouOrderSource]).to(classOf[TgouOrderSourceImpl])
    bind(classOf[BaseSource]).to(classOf[BaseSourceImpl])
    bind(classOf[ItemSource]).to(classOf[ItemSourceImpl])
  }

}
