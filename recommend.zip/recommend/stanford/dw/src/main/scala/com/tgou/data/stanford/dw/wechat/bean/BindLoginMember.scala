package com.tgou.data.stanford.dw.wechat.bean

import com.tgou.data.stanford.core.base.BaseBean

/**
  * Created by xinghailong on 2017/8/21.
  */
object BindLoginMember extends BaseBean {
  override def list: List[(Any,String)] = {
    List(
      (0, "id"),
      (1, "fk_member_id"),
      (2, "openid"),
      (3, "modify_time")
    )
  }
}
