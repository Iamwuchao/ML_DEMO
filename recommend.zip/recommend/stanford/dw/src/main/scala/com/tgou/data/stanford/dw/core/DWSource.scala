package com.tgou.data.stanford.dw.core

import org.apache.spark.sql.functions._
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.joda.time.LocalDate

/**
  * Created by 李震 on 2017/9/12.
  */
object DWSource {

  def getCompleteDF(spark: SparkSession, path: String, date: LocalDate, columns: Seq[String]): DataFrame = {
    var df: DataFrame = null

    for (year <- 2014 until date.getYear) {
      val dataPath = s"${path}/${year}"
      if (HDFS.exists(dataPath)) {
        val csvDF = spark.read
          .options(Map(
            "delimiter" -> "^",
            "nullValue" -> "\\N",
            "quote" -> ""
          ))
          .csv(dataPath + "/*/*")
        if (df != null) df = df.union(csvDF)
        else df = csvDF
      }
    }

    for (month <- 1 until date.getMonthOfYear) {
      val dataPath = s"${path}/${date.getYear}/${"%02d".format(month)}"
      if (HDFS.exists(dataPath)) {
        val csvDF = spark.read
          .options(Map(
            "delimiter" -> "^",
            "nullValue" -> "\\N",
            "quote" -> ""
          ))
          .csv(dataPath + "/*")
        if (df != null) df = df.union(csvDF)
        else df = csvDF
      }
    }

    for (day <- 1 to date.getDayOfMonth) {
      val dataPath = s"${path}/${date.getYear}/${"%02d".format(date.getMonthOfYear)}/${"%02d".format(day)}"
      if (HDFS.exists(dataPath)) {
        val csvDF = spark.read
          .options(Map(
            "delimiter" -> "^",
            "nullValue" -> "\\N",
            "quote" -> ""
          ))
          .csv(dataPath + "/*")
        if (df != null) df = df.union(csvDF)
        else df = csvDF
      }
    }

    if (df != null) df.toDF(columns: _*) else df
  }


  def getAppendDF(spark: SparkSession, path: String, date: LocalDate, columns: Seq[String]): DataFrame = {
    spark.read
      .options(Map(
        "delimiter" -> "^",
        "nullValue" -> "\\N",
        "quote" -> ""
      ))
      .csv(s"${path}/${date.toString("yyyy/MM/dd")}")
      .toDF(columns: _*)
  }


  def getUpdateDF(spark: SparkSession, path: String, date: LocalDate, primaryKey: Seq[String], timestamp: String, columns: Seq[String]): DataFrame = {
    val completeDF = getCompleteDF(spark, path, date, columns)
    completeDF.join(
      completeDF.groupBy(primaryKey.map(column): _*).agg(max(timestamp) as timestamp),
      primaryKey :+ timestamp
    )
  }

}
