package com.tgou.data.stanford.dw;

/**
 * Created by 李震 on 2018/3/9.
 */
public interface Constants {

    /*
     * Hive 数据库
     * */
    String DATABASE_TGOUORDER = "tgouorder";
    String DATABASE_ITEM = "item";
    String DATABASE_BASE = "base";

    /*
     * Hive 表
     * */

    // tgou_roder
    String TABLE_TGOU_ORDER = DATABASE_TGOUORDER + ".tgou_order";
    String TABLE_ORDER_ITEM = DATABASE_TGOUORDER + ".order_item";
    String TABLE_ORDER_AMOUNT = DATABASE_TGOUORDER + ".order_amount";
    String TABLE_RETURN_REQUEST = DATABASE_TGOUORDER + ".return_request";
    String TABLE_PAYMENT = DATABASE_TGOUORDER + ".payment";
    String TABLE_TGOU_ORDER_FSM_LOG = DATABASE_TGOUORDER + ".tgou_order_fsm_log";
    String TABLE_ORDER_PREFERENTIAL = DATABASE_TGOUORDER + ".order_preferential";

    // item
    String TABLE_PRODUCT = DATABASE_ITEM + ".product";
    String TABLE_CATEGORY = DATABASE_ITEM + ".category";

    // base
    String TABLE_STORE = DATABASE_BASE + ".store";
    String TABLE_STORE_ADDRESS = DATABASE_BASE + ".store_address";
}