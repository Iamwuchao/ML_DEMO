package com.tgou.data.stanford.test

import org.apache.spark.sql.SparkSession

/**
  * Created by xinghailong on 2017/9/12.
  */
object CSVTest {
  def main(args: Array[String]) {
    val spark = SparkSession.builder()
      .master("local")
      .appName("csv-test")
      .getOrCreate()

    // 日志级别
    spark.sparkContext.setLogLevel("WARN")

    val df = spark.read.option("delimiter","^").option("quote","").csv("C:\\Users\\xinghailong\\Desktop\\test.csv")
    df.show()

    spark.stop()
  }
}
