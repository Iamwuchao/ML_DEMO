package com.tgou.data.stanford.sirius.utils;

import com.alibaba.fastjson.JSONObject;
import org.apache.http.HttpResponse;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class IpWebUtils {

    public static void main(String[] args) {
        System.out.println(getCityByIpFromGaode("223.104.107.74","河南"));
    }

    private static final Map<String,String> cache = new ConcurrentHashMap<>();

    //QPS 是100，10次/day。需要限制QPS啊。
    //此处，如果出现问题，使得城市名称为 省份-其他 。
    //日均distinct的ip是4万左右。使用此方法的在4千左右。

    //key 1
    //12ce5d4ea4069086f0bec89619b2bfad
    //key 2
    //0dede0885590e061eb3f4795fc81440d
    //key 3
    //0a1e496e08b7570790eee1824b56f8e7
    public static String getCityByIpFromGaode(String ip, String country){
        String cacheCity = cache.get(ip);
        if(cacheCity!=null) return cacheCity;
        String city = "";
        try {
            String s = doGetFromGaode("http://restapi.amap.com/v3/ip?key=0a1e496e08b7570790eee1824b56f8e7&ip="+ip);
            JSONObject jsonObject = JSONObject.parseObject(s);
            city = jsonObject.getString("city");
            if(city != null && !city.trim().equals("") && city.lastIndexOf('市') + 1 == city.length()){
                city = city.substring(0,city.length()-1);
            }
            if(city.equals("[]")){
                city = "其他";
            }
        }catch (Exception e){
            e.printStackTrace();
            return null;
        }
        cache.put(ip,city);
        return city;
    }

    public static String getCityByIpFromGaode(String ip){
        try {
            String s = doGetFromGaode("http://restapi.amap.com/v3/ip?key=0dede0885590e061eb3f4795fc81440d&ip="+ip);
            JSONObject jsonObject = JSONObject.parseObject(s);
            String city  = jsonObject.getString("city");
            String country = jsonObject.getString("province");
            if(country != null && !country.trim().equals("") && country.lastIndexOf('省') + 1 == city.length()){
                country = country.substring(0,country.length()-1);
            }
            if(city != null && !city.trim().equals("") && city.lastIndexOf('市') + 1 == city.length()){
                city = city.substring(0,city.length()-1);
            }
            if(city.equals("[]")){
                city =  "其他";
            }
            return city;
        }catch (Exception e){
            e.printStackTrace();
        }
       return null;
    }

    //qps太低，暂时放弃
    public static String getCityByIpFromTaoBao(String ip, String country){
        String cacheCity = cache.get(ip);
        if(cacheCity!=null) return cacheCity;
        String city = null;
        String s = doGetFromTaoBao("http://ip.taobao.com/service/getIpInfo.php?ip="+ip);
        try {
            if(s!=null){
                JSONObject jsonObject = JSONObject.parseObject(s);
                if(jsonObject.getJSONObject("data")!=null){
                    city = jsonObject.getJSONObject("data").getString("city");
                }
                if(city != null && !city.trim().equals("") && city.lastIndexOf('市') + 1 == city.length()){
                    city = city.substring(0,city.length()-1);
                }
            }
        }catch (Exception e){
            e.printStackTrace();
        }finally {
            if(city == null){
                city = "其他";
            }
        }
        cache.put(ip,city);
        return city;
    }

    public static String doGetFromTaoBao(String path) {
        String inputline="";
        String info="";
        try  {
            URL url = new URL(path);
            HttpURLConnection conn = (HttpURLConnection)url.openConnection();
            conn.setReadTimeout(15*1000);//时间尽量的短
            conn.setRequestMethod("GET");
            InputStreamReader  inStream = new InputStreamReader(conn.getInputStream(),"UTF-8");
            BufferedReader buffer=new BufferedReader(inStream);

            while((inputline=buffer.readLine())!=null){
                info+=inputline;
            }
        }catch (MalformedURLException e) {
            e.printStackTrace();
        }catch (IOException e) {
            e.printStackTrace();
        }
        return info;
    }

    public static String doGetFromGaode(String url){
        RequestConfig httpParams = RequestConfig.custom().setConnectTimeout(1000).setSocketTimeout(1000*3).build();
        HttpGet get = new HttpGet(url);
        String result = "";
        try( CloseableHttpClient client = HttpClientBuilder.create().setDefaultRequestConfig(httpParams).build()) {
            // 发送请求
            HttpResponse httpResponse = client.execute(get);
            // 获取响应输入流
            InputStream inStream = httpResponse.getEntity().getContent();
            BufferedReader reader = new BufferedReader(new InputStreamReader(
                    inStream, "utf-8"));
            StringBuilder strber = new StringBuilder();
            String line = null;
            while ((line = reader.readLine()) != null)
                strber.append(line);
            inStream.close();
            result = strber.toString();
        } catch (Exception e) {
            System.out.println("请求异常");
            throw new RuntimeException(e);
        }
        return result;
    }
}
