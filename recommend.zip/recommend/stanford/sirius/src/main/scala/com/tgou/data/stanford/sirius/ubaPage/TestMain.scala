package com.tgou.data.stanford.sirius.ubaPage

import java.time.LocalDate

import scala.util.Success

object TestMain {
  def main(args: Array[String]): Unit = {
    def str2date(str: String): LocalDate= {
      scala.util.Try(str.toInt) match {
        case Success(_) => LocalDate.now().plusDays(str.toInt);
        case _ => LocalDate.parse(str)
      }
    }
    val dateBegin = str2date("2017-12-30").toEpochDay- str2date("0").toEpochDay
    val dateEnd = str2date("-1").toEpochDay- str2date("0").toEpochDay
    println(LocalDate.now().toString.replace("-","/"))
    println(dateEnd)
  }
}
