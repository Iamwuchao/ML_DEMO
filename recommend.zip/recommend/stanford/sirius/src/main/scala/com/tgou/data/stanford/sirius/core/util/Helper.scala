package com.tgou.data.stanford.sirius.core.util

import com.tgou.data.stanford.sirius.core.BaseSchema
import com.tgou.data.stanford.sirius.core.constants.EventEnum.pageMap

object Helper {

  def main(args: Array[String]): Unit = {
    println(getEventInsertSql())
  }

  /**
    * 插入到Mysql的SQL语句。
    * @return
    */
  def getEventInsertSql(): String = {
    val values = pageMap.keySet.map(key =>{
      val e = pageMap(key)
      var tmpText =
        s"""
           | (null,'${e.eventId}','${e.buckId}','1','${e.name}','${e.name}','浏览','${e.name}','0',NOW(),NOW())
        """.stripMargin
      tmpText
    }).mkString(",")

    var sqlText =
      s"""
         | INSERT INTO `event` VALUES
         |  $values
      """.stripMargin
    sqlText
  }

  /**
    * 需要手动修改time 的 type为‘日期’
    * @return
    */
  def getPropertyInsertSql(): String = {
    BaseSchema.columns
      .map(t =>{
//
//        val
//        s
      })
    ""
//    for (columns <- BaseSchema.columns) {
//      val columnName = columns._1
//      columns._2 match {
//        case "INT"    => fieldDelareList += s"${columnName} INT"
//        case "BIGINT" => fieldDelareList += s"${columnName} BIGINT"
//        case "DOUBLE" => fieldDelareList += s"${columnName} DOUBLE"
//        case "BOOLEAN"=> fieldDelareList += s"${columnName} BOOLEAN"
//        case "STRING" => fieldDelareList += s"${columnName} STRING"
//        case _        => fieldDelareList += s"${columnName} STRING"
//      }
//    }
//    val fieldDeclare = fieldDelareList.mkString(",")
  }
}
