package com.tgou.data.stanford.sirius.ubaPage.eventParser
import com.tgou.data.stanford.sirius.core.constants.UbaGlobalEnum
import com.tgou.data.stanford.sirius.ubaPage.bean.{PageEvent, UbaPage}
import org.apache.commons.lang.StringUtils

object Parser{

  def getEvent(eventId: Int, bucketId: Int,events: Array[UbaPage]): PageEvent = {
    commonExecute(events(0), eventId, bucketId)
  }

  def commonExecute(ubaPage: UbaPage, eventId: Int, bucketId: Int): PageEvent ={

    PageEvent(
      event_id = eventId,
      bucket_id = bucketId,
      member_id = black2Null(ubaPage.member_id),
      uuid = black2Null(ubaPage.uuid),
      session_id = black2Null(ubaPage.session_id),
      page = {
        black2Null(ubaPage.a_b)
      },
      geo_province = null,
      geo_city = null,
      global = UbaGlobalEnum.getValue(ubaPage.global),
      jr = black2Null(ubaPage.jr.toLowerCase),
      time = {
        ubaPage.time
      },
      item_id = IntOrNull(getBk(ubaPage.bk,1)),
      item_type = black2Null(getBk(ubaPage.bk,0)),
      ubaPage.is_new_guest,
      ubaPage.is_out,
      is_quit = ubaPage.is_quit,
      scp_abc = black2Null(splitScp(ubaPage.scp)),
      scp = black2Null(ubaPage.scp),
      ip = black2Null(ubaPage.ip),
      url = black2Null(ubaPage.orgin)//clean it
    )
  }

  def getBk(oldBk: String,index :Int):String = {
    if(StringUtils.isBlank(oldBk) || oldBk.split("\\-").length < 2){
      ""
    }else{
      try{
        val splits = oldBk.toLowerCase.split("\\-")
        splits(index)
      }
      catch {
        case e: Exception => throw new RuntimeException(e)
      }
    }
  }

  def main(args: Array[String]): Unit = {
    println(IntOrNull("23432_asd"))
  }

  def IntOrNull(value: String): Int ={
    if(value.trim.equals("")){
      null.asInstanceOf[Int]
    }else{
      try value.toInt catch {
        case e: Exception => null.asInstanceOf[Int]
      }
    }
  }

  def black2Null(value: String): String = {
    if(value.trim.equals("")){
      null
    }else{
      value
    }
  }
  def splitScp(scp: String): (String) = {
    if(StringUtils.isBlank(scp) || scp == "undefined" || scp.split("\\.").length < 3){
      ""
    }else{
      try{
        val splits = scp.toLowerCase.split("\\.")
        //包含bk
        val a = splits(0)
        val b = splits(1)
        val c = splits(2)
        val a_b_c = a+"."+b+"."+c
        a_b_c
      }
      catch {
        case e: Exception => throw new RuntimeException(e)
      }
    }
  }
}
