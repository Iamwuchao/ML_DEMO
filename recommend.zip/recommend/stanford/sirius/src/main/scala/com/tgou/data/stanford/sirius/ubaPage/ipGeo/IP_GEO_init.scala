package com.tgou.data.stanford.sirius.ubaPage.ipGeo

import java.io.IOException
import java.net.URI

import com.tgou.data.stanford.sirius.core.constants.EventEnum
import com.tgou.data.stanford.sirius.utils.{IpUtils, IpWebUtils}
import org.apache.hadoop.conf.Configuration
import org.apache.hadoop.fs.{FileSystem, Path}
import org.apache.spark.sql.{Dataset, SaveMode, SparkSession}
import org.joda.time.LocalDate

object IP_GEO_init {

  def execute(spark: SparkSession, dateBegin: Int, dateEnd: Int):Unit = {
    //loadData
    val nameNode = "hdfs://hnode1:8020"
    import spark.implicits._

    //load page_data
    var pageEventIPToCalDs: Dataset[IP] = {
      (dateBegin to dateEnd).map(day => {
        spark.read.parquet(nameNode + "/dw/data/uba_page/his_time=" +  LocalDate.now().plusDays(day))
          .select("ip")}).reduce(_.union(_))
    }.distinct().as[IP]
    pageEventIPToCalDs.createTempView("new_ip")

    //找到历史没有定位过的IP。进行GEO化
    val sqlText =  """
        | select ip from new_ip
      """.stripMargin

    val newIpDs = spark.sql(sqlText).as[IP].map(row=>{
      loadFileFromHDFS
      val geoLocal = IpUtils.findSafe(row.ip)
      var geoCountry: String = ""
      //如果是城市为空的，使用WEB API进行查询。
      var geoCity: String = ""
      var version = 2
      if(!geoLocal(0).equals("中国")){
        geoCountry="其他"
        geoCity="其他"
        version = 1
      }else{
        geoCountry = geoLocal(1)
        geoCity = {
          if(geoLocal(2) == null || geoLocal(2).trim.equals("")){
            IpWebUtils.getCityByIpFromGaode(row.ip,geoLocal(1))
          }else {
            geoLocal(2)
          }
        }
      }
      if(geoCity == null || geoCity.equals("")){
        //这类是高德地图也没算对的情况。
        version = 1
        geoCity = "其他"
      }
      IPWithGeo(row.ip,geoCountry,geoCity,version)
    })
    newIpDs.write.mode(SaveMode.Overwrite).parquet(nameNode + EventEnum.Ip2GeoPath)
  }

  def loadFileFromHDFS(){
    val dataPath = EventEnum.IpDatPath
    val conf = new Configuration
    conf.setBoolean("dfs.support.append", true)
    try {
      var fs  = FileSystem.get(URI.create(dataPath), conf)
      IpUtils.testAndLoad(fs.open(new Path(dataPath)))
    } catch {
      case e: IOException =>
        e.printStackTrace()
    }
  }

  def main(args: Array[String]): Unit = {
    System.setProperty("hive.metastore.uris", "thrift://hnode1:9083")
    var builder = SparkSession.builder()

    var dateBegin = -1
    var dateEnd = -1

    if(args == null || args.length == 0){
      builder = builder.master("local")
    }else{
      dateBegin = args(1).toInt
      dateEnd = args(2).toInt
    }

    val spark = builder
      .appName("IP_GEO")
      .enableHiveSupport()
      .getOrCreate()

    spark.sparkContext.setLogLevel("WARN")
    try {
        execute(spark,dateBegin ,dateEnd)
    } catch {
      case e: Exception => throw new RuntimeException(e)
    } finally {
      spark.close()
    }
  }

}
