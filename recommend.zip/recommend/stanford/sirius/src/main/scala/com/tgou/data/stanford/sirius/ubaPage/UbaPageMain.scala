package com.tgou.data.stanford.sirius.ubaPage

import java.time.LocalDate

import com.tgou.data.stanford.sirius.core.constants.EventEnum
import com.tgou.data.stanford.sirius.core.util.HiveUtils
import com.tgou.data.stanford.sirius.ubaPage.bean.{PageEvent, UbaPage}
import com.tgou.data.stanford.sirius.ubaPage.eventParser.Parser
import org.apache.spark.sql.{Dataset, SaveMode, SparkSession}

import scala.util.Success


//需要保证 IP_GEO执行成功。否则geo_city，geo_country无法解析。
object UbaPageMain {

  def execute(spark: SparkSession, date: LocalDate):Unit = {
    //loadData
    val nameNode = "hdfs://nameservice1:8020"
    import spark.implicits._
    val pageEventDs:Dataset[PageEvent] = spark.read.parquet(nameNode + "/dw/data/uba_page/his_time=" + date)
        .select("a_b","agent","global","ip","bk","is_new_guest","is_out","is_quit","jr","member_id","page","scp","session_id","stay_time","time","uuid","orgin")
        .filter("a_b != '' and a_b != '*.*'")
        .as[UbaPage]
        .map(transfer)

    pageEventDs.createOrReplaceTempView("events")
    spark.read.parquet(EventEnum.Ip2GeoPath).createOrReplaceTempView("ip_db")
    val sqlText =
      """
        | SELECT
        | o.event_id,
        | o.bucket_id,
        | o.member_id,
        | o.uuid,
        | o.session_id,
        | o.page,
        | f.geo_country as geo_province,
        | CASE WHEN f.geo_city IS NULL AND f.geo_country is not NULL THEN concat(f.geo_country,'-其他') ELSE f.geo_city END AS geo_city,
        | o.global,
        | o.jr,
        | o.time,
        | o.item_id,
        | o.item_type,
        | o.is_new_guest,
        | o.is_out,
        | o.is_quit,
        | o.scp_abc,
        | o.scp,
        | o.ip,
        | o.url
        | FROM events o
        | LEFT JOIN ip_db f
        | on o.ip = f.ip
        | order by o.time
      """.stripMargin
    val pageEventResultDs = spark.sql(sqlText)

    //save to path
    pageEventResultDs.write.partitionBy("bucket_id").mode(SaveMode.Overwrite).parquet(EventEnum.PageEventPath+"/his_time=" + date)

    //build Partition
    EventEnum.getPageBuckets()
      .foreach(bucket =>
        spark.sql(HiveUtils.generateAddPartitionSQL("events", "page_event", date.toString(), bucket.toString))
      )
    //end
  }

  def transfer(ubaPage:UbaPage) : PageEvent = {
    var page =  ubaPage.page.toLowerCase.split('-')(0)
    if(!EventEnum.pageMap.contains(page)){
      page = "other"
    }
    val baseEvent = EventEnum.pageMap(page)
    Parser.getEvent(baseEvent.eventId, baseEvent.buckId,Array(ubaPage))
  }

  def main(args: Array[String]): Unit = {
    System.setProperty("hive.metastore.uris", "thrift://hnode1:9083")
    var builder = SparkSession.builder()

    var dateBegin = LocalDate.now().plusDays(-1)
    var dateEnd = LocalDate.now().plusDays(-1)

    def str2date(str: String): LocalDate= {
      scala.util.Try(str.toInt) match {
        case Success(_) => LocalDate.now().plusDays(str.toInt);
        case _ => LocalDate.parse(str)
      }
    }

    if(args == null || args.length == 0){
      builder = builder.master("local")
    }else{
      dateBegin = str2date(args(1))
      dateEnd = str2date(args(2))
    }


    val spark = builder
      .appName("Event--SCP")
      .enableHiveSupport()
      .getOrCreate()

    spark.sparkContext.setLogLevel("WARN")
    try {
      var date = LocalDate.now().plusDays(-1)
      while (!dateBegin.isAfter(dateEnd)){
        date = dateBegin
        dateBegin = dateBegin.plusDays(1)
        execute(spark,date)
      }
    } catch {
      case e: Exception => throw new RuntimeException(e)
    } finally {
      spark.close()
    }
  }

}
