package com.tgou.data.stanford.sirius.ubaPage.bean

case class UbaPage (
                     a_b: String,
                     agent: String,
                     global: String,
                     ip: String,
                     bk: String,
                     is_new_guest: Boolean,
                     is_out: Boolean,
                     is_quit: Boolean,
                     jr: String,
                     member_id: String,
                     page: String,
                     scp: String,
                     session_id: String,
                     stay_time: BigInt,
                     time: String,
                     uuid: String,
                     orgin: String
                   ){}
