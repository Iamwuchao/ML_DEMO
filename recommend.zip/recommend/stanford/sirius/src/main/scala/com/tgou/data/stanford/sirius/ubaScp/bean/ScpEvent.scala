package com.tgou.data.stanford.sirius.ubaScp.bean

case class ScpEvent (

                    ){

}
