package com.tgou.data.stanford.sirius.ubaPage.bean

case class PageEvent(
                    /**
                      * see [[com.tgou.data.stanford.sirius.core.constants.EventEnum.pageMap]]
                      */
                    event_id: Int,
                    bucket_id:Int,
                    member_id: String,
                    uuid: String,
                    session_id: String,
                    page: String,
                    geo_province: String,
                    geo_city: String,
                    /**
                      * see [[com.tgou.data.stanford.sirius.core.constants.UbaGlobalEnum]]
                      */
                    global: Int,
                    jr: String,
                    time: String,
                    item_id: Int,
                    item_type: String,
                    is_new_guest: Boolean,
                    is_out: Boolean,
                    is_quit: Boolean,
                    scp_abc: String,
                    scp: String,
                    ip: String,
                    url: String
                    ){}
