package com.tgou.data.stanford.sirius.core.util

import java.time.{LocalDate, LocalDateTime}
import java.time.format.DateTimeFormatter

import com.tgou.data.stanford.sirius.core.BaseSchema
import com.tgou.data.stanford.sirius.core.constants.EventEnum

import scala.collection.mutable

//需要进行人肉运维的。有点费劲的啊。
object HiveUtils {
  def main(args: Array[String]): Unit = {
    println(generateCreateTableSQL(EventEnum.EventPath,"events"))
//    println(generateAddPartitionSQL("events","2017-12-10","1"))
  }

  def parseLocalDate(date: String, format: String): LocalDate = {
    val formatter = DateTimeFormatter.ofPattern(format)
    LocalDate.parse(date, formatter)
  }

  def formatLocalDateTime(dateTime: LocalDateTime, format: String): String = {
    val formatter = DateTimeFormatter.ofPattern(format)
    dateTime.format(formatter)
  }

  def formatLocalDate(dateTime: LocalDate, format: String): String = {
    val formatter = DateTimeFormatter.ofPattern(format)
    dateTime.format(formatter)
  }

  def convertPathDateToISODate(date: String): String = {
    val localDate = LocalDate.parse(date, DateTimeFormatter.ofPattern("yyyy/MM/dd"))
    formatLocalDate(localDate, "yyyy-MM-dd")
  }


  def generateCreateTableSQL(path:String, tableName: String): String = {

    var fieldDelareList = mutable.MutableList[String]()

    for (columns <- BaseSchema.columns) {
      val columnName = columns._1
      columns._2 match {
        case "INT"    => fieldDelareList += s"${columnName} INT"
        case "BIGINT" => fieldDelareList += s"${columnName} BIGINT"
        case "DOUBLE" => fieldDelareList += s"${columnName} DOUBLE"
        case "BOOLEAN"=> fieldDelareList += s"${columnName} BOOLEAN"
        case "STRING" => fieldDelareList += s"${columnName} STRING"
        case _        => fieldDelareList += s"${columnName} STRING"
      }
    }
    val fieldDeclare = fieldDelareList.mkString(",")

    s"""
       |CREATE EXTERNAL TABLE IF NOT EXISTS sirius.${tableName}
       |(
       |  ${fieldDeclare}
       |)
       |PARTITIONED BY (type STRING, his_time STRING, bucket_id STRING)
       |STORED AS PARQUET
       |LOCATION '${path}'
     """.stripMargin
  }

  def generateAddPartitionSQL(tableName:String,eventType: String, date: String, bucketId: String): String = {
    s"""
       |ALTER TABLE sirius.${tableName} ADD IF NOT EXISTS PARTITION (type='${eventType}',his_time='${date}',bucket_id = '${bucketId}')
     """.stripMargin
  }
}
