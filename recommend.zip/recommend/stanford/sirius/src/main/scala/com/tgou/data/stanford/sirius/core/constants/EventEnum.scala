package com.tgou.data.stanford.sirius.core.constants

/**
  *
  * @param eventId
  * @param buckId
  * @param name
  */
case class BaseEvent(eventId: Int, buckId :Int, name: String){

}

object EventEnum {
  val EventPath: String = "/data/sirius/events"
  val PageEventPath: String = EventPath + "/type=page_event"
  val ScpEventPath: String = EventPath + "/type=scp_event"
  val Ip2GeoPath: String = "/data/sirius/ip_geo"
  val IpDatPath: String = "/app/sirius/17monipdb.dat"


  val scpMap: Map[String, BaseEvent] = Map(
    "01"     ->      BaseEvent(101,101,"发现频道"),
    "0301"   ->      BaseEvent(101,109,"试衣秀"),
    "10"     ->      BaseEvent(102,102,"下单流程"),
    "02"     ->      BaseEvent(103,103,"购物"),
    "14"     ->      BaseEvent(104,104,"新购物"),
    "06"     ->      BaseEvent(105,105,"全球购"),
    "12"     ->      BaseEvent(106,106,"活动"),
    "07"     ->      BaseEvent(106,107,"搜索"),
    "04"     ->      BaseEvent(106,108,"优惠券"),
    "05"     ->      BaseEvent(107,110,"我的"),
    "other"  ->      BaseEvent(100,100,"其他浏览行为")
  )

  def getScpBuckets(): Set[Int] = {
    var result = scala.collection.mutable.Set[Int]()
    for(events <- scpMap.values){
      result+=events.buckId
    }
    result.toSet
  }

  val pageMap: Map[String, BaseEvent] = Map(
    "14.sp"                ->             BaseEvent(6,2,"购物页"),
    "02.sp"                ->             BaseEvent(6,2,"购物页"),
    "14.bddirect"          ->             BaseEvent(7,2,"品牌直供页"),
    "14.bdflagship"        ->             BaseEvent(8,2,"品牌旗舰店页"),
    "06.seaamoy"           ->             BaseEvent(9,2,"全球购首页"),
    "02.dd"                ->             BaseEvent(10,3,"百货逛商场"),
    "02.sd.counter"        ->             BaseEvent(11,3,"专柜首页"),
    "02.csign"             ->             BaseEvent(12,3,"专柜导视"),
    "08.smc"               ->             BaseEvent(12,3,"超市逛商场"),
    "07.dsrlt"             ->             BaseEvent(13,3,"专柜搜索结果页"),
    "07.asrlt"             ->             BaseEvent(14,3,"单品搜索结果页"),
    "07.search"            ->             BaseEvent(15,2,"全球购搜索首页"),
    "07.brand.brand"       ->             BaseEvent(16,2,"全球购品牌搜索页"),
    "07.class"             ->             BaseEvent(17,2,"全球购分类搜索页"),
    "10.pd.item"           ->             BaseEvent(18,4,"单品详情页"),
    "10.shopcar"           ->             BaseEvent(19,4,"购物车页"),
    "10.conmorder"         ->             BaseEvent(20,4,"确认订单页"),
    "10.payment.order"     ->             BaseEvent(21,4,"支付结果页"),
    "12.actpro"            ->             BaseEvent(22,5,"活动商品聚合页"),
    "12.1.activity"        ->             BaseEvent(23,5,"常规活动"),
    "12.4.activity"        ->             BaseEvent(24,5,"限时抢活动页"),
    "12.6"                 ->             BaseEvent(25,5,"限时抢购"),
    "12.7"                 ->             BaseEvent(26,5,"品牌限时抢购"),
    "03.tc"                ->             BaseEvent(27,6,"收藏列表"),
    "03.tdt"               ->             BaseEvent(28,6,"收藏间详情"),
    "04.1"                 ->             BaseEvent(29,6,"优惠券列表"),
    //fake other。这几个Page的访问量也是很大。
    "05.1"                 ->             BaseEvent(1,1,"我的天狗"),
    "05.mi"                ->             BaseEvent(1,1,"我的天狗"),
    "05.01"                ->             BaseEvent(1,1,"我的天狗"),
    "05.mbrct"             ->             BaseEvent(3,1,"我的会员卡"),
    "01.log"               ->             BaseEvent(4,1,"登陆页"),
    "01.star"              ->             BaseEvent(5,1,"通用弹窗下载"),
    "other"                ->             BaseEvent(0,0,"其他浏览行为")
  )

  def getPageBuckets(): Set[Int] = {
    var result = scala.collection.mutable.Set[Int]()
    for(events <- pageMap.values){
      result+=events.buckId
    }
    result.toSet
  }
}

object UbaGlobalEnum extends Enumeration{
  type UbaGlobalEnum = Value

  val android = Value(1,"android")
  val ios = Value(2,"ios")
  val weChat = Value(3,"wechat")
  val webApp = Value(4,"webapp")
  val alipayClient = Value(5,"AlipayClient")
  val others = Value(6,"others")

  def getValue(global: String): Int = {
    for(s <- UbaGlobalEnum.values){
      if(s.toString.equals(global)){
        return UbaGlobalEnum.withName(global).id
      }
    }
    UbaGlobalEnum.others.id
  }
}