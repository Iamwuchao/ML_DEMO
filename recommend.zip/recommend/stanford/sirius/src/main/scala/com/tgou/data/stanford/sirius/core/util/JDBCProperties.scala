package com.tgou.data.stanford.sirius.core.util
import java.util.Properties
import scala.io.Source

object JDBCProperties {
  val file = "sirius/src/main/resources/jdbc.properties"

  def getProperties():Properties ={
    val jDBCProperties = new Properties()
    jDBCProperties.load(Source.fromFile(file).reader())
    jDBCProperties
  }

}
