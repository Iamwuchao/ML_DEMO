package com.tgou.data.stanford.sirius.core

/**
  * sirius表的schema。不同的action_type都使用这个schema。
  */
object BaseSchema {
  val columns = Seq(
    ("event_id","INT"),
    ("member_id","STRING"),
    ("uuid","STRING"),
    ("session_id","STRING"),
    ("page","STRING"),
    ("geo_province","STRING"),
    ("geo_city","STRING"),
    ("global","INT"),
    ("jr","STRING"),
    ("time","STRING"),
    ("item_id","INT"),
    ("item_type","STRING"),
    ("is_new_guest","BOOLEAN"),
    ("is_out","BOOLEAN"),
    ("is_quit","BOOLEAN"),
    ("ip","STRING"),
    ("url","STRING")
  )
}
