package com.tgou.data.stanford.sirius.ubaPage.ipGeo

import com.tgou.data.stanford.sirius.core.constants.EventEnum
import org.apache.spark.sql.{Dataset, SaveMode, SparkSession}

object IP_GEO_refresh {

  def execute(spark: SparkSession):Unit = {
    //loadData
    val nameNode = "hdfs://hnode1:8020"
    import spark.implicits._

    //load his_data
    val oldIpDs: Dataset[IPWithGeo] = spark.read.parquet(nameNode + EventEnum.Ip2GeoPath + "_copy")
      .as[IPWithGeo]
    oldIpDs.createTempView("old_ip")

    val sqlText =
      """
        | select
        | ip,
        | CASE WHEN geo_country like '国外' or geo_country like '中国' THEN '其他' ELSE geo_country END as geo_country,
        | CASE WHEN geo_city like '国外' or geo_city like '中国' or geo_city like '%其他' THEN '其他'
        |     WHEN geo_city like '%市' THEN  substring(geo_city, 0, length(geo_city)-1)
        |     ELSE geo_city END as geo_city,
        | version
        | FROM old_ip
      """.stripMargin
    val resultDs = spark.sql(sqlText)
    resultDs.write.mode(SaveMode.Overwrite).parquet(nameNode + EventEnum.Ip2GeoPath)
  }


  def main(args: Array[String]): Unit = {
    System.setProperty("hive.metastore.uris", "thrift://hnode1:9083")
    var builder = SparkSession.builder()

    var dateBegin = -1
    var dateEnd = -1

    if(args == null || args.length == 0){
      builder = builder.master("local")
    }else{
      dateBegin = args(1).toInt
      dateEnd = args(2).toInt
    }

    val spark = builder
      .appName("IP_GEO")
      .enableHiveSupport()
      .getOrCreate()

    spark.sparkContext.setLogLevel("WARN")
    try {
      execute(spark)
    } catch {
      case e: Exception => throw new RuntimeException(e)
    } finally {
      spark.close()
    }
  }

}
