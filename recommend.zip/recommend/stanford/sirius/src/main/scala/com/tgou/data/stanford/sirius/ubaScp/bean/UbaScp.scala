package com.tgou.data.stanford.sirius.ubaScp.bean

case class UbaScp (
                    a: String,
                    a_b: String,
                    a_b_c: String,
                    agent: String,
                    global: String,
                    ip: String,
                    bk: String,
                    member_id: String,
                    scp: String,
                    time: String,
                    uuid: String,
                    trace_object: String
                  ){

}
