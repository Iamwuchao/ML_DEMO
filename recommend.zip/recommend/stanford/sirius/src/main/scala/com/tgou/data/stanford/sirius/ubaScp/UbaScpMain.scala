package com.tgou.data.stanford.sirius.ubaScp

import java.time.LocalDate

import com.tgou.data.stanford.sirius.core.constants.EventEnum
import com.tgou.data.stanford.sirius.ubaScp.bean.{ScpEvent, UbaScp}
import org.apache.spark.sql.SparkSession
import com.tgou.data.stanford.sirius.ubaScp.eventParser.Parser

import scala.util.Success
object UbaScpMain {
  def execute(spark: SparkSession, date: LocalDate):Unit = {
    //这个跟那啥比较类似。
    val nameNode = "hdfs://nameservice1:8020"
    import spark.implicits._
    //load data
    var sqlText =
      s"""
         | SELECT * FROM dw.uba_scp where his_time = '$date' and a != '' and a regexp '${"^[a-zA-Z0-9]+$"}'
       """.stripMargin
    //需要处理下member_id，
    val ss = spark.sql(sqlText)
    ss.createOrReplaceTempView("scp_origin")
    //
    //逻辑有不对的地方啊。这么一join就多了很多了啊。
    //没弄明白
    //还得知道，是否那啥了的才行。
    //不用想了，肯定不对
    //也还是不行。shit。
    //明白了，这么写起来好麻烦啊，吼
//    这样不行，得有一个公用的方法，来补全member_id。
    //直接join，好像满足不了啊。shit啊。
    //lets fuck
    val mMember = spark.sql(
      """
        | SELECT uuid,member_id,MIN(time) as min_time FROM scp_origin where a is not null  and member_id != '' group by uuid,member_id
      """.stripMargin)

    sqlText =
      """
        | SELECT
        |  CASE WHEN t.member_id = '' and t.
        |  FROM scp_origin t
        | inner join
        |   () mt1
        | t.uuid = mt.uuid
        | and t.time < mt.time
        | inner join
        |
      """.stripMargin
    val ds = spark.sql(sqlText).as[UbaScp].map(transfer)
  }
  def transfer(ubaPage:UbaScp) : ScpEvent = {

    val a = if(!EventEnum.scpMap.contains(ubaPage.a)){
      "other"
    }else{
      ubaPage.a
    }
    val baseEvent = EventEnum.scpMap(a)
    Parser.getEvent(baseEvent.eventId, baseEvent.buckId,Array(ubaPage))
  }

  def main(args: Array[String]): Unit = {
    System.setProperty("hive.metastore.uris", "thrift://hnode1:9083")
    var builder = SparkSession.builder()

    var dateBegin = LocalDate.now().plusDays(-1)
    var dateEnd = LocalDate.now().plusDays(-1)

    def str2date(str: String): LocalDate= {
      scala.util.Try(str.toInt) match {
        case Success(_) => LocalDate.now().plusDays(str.toInt);
        case _ => LocalDate.parse(str)
      }
    }

    if(args == null || args.length == 0){
      builder = builder.master("local")
    }else{
      dateBegin = str2date(args(1))
      dateEnd = str2date(args(2))
    }


    val spark = builder
      .appName("Event--SCP")
      .enableHiveSupport()
      .getOrCreate()

    spark.sparkContext.setLogLevel("WARN")
    try {
      var date = LocalDate.now().plusDays(-1)
      while (!dateBegin.isAfter(dateEnd)){
        date = dateBegin
        dateBegin = dateBegin.plusDays(1)
        execute(spark,date)
      }
    } catch {
      case e: Exception => throw new RuntimeException(e)
    } finally {
      spark.close()
    }
  }
}
