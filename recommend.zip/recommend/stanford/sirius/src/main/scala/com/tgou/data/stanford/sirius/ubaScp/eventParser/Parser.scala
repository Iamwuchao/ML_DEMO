package com.tgou.data.stanford.sirius.ubaScp.eventParser

import com.tgou.data.stanford.sirius.ubaScp.bean.{ScpEvent, UbaScp}

object Parser {
  def getEvent(eventId: Int, bucketId: Int,events: Array[UbaScp]): ScpEvent = {
    commonExecute(events(0), eventId, bucketId)
  }
  def commonExecute(ubaPage: UbaScp, eventId: Int, bucketId: Int): ScpEvent ={
    //多了没几项。

    null
  }
}
