package com.tgou.data.stanford.sirius.ubaPage.ipGeo

import java.io.IOException
import java.net.URI
import java.time.LocalDate

import com.tgou.data.stanford.sirius.core.constants.EventEnum
import com.tgou.data.stanford.sirius.utils.{IpUtils, IpWebUtils}
import org.apache.hadoop.conf.Configuration
import org.apache.hadoop.fs.{FileSystem, Path}
import org.apache.spark.sql.{Dataset, SaveMode, SparkSession}

import scala.util.Success

/**
  * 处理的稍微有些复杂。由于离线的IP的数据库不够准，在线的又达不到API的离线量。
  * 现在的做法。比较狠。
  * 先初始化个离线的IP-->geo的对应库。
  *
  * step 1. copy old geo files
  * step 2. 将新的IP跟旧的可能存在问题的IP筛选出来
  * step 3. 先用离线方式解析，如果省市都无问题，则version = 2 ，如果省市为国外，则version = 1
  * step 4. 先用离线方式解析，如果市无法解析，则用高德API进行解析，如果没问题 version = 2
  * step 5. 先用离线方式解析，如果市无法解析，则用高德API进行解析，如果有问题，city=省+其他 version = 1 (被标记为此次可用，下次仍需再处理)
  * step 6. 过滤重复
  *
  * i wanna read from pathA then overwrite pathA. But i dont know how
  * so....pathA copy pathB then read pathB and overwrite pathA
  * lucky...ip_db is small...
  *
  * hadoop dfs -rm -r /data/sirius/ip_geo_copy
  * hadoop dfs -cp -f /data/sirius/ip_geo /data/sirius/ip_geo_copy
  *
  *
  * add 17/12/14 会有高德api+离线，都无法解析的IP。不过是少量。
  */

/*version = 1 是还可能存在问题的情况，如果version = 2，则认为IP解析已经正确。*/
case class IPWithGeo(ip: String, geo_country: String, geo_city: String, version: Int){}
case class IP(ip: String){}
object IP_GEO {

  def execute(spark: SparkSession, dateBegin: Int, dateEnd: Int):Unit = {
    //loadData
    val nameNode = "hdfs://hnode1:8020"
//    val toCopyDs = spark.read.parquet(nameNode + EventEnum.Ip2GeoPath)
//    toCopyDs.write.mode("overwrite").parquet(nameNode + EventEnum.Ip2GeoPath + "_copy")
    import spark.implicits._

    //reload his_data
    val oldIpDs: Dataset[IPWithGeo] = spark.read.parquet(nameNode + EventEnum.Ip2GeoPath + "_copy")
        .as[IPWithGeo]
    oldIpDs.createOrReplaceTempView("old_ip")
    //load page_data
    var pageEventIPToCalDs: Dataset[IP] = {
      (dateBegin to dateEnd).map(day => {
        spark.read.parquet(nameNode + "/dw/data/uba_page/his_time=" +  LocalDate.now().plusDays(day))
          .select("ip")}).reduce(_.union(_))
    }.distinct().as[IP]
    pageEventIPToCalDs.createTempView("new_ip")

    var sqlText =  """
        | (select n.ip from new_ip n
        | LEFT JOIN old_ip o
        | ON n.ip = o.ip
        | where o.geo_city is null or o.geo_country is null)
        | union
        | (select ip from old_ip where geo_city like '%其他' and version = 1)
      """.stripMargin

    val newIpDs = spark.sql(sqlText).as[IP].map(row=>{
      loadFileFromHDFS
      val geoLocal = IpUtils.findSafe(row.ip)
      var geoCountry: String = ""
      var geoCity: String = ""
      var version = 2
      if(!geoLocal(0).equals("中国")){
        geoCountry="其他"
        geoCity="其他"
        version = 1
      }else{
        geoCountry = geoLocal(1)
        geoCity = {
          if(geoLocal(2) == null || geoLocal(2).trim.equals("")){
            //如果高德的API次数超出。
            IpWebUtils.getCityByIpFromGaode(row.ip,geoLocal(1))
          }else {
            geoLocal(2)
          }
        }
      }
      if(geoCity == null || geoCity.equals("")){
        version = 1
        geoCity = "其他"
      }
      if (geoCity != null && !(geoCity.trim == "") && geoCity.lastIndexOf('市') + 1 == geoCity.length) geoCity = geoCity.substring(0, geoCity.length - 1)
      IPWithGeo(row.ip,geoCountry,geoCity,version)
    })
    oldIpDs.union(newIpDs).createTempView("ip_geo")
    sqlText =
      """
        | (select ip,
        | max(geo_country) as geo_country,
        | max(geo_city) as geo_city,
        | max(version) as version
        |  from ip_geo group by ip having count(1) = 1)
        |  union
        |  (
        |  select
        |  a.ip,a.geo_country,a.geo_city,a.version
        |  from ip_geo a
        |  join ip_geo b
        |  on a.ip = b.ip
        |  and (a.version != b.version or a.geo_city != b.geo_city)
        |  where a.version = 2
        |  )
      """.stripMargin
    val tmpResultDs = spark.sql(sqlText)
    tmpResultDs.createOrReplaceTempView("tmp_ip")

    sqlText =
      """
        | select
        | ip,
        | CASE WHEN geo_country like '国外' or geo_country like '中国' THEN '其他' ELSE geo_country END as geo_country,
        | CASE WHEN geo_city like '国外' or geo_city like '中国' or geo_city like '%其他' THEN '其他'
        |     WHEN geo_city like '%市' THEN  substring(geo_city, 0, length(geo_city)-1)
        |     ELSE geo_city END as geo_city,
        | version
        | FROM tmp_ip
      """.stripMargin
    val resultDs = spark.sql(sqlText)
    resultDs.createOrReplaceTempView("ip_db")
    resultDs.write.mode(SaveMode.Overwrite).parquet(nameNode + EventEnum.Ip2GeoPath)
  }

  def loadFileFromHDFS(){
    val dataPath = EventEnum.IpDatPath
    val conf = new Configuration
    conf.setBoolean("dfs.support.append", true)
    try {
      var fs  = FileSystem.get(URI.create(dataPath), conf)
      IpUtils.testAndLoad(fs.open(new Path(dataPath)))
    } catch {
      case e: IOException =>
        e.printStackTrace()
    }
  }

  def main(args: Array[String]): Unit = {
    System.setProperty("hive.metastore.uris", "thrift://hnode1:9083")
    var builder = SparkSession.builder()

    var dateBegin = -1
    var dateEnd = -1

    def str2date(str: String): LocalDate= {
      scala.util.Try(str.toInt) match {
        case Success(_) => LocalDate.now().plusDays(str.toInt);
        case _ => LocalDate.parse(str)
      }
    }

    if(args == null || args.length == 0){
      builder = builder.master("local")
    }else{
      dateBegin = (str2date(args(1)).toEpochDay- str2date("0").toEpochDay).toInt
      dateEnd = (str2date(args(2)).toEpochDay- str2date("0").toEpochDay).toInt
    }

    val spark = builder
      .appName("IP_GEO")
      .enableHiveSupport()
      .getOrCreate()

    spark.sparkContext.setLogLevel("WARN")
    try {
        execute(spark,dateBegin ,dateEnd)
    } catch {
      case e: Exception => throw new RuntimeException(e)
    } finally {
      spark.close()
    }
  }

}
