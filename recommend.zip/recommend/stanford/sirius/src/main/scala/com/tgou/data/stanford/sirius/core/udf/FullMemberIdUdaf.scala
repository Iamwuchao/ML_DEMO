package com.tgou.data.stanford.sirius.core.udf

import org.apache.spark.sql.Row
import org.apache.spark.sql.expressions.{MutableAggregationBuffer, UserDefinedAggregateFunction}
import org.apache.spark.sql.types._

class FullMemberIdUdaf extends UserDefinedAggregateFunction{
  override def inputSchema: StructType = StructType(List(StructField("member_id",StringType),StructField("time", StringType)))

  override def bufferSchema: StructType = StructType(StructField("values", MapType(StringType, StringType))::Nil)

  override def dataType: DataType = StructType(List(StructField("member_id",StringType),StructField("time", StringType)))

  override def deterministic: Boolean = true

  override def initialize(buffer: MutableAggregationBuffer): Unit = {
    buffer(0) = List()
  }

  override def update(buffer: MutableAggregationBuffer, input: Row): Unit = {
    //时间是key
    var list = buffer.getList[(String,String)](0)
    list.add(input.getString(1) -> input.getString(0))
    buffer(0) = list
  }

  override def merge(buffer1: MutableAggregationBuffer, buffer2: Row): Unit = {
    if(buffer2(0)!=null){
      val list1 = buffer2.getList[(String,String)](0)
      var list2 = buffer1.getList[(String,String)](0)
      //这个merge有点问题吧

//      for(kv <- map2){
//        map1 = map1 + kv
//      }
//      buffer1(0) = map1
    }
  }

  override def evaluate(buffer: Row): Any = {
    //fuck o
    //怎么写啊

  }
}
