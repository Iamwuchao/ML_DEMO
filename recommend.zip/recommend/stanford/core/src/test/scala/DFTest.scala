import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.types.{StringType, StructField, StructType}

/**
  * Created by xinghailong on 2017/9/13.
  */
object DFTest {
  def main(args: Array[String]) {
    val spark = SparkSession
      .builder
      .master("local")
      .appName(s"${this.getClass.getSimpleName}")
      .getOrCreate()
    val schema = StructType(Seq(StructField("a", StringType, nullable = true),StructField("b", StringType, nullable = true)))
    val df = spark.createDataFrame(spark.emptyDataFrame.toJavaRDD,schema)
    df.show()
    spark.stop()
  }
}
