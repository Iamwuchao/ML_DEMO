package com.tgou.data.stanford.core.utils

import java.text.SimpleDateFormat
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.Date

/**
  * Created by xinghailong on 2017/9/12.
  */
object DateUtils {
  val DATE_FORMAT       = "yyyy-MM-dd"
  val DATE_PATH_FORMAT  = "yyyy/MM/dd"
  /**
    * 把date格式化成字符串
    *
    * @param date LocalDate
    * @param format "yyyy-MM-dd"
    * @return
    */
  def dateFormat(date: LocalDate,format:String = DATE_FORMAT) = {
    date.format(DateTimeFormatter.ofPattern(format))
  }

  def getDateString(input: String, format: String): String = {
    getDateString(input.toInt,format)
  }

  def getDateString(day: Int, format: String): String = {
    val sdf: SimpleDateFormat = new SimpleDateFormat(format)
    sdf.format(getDay(day))
  }

  def getDay (index: Int): Date = {
    var date: Date = new Date()
    date = org.apache.commons.lang3.time.DateUtils.setHours(date, 0)
    date = org.apache.commons.lang3.time.DateUtils.setMinutes(date, 0)
    date = org.apache.commons.lang3.time.DateUtils.setSeconds(date, 0)
    date = org.apache.commons.lang3.time.DateUtils.setMilliseconds(date, 0)
    org.apache.commons.lang3.time.DateUtils.addDays(date, index)
  }

}
