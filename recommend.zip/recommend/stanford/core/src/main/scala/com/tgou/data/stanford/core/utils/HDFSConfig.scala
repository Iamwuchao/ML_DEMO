package com.tgou.data.stanford.core.utils

/**
  * Created by xinghailong on 2017/9/12.
  */
object HDFSConfig {

  val DW_SQOOP_ROOT = "/tiangou"
  val MIS_SQOOP_ROOT  = "/mis"

  val DW_ROOT       = "/data/dw"
  val MARKET_ROOT   = "/data/market"

  val WECHAT    = "/wechat"
  val TGOU      = "/tgou"
  val TGOUORDER = "/tgouorder"
  val MEMEBR    = "/member"
  val SHOW      = "/show"

  val ACCESS  = "access"
  val SEARCH  = "search"
  val SCP     = "scp"
}
