package com.tgou.data.stanford.core.udaf

import org.apache.spark.sql.Row
import org.apache.spark.sql.expressions.{MutableAggregationBuffer, UserDefinedAggregateFunction}
import org.apache.spark.sql.types.{DataType, StringType, StructField, StructType}

/**
  * Created by xinghailong on 2017/8/22.
  */
class MergeUDAF extends UserDefinedAggregateFunction {

  override def inputSchema: StructType = StructType(List(StructField("ids", StringType)))

  override def bufferSchema: StructType = StructType(List(StructField("ids", StringType)))

  override def dataType: DataType = StringType

  override def deterministic: Boolean = true

  override def initialize(buffer: MutableAggregationBuffer): Unit = {
    buffer(0) = null
  }

  override def update(buffer: MutableAggregationBuffer, input: Row): Unit = {
    val in = input.getAs[String](0)

    if (in != null) {
      val buff = buffer.getAs[String](0)

      if (buff == null) {
        buffer.update(0, in)
      }else{
        buffer.update(0, buff+","+in)
      }

    }
  }

  override def merge(buffer1: MutableAggregationBuffer, buffer2: Row): Unit = {
    val left = buffer1.getAs[String](0)
    val right = buffer2.getAs[String](0)

    if(right != null){
      if(left == null){
        buffer1.update(0,right)
      }else{
        buffer1.update(0,left+","+right)
      }
    }
  }

  override def evaluate(buffer: Row): Any = {
    buffer.getAs[String](0)
  }
}