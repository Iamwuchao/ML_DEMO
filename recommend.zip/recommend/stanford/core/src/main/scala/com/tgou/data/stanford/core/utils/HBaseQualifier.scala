package com.tgou.data.stanford.core.utils

object HBaseQualifier extends Enumeration{
  type HBaseQualifier = Value
  val user    = Value(0,"com.tgou.standford.core.persona.PersonaUserQualifier")
  val product = Value(1,"com.tgou.standford.core.persona.PersonaProductQualifier")
  val test    = Value(2,"com.tgou.standford.core.persona.PersonaTestQualifier")
  val user_rec = Value(3,"com.tgou.standford.core.persona.UserRecQualifier")
}
