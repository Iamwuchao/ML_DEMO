package com.tgou.data.stanford.core.udaf

import org.apache.spark.sql.Row
import org.apache.spark.sql.expressions.{MutableAggregationBuffer, UserDefinedAggregateFunction}
import org.apache.spark.sql.types._

/**
  * 获取最大值对应的其他列
  *
  * 数据如：[(a,1,1),(a,2,2),(a,1,3),(b,2,1),(b,1,4)]
  *
  * select get_max_data(col3,col2) from t group by col1
  *
  * 得到数据如下：
  * [(a,1),(b,1)]
  *
  * Created by xinghailong on 2017/2/6.
  */
class NumberMaxData extends UserDefinedAggregateFunction {

  override def inputSchema: StructType = StructType(List(StructField("score", DoubleType),StructField("listing_id", StringType)))

  override def bufferSchema: StructType = StructType(List(StructField("score", DoubleType),StructField("listing_id", StringType)))

  override def dataType: DataType = StringType

  override def deterministic: Boolean = true

  override def initialize(buffer: MutableAggregationBuffer): Unit = {
    buffer(0) = Double.MinValue
    buffer(1) = ""
  }

  override def update(buffer: MutableAggregationBuffer, input: Row): Unit = {
    val scoreValue = input.getAs[Double](0)
    val listingValue = input.getAs[String](1)

    if (scoreValue != null && listingValue!=null && listingValue.length > 0) {
      val bufferScoreValue = buffer.getAs[Double](0)

      if (bufferScoreValue != null) {
        if (scoreValue >= bufferScoreValue) {
          buffer.update(0, scoreValue)
          buffer.update(1, listingValue)
        }
      }
    }
  }

  override def merge(buffer1: MutableAggregationBuffer, buffer2: Row): Unit = {
    val leftScoreValue = buffer1.getAs[Double](0)
    val rightScoreValue = buffer2.getAs[Double](0)
    val rightListingValue = buffer2.getAs[String](1)

    if(leftScoreValue < rightScoreValue){
      buffer1.update(0,rightScoreValue)
      buffer1.update(1,rightListingValue)
    }
  }

  override def evaluate(buffer: Row): Any = {
    buffer.getAs[String](1)
  }
}
