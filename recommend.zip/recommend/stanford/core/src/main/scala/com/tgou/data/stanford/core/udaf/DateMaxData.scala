package com.tgou.data.stanford.core.udaf

import java.sql.Date

import org.apache.spark.sql.Row
import org.apache.spark.sql.expressions.{MutableAggregationBuffer, UserDefinedAggregateFunction}
import org.apache.spark.sql.types._

/**
  * 获取最大值对应的其他列
  *
  * 数据如：[(a,1,1),(a,2,2),(a,1,3),(b,2,1),(b,1,4)]
  *
  * select get_max_data(col3,col2) from t group by col1
  *
  * 得到数据如下：
  * [(a,1),(b,1)]
  *
  * Created by xinghailong on 2017/2/6.
  */
class DateMaxData extends UserDefinedAggregateFunction {

  override def inputSchema: StructType = StructType(List(StructField("date", DateType),StructField("id", StringType)))

  override def bufferSchema: StructType = StructType(List(StructField("date", DateType),StructField("id", StringType)))

  override def dataType: DataType = StringType

  override def deterministic: Boolean = true

  override def initialize(buffer: MutableAggregationBuffer): Unit = {
    buffer(0) = null
    buffer(1) = ""
  }

  override def update(buffer: MutableAggregationBuffer, input: Row): Unit = {
    val dateValue = input.getAs[Date](0)
    val idValue = input.getAs[String](1)

    if (dateValue != null && idValue != null) {
      val bufferDateValue = buffer.getAs[Date](0)

      if ((bufferDateValue == null) || (bufferDateValue!=null && bufferDateValue.compareTo(dateValue)<0 )) {
        buffer.update(0, dateValue)
        buffer.update(1, idValue)
      }
    }
  }

  override def merge(buffer1: MutableAggregationBuffer, buffer2: Row): Unit = {
    val leftDateValue = buffer1.getAs[Date](0)
    val rightDateValue = buffer2.getAs[Date](0)
    val rightIdValue = buffer2.getAs[String](1)

    if(leftDateValue == null || (leftDateValue!=null && rightDateValue!=null && leftDateValue.compareTo(rightDateValue) < 0)){
      buffer1.update(0,leftDateValue)
      buffer1.update(1,rightIdValue)
    }
  }

  override def evaluate(buffer: Row): Any = {
    buffer.getAs[String](1)
  }
}
