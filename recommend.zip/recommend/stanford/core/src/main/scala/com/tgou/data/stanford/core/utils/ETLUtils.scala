package com.tgou.data.stanford.core.utils

import java.net.URI

import com.tgou.data.stanford.core.base.BaseBean
import org.apache.hadoop.conf.Configuration
import org.apache.hadoop.fs.{FileSystem, Path}
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.storage.StorageLevel

import scala.collection.mutable

/**
  * Hdfs读取数据工具类
  *
  * Created by xinghailong on 2017/9/11.
  */
object ETLUtils {

  /**
    * 获取当天的dataFrame
    *
    * @param spark    SparkSession
    * @param namenode 请求的namenode，用户区分线上和线下，一般情况下传入hdfs://nameservice1即可
    * @param path     请求的数据路径，格式为"/tiangou/wechat/wechat_info"
    * @param date     请求的时间，格式为"2017/09/12"
    * @param base     需要用户自己实现
    * @return 返回dataFrame，如果当天没有数据，会打印一条记录，并返回 空的DataFrame
    */
  def getModify(spark: SparkSession, namenode:String, path:String, date:String, base: BaseBean): DataFrame ={
    val sourcePath = namenode + path + "/" + date
    //创建一个空的RDD
    val df =
      try {
        val fs = FileSystem.get(new URI(namenode), new Configuration)
        if (fs.exists(new Path(sourcePath))) {
          try {
          spark.read
            .option("delimiter", "^")
            .option("nullValue", "\\N")
            .option("quote","")
            .csv(sourcePath)
            .select(base.columns: _*)
            .toDF(base.title: _*)
          }catch{
            case ex: Exception => println("文件为空")
              spark.createDataFrame(spark.emptyDataFrame.toJavaRDD,base.structType)
          }
        } else {
          println(s"${sourcePath}下没有RDD数据...")
          spark.createDataFrame(spark.emptyDataFrame.toJavaRDD,base.structType)
        }
      }
      catch {
        case e: Exception =>
          e.printStackTrace()
          throw new RuntimeException(e)
      }
    df
  }

  /**
    * 获取全量的数据
    * @param spark    SparkSession
    * @param namenode 请求的namenode，用户区分线上和线下，一般情况下传入hdfs://nameservice1即可
    * @param path     请求的数据路径，格式为"/tiangou/wechat/wechat_info"
    * @param date     请求的时间，格式为"2017/09/12"
    * @param base     需要用户自己实现
    * @return 返回dataFrame，如果当天没有数据，会打印一条记录，并返回 空的DataFrame
    */
  def getTotal(spark: SparkSession, namenode:String, path:String, date:String, base: BaseBean): DataFrame = {

    val yearStr   = date.split("/")(0)
    val monthStr  = date.split("/")(1)
    val dayStr    = date.split("/")(2)

    val fs = FileSystem.get(new URI(namenode), new Configuration)
    var total = mutable.ArrayBuffer[DataFrame]()

    //1.处理年
    for (y <- 2014 until yearStr.toInt) {
      val yStr: String = y.toString
      val sourcePath: String = namenode + path + "/" + yStr + "/"
      if (fs.exists(new Path(sourcePath))) {
        try {
          val df = spark.read
                        .option("delimiter", "^")
                        .option("nullValue", "\\N")
                        .option("quote","")
                        .csv(sourcePath+"*/*/")
                        .select(base.columns: _*)
                        .toDF(base.title: _*)
          total += df
        }catch{
          case ex: Exception => println("文件为空")
        }
      }
    }

    //2.处理月
    for (m <- 1 until Integer.parseInt(monthStr)) {
      var mStr = m.toString
      if (m < 10) {
        mStr = "0" + mStr
      }
      val sourcePath: String = namenode + path + "/" + yearStr + "/" + mStr + "/"
      if (fs.exists(new Path(sourcePath))) {
        try {
          val df = spark.read
            .option("delimiter", "^")
            .option("nullValue", "\\N")
            .option("quote","")
            .csv(sourcePath+"*/")
            .select(base.columns: _*)
            .toDF(base.title: _*)
          total += df
        }catch{
          case ex: Exception => println("文件为空")
        }
      }
    }

    //3.处理日，注意是<=
    for (d <- 1 to Integer.parseInt(dayStr)) {
      var dStr = d.toString
      if (d < 10) {
        dStr = "0" + dStr
      }
      val sourcePath: String = namenode + path + "/" + yearStr + "/" + monthStr + "/" + dStr + "/"
      if (fs.exists(new Path(sourcePath))) {
        try {
          val df = spark.read
            .option("delimiter", "^")
            .option("nullValue", "\\N")
            .option("quote", "")
            .csv(sourcePath)
            .select(base.columns: _*)
            .toDF(base.title: _*)
          total += df
        }catch{
          case ex: Exception => println("文件为空")
        }
      }
    }

    //4 汇总结果
    val merge =
      if (total.isEmpty) {
        spark.createDataFrame(spark.emptyDataFrame.toJavaRDD,base.structType)
      } else {
        var result = total.head

        for(i <- 1 until total.length){
          result = result.union(total(i))
        }
        result
      }
    merge
  }

  /**
    * 获取最新的DataFrame
    * @param spark      SparkSession
    * @param df         想要去重的DataFrame
    * @param primaryCol 去重的主键
    * @param timeCol    对比的时间字段
    * @return 返回最新的DataFrame
    */
  def getNewestDF(spark: SparkSession, df: DataFrame, primaryCol: String, timeCol: String): DataFrame = {

    df.persist(StorageLevel.MEMORY_AND_DISK)

    val reuslt =
      if(df.count() == 0) {
        println(s"df没有数据,不需要获取最新...")
        df
      }else{
        val tmpTable = "tmp_" + System.currentTimeMillis()
        df.createOrReplaceTempView(tmpTable)
        spark.sql(
          s"""
             |select
             |  t1.*
             |from $tmpTable t1
             |inner join (
             |  select $primaryCol, max($timeCol) as $timeCol from $tmpTable group by $primaryCol
             |) t2
             |on t1.$primaryCol = t2.$primaryCol
             |  and t1.$timeCol = t2.$timeCol
           """.stripMargin)
    }
    reuslt
  }
}
