package com.tgou.data.stanford.core.udaf

import org.apache.spark.sql.Row
import org.apache.spark.sql.expressions.{MutableAggregationBuffer, UserDefinedAggregateFunction}
import org.apache.spark.sql.types._

class TopFieldByDouble extends UserDefinedAggregateFunction {

  override def inputSchema: StructType = StructType(List(StructField("field", StringType),StructField("number", DoubleType),StructField("top",IntegerType)))

  override def bufferSchema: StructType = StructType(List(StructField("buffer", StringType),StructField("top",IntegerType)))

  override def dataType: DataType = StringType

  override def deterministic: Boolean = true

  override def initialize(buffer: MutableAggregationBuffer): Unit = {
    buffer(0) = ""
    buffer(1) = 1
  }

  override def update(buffer: MutableAggregationBuffer, input: Row): Unit = {
    val brand_id  = input.getString(0)
    val je        = input.getDouble(1)

    if(brand_id !=null && je != null){

      val new_line = brand_id+":"+je

      if("".equals(buffer(0))){
        buffer.update(0, new_line)
        buffer.update(1,input.get(2))
      }else{
        buffer.update(0, buffer(0) + "," + new_line)
        buffer.update(1,input.getInt(2))
      }
    }
  }

  override def merge(buffer1: MutableAggregationBuffer, buffer2: Row): Unit = {
    if("".equals(buffer1(0))){
      buffer1.update(0,buffer2.getString(0))
      buffer1.update(1,buffer2.getInt(1))
    }else{
      if(!"".equals(buffer2(0))){
        buffer1.update(0,buffer1(0) + "," + buffer2(0))
      }
    }
  }

  override def evaluate(buffer: Row): Any = {
    val buff = buffer.getString(0)
    // 拆分合并内容，形成二元组数组
    val tuples = buff.split(",").map(line => (line.split(":")(0),line.split(":")(1))).sortWith((a,b) => a._2.toDouble>b._2.toDouble).take(buffer.getInt(1))
    val length = tuples.length
    // 拼接形成
    var count = 1
    String.join(",", tuples.map(t2 => {
      val line = t2._1+":"+t2._2
      count += 1
      line
    } ):_*)
  }
}
