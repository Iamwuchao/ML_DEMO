package com.tgou.data.stanford.core.utils

import java.lang.reflect.Method

import com.tgou.data.stanford.core.utils.HBaseQualifier.HBaseQualifier
import com.tgou.standford.core.hbase.HbaseServer
import com.tgou.standford.core.hbase.plugins.SimplePutter
import org.apache.commons.lang3.StringUtils
import org.apache.spark.sql.{DataFrame, Row}

object HBaseUtils {

  private def row2HBase(rowkey: String,
                        family: String,
                        row: Row,
                        putter: SimplePutter,
                        map: Array[(Int,String,String)],
                        hBaseQualifier: HBaseQualifier) = {
    val clazz = Class.forName(hBaseQualifier.toString)
    val m:Method = clazz.getMethod("get",classOf[String])

    for((index, col, colType) <- map){
      if(row(index) != null){
        val qualifier = m.invoke(clazz,col).toString

        colType match {
          case "double" => putter.add(rowkey,family,qualifier,java.lang.Double.valueOf(row(index).toString))
          case "long"   => putter.add(rowkey,family,qualifier,java.lang.Long.valueOf(row(index).toString))
          case _        => putter.add(rowkey,family,qualifier,row(index).toString)
        }
      }
    }
  }

  /**
    * 保存df到hbase
    *
    * @param df                 想要保存的数据
    * @param family             对应的列族
    * @param cols               对应的列限定符与dataframe中的row下标映射
    * @param rowkey_index       rowkey对应的row下标，默认 0
    * @param write_batch        每次写入的数据量，默认 50000
    * @param table              写入的表名，默认 "persona:user"
    */
  def save2HBase(df: DataFrame,
                  family: String = "t",
                  cols: Array[(Int,String,String)],
                  rowkey_index: Int = 0,
                  write_batch: Int = 1000,
                  table: String,
                  hBaseQualifier: HBaseQualifier
                 ) = {
    df.foreachPartition(it => {

      val userServer: HbaseServer = new HbaseServer(table)
      val userPutter: SimplePutter = new SimplePutter(userServer)

      while(it.hasNext){

        val row = it.next()
        val row_key = row.get(rowkey_index).toString

        if(StringUtils.isNotBlank(row_key)){
          val timestamp = System.currentTimeMillis()

          // 把df对应到putter中
          row2HBase(
            row_key,
            family,
            row,
            userPutter,
            cols,
            hBaseQualifier
          )

          userPutter.putAndClearIfMorethan(write_batch)
        }
      }

      userPutter.putAndClearIfMorethan(0)
      userPutter.close()
      userServer.close()
    })
  }
}
