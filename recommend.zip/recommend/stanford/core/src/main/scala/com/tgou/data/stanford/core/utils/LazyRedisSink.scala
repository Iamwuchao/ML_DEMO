package com.tgou.data.stanford.core.utils

import org.apache.commons.pool2.impl.GenericObjectPoolConfig
import redis.clients.jedis.JedisPool

/**
  * spark.broadcast分发Jedis的客户端用。
  */
class LazyRedisSink(createProducer: () => JedisPool) extends Serializable  {

  lazy val producer = createProducer()

  //清空所有Keys Patten
  def delKeys(keysPattern: String): Unit = {
    val client = producer.getResource
    try {
      import scala.collection.JavaConversions._

      val keys = client.keys(keysPattern)
      for(key <- keys){
        client.del(key)
      }
    }finally {
      client.close()
    }
  }

  //发送默认过期时间得kv
  def send(key: String, value: String): Unit = {
    val client = producer.getResource
    try {
      client.set(key,value)
    }finally {
      client.close()
    }
  }

  //发送带过期时间的kv
  def send(key: String, value: String, timeout: Int): Unit = {
    val client = producer.getResource
    try {
      client.setex(key, timeout, value)
    }finally {
      client.close()
    }
  }
}


object LazyRedisSink {
  private val DEFAULT_TIMEOUT = 2000
  def
  apply(config: Map[String, String]): LazyRedisSink = {
    val f = () =>{
      val jedisPool = new JedisPool(new GenericObjectPoolConfig(),
        config.getOrElse("host", redis.clients.jedis.Protocol.DEFAULT_HOST),
        toMaybeInt(config.getOrElse("port", redis.clients.jedis.Protocol.DEFAULT_PORT.toString)),
        DEFAULT_TIMEOUT,
        config.getOrElse("password", null)
      )
      //刚学到的，关闭的hook
      sys.addShutdownHook{
        jedisPool.close()
      }
      jedisPool
    }
    new LazyRedisSink(f)
  }

  def toMaybeInt(s:String): Int = {
    scala.util.Try(s.toInt).get
  }
}
