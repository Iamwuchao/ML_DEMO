package com.tgou.data.stanford.tempdata.tuihui

import com.tgou.data.stanford.tempdata.core.TempDataBootstrap
import org.apache.spark.sql._
import org.joda.time.LocalDate

/**
  * Created by 李磊 on 2018/1/31.
  * 退货统计
  */
object TuiHuo {
  def main(args: Array[String]): Unit = {
    TempDataBootstrap(args).bootstrap(execute)
  }

  def execute(spark: SparkSession, appName: String, date: LocalDate): Unit = {

    /**
      * 第一步 获取数据
      * */
    //天狗支付概况
    val tuiHuo = getTansDF(spark, date)


    /**
      * 第二步 拼接数据
      * */
    val result = tuiHuo

    /**
      * 第三步 保存数据到HDFS上
      * */
    result.select(columns(spark): _*).coalesce(2).write.format("csv").option("delimiter", ",").option("nullValue", " ").mode(SaveMode.Overwrite).save(s"/tmp/lilei/TuiHuoTongJi/$date")
    spark.stop()

  }

  def getTansDF(spark:SparkSession, date: LocalDate): DataFrame = {

    var his_time = date.toString("yyyy-MM-dd")

    var end = date.plusDays(1).toString("yyyy-MM-dd")

    val returnRequest = spark.read.format("csv")
      .option("delimiter", "^")
      .option("qoute", "")
      .option("nullValue", "\\N")
      .load("hdfs://nameservice1/tiangou/tgouorder/return_request/*/*/*")

    val returnRequestS = returnRequest.select("_c0","_c6","_c7","_c9","_c11","_c19").toDF("id","comment","create_time","state","fk_tgou_order_id","modify_time")

    var returnRequestMax = returnRequestS.groupBy("id").agg(functions.max("modify_time") as "modify_time")

    var returnRequestY = returnRequestS.join(returnRequestMax,
      returnRequestS("id") === returnRequestMax("id")
        &&  returnRequestS("modify_time") === returnRequestMax("modify_time")
      ,"inner"
    ).select(
      returnRequestS("id") ,
      returnRequestS("comment") ,
      returnRequestS("create_time") ,
      returnRequestS("state") ,
      returnRequestS("fk_tgou_order_id")
    )

    var returnRequestYY = returnRequestY.groupBy("id").agg(functions.max("comment") as "comment",functions.max("create_time") as "create_time",functions.max("state") as "state",functions.max("fk_tgou_order_id") as "fk_tgou_order_id")

    returnRequestYY.createOrReplaceTempView("return_request_lilei")

    val tgouPackage = spark.read.format("csv")
      .option("delimiter", "^")
      .option("qoute", "")
      .option("nullValue", "\\N")
      .load("hdfs://nameservice1/tiangou/tgouorder/tgou_package/*/*/*")

    val tgouPackageS = tgouPackage.select("_c0","_c4","_c18","_c20").toDF("id","tracking_no","fk_tgou_order_id","modify_time")

    var tgouPackageMax = tgouPackageS.groupBy("id").agg(functions.max("modify_time") as "modify_time")

    var tgouPackageY = tgouPackageS.join(tgouPackageMax,
      tgouPackageS("id") === tgouPackageMax("id")
        &&  tgouPackageS("modify_time") === tgouPackageMax("modify_time")
      ,"inner"
    ).select(
      tgouPackageS("id") ,
      tgouPackageS("tracking_no") ,
      tgouPackageS("fk_tgou_order_id")
    )

    var tgouPackageYY = tgouPackageY.groupBy("id").agg(functions.max("tracking_no") as "tracking_no",functions.max("fk_tgou_order_id") as "fk_tgou_order_id")

    tgouPackageYY.createOrReplaceTempView("tgou_package_lilei")

    val resultDF = spark.sql(
      s"""
         |select yw.lx,
         |yw.store_name,
         |yw.id,
         |yw.fk_tgou_order_id,
         |yw.cell_phone,
         |yw.thzt,
         |yw.comment,
         |yw.create_time,
         |yw.tracking_no
         |from (select CASE b.order_source
         |        WHEN 1 THEN '百货'
         |        WHEN 2 THEN '超市'
         |        WHEN 3 THEN '有机'
         |        WHEN 4 THEN '跨境'
         |        ELSE ''
         |    END AS lx,
         |s.store_name,
         |a.id,
         |a.fk_tgou_order_id,
         |m.cell_phone,
         |CASE a.state
         |        WHEN 'Pending' THEN '待审核'
         |        WHEN 'Confirmed' THEN '已确认'
         |        WHEN 'Receiving' THEN '待收货'
         |        ELSE ''
         |    END AS thzt,
         |a.comment,
         |a.create_time,
         |d.tracking_no
         |from return_request_lilei a
         |join dw.order_information b
         |on a.fk_tgou_order_id = b.order_id
         |and b.his_time = '${his_time}'
         |join dw.store s
         |on b.store_id = s.id
         |and s.his_time = '${his_time}'
         |and s.state = 'onshelf'
         |left join tgou_package_lilei d
         |on b.order_id = d.fk_tgou_order_id
         |left join dw.member m
         |on b.member_id = m.member_id
         |and m.his_time = '${his_time}'
         |where a.state in ('Pending' , 'Confirmed', 'Receiving')
         |and a.create_time >= '2017-10-01'
         |and a.create_time < '${end}') yw
         |group by yw.lx,
         |yw.store_name,
         |yw.id,
         |yw.fk_tgou_order_id,
         |yw.cell_phone,
         |yw.thzt,
         |yw.comment,
         |yw.create_time,
         |yw.tracking_no
      """.stripMargin)

    return resultDF
  }

  def columns(spark: SparkSession): Seq[Column] = {
    import org.apache.spark.sql.functions._

    Seq(
      column("lx"),
      column("store_name"),
      column("id"),
      column("fk_tgou_order_id"),
      column("cell_phone"),
      column("thzt"),
      column("comment"),
      column("create_time"),
      column("tracking_no")
    )
  }
}