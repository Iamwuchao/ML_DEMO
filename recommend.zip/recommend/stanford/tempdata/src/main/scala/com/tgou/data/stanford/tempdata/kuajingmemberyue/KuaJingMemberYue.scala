package com.tgou.data.stanford.tempdata.kuajingmemberyue

import com.tgou.data.stanford.tempdata.core.TempDataBootstrap
import org.apache.spark.sql.{Column, DataFrame, SaveMode, SparkSession}
import org.joda.time.LocalDate

/**
* Created by 李磊 on 2018/1/31.
* 跨境用户月交易统计
*/

object KuaJingMemberYue {
  def main(args: Array[String]): Unit = {
    TempDataBootstrap(args).bootstrap(execute)
  }

  def execute(spark: SparkSession, appName: String, date: LocalDate): Unit = {

    /**
      * 第一步 获取数据
      * */
    //天狗支付概况
    val kuaJingMemberYue = getTansDF(spark, date)


    /**
      * 第二步 拼接数据
      * */
    val result = kuaJingMemberYue

    /**
      * 第三步 保存数据到HDFS上
      * */
    result.select(columns(spark): _*).coalesce(6).write.format("csv").option("delimiter", ",").option("nullValue", " ").mode(SaveMode.Overwrite).save(s"/tmp/lilei/KuaJingMemberYue/$date")
    spark.stop()

  }

  def getTansDF(spark:SparkSession, date: LocalDate): DataFrame = {

    var his_time = date.toString("yyyy-MM-dd")

   val month = date.minusMonths(1).withDayOfMonth(1).toString("yyyy-MM-dd")

   var end = date.withDayOfMonth(1).toString("yyyy-MM-dd")



    val resultDF = spark.sql(
      s"""
         |select a.member_id,
         |max(m.cell_phone) as cell_phone,
         |count(a.order_id) as bs,
         |sum(a.total_amount) as je
         |from dw.order_information a
         |join dw.store s
         |on a.store_id = s.id
         |and s.state = 'onshelf'
         |and s.his_time = '${his_time}'
         |and s.is_international = '1'
         |left join dw.member m
         |on a.member_id = m.member_id
         |and m.his_time = '${his_time}'
         |where a.his_time = '${his_time}'
         |and a.pay_time >= '${month}'
         |and a.pay_time < '${end}'
         |and a.order_source = '4'
         |group by a.member_id
      """.stripMargin)

    return resultDF
  }

  def columns(spark: SparkSession): Seq[Column] = {
    import org.apache.spark.sql.functions._

    Seq(
      column("member_id"),
      column("cell_phone"),
      column("bs"),
      column("je")
    )
  }
}