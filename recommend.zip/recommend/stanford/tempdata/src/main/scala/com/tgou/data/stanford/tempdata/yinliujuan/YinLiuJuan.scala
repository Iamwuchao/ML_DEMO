package com.tgou.data.stanford.tempdata.yinliujuan

import com.tgou.data.stanford.tempdata.core.TempDataBootstrap
import org.apache.spark.sql._
import org.joda.time.LocalDate


/**
  * Created by 李磊 on 2018/1/31.
  * 引流领券
  */

object YinLiuJuan {
  def main(args: Array[String]): Unit = {
     TempDataBootstrap(args).bootstrap(execute)
  }

   def execute(spark: SparkSession, appName: String, date: LocalDate): Unit = {

      var flg = 0

      for (flg <- 4 to 14 ){

      /**
        * 第一步 获取数据
        * */
      //天狗支付概况
      val yinliujuan = getTansDF(spark, date,flg * -1)


      /**
        * 第二步 拼接数据
        * */
      val result = yinliujuan

      /**
        * 第三步 保存数据到HDFS上
        * */
      result.select(columns(spark): _*).coalesce(2).write.format("csv").option("delimiter", ",").option("nullValue", " ").mode(SaveMode.Overwrite).save(s"/tmp/lilei/YinLiuJuan/115805/${date.plusDays(flg * -1).toString("yyyy-MM-dd")}")
      }
      spark.stop()

    }

    def getTansDF(spark:SparkSession, date: LocalDate,flg: Int): DataFrame = {

      var his_time = date.plusDays(flg).toString("yyyy-MM-dd")

      var end = date.plusDays(flg+1).toString("yyyy-MM-dd")

     // var etl_time = date.plusDays(flg).toString("yyyy-MM-dd HH:mm:ss")


//      val resultDF = spark.sql(
//        s"""
//           |select
//           |     m.cell_phone,
//           |    c.name,
//           |    fk_coupon_id,
//           |    dc.create_time,
//           |    dc.use_tag ,
//           |    dc.use_time,
//           |   b.je,
//           |   b.ppmc,
//           |   CASE WHEN register_time > '2018-01-22' THEN true ELSE FALSE END as new_register,
//           |    uba.is_new_guest
//           |from dw.coupon_code  dc
//           |    join dw.coupon c on c.his_time = '${his_time}' and c.coupon_id = dc.fk_coupon_id
//           |    join dw.member m on m.his_time = '${his_time}' and dc.member_id = m.member_id
//           |    left join
//           |   (select member_id,MAX(is_new_guest) as is_new_guest
//           |     from  dw.uba_page a
//           |      join (select distinct uuid from dw.uba_page
//           |                 where his_time = '${his_time}' and orgin like 'https://m.51tiangou.com/product/activityDetail.html%'
//           |                 and orgin like '%id=116986%' and orgin like '%JR=temp.0202.102.0.7%' and orgin like '%storeId=49%') b
//           |                on a.uuid = b.uuid
//           |   where a.his_time = '${his_time}' and a.orgin like 'https://m.51tiangou.com/tempPage/mayLIke.html?%' and a.orgin like '%storeId=179%' and a.orgin like '%activityid=115661%' and a.member_id != ''
//           |      group by a.member_id
//           |     ) uba on uba.member_id = dc.member_id
//           |    left join dw.pos_fk a
//           |    on a.coupon_code = dc.coupon_code_id
//           |    and a.his_time >= '${his_time}'
//           |    and a.his_time < '${end}'
//           |    left join dw.pos_mx b
//           |    on a.jysbm = b.jysbm
//           |    and b.his_time >= '${his_time}'
//           |    and b.his_time < '${end}'
//           |where dc.his_time = '${his_time}'
//           |    and dc.etl_time = '${his_time} 00:00:00'
//           |    and dc.fk_activity_id = '115661'
//        """.stripMargin)

//      val resultDF = spark.sql(
//        s"""
//           |select
//           |     m.cell_phone,
//           |    c.name,
//           |    fk_coupon_id,
//           |    dc.create_time,
//           |    dc.use_tag ,
//           |    dc.use_time,
//           |   b.je,
//           |   b.ppmc,
//           |   CASE WHEN register_time > '2018-01-22' THEN true ELSE FALSE END as new_register,
//           |    uba.is_new_guest
//           |from dw.coupon_code  dc
//           |    join dw.coupon c on c.his_time = '${his_time}' and c.coupon_id = dc.fk_coupon_id
//           |    join dw.member m on m.his_time = '${his_time}' and dc.member_id = m.member_id
//           |   left join
//           |   (select member_id,MAX(is_new_guest) as is_new_guest
//           |     from  dw.uba_page a
//           |      join (select distinct uuid from dw.uba_page
//           |                 where his_time = '${his_time}' and orgin like 'https://m.51tiangou.com/product/activityDetail.html%'
//           |                 and orgin like '%id=116986%' and orgin like '%JR=temp.0202.102.0.7%' and orgin like '%storeId=49%') b
//           |                on a.uuid = b.uuid
//           |   where a.his_time = '${his_time}' and a.orgin like 'https://m.51tiangou.com/tempPage/mayLIke.html?%' and a.orgin like '%storeId=49%' and a.orgin like '%activityid=116011%' and a.member_id != ''
//           |      group by a.member_id
//           |     ) uba on uba.member_id = dc.member_id
//           |    left join dw.pos_fk a
//           |    on a.coupon_code = dc.coupon_code_id
//           |    and a.his_time >= '${his_time}'
//           |    and a.his_time < '${end}'
//           |    left join dw.pos_mx b
//           |    on a.jysbm = b.jysbm
//           |    and b.his_time >= '${his_time}'
//           |    and b.his_time < '${end}'
//           |where dc.his_time = '${his_time}'
//           |    and dc.etl_time = '${his_time} 00:00:00'
//           |    and dc.fk_activity_id = '116011'
//        """.stripMargin)

      val resultDF = spark.sql(
        s"""
           |select
           |     m.cell_phone,
           |    c.name,
           |    fk_coupon_id,
           |    dc.create_time,
           |    dc.use_tag ,
           |    dc.use_time,
           |   b.je,
           |   b.ppmc,
           |   CASE WHEN register_time > '2018-01-22' THEN true ELSE FALSE END as new_register,
           |    uba.is_new_guest
           |from dw.coupon_code  dc
           |    join dw.coupon c on c.his_time = '${his_time}' and c.coupon_id = dc.fk_coupon_id
           |    join dw.member m on m.his_time = '${his_time}' and dc.member_id = m.member_id
           |    left join
           |   (select member_id,MAX(is_new_guest) as is_new_guest
           |     from  dw.uba_page a
           |      join (select distinct uuid from dw.uba_page
           |                 where his_time = '${his_time}' and orgin like 'https://m.51tiangou.com/product/activityDetail.html%'
           |                 and orgin like '%id=116986%' and orgin like '%JR=temp.0202.102.0.7%' and orgin like '%storeId=49%') b
           |                on a.uuid = b.uuid
           |   where a.his_time = '${his_time}' and a.orgin like 'https://m.51tiangou.com/tempPage/mayLIke.html?%' and a.orgin like '%storeId=127%' and a.orgin like '%activityid=115805%' and a.member_id != ''
           |      group by a.member_id
           |     ) uba on uba.member_id = dc.member_id
           |    left join dw.pos_fk a
           |    on a.coupon_code = dc.coupon_code_id
           |    and a.his_time >= '${his_time}'
           |    and a.his_time < '${end}'
           |    left join dw.pos_mx b
           |    on a.jysbm = b.jysbm
           |    and b.his_time >= '${his_time}'
           |    and b.his_time < '${end}'
           |where dc.his_time = '${his_time}'
           |    and dc.etl_time = '${his_time} 00:00:00'
           |    and dc.fk_activity_id = '115805'
        """.stripMargin)

      return resultDF
    }

    def columns(spark: SparkSession): Seq[Column] = {
      import org.apache.spark.sql.functions._

      Seq(
        column("cell_phone"),
        column("name"),
        column("fk_coupon_id"),
        column("create_time"),
        column("use_tag"),
        column("use_time"),
        column("je"),
        column("ppmc"),
        column("new_register"),
        column("is_new_guest")
      )
    }
}