package com.tgou.data.stanford.tempdata.xianxia

import com.tgou.data.stanford.tempdata.core.TempDataBootstrap
import org.apache.spark.sql._
import org.joda.time.LocalDate


/**
  * Created by 李磊 on 2018/1/31.
  * 数机立减-统计
  */

object ShuiJiLiJianJian {
  def main(args: Array[String]): Unit = {
    TempDataBootstrap(args).bootstrap(execute)
  }

  def execute(spark: SparkSession, appName: String, date: LocalDate): Unit = {
    /**
      * 第一步 获取数据
      * */



     val result1 = getTansDF(spark, date)


    /**
      * 第二步 保存数据到HDFS上
      * */
    result1.select(columns(spark): _*).coalesce(2).write.format("csv").option("delimiter", ",").option("nullValue", " ").mode(SaveMode.Overwrite).save(s"/tmp/lilei/ShuiJiLiJianJian/$date")
    spark.stop()

  }
  def getTansDF(spark:SparkSession, date: LocalDate): DataFrame = {

    val resultDF = spark.sql(
      s"""
         |select a.storecode,
         |m.cell_phone ,
         |nvl(cast (sum(a.fkje) as decimal(18,2)),0) as fkje
         |from dw.pos_fk a
         |join dw.ds_card_bind b
         |on a.cid = b.card_id
         |and b.his_time = '2018-04-24'
         |join dw.member m
         |on b.member_id = m.member_id
         |and m.his_time = '2018-04-24'
         |where a.his_time >= '2018-04-24'
         |and a.his_time < '2018-04-25'
         |and a.fkfsh = '88'
         |and isnull(a.cid) = false
         |group by a.storecode, m.cell_phone
      """.stripMargin)

    return resultDF
  }


  def columns(spark: SparkSession): Seq[Column] = {
    import org.apache.spark.sql.functions._

    Seq(
      column("storecode"),
      column("cell_phone"),
      column("fkje")
    )
  }

}