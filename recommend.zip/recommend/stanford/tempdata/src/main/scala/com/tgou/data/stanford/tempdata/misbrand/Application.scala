package com.tgou.data.stanford.tempdata.misbrand

import com.google.common.base.Splitter
import com.tgou.data.stanford.tempdata.core.TempDataBootstrap
import com.tgou.data.stanford.tempdata.misbrand.bean.DaPp
import org.apache.spark.sql.catalyst.ScalaReflection
import org.apache.spark.sql.types.StructType
import org.apache.spark.sql.{Dataset, SparkSession}
import org.joda.time.{Days, LocalDate}

import scala.collection.mutable
import scala.collection.JavaConverters._
import scala.io.Source

/**
  * Created by 李震 on 2018/5/3.
  */
object Application {

  val executorMap: Map[String, Executor] = Map(
    "ld_day" -> ld_day.LdDayExecutor,
    "ld_month" -> ld_month.LdMonthExecutor,
    "saoma" -> saoma.SaomaExecutor
  )

  def main(args: Array[String]): Unit = {
    TempDataBootstrap(args).bootstrapHistory(execute)
  }

  def getBrandMap: Map[String, String] = {
    val brandMap = new mutable.HashMap[String, String]()
    val in = Application.getClass.getResourceAsStream("/brand_merge.csv")
    for (line <- Source.fromInputStream( in).getLines) {
      val split = Splitter.on(",").trimResults().split(line).asScala.toArray
      brandMap.put(split(0), split(1))
    }
    in.close()

    brandMap.toMap
  }

  def getDaPpDataset(spark: SparkSession): Dataset[DaPp] = {
    import spark.implicits._

    spark.read
      .format("csv")
      .options(Map(
        "delimiter" -> "^",
        "nullValue" -> "\\N",
        "quote" -> ""))
      .schema(ScalaReflection.schemaFor[DaPp].dataType.asInstanceOf[StructType])
      .load(s"/mis/da_pp/${LocalDate.now().minusDays(1).toString("yyyy/MM/dd")}/*")
      .as[DaPp]
      .map(i => {
        if ("D".equals(i.YT)) i.copy(YT = "1")
        else i.copy(YT = "2")
      })
  }

  def execute(spark: SparkSession, appName: String, startDate: LocalDate, endDate: LocalDate): Unit = {
    val executor = executorMap(appName)
    if (executor != null) {
      for (offset <- 0 to Days.daysBetween(startDate, endDate).getDays) {
        val date = startDate.plusDays(offset)
        executor.execute(spark, appName, date)
      }
    }
  }

}
