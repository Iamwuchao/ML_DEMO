package com.tgou.data.stanford.tempdata.dianpushangpin

import com.tgou.data.stanford.tempdata.core.TempDataBootstrap
import org.apache.spark.sql._
import org.joda.time.LocalDate


/**
  * Created by 李磊 on 2018/1/31.
  * 店铺商品统计
  */

object DianPuShangPin {

  def main(args: Array[String]): Unit = {
    TempDataBootstrap(args).bootstrap(execute)
  }

  def execute(spark: SparkSession, appName: String, date: LocalDate): Unit = {

    /**
      * 第一步 获取数据
      * */
    //天狗支付概况
    val DianPuShangPin = getTansDF(spark, date)


    /**
      * 第二步 拼接数据
      * */
    val result = DianPuShangPin

    /**
      * 第三步 保存数据到HDFS上
      * */

    result.select(columns(spark): _*).coalesce(2).write.format("csv").option("delimiter", ",").option("nullValue", " ").mode(SaveMode.Overwrite).save(s"/tmp/lilei/DianPuShangPin/")
    spark.stop()

  }

  def getTansDF(spark:SparkSession, date: LocalDate): DataFrame = {



    val resultDF = spark.sql(
      s"""
         |select a.listing_id,
         |b.barcode,
         |a.name as namep,
         |b.weight,
         |b.unit,
         |a.price,
         |c.name as namec,
         |b.brand_name,
         |case when a.state = 'onshelf' then '上架'
         |     when a.state = 'offshelf' then '下架'
         |     when a.state = 'deleted' then '删除'
         |     when a.state = 'offline' then '线下'
         |     when a.state = 'draft' then '草稿'
         |     when a.state = 'haltSale' then '停售'
         |     when a.state = 'pending' then '待审核'
         |     when a.state = 'rejected' then '打回'
         |end as state
         |from dw.listing a
         |join dw.product b
         |on a.product_id = b.product_id
         |and b.his_time = '2018-02-10'
         |join dw.category c
         |on b.product_third_category = c.id
         |and c.his_time = '2018-02-10'
         |where a.his_time = '2018-02-10'
         |and a.store_id = '1265'
      """.stripMargin)

    return resultDF
  }

  def columns(spark: SparkSession): Seq[Column] = {
    import org.apache.spark.sql.functions._

    Seq(
      column("listing_id"),
      column("barcode"),
      column("namep"),
      column("weight"),
      column("unit"),
      column("price"),
      column("namec"),
      column("brand_name"),
      column("state")
    )
  }


}