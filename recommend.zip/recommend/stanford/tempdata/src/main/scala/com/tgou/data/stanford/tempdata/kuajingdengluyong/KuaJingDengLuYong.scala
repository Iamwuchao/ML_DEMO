package com.tgou.data.stanford.tempdata.kuajingdengluyong

import com.tgou.data.stanford.tempdata.core.TempDataBootstrap
import org.apache.spark.sql._
import org.joda.time.LocalDate

/**
  * Created by 李磊 on 2018/1/31.
  * 跨境登录用户
  */

object KuaJingDengLuYong {

  def main(args: Array[String]): Unit = {
    TempDataBootstrap(args).bootstrap(execute)
  }

  def execute(spark: SparkSession, appName: String, date: LocalDate): Unit = {

    /**
      * 第一步 获取数据
      * */
    //天狗支付概况
    val kuaJingDengLuYong = getTansDF(spark, date)


    /**
      * 第二步 拼接数据
      * */
    val result = kuaJingDengLuYong

    /**
      * 第三步 保存数据到HDFS上
      * */
    result.select(columns(spark): _*).coalesce(2).write.format("csv").option("delimiter", ",").option("nullValue", " ").mode(SaveMode.Overwrite).save(s"/tmp/lilei/KuaJingDengLuYong/$date")
    spark.stop()

  }

  def getTansDF(spark:SparkSession, date: LocalDate): DataFrame = {

    var his_time = date.toString("yyyy-MM-dd")

    var end = date.plusDays(1).toString("yyyy-MM-dd")

    var start = date.plusDays(-7).toString("yyyy-MM-dd")


    val resultDF = spark.sql(
      s"""
         |select  a1.member_id,a1.global
         |from (select member_id,global
         |from dw.uba_page a
         |where a.his_time >= '${start}'
         |and a.his_time < '${end}'
         |and isnull(member_id) = false
         |and member_id != ''
         |group by member_id,global) a1
         |left join (select a2.member_id
         |from dw.order_information a2
         |join dw.store s
         |on a2.store_id = s.id
         |and s.his_time = '${his_time}'
         |and s.yt = '4'
         |and s.is_international = '1'
         |where a2.his_time = '${his_time}'
         |and a2.order_source = '4'
         |group by a2.member_id) a3
         |on  a1.member_id = a3.member_id
         |where isnull(a3.member_id) = true
      """.stripMargin)

    return resultDF
  }

  def columns(spark: SparkSession): Seq[Column] = {
    import org.apache.spark.sql.functions._

    Seq(
      column("member_id"),
      column("global")
    )
  }

}