package com.tgou.data.stanford.tempdata.brand

import com.tgou.data.stanford.tempdata.core.TempDataBootstrap
import org.apache.spark.sql.{Column, DataFrame, SaveMode, SparkSession}
import org.joda.time.LocalDate


/**
  * Created by 李磊 on 2018/1/31.
  * 品牌-线下
  */



object BrandXianXia {
  def main(args: Array[String]): Unit = {
    TempDataBootstrap(args).bootstrap(execute)
  }

  def execute(spark: SparkSession, appName: String, date: LocalDate): Unit = {

    /**
      * 第一步 获取数据
      * */
    //天狗支付概况
    val DianPuShangPin = getTansDF(spark, date)


    /**
      * 第二步 拼接数据
      * */
    val result = DianPuShangPin

    /**
      * 第三步 保存数据到HDFS上
      * */

    result.select(columns(spark): _*).coalesce(2).write.format("csv").option("delimiter", ",").option("nullValue", " ").mode(SaveMode.Overwrite).save(s"/tmp/lilei/BrandXianXia/")
    spark.stop()

  }

  def getTansDF(spark:SparkSession, date: LocalDate): DataFrame = {



    val resultDF = spark.sql(
      s"""
         |select a.ppmc,a.ppbm,aa.je as je2016,bb.je as je2017
         |from
         |dw.da_pp a
         |left join
         |(
         |select pz.ppbm,sum(pz.je) je
         |  from dw.pos_mx pz
         |  where pz.his_time>='2016-07-01'
         |  and pz.his_time<'2017-01-01'
         |  and pz.yt='D'
         |  group by pz.ppbm
         |)aa on a.ppbm=aa.ppbm
         |left join
         |(
         |select pz.ppbm,sum(pz.je) je
         |  from dw.pos_mx pz
         |  where pz.his_time>='2017-01-01'
         |  and pz.his_time<'2018-01-01'
         |  and pz.yt='D'
         |  group by pz.ppbm
         |)bb on a.ppbm=bb.ppbm
         |where a.his_time='2018-03-16'
         |and a.yt='D'
      """.stripMargin)

    return resultDF
  }

  def columns(spark: SparkSession): Seq[Column] = {
    import org.apache.spark.sql.functions._

    Seq(
      column("ppmc"),
      column("ppbm"),
      column("je2016"),
      column("je2017")
    )
  }
}