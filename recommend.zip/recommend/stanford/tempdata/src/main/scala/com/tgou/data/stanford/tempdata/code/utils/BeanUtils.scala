package com.tgou.data.stanford.tempdata.core.utils

import scala.reflect.runtime.universe._

import org.apache.spark.sql.catalyst.ScalaReflection
import org.apache.spark.sql.types.StructType

/**
  * Created by 李磊 on 2018/1/31.
  */
object BeanUtils {

  def getSchemaFromBean[T : TypeTag]: StructType = {
    ScalaReflection.schemaFor[T].dataType.asInstanceOf[StructType]
  }

}