package com.tgou.data.stanford.tempdata.kuajing

import com.tgou.data.stanford.tempdata.core.TempDataBootstrap
import org.apache.spark.sql._
import org.joda.time.LocalDate


/**
  * Created by 李磊 on 2018/1/31.
  * 跨境用户交易3次以上统计
  */

object MemberXiaoFei3 {
  def main(args: Array[String]): Unit = {
    TempDataBootstrap(args).bootstrap(execute)
  }

  def execute(spark: SparkSession, appName: String, date: LocalDate): Unit = {
    /**
      * 第一步 获取数据
      * */



    val result1 = getTansDF(spark, date)


    /**
      * 第二步 保存数据到HDFS上
      * */
    result1.select(columns(spark): _*).coalesce(6).write.format("csv").option("delimiter", ",").option("nullValue", " ").mode(SaveMode.Overwrite).save(s"/tmp/lilei/MemberXiaoFei3/$date")
    spark.stop()

  }
  def getTansDF(spark:SparkSession, date: LocalDate): DataFrame = {

    val resultDF = spark.sql(
      s"""
         |select m.cell_phone,
         |m1.bs,
         |m1.je
         |from (select member_id,
         |count(order_id) as bs,
         |sum(total_amount) as je
         |from dw.order_information a
         |join dw.store s
         |on  a.store_id  = s.id
         |and s.his_time = '2018-04-25'
         |and s.state = 'onshelf'
         |and s.yt = '4'
         |and s.is_international = '1'
         |where a.his_time = '2018-04-25'
         |and a.pay_time >= '2018-01-01'
         |and a.pay_time < '2018-04-13'
         |and a.pay_method != '010'
         |group by member_id
         |having count(order_id) > 2) m1
         |join dw.member m
         |on m1.member_id = m.member_id
         |and m.his_time = '2018-04-25'
      """.stripMargin)

    return resultDF
  }


  def columns(spark: SparkSession): Seq[Column] = {
    import org.apache.spark.sql.functions._

    Seq(
      column("cell_phone"),
      column("bs"),
      column("je")
    )
  }

}