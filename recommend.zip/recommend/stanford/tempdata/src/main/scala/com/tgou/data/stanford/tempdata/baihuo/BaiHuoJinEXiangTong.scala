package com.tgou.data.stanford.tempdata.baihuo

import com.tgou.data.stanford.tempdata.core.TempDataBootstrap
import org.apache.spark.sql._
import org.joda.time.LocalDate


/**
  * Created by 李磊 on 2018/1/31.
  * 百货-金额相同订单
  */

object BaiHuoJinEXiangTong {
  def main(args: Array[String]): Unit = {
    TempDataBootstrap(args).bootstrap(execute)
  }

  def execute(spark: SparkSession, appName: String, date: LocalDate): Unit = {
    /**
      * 第一步 获取数据
      * */

    val result = getTansDF(spark, date)

    /**
      * 第二步 保存数据到HDFS上
      * */
    result.select(columns(spark): _*).coalesce(2).write.format("csv").option("delimiter", ",").option("nullValue", " ").mode(SaveMode.Overwrite).save(s"/tmp/lilei/BaiHuoJinEXiangTong/$date")
    spark.stop()

  }
  def getTansDF(spark:SparkSession, date: LocalDate): DataFrame = {


    val tgouOrder = spark.read.format("csv")
      .option("delimiter", "^")
      .option("qoute", "")
      .option("nullValue", "\\N")
      .load("hdfs://nameservice1/tiangou/tgouorder/tgou_order/*/*/*/*")

    val tgouOrderS = tgouOrder.select("_c0","_c1","_c2","_c4","_c6","_c8","_c11","_c13","_c18","_c19","_c20").toDF("id","fk_member_id","total_amount","state","create_time","pay_method","store_id","source","receive_type","fixed_tags","modify_time")

    var tgouOrderMax = tgouOrderS.groupBy("id").agg(functions.max("modify_time") as "modify_time")

    var tgouOrderY = tgouOrderS.join(tgouOrderMax,
      tgouOrderS("id") === tgouOrderMax("id")
        &&  tgouOrderS("modify_time") === tgouOrderMax("modify_time")
      ,"inner"
    ).select(
      tgouOrderS("id") ,
      tgouOrderS("fk_member_id") ,
      tgouOrderS("total_amount") ,
      tgouOrderS("state") ,
      tgouOrderS("create_time") ,
      tgouOrderS("pay_method"),
      tgouOrderS("store_id"),
      tgouOrderS("source"),
      tgouOrderS("receive_type"),
      tgouOrderS("fixed_tags")
    )

    var tgouOrderYY = tgouOrderY.groupBy("id").agg(functions.max("fk_member_id") as "fk_member_id", functions.max("total_amount") as "total_amount" ,functions.max("state") as "state", functions.max("create_time") as "create_time", functions.max("pay_method") as "pay_method", functions.max("receive_type") as "receive_type", functions.max("store_id") as "store_id",functions.max("source") as "source", functions.max("fixed_tags") as "fixed_tags")

    tgouOrderY.createOrReplaceTempView("tgou_order_lilei")

    val resultDF = spark.sql(
      s"""
         |select s.store_name,
         |co.name,
         |z1.tgou_order_id,
         |z1.create_time,
         |z1.product_name,
         |z1.state,
         |z1.cell_phone
         |from (select
         |x1.sj2 - x2.sj2 as sc,
         |x1.total_amount,
         |x1.store_id,
         |x1.counter_id,
         |x1.tgou_order_id,
         |x1.create_time,
         |x1.product_name,
         |x1.state,
         |x1.cell_phone
         |from (select b.total_amount,substr(b.create_time,0,10) as sj1,
         |concat(substr(b.create_time,12,2),substr(b.create_time,15,2)) as sj2,
         |b.store_id,a.counter_id,a.tgou_order_id,b.create_time,a.product_name,b.state,me.cell_phone
         |from dw.order_product a
         |join tgou_order_lilei b
         |on a.tgou_order_id = b.id
         |and b.create_time >= '2018-03-15'
         |and b.create_time < '2018-04-01'
         |and substr(b.fixed_tags,0,1) = '0'
         |and b.source = '1'
         |left join dw.member me
         |on b.fk_member_id = me.member_id
         |and me.his_time = '2018-04-07'
         |where a.his_time = '2018-03-31'
         |and a.create_time >= '2018-03-15'
         |and a.create_time < '2018-04-01'
         |and a.product_source = '1') x1
         |join (select b.total_amount,substr(b.create_time,0,10) as sj1,
         |concat(substr(b.create_time,12,2),substr(b.create_time,15,2)) as sj2,
         |b.store_id,a.counter_id,a.tgou_order_id,me.cell_phone
         |from dw.order_product a
         |join tgou_order_lilei b
         |on a.tgou_order_id = b.id
         |and b.create_time >= '2018-03-15'
         |and b.create_time < '2018-04-01'
         |and substr(b.fixed_tags,0,1) = '0'
         |and b.source = '1'
         |left join dw.member me
         |on b.fk_member_id = me.member_id
         |and me.his_time = '2018-04-07'
         |where a.his_time = '2018-03-31'
         |and a.create_time >= '2018-03-15'
         |and a.create_time < '2018-04-01'
         |and a.product_source = '1') x2
         |on x1.store_id = x2.store_id
         |and x1.counter_id = x2.counter_id
         |and x1.sj1 = x2.sj1
         |and x1.total_amount = x2.total_amount
         |and x1.cell_phone != x2.cell_phone
         |and x1.tgou_order_id != x2.tgou_order_id) z1
         |left join dw.store s
         |on z1.store_id = s.id
         |and s.his_time = '2018-04-07'
         |and s.state = 'onshelf'
         |left join dw.counter co
         |on z1.counter_id = co.id
         |and co.his_time = '2018-04-07'
         |where z1.sc <= 10 and z1.sc >= -10
         |group by s.store_name,
         |co.name,
         |z1.tgou_order_id,
         |z1.create_time,
         |z1.product_name,
         |z1.state,
         |z1.cell_phone
         |order by s.store_name,
         |co.name,z1.create_time
      """.stripMargin)

    return resultDF
  }

  def columns(spark: SparkSession): Seq[Column] = {
    import org.apache.spark.sql.functions._

    Seq(
      column("store_name"),
      column("name"),
      column("tgou_order_id"),
      column("create_time"),
      column("product_name"),
      column("state"),
      column("cell_phone")
    )
  }
}