package com.tgou.data.stanford.tempdata.xianxia

import com.tgou.data.stanford.tempdata.core.TempDataBootstrap
import org.apache.spark.sql._
import org.joda.time.LocalDate


/**
  * Created by 李磊 on 2018/1/31.
  * 澳牛用户购买统计
  */

object AoNiuMember {
  def main(args: Array[String]): Unit = {
    TempDataBootstrap(args).bootstrap(execute)
  }

  def execute(spark: SparkSession, appName: String, date: LocalDate): Unit = {
    /**
      * 第一步 获取数据
      * */



    val result1 = getTansDF(spark, date)


    /**
      * 第二步 保存数据到HDFS上
      * */
    result1.select(columns(spark): _*).coalesce(5).write.format("csv").option("delimiter", ",").option("nullValue", " ").mode(SaveMode.Overwrite).save(s"/tmp/lilei/AoNiuMember/$date")
    spark.stop()

  }
  def getTansDF(spark:SparkSession, date: LocalDate): DataFrame = {

    val resultDF = spark.sql(
      s"""
         |select zz.cell_phone,
         |zz.member_id,
         |count(zz.jysbm) as bs,
         |max(zz.his_time) as sj
         |from (select case when isnull(m.cell_phone) = false then m.cell_phone else mi.mblphone end as cell_phone,
         |case when isnull(m.cell_phone) = false then m.member_id end as member_id ,
         |a.jysbm,
         |a.his_time
         |from dw.pos_mx a
         |left join dw.ds_card_bind d
         |on a.cid = d.card_id
         |and d.his_time = '2018-04-27'
         |left join dw.member m
         |on d.member_id  = m.member_id
         |and m.his_time = '2018-04-27'
         |left join dw.mmc_info mi
         |on a.cid = mi.cid
         |and mi.his_time = '2018-04-27'
         |and isnull(mi.mblphone) = false
         |and length(mi.mblphone) = 11
         |where a.his_time >= '2018-01-01'
         |and  a.his_time < '2018-04-28'
         |and a.storecode in ('6200',
         |'0369',
         |'6202',
         |'1004',
         |'1043',
         |'1035',
         |'1002',
         |'6235',
         |'6205',
         |'1062',
         |'6462',
         |'6360')
         |and a.yt = 'S'
         |and a.flh2 = '03110000'
         |and isnull(a.cid) = false
         |union all
         |select case when isnull(m.cell_phone) = false then m.cell_phone else mi.mblphone end as cell_phone,
         |case when isnull(m.cell_phone) = false then m.member_id end as member_id ,
         |a.jysbm,
         |a.his_time
         |from dw.pos_mx a
         |left join dw.ds_card_bind d
         |on a.cid = d.card_id
         |and d.his_time = '2018-04-27'
         |left join dw.member m
         |on d.member_id  = m.member_id
         |and m.his_time = '2018-04-27'
         |left join dw.mmc_info mi
         |on a.cid = mi.cid
         |and mi.his_time = '2018-04-27'
         |and isnull(mi.mblphone) = false
         |and length(mi.mblphone) = 11
         |where a.his_time >= '2018-01-01'
         |and  a.his_time < '2018-04-28'
         |and a.storecode in ('6200',
         |'0369',
         |'6202',
         |'1004',
         |'1043',
         |'1035',
         |'1002',
         |'6235',
         |'6205',
         |'1062',
         |'6462',
         |'6360')
         |and a.yt = 'D'
         |and a.flh2 = '07120000'
         |and isnull(a.cid) = false) zz
         |where isnull(zz.cell_phone) = false
         |group by zz.cell_phone,
         |zz.member_id
      """.stripMargin)

    return resultDF
  }


  def columns(spark: SparkSession): Seq[Column] = {
    import org.apache.spark.sql.functions._

    Seq(
      column("cell_phone"),
      column("member_id"),
      column("bs"),
      column("sj")
    )
  }

}