package com.tgou.data.stanford.tempdata.ziying

import com.tgou.data.stanford.tempdata.core.TempDataBootstrap
import org.apache.spark.sql._
import org.joda.time.LocalDate


/**
  * Created by 李磊 on 2018/1/31.
  * 自营-卷使用明细
  */

object ZiYingJuan {
  def main(args: Array[String]): Unit = {
    TempDataBootstrap(args).bootstrap(execute)
  }

  def execute(spark: SparkSession, appName: String, date: LocalDate): Unit = {
    /**
      * 第一步 获取数据
      * */

    val result = getTansDF(spark, date)
    val result2 = getTansDF2(spark, date)

    /**
      * 第二步 保存数据到HDFS上
      * */
    result.select(columns(spark): _*).coalesce(2).write.format("csv").option("delimiter", ",").option("nullValue", " ").mode(SaveMode.Overwrite).save(s"/tmp/lilei/ZiYingJuan/ju/$date")
    result2.select(columns2(spark): _*).coalesce(2).write.format("csv").option("delimiter", ",").option("nullValue", " ").mode(SaveMode.Overwrite).save(s"/tmp/lilei/ZiYingJuan/mx/$date")
    spark.stop()

  }
  def getTansDF(spark:SparkSession, date: LocalDate): DataFrame = {

   var his = date.toString("yyyy-MM-dd")


    //var  sDate = date.toString("yyyy-MM-dd")

    //var endDate = date.plusDays(1).toString("yyyy-MM-dd")


    var  sDate = "2018-04-01"
   var endDate = "2018-05-01"


    val resultDF = spark.sql(
      s"""
         |
         |select x1.fk_coupon_id,
         |x1.coupon_code,
         |c.his_time,
         |x1.jysbm,
         |max(nvl(case when c.FKFSH = '90' then c.FKJE end,0)) 90je,
         |max(nvl(case when c.FKFSH = '81' then c.FKJE end,0)) 81je,
         |max(nvl(case when c.FKFSH = '86' then c.FKJE end,0)) 86je,
         |-- max(nvl(case when c.FKFSH not in ( '90','81','86') then c.FKJE end,0)) qtje
         |sum(nvl(case when c.FKFSH != '90' and c.FKFSH != '81' and c.FKFSH != '86' then c.FKJE end,0)) qtje
         |from (select a.fk_coupon_id,a.coupon_code,b.jysbm
         |from dw.coupon_code a
         |join dw.pos_fk b
         |on a.coupon_code_id = b.COUPON_CODE
         |and b.his_time >= '${sDate}'
         |and b.his_time < '${endDate}'
         |where a.his_time =  '${his}'
         |--and a.fk_coupon_id  in ('1215375','1215043','1215064','1215045','1216601','1216600','1216598','1216599','1216597','1216596','1216595','1216594','1216593','1216592','1216591','1216590','1216589','1216588','1216587','1216585','1216583','1216582','1216581','1216580','1216575')
         |and a.fk_coupon_id  in ('1216580')
         |) x1
         |join dw.pos_fk c
         |on x1.jysbm = c.jysbm
         |and c.his_time >= '${sDate}'
         |and c.his_time < '${endDate}'
         |group by x1.fk_coupon_id,
         |x1.coupon_code,
         |c.his_time,
         |x1.jysbm
      """.stripMargin)



    return resultDF
  }

  def getTansDF2(spark:SparkSession, date: LocalDate): DataFrame = {

    var his = date.toString("yyyy-MM-dd")


    //var  sDate = date.toString("yyyy-MM-dd")

    //var endDate = date.plusDays(1).toString("yyyy-MM-dd")


    var  sDate = "2018-04-01"
    var endDate = "2018-05-01"





    val resultDF = spark.sql(
      s"""
         |
         |select
         |z.his_time,
         |z.jysbm,
         |d.PINM
         |from(select
         |c.his_time,
         |x1.jysbm
         |from (select a.fk_coupon_id,a.coupon_code,b.jysbm
         |from dw.coupon_code a
         |join dw.pos_fk b
         |on a.coupon_code_id = b.COUPON_CODE
         |and b.his_time >= '${sDate}'
         |and b.his_time < '${endDate}'
         |where a.his_time =  '${his}'
         |--and a.fk_coupon_id  in ('1215375','1215043','1215064','1215045','1216601','1216600','1216598','1216599','1216597','1216596','1216595','1216594','1216593','1216592','1216591','1216590','1216589','1216588','1216587','1216585','1216583','1216582','1216581','1216580','1216575')
         |and a.fk_coupon_id  in ('1216580')
         |) x1
         |join dw.pos_fk c
         |on x1.jysbm = c.jysbm
         |and c.his_time >= '${sDate}'
         |and c.his_time < '${endDate}'
         |group by
         |c.his_time,
         |x1.jysbm) z
         |join dw.pos_mx d
         |on  z.jysbm = d.jysbm
         |and d.his_time >= '${sDate}'
         |and d.his_time < '${endDate}'
      """.stripMargin)

    return resultDF
  }

  def columns(spark: SparkSession): Seq[Column] = {
    import org.apache.spark.sql.functions._

    Seq(
      column("fk_coupon_id"),
      column("coupon_code"),
      column("his_time"),
      column("jysbm"),
      column("90je"),
      column("81je"),
      column("86je"),
      column("qtje")
    )
  }

  def columns2(spark: SparkSession): Seq[Column] = {
    import org.apache.spark.sql.functions._

    Seq(
      column("his_time"),
      column("jysbm"),
      column("PINM")
    )
  }
}