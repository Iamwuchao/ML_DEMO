package com.tgou.data.stanford.tempdata.dianzixiaopiao

import com.tgou.data.stanford.tempdata.core.TempDataBootstrap
import org.apache.spark.sql._
import org.joda.time.LocalDate


/**
  * Created by 李磊 on 2018/1/31.
  * 电子小票
  */

object DianZiXiaoPiao {

  def main(args: Array[String]): Unit = {
    TempDataBootstrap(args).bootstrap(execute)
  }

  def execute(spark: SparkSession, appName: String, date: LocalDate): Unit = {

    /**
      * 第一步 获取数据
      * */
    //天狗支付概况
    val dianZiXiaoPiao = getTansDF(spark, date)


    /**
      * 第二步 拼接数据
      * */
    val result = dianZiXiaoPiao

    /**
      * 第三步 保存数据到HDFS上
      * */
    result.select(columns2(spark): _*).coalesce(2).write.format("csv").option("delimiter", ",").option("nullValue", " ").mode(SaveMode.Overwrite).save(s"/tmp/lilei/DianZiXiaoPiao/")
    spark.stop()

  }

  def getTansDF(spark:SparkSession, date: LocalDate): DataFrame = {

    var his_time = "2018-02-01"

    var end = "2018-02-02"

    var etl_time = "2018-02-01 00:00:00"


//    val resultDF = spark.sql(
//      s"""
//         |select s.area_name,
//         |s.store_name,
//         |l.sold_area_name,
//         |l.counter_name,
//         |l.listing_id,
//         |l.name,
//         |count(distinct order_id) as bs
//         |from dw.order_product a
//         |join dw.order_information b
//         |on a.tgou_order_id = b.order_id
//         |and b.his_time = '2018-02-05'
//         |and substr(nvl(b.ship_time,'1000000000'),0,10) = substr(nvl(b.pay_time,'1000000000'),0,10)
//         |and b.pay_time >= '2018-01-01'
//         |and b.pay_time < '2018-02-06'
//         |and b.pay_method != '010'
//         |and b.receive_method in ('00','01')
//         |and b.order_source = '1'
//         |join dw.store s
//         |on b.store_id = s.id
//         |and s.his_time = '2018-02-05'
//         |and s.state = 'onshelf'
//         |join dw.listing l
//         |on a.mall_product_id = l.listing_id
//         |and a.sold_area_id = l.sold_area_id
//         |and a.counter_id = l.counter_id
//         |and l.his_time = '2018-02-05'
//         |where a.his_time = '2018-02-05'
//         |group by s.area_name,
//         |s.store_name,
//         |l.sold_area_name,
//         |l.counter_name,
//         |l.listing_id,
//         |l.name
//         |having count(distinct order_id) > 49
//      """.stripMargin)

    val resultDF = spark.sql(
      s"""
         |select s.area_name,
         |s.store_name,
         |l.sold_area_name,
         |l.counter_name,
         |l.listing_id,
         |l.name,
         |a.product_price,
         |count(distinct order_id) as bs
         |from dw.order_product a
         |join dw.order_information b
         |on a.tgou_order_id = b.order_id
         |and b.his_time = '2018-02-05'
         |and substr(nvl(b.ship_time,'1000000000'),0,10) = substr(nvl(b.pay_time,'1000000000'),0,10)
         |and b.pay_time >= '2018-01-01'
         |and b.pay_time < '2018-02-06'
         |and b.pay_method != '010'
         |and b.receive_method in ('00','01')
         |and b.order_source = '1'
         |join dw.store s
         |on b.store_id = s.id
         |and s.his_time = '2018-02-05'
         |and s.state = 'onshelf'
         |join dw.listing l
         |on a.mall_product_id = l.listing_id
         |and a.sold_area_id = l.sold_area_id
         |and a.counter_id = l.counter_id
         |and l.his_time = '2018-02-05'
         |where a.his_time = '2018-02-05'
         |and a.mall_product_id  in ('11970172',
         |'11174141',
         |'12494411',
         |'12483699',
         |'11199717',
         |'11999203',
         |'12202108',
         |'11279943',
         |'12124586',
         |'12399715',
         |'12313922',
         |'12396411',
         |'12458264',
         |'12458195',
         |'12423147',
         |'11821482',
         |'11214246',
         |'12170800',
         |'11201652',
         |'12492788',
         |'12375607',
         |'12265426',
         |'12558483',
         |'11871024',
         |'12093846',
         |'12291673',
         |'12458251',
         |'12458315',
         |'12407267',
         |'12068587')
         |group by s.area_name,
         |s.store_name,
         |l.sold_area_name,
         |l.counter_name,
         |l.listing_id,
         |l.name,
         |a.product_price
      """.stripMargin)

    return resultDF
  }

  def columns(spark: SparkSession): Seq[Column] = {
    import org.apache.spark.sql.functions._

    Seq(
      column("area_name"),
      column("store_name"),
      column("sold_area_name"),
      column("counter_name"),
      column("listing_id"),
      column("name"),
      column("bs")
    )
  }

  def columns2(spark: SparkSession): Seq[Column] = {
    import org.apache.spark.sql.functions._

    Seq(
      column("area_name"),
      column("store_name"),
      column("sold_area_name"),
      column("counter_name"),
      column("listing_id"),
      column("name"),
      column("product_price"),
      column("bs")
    )
  }
}