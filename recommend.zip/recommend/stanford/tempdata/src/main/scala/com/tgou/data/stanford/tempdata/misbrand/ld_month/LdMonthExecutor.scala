package com.tgou.data.stanford.tempdata.misbrand.ld_month

import com.tgou.data.stanford.tempdata.misbrand.bean.LdDetailMonthMarket
import com.tgou.data.stanford.tempdata.misbrand.{Application, Executor}
import org.apache.spark.sql.{SaveMode, SparkSession}
import org.apache.spark.sql.catalyst.ScalaReflection
import org.apache.spark.sql.types.StructType
import org.joda.time.LocalDate

/**
  * Created by 李震 on 2018/5/3.
  */
object LdMonthExecutor extends Executor {

  override def execute(spark: SparkSession, appName: String, date: LocalDate): Unit = {
    import spark.implicits._

    val brandBc = spark.sparkContext.broadcast(Application.getBrandMap)

    val daPpDs = Application.getDaPpDataset(spark)

    val ldDetailMonthMarketDs = spark.read
      .format("csv")
      .options(Map(
        "delimiter" -> "^",
        "nullValue" -> "\\N",
        "quote" -> ""))
      .schema(ScalaReflection.schemaFor[LdDetailMonthMarket].dataType.asInstanceOf[StructType])
      .load(s"/mis_market/sqoop/ld-detail-month-market/${date.toString("yyyy/MM/dd")}/*")
      .as[LdDetailMonthMarket]
      .map(i => {
        val brandMap = brandBc.value
        if (brandMap.keySet.contains(i.PPBM)) i.copy(PPBM = brandMap(i.PPBM)) else i
      })

    val r = ldDetailMonthMarketDs.join(
        daPpDs,
        ldDetailMonthMarketDs.col("PPBM") === daPpDs.col("PPBM") && ldDetailMonthMarketDs.col("YT") === daPpDs.col("YT"),
        "left_outer")
      .select(
        ldDetailMonthMarketDs.col("ID"),
        ldDetailMonthMarketDs.col("STORECODE"),
        ldDetailMonthMarketDs.col("YT"),
        ldDetailMonthMarketDs.col("YZH"),
        ldDetailMonthMarketDs.col("YZM"),
        ldDetailMonthMarketDs.col("MQH"),
        ldDetailMonthMarketDs.col("MQM"),
        ldDetailMonthMarketDs.col("PPBM"),
        daPpDs.col("PPMC"),
        ldDetailMonthMarketDs.col("COUPONLDJE"),
        ldDetailMonthMarketDs.col("COUPONLDBS"),
        ldDetailMonthMarketDs.col("COUPONLDRS"),
        ldDetailMonthMarketDs.col("ORDERLDJE"),
        ldDetailMonthMarketDs.col("ORDERLDBS"),
        ldDetailMonthMarketDs.col("ORDERLDRS"),
        ldDetailMonthMarketDs.col("JIESUANMAJYJE"),
        ldDetailMonthMarketDs.col("JIESUANMAJYBS"),
        ldDetailMonthMarketDs.col("JIESUANMAJYRS"),
        ldDetailMonthMarketDs.col("TOTALLDJE"),
        ldDetailMonthMarketDs.col("TOTALLDBS"),
        ldDetailMonthMarketDs.col("TOTALLDRS"),
        ldDetailMonthMarketDs.col("TOTAL_NON_RETURN_JYJE"),
        ldDetailMonthMarketDs.col("TOTAL_NON_RETURN_JYBS"),
        ldDetailMonthMarketDs.col("TOTAL_NON_RETURN_JYRS"),
        ldDetailMonthMarketDs.col("TOTAL_RETURN_JYJE"),
        ldDetailMonthMarketDs.col("TOTAL_RETURN_JYBS"),
        ldDetailMonthMarketDs.col("TOTAL_RETURN_JYRS"),
        ldDetailMonthMarketDs.col("DG_COUPONLDJE"),
        ldDetailMonthMarketDs.col("DG_COUPONLDBS"),
        ldDetailMonthMarketDs.col("DG_COUPONLDRS"),
        ldDetailMonthMarketDs.col("DG_ORDERLDJE"),
        ldDetailMonthMarketDs.col("DG_ORDERLDBS"),
        ldDetailMonthMarketDs.col("DG_ORDERLDRS"),
        ldDetailMonthMarketDs.col("DG_JIESUANMAJYJE"),
        ldDetailMonthMarketDs.col("DG_JIESUANMAJYBS"),
        ldDetailMonthMarketDs.col("DG_JIESUANMAJYRS"),
        ldDetailMonthMarketDs.col("DG_TOTALLDJE"),
        ldDetailMonthMarketDs.col("DG_TOTALLDBS"),
        ldDetailMonthMarketDs.col("DG_TOTALLDRS"),
        ldDetailMonthMarketDs.col("DG_TOTAL_NON_RETURN_JYJE"),
        ldDetailMonthMarketDs.col("DG_TOTAL_NON_RETURN_JYBS"),
        ldDetailMonthMarketDs.col("DG_TOTAL_NON_RETURN_JYRS"),
        ldDetailMonthMarketDs.col("DG_TOTAL_RETURN_JYJE"),
        ldDetailMonthMarketDs.col("DG_TOTAL_RETURN_JYBS"),
        ldDetailMonthMarketDs.col("DG_TOTAL_RETURN_JYRS"),
        ldDetailMonthMarketDs.col("MARKET_TIME"),
        ldDetailMonthMarketDs.col("IDENTITY")
      )

    r.write
      .mode(SaveMode.Overwrite)
      .option("delimiter", "^")
      .option("quote", "")
      .option("nullValue", "\\N")
      .csv(s"/tmp/lz/data/${appName}/${date.toString("yyyy/MM/dd")}")
  }

}
