package com.tgou.data.stanford.tempdata.member

import com.tgou.data.stanford.tempdata.core.TempDataBootstrap
import org.apache.spark.sql._
import org.joda.time.LocalDate

/**
  * Created by 李磊 on 2018/1/31.
  * 跨境登录
  */

object KuaJingDenglu {
  def main(args: Array[String]): Unit = {
    TempDataBootstrap(args).bootstrap(execute)
  }

  def execute(spark: SparkSession, appName: String, date: LocalDate): Unit = {
    /**
      * 第一步 获取数据
      **/

    val result = getTansDF(spark, date)

    /**
      * 第二步 保存数据到HDFS上
      **/
    //result.select(columns(spark): _*).coalesce(2).write.format("csv").option("delimiter", ",").option("nullValue", " ").mode(SaveMode.Overwrite).save(s"/tmp/lilei/KuaJingDenglu/1/$date")
    result.select(columns(spark): _*).coalesce(6).write.format("csv").option("delimiter", ",").option("nullValue", " ").mode(SaveMode.Overwrite).save(s"/tmp/lilei/KuaJingDenglu/2/$date")
    spark.stop()

  }

  def getTansDF(spark: SparkSession, date: LocalDate): DataFrame = {

//    val resultDF = spark.sql(
//      s"""
//         |select member_id,global
//         |from(select  a.member_id ,max(a.global) as global
//         |from dw.uba_page  a
//         |join dw.member b
//         |on a.member_id = b.member_id
//         |and b.his_time = '2018-03-18'
//         |and b.register_time < '2018-02-05'
//         |where a.his_time >= '2018-02-05'
//         |and a.his_time < '2018-03-19'
//         |and a.member_id != ''
//         |and a.global in ('ios','android')
//         |group by a.member_id
//         |having count(*) > 1)
//      """.stripMargin)

        val resultDF = spark.sql(
          s"""
             |select x1.member_id,x1.global
             |from(select  a.member_id ,max(a.global) as global
             |from dw.uba_page  a
             |join dw.member b
             |on a.member_id = b.member_id
             |and b.his_time = '2018-03-18'
             |and b.register_time < '2018-02-05'
             |where a.his_time >= '2018-02-05'
             |and a.his_time < '2018-03-19'
             |and a.member_id != ''
             |and a.global in ('webapp','wechat')
             |group by a.member_id
             |having count(*) > 1) x1
             |left join (select  a.member_id
             |from dw.uba_page  a
             |join dw.member b
             |on a.member_id = b.member_id
             |and b.his_time = '2018-03-18'
             |and b.register_time < '2018-02-05'
             |where a.his_time >= '2018-02-05'
             |and a.his_time < '2018-03-19'
             |and a.member_id != ''
             |and a.global in ('ios','android')
             |group by a.member_id
             |having count(*) > 1) x2
             |on x1.member_id = x2.member_id
             |where isnull(x2.member_id) = true
          """.stripMargin)

    return resultDF
  }

  def columns(spark: SparkSession): Seq[Column] = {
    import org.apache.spark.sql.functions._

    Seq(
      column("member_id"),
      column("global")
    )
  }

}