package com.tgou.data.stanford.tempdata.misbrand.bean

/**
  * Created by 李震 on 2018/5/3.
  */
case class SaomaDetail (
                         ID: String,
                         STORECODE: String,
                         YT: String,
                         YEZHONGH: String,
                         YEZHONGM: String,
                         MAIQUH: String,
                         MAIQUM: String,
                         PPBM: String,
                         PPMC: String,
                         SAOMA_JYRS: String,
                         SAOMA_NEW_JYRS: String,
                         SAOMA_JYBS: String,
                         SAOMA_JYJE: String,
                         TOTAL_NON_RETURN_JYBS: String,
                         TOTAL_NON_RETURN_JYJE: String,
                         TOTAL_NON_RETURN_JYRS: String,
                         TOTAL_RETURN_JYBS: String,
                         TOTAL_RETURN_JYJE: String,
                         TOTAL_RETURN_JYRS: String,
                         IDENTITY: String,
                         MARKET_TIME: String
                       )
