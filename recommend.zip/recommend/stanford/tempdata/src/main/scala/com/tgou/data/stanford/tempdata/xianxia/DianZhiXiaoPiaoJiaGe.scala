package  com.tgou.data.stanford.tempdata.xianxia

import com.tgou.data.stanford.tempdata.core.TempDataBootstrap
import org.apache.spark.sql.{Column, DataFrame, SaveMode, SparkSession}
import org.joda.time.LocalDate


/**
  * Created by 李磊 on 2018/03/06.
  * 线下交易-电子小票价格区间
  */

object DianZhiXiaoPiaoJiaGe {
  def main(args: Array[String]): Unit = {
    TempDataBootstrap(args).bootstrap(execute)
  }

  def execute(spark: SparkSession, appName: String, date: LocalDate): Unit = {
    /**
      * 第一步 获取数据
      * */

    val result = getTansDF(spark, date)

    /**
      * 第二步 保存数据到HDFS上
      * */

    result.select(columns(spark): _*).coalesce(3).write.format("csv").option("delimiter", ",").option("nullValue", " ").mode(SaveMode.Overwrite).save(s"/tmp/lilei/DianZhiXiaoPiaoJiaGe//$date")

    spark.stop()

  }

  def getTansDF(spark:SparkSession, date: LocalDate): DataFrame = {

    val resultDF = spark.sql(
      s"""
         |select case
         |when a.SJ >= 0 and a.SJ <=  100      then  '0-100元'
         |when a.SJ >= 101 and a.SJ <=  200   then    '101元-200元'
         |when a.SJ >= 201 and a.SJ <=  300   then    '201元-300元'
         |when a.SJ >= 301 and a.SJ <=  400   then    '301元-400元'
         |when a.SJ >= 401 and a.SJ <=  500   then    '401元-500元'
         |when a.SJ >= 501 and a.SJ <=  600   then    '501元-600元'
         |when a.SJ >= 601 and a.SJ <=  700   then    '601元-700元'
         |when a.SJ >= 701 and a.SJ <=  800   then    '701元-800元'
         |when a.SJ >= 801 and a.SJ <=  900   then    '801元-900元'
         |when a.SJ >= 901 and a.SJ <=  1000  then    '901元-1000元'
         |when a.SJ >= 1001 and a.SJ <=  1100 then    '1001元-1100元'
         |when a.SJ >= 1001 and a.SJ <=  1100 then    '1001元-1100元'
         |when a.SJ >= 1201 and a.SJ <=  1300 then    '1201元-1300元'
         |when a.SJ >= 1301 and a.SJ <=  1400 then    '1301元-1400元'
         |when a.SJ >= 1401 and a.SJ <=  1500 then    '1401元-1500元'
         |when a.SJ >= 1501 and a.SJ <=  1600 then    '1501元-1600元'
         |when a.SJ >= 1601 and a.SJ <=  1700 then    '1601元-1700元'
         |when a.SJ >= 1701 and a.SJ <=  1800 then    '1701元-1800元'
         |when a.SJ >= 1801 and a.SJ <=  1900 then    '1801元-1900元'
         |when a.SJ >= 1901 and a.SJ <=  2000 then    '1901元-2000元'
         |when a.SJ >= 2001 and a.SJ <=  2100 then    '2001元-2100元'
         |when a.SJ >= 2101 and a.SJ <=  2200 then    '2101元-2200元'
         |when a.SJ >= 2201 and a.SJ <=  2300 then    '2201元-2300元'
         |when a.SJ >= 2301 and a.SJ <=  2400 then    '2301元-2400元'
         |when a.SJ >= 2401 and a.SJ <=  2500 then    '2401元-2500元'
         |when a.SJ >= 2501 and a.SJ <=  2600 then    '2501元-2600元'
         |when a.SJ >= 2601 and a.SJ <=  2700 then    '2601元-2700元'
         |when a.SJ >= 2701 and a.SJ <=  2800 then    '2701元-2800元'
         |when a.SJ >= 2801 and a.SJ <=  2900 then    '2801元-2900元'
         |when a.SJ >= 2901 and a.SJ <=  3000 then    '2901元-3000元'
         |when a.SJ >= 3001 then '3001元-及以上'
         |end as jg,
         |count(distinct xd.jysbm) as dzbs,
         |count(distinct a.jysbm) as bs
         |from dw.pos_mx a
         |left join (select b.jysbm
         |from dw.pos_fk b
         |where b.his_time >= '2018-01-01'
         |and b.his_time < '2018-03-01'
         |and b.FKFSH in ('78','79','87','76')
         |group by b.jysbm) xd
         |on a.jysbm = xd.jysbm
         |where a.his_time >= '2018-01-01'
         |and a.his_time < '2018-03-01'
         |and a.YT = 'D'
         |group by case
         |when a.SJ >= 0 and a.SJ <=  100      then  '0-100元'
         |when a.SJ >= 101 and a.SJ <=  200   then    '101元-200元'
         |when a.SJ >= 201 and a.SJ <=  300   then    '201元-300元'
         |when a.SJ >= 301 and a.SJ <=  400   then    '301元-400元'
         |when a.SJ >= 401 and a.SJ <=  500   then    '401元-500元'
         |when a.SJ >= 501 and a.SJ <=  600   then    '501元-600元'
         |when a.SJ >= 601 and a.SJ <=  700   then    '601元-700元'
         |when a.SJ >= 701 and a.SJ <=  800   then    '701元-800元'
         |when a.SJ >= 801 and a.SJ <=  900   then    '801元-900元'
         |when a.SJ >= 901 and a.SJ <=  1000  then    '901元-1000元'
         |when a.SJ >= 1001 and a.SJ <=  1100 then    '1001元-1100元'
         |when a.SJ >= 1001 and a.SJ <=  1100 then    '1001元-1100元'
         |when a.SJ >= 1201 and a.SJ <=  1300 then    '1201元-1300元'
         |when a.SJ >= 1301 and a.SJ <=  1400 then    '1301元-1400元'
         |when a.SJ >= 1401 and a.SJ <=  1500 then    '1401元-1500元'
         |when a.SJ >= 1501 and a.SJ <=  1600 then    '1501元-1600元'
         |when a.SJ >= 1601 and a.SJ <=  1700 then    '1601元-1700元'
         |when a.SJ >= 1701 and a.SJ <=  1800 then    '1701元-1800元'
         |when a.SJ >= 1801 and a.SJ <=  1900 then    '1801元-1900元'
         |when a.SJ >= 1901 and a.SJ <=  2000 then    '1901元-2000元'
         |when a.SJ >= 2001 and a.SJ <=  2100 then    '2001元-2100元'
         |when a.SJ >= 2101 and a.SJ <=  2200 then    '2101元-2200元'
         |when a.SJ >= 2201 and a.SJ <=  2300 then    '2201元-2300元'
         |when a.SJ >= 2301 and a.SJ <=  2400 then    '2301元-2400元'
         |when a.SJ >= 2401 and a.SJ <=  2500 then    '2401元-2500元'
         |when a.SJ >= 2501 and a.SJ <=  2600 then    '2501元-2600元'
         |when a.SJ >= 2601 and a.SJ <=  2700 then    '2601元-2700元'
         |when a.SJ >= 2701 and a.SJ <=  2800 then    '2701元-2800元'
         |when a.SJ >= 2801 and a.SJ <=  2900 then    '2801元-2900元'
         |when a.SJ >= 2901 and a.SJ <=  3000 then    '2901元-3000元'
         |when a.SJ >= 3001 then '3001元-及以上'
         |end
      """.stripMargin)

    return resultDF
  }

  def columns(spark: SparkSession): Seq[Column] = {
    import org.apache.spark.sql.functions._

    Seq(
      column("jg"),
      column("dzbs"),
      column("bs")
    )
  }
}