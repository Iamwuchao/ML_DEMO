package com.tgou.data.stanford.tempdata.misbrand.bean

/**
  * Created by 李震 on 2018/5/3.
  */
case class DaPp (
             PPBM: String,
             YT: String,
             PPMC: String,
             OPTIME: String
           )
