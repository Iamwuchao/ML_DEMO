package com.tgou.data.stanford.tempdata.misbrand

import org.apache.spark.sql.SparkSession
import org.joda.time.LocalDate

/**
  * Created by 李震 on 2018/5/3.
  */
trait Executor {

  def execute(spark: SparkSession, appName: String, date: LocalDate)

}
