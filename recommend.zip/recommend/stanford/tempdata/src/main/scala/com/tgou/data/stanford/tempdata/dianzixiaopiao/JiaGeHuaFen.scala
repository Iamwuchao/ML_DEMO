package com.tgou.data.stanford.tempdata.dianzixiaopiao

import com.tgou.data.stanford.tempdata.core.TempDataBootstrap
import org.apache.spark.sql._
import org.joda.time.LocalDate


/**
  * Created by 李磊 on 2018/1/31.
  * 电子小票-价格划分
  */

object JiaGeHuaFen {
  def main(args: Array[String]): Unit = {
    TempDataBootstrap(args).bootstrap(execute)
  }

  def execute(spark: SparkSession, appName: String, date: LocalDate): Unit = {
    /**
      * 第一步 获取数据
      **/



      val result = getTansDF(spark, date)
      /**
        * 第二步 保存数据到HDFS上
        **/
      result.select(columns(spark): _*).coalesce(2).write.format("csv").option("delimiter", ",").option("nullValue", " ").mode(SaveMode.Overwrite).save(s"/tmp/lilei/JiaGeHuaFen/m/$date")



    spark.stop()

  }

  def getTansDF(spark: SparkSession, date: LocalDate): DataFrame = {




    val resultDF = spark.sql(
      s"""
         |select zx.FLM2,
         |nvl(cast(sum(case when zx.jyje >0
         |and zx.jyje < 800
         | and zx.FKFSH not in ('84','82' ,'93')then zx.jyje end) as decimal(18,2)),0) as yhk1,
         |nvl(cast(sum(case when zx.jyje >0
         |and zx.jyje < 800
         | and zx.FKFSH = '84' then zx.jyje end) as decimal(18,2)),0) as weixin1,
         |nvl(cast(sum(case when zx.jyje >0
         |and zx.jyje < 800
         | and zx.FKFSH in ('82' ,'93')then zx.jyje end) as decimal(18,2)),0) as zfb1,
         |nvl(cast(sum(case when zx.jyje >800
         |and zx.jyje < 4001
         | and zx.FKFSH not in ('84','82' ,'93')then zx.jyje end) as decimal(18,2)),0) as yhk2,
         |nvl(cast(sum(case when zx.jyje >800
         |and zx.jyje < 4001
         | and zx.FKFSH = '84' then zx.jyje end) as decimal(18,2)),0) as weixin2,
         |nvl(cast(sum(case when zx.jyje >800
         |and zx.jyje < 4001
         | and zx.FKFSH in ('82' ,'93')then zx.jyje end) as decimal(18,2)),0) as zfb2,
         | nvl(cast(sum(case when zx.jyje >4000
         | and zx.FKFSH not in ('84','82' ,'93')then zx.jyje end) as decimal(18,2)),0) as yhk3,
         |nvl(cast(sum(case when zx.jyje >4000
         | and zx.FKFSH = '84' then zx.jyje end) as decimal(18,2)),0) as weixin3,
         |nvl(cast(sum(case when zx.jyje >4000
         | and zx.FKFSH in ('82' ,'93')then zx.jyje end) as decimal(18,2)),0) as zfb3
         |from (select max(m.FLM2) as FLM2,z.jysbm,z.jyje,fc.FKFSH
         |from dw.pos_zz z
         |join (select fz.jysbm,fz.FKFSH
         |from (select f.jysbm,f.FKFSH,p.PAYN
         |from  dw.pos_fk f
         |left join dw.sy_pay p
         |on f.FKFSH = p.PAYN
         |and p.PAYLX in ('D','E','K','L')
         |and p.his_time = '2018-03-31'
         |where f.his_time >= '2018-03-01'
         |and f.his_time < '2018-04-01' ) fz
         |where (fz.FKFSH = '84'
         |or fz.FKFSH = '82'
         |or fz.FKFSH = '93'
         |or isnull(fz.PAYN) = false)) fc
         |on z.jysbm = fc.jysbm
         |join dw.pos_mx m
         |on z.JYSBM = m.JYSBM
         |and m.his_time >= '2018-03-01'
         |and m.his_time < '2018-04-01'
         |and m.YT = 'D'
         |where z.his_time >= '2018-03-01'
         |and z.his_time < '2018-04-01'
         |and z.YT = 'D'
         |group by z.jysbm,z.jyje,fc.FKFSH) zx
         |group by zx.FLM2
          """.stripMargin)

    return resultDF
  }

  def columns(spark: SparkSession): Seq[Column] = {
    import org.apache.spark.sql.functions._

    Seq(
      column("FLM2"),
      column("yhk1"),
      column("weixin1"),
      column("zfb1"),
      column("yhk2"),
      column("weixin2"),
      column("zfb2"),
      column("yhk3"),
      column("weixin3"),
      column("zfb3")
    )
  }
}