package com.tgou.data.stanford.tempdata.memberwuliu

import com.tgou.data.stanford.tempdata.core.TempDataBootstrap
import org.apache.spark.sql._
import org.joda.time.LocalDate

/**
  * Created by 李磊 on 2018/1/31.
  * 用户物流分析
  */

object MemberWuLiu {
  def main(args: Array[String]): Unit = {
    TempDataBootstrap(args).bootstrap(execute)
  }

  def execute(spark: SparkSession, appName: String, date: LocalDate): Unit = {
    /**
      * 第一步 获取数据
      * */

    val result = getTansDF(spark, date)

    /**
      * 第二步 保存数据到HDFS上
      * */
    result.select(columns(spark): _*).coalesce(2).write.format("csv").option("delimiter", ",").option("nullValue", " ").mode(SaveMode.Overwrite).save(s"/tmp/lilei/CounterContractNumber/$date")
    spark.stop()

  }
  def getTansDF(spark:SparkSession, date: LocalDate): DataFrame = {

    val resultDF = spark.sql(
      s"""
         |select '2017-11-23' as sj,
         |count(distinct a.uuid) as uv
         |from dw.order_uba a
         |join dw.order_information c
         |on a.tgou_order_id = c.order_id
         |and c.his_time = '2017-11-23'
         |and c.receive_method = '10'
         |join dw.uba_page b
         |on a.jr = b.jr
         |and b.his_time = '2017-11-23'
         |where a.his_time = '2017-11-23'
         |union all
         |select '2017-12-26' as sj,
         |count(distinct a.uuid) as uv
         |from dw.order_uba a
         |join dw.order_information c
         |on a.tgou_order_id = c.order_id
         |and c.his_time = '2017-12-26'
         |and c.receive_method = '10'
         |join dw.uba_page b
         |on a.jr = b.jr
         |and b.his_time = '2017-12-26'
         |where a.his_time = '2017-12-26'
         |union all
         |select '2018-01-23' as sj,
         |count(distinct a.uuid) as uv
         |from dw.order_uba a
         |join dw.order_information c
         |on a.tgou_order_id = c.order_id
         |and c.his_time = '2018-01-23'
         |and c.receive_method = '10'
         |join dw.uba_page b
         |on a.jr = b.jr
         |and b.his_time = '2018-01-23'
         |where a.his_time = '2018-01-23'
      """.stripMargin)

    return resultDF
  }

  def columns(spark: SparkSession): Seq[Column] = {
    import org.apache.spark.sql.functions._

    Seq(
      column("brand_id"),
      column("brand_name"),
      column("counter_id"),
      column("counter_name"),
      column("contract_number"),
      column("store_id"),
      column("store_name")
    )
  }
}