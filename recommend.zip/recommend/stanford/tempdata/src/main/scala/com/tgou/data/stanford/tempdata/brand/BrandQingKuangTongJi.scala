package com.tgou.data.stanford.tempdata.brand

import com.tgou.data.stanford.tempdata.core.TempDataBootstrap
import org.apache.spark.sql._
import org.joda.time.LocalDate


/**
  * Created by 李磊 on 2018/1/31.
  * 品牌-情况统计
  */

object BrandQingKuangTongJi {
  def main(args: Array[String]): Unit = {
    TempDataBootstrap(args).bootstrap(execute)
  }

  def execute(spark: SparkSession, appName: String, date: LocalDate): Unit = {
    /**
      * 第一步 获取数据
      * */

    val brand = spark.read.format("csv")
      .option("delimiter", "^")
      .option("qoute", "")
      .option("nullValue", "\\N")
      .load("hdfs://nameservice1/tiangou/tgou/brand/2018/04/09/*")

    val brandS = brand.select("_c0","_c1","_c2","_c3","_c10").toDF("id","name","mis_code","is_on","modify_time")


    brandS.createOrReplaceTempView("brand_lilei")

   // val result1 = getTansDF1(spark, date)

    val result2 = getTansDF2(spark, date)

    val result3 = getTansDF3(spark, date)

    val result4 = getTansDF4(spark, date)

   val result5 = getTansDF5(spark, date)

    /**
      * 第二步 保存数据到HDFS上
      * */
    //result1.select(columns1(spark): _*).coalesce(2).write.format("csv").option("delimiter", ",").option("nullValue", " ").mode(SaveMode.Overwrite).save(s"/tmp/lilei/BrandQingKuangTongJi/1/$date")
    result2.select(columns2(spark): _*).coalesce(2).write.format("csv").option("delimiter", ",").option("nullValue", " ").mode(SaveMode.Overwrite).save(s"/tmp/lilei/BrandQingKuangTongJi/2/$date")
   // result3.select(columns3(spark): _*).coalesce(2).write.format("csv").option("delimiter", ",").option("nullValue", " ").mode(SaveMode.Overwrite).save(s"/tmp/lilei/BrandQingKuangTongJi/3/$date")
   // result4.select(columns4(spark): _*).coalesce(2).write.format("csv").option("delimiter", ",").option("nullValue", " ").mode(SaveMode.Overwrite).save(s"/tmp/lilei/BrandQingKuangTongJi/4/$date")
   // result5.select(columns5(spark): _*).coalesce(2).write.format("csv").option("delimiter", ",").option("nullValue", " ").mode(SaveMode.Overwrite).save(s"/tmp/lilei/BrandQingKuangTongJi/5/$date")
    spark.stop()

  }
  def getTansDF1(spark:SparkSession, date: LocalDate): DataFrame = {

    val resultDF = spark.sql(
      s"""
         |select a.id as brand_id,
         |max(a.mis_code) as mis_code,
         |max(a.name) as brand_name,
         |count(distinct p.product_id) as jcps,
         |count(distinct l.listing_id) as yxps,
         |count(distinct ap.fk_listing_id) as hdps,
         |max(case
         |when a.is_on = true then '是'
         |when a.is_on = false then '否' end) as sf
         |from brand_lilei a
         |left join dw.product p
         |on a.id = p.brand_id
         |and p.his_time = '2018-04-09'
         |and p.state = 'onshelf'
         |left join dw.listing l
         |on p.product_id = l.product_id
         |and l.his_time = '2018-04-09'
         |and l.state = 'onshelf'
         |left join dw.activity_product ap
         |on ap.fk_listing_id = l.listing_id
         |and ap.his_time = '2018-04-09'
         |and ap.state = 'onshelf'
         |and ap.stop_time >= '2018-04-09'
         |group by a.id
      """.stripMargin)

    return resultDF
  }

  def getTansDF2(spark:SparkSession, date: LocalDate): DataFrame = {

    val resultDF = spark.sql(
      s"""
         |select a.id as brand_id,
         |concat_ws('.',collect_set(case when s.yt = '1' then '百货'
         |when s.yt = '2' then '超市'
         |when s.yt in ('3','4') then '全球购或社会化' end)) as yt
         |from brand_lilei a
         |left join dw.product p
         |on a.id = p.brand_id
         |and p.his_time = '2018-04-09'
         |and p.state = 'onshelf'
         |left join dw.listing l
         |on p.product_id = l.product_id
         |and l.his_time = '2018-04-09'
         |and l.state = 'onshelf'
         |left join dw.store s
         |on l.store_id = s.id
         |and s.his_time = '2018-04-09'
         |and s.state = 'onshelf'
         |group by a.id
      """.stripMargin)

    return resultDF
  }

  def getTansDF3(spark:SparkSession, date: LocalDate): DataFrame = {

    val resultDF = spark.sql(
      s"""
         |select a.id as brand_id,
         |count(distinct op.order_id) as 3bs,
         |count(distinct op.store_id) as 3dps
         |from brand_lilei a
         |left join (select op.brand_id,
         |oi.store_id,
         |oi.order_id
         |from dw.order_product op
         |join dw.order_information oi
         |on op.tgou_order_id  = oi.order_id
         |and oi.pay_method != '010'
         |and oi.order_type = '0'
         |and oi.his_time = '2018-04-09'
         |and oi.pay_time >= '2018-01-09'
         |and oi.pay_time < '2018-04-10'
         |where op.his_time = '2018-04-09'
         |and op.pay_time >= '2018-01-09'
         |and op.pay_time < '2018-04-10'
         |) op
         |on op.brand_id = a.id
         |group by a.id
      """.stripMargin)

    return resultDF
  }

  def getTansDF4(spark:SparkSession, date: LocalDate): DataFrame = {

    val resultDF = spark.sql(
      s"""
         |select a.id as brand_id,
         |count(distinct op2.order_id) as 6bs,
         |count(distinct op2.store_id) as 6dps
         |from brand_lilei a
         |left join (select op.brand_id,
         |oi.store_id,
         |oi.order_id
         |from dw.order_product op
         |join dw.order_information oi
         |on op.tgou_order_id  = oi.order_id
         |and oi.pay_method != '010'
         |and oi.order_type = '0'
         |and oi.his_time = '2018-04-09'
         |and oi.pay_time >= '2017-10-09'
         |and oi.pay_time < '2018-04-10'
         |where op.his_time = '2018-04-09'
         |and op.pay_time >= '2017-10-09'
         |and op.pay_time < '2018-04-10'
         |) op2
         |on op2.brand_id = a.id
         |group by a.id
      """.stripMargin)

    return resultDF
  }

  def getTansDF5(spark:SparkSession, date: LocalDate): DataFrame = {

    val resultDF = spark.sql(
      s"""
         |select a.id as brand_id,
         |max(pp.ppmc) as ppmc
         |from brand_lilei a
         |left join dw.da_pp pp
         |on a.mis_code = pp.ppbm
         |and pp.his_time = '2018-04-09'
         |group by a.id
      """.stripMargin)

    return resultDF
  }

  def columns1(spark: SparkSession): Seq[Column] = {
    import org.apache.spark.sql.functions._

    Seq(
      column("brand_id"),
      column("mis_code"),
      column("brand_name"),
      column("jcps"),
      column("yxps"),
      column("hdps"),
      column("sf")
    )
  }
  def columns2(spark: SparkSession): Seq[Column] = {
    import org.apache.spark.sql.functions._

    Seq(
      column("brand_id"),
      column("yt")
    )
  }
  def columns3(spark: SparkSession): Seq[Column] = {
    import org.apache.spark.sql.functions._

    Seq(
      column("brand_id"),
      column("3bs"),
      column("3dps")
    )
  }
  def columns4(spark: SparkSession): Seq[Column] = {
    import org.apache.spark.sql.functions._

    Seq(
      column("brand_id"),
      column("6bs"),
      column("6dps")
    )
  }
  def columns5(spark: SparkSession): Seq[Column] = {
    import org.apache.spark.sql.functions._

    Seq(
      column("brand_id"),
      column("ppmc")
    )
  }
}