package com.tgou.data.stanford.tempdata.counter

import com.tgou.data.stanford.tempdata.core.TempDataBootstrap
import org.apache.spark.sql._
import org.joda.time.LocalDate


/**
  * Created by 李磊 on 2018/1/31.
  * 柜组合同号
  */

object CounterContractNumber {
  def main(args: Array[String]): Unit = {
    TempDataBootstrap(args).bootstrap(execute)
  }

  def execute(spark: SparkSession, appName: String, date: LocalDate): Unit = {
    /**
      * 第一步 获取数据
      * */

    val result = getTansDF(spark, date)

    /**
      * 第二步 保存数据到HDFS上
      * */
    result.select(columns(spark): _*).coalesce(2).write.format("csv").option("delimiter", ",").option("nullValue", " ").mode(SaveMode.Overwrite).save(s"/tmp/lilei/CounterContractNumber/$date")
    spark.stop()

  }
  def getTansDF(spark:SparkSession, date: LocalDate): DataFrame = {
    val counter = spark.read.format("csv")
      .option("delimiter", "^")
      .option("qoute", "")
      .option("nullValue", "\\N")
      .load("hdfs://nameservice1/tiangou/tgou/counter/*/*/*/*")

    val counterS = counter.select("_c0","_c1","_c2","_c6","_c10","_c27","_c19").toDF("id","name","fk_store_id","fk_brand_id","state","contract_number","modify_time")

    var counterMax = counterS.groupBy("id").agg(functions.max("modify_time") as "modify_time")

    var counterY = counterS.join(counterMax,
      counterS("id") === counterMax("id")
        &&  counterS("modify_time") === counterMax("modify_time")
      ,"inner"
    ).select(
      counterS("id") ,
      counterS("name") ,
      counterS("fk_store_id") ,
      counterS("fk_brand_id"),
      counterS("state") ,
      counterS("contract_number")
    )

    val counterYY = counterY.groupBy("id","name","fk_store_id","fk_brand_id").agg(functions.max("contract_number") as "contract_number")


    counterYY.createOrReplaceTempView("counter_lilei")


    val counterGroupCode = spark.read.format("csv")
      .option("delimiter", "^")
      .option("qoute", "")
      .option("nullValue", "\\N")
      .load("hdfs://nameservice1/tiangou/tgou/counter_group_code/*/*/*/*")

    val counterGroupCodeS = counterGroupCode.select("_c0","_c1","_c2","_c3","_c6").toDF("id","fk_counter_id","group_code","group_name","modify_time")


    val counterGroupCodeYY = counterGroupCodeS.groupBy("fk_counter_id","group_code","group_name").agg(functions.max("id") as "id")


    counterGroupCodeYY.createOrReplaceTempView("counter_group_code_lilei")

    val resultDF = spark.sql(
      s"""
         |select b.id as brand_id,
         |b.name as brand_name,
         |b.mis_code ,
         |d.group_code as counter_id,
         |d.group_name as counter_name,
         |a.contract_number,
         |s.id as store_id,
         |s.store_name
         |from counter_lilei a
         |join counter_group_code_lilei d
         |on a.id = d.fk_counter_id
         |join dw.brand  b
         |on a.fk_brand_id = b.id
         |and b.his_time = '2018-02-26'
         |join dw.store s
         |on a.fk_store_id = s.id
         |and s.his_time = '2018-02-26'
         |and s.yt = '1'
         |and s.state = 'onshelf'
         |order by b.id,
         |b.name ,
         |d.group_code ,
         |d.group_name ,
         |a.contract_number,
         |s.id,
         |s.store_name
      """.stripMargin)

    return resultDF
  }

  def columns(spark: SparkSession): Seq[Column] = {
    import org.apache.spark.sql.functions._

    Seq(
      column("brand_id"),
      column("brand_name"),
      column("mis_code"),
      column("counter_id"),
      column("counter_name"),
      column("contract_number"),
      column("store_id"),
      column("store_name")
    )
  }
}