package com.tgou.data.stanford.tempdata.xianxia

import com.tgou.data.stanford.tempdata.core.TempDataBootstrap
import org.apache.spark.sql._
import org.joda.time.LocalDate

/**
* Created by 李磊 on 2018/1/31.
* 卷保鲜礼线下联代
  */

object JuanBaoXian {
  def main(args: Array[String]): Unit = {
    TempDataBootstrap(args).bootstrap(execute)
  }

  def execute(spark: SparkSession, appName: String, date: LocalDate): Unit = {
    /**
      * 第一步 获取数据
      * */

    val result = getTansDF(spark, date)

    /**
      * 第二步 保存数据到HDFS上
      * */
    result.select(columns(spark): _*).coalesce(2).write.format("csv").option("delimiter", ",").option("nullValue", " ").mode(SaveMode.Overwrite).save(s"/tmp/lilei/CounterContractNumber/$date")
    spark.stop()

  }
  def getTansDF(spark:SparkSession, date: LocalDate): DataFrame = {


    val resultDF = spark.sql(
      s"""
         |select x1.fk_coupon_id,
         |c.his_time,
         |x1.jysbm,
         |d.PINM,
         |max(nvl(case when c.FKFSH = '90' then c.FKJE end,0)) 90je,
         |max(nvl(case when c.FKFSH = '81' then c.FKJE end,0)) 81je,
         |max(nvl(case when c.FKFSH = '86' then c.FKJE end,0)) 86je,
         |max(nvl(case when c.FKFSH not in ( '90','81','86') then c.FKJE end,0)) qtje
         |from (select a.fk_coupon_id,b.jysbm
         |from dw.coupon_code a
         |join dw.pos_fk b
         |on a.coupon_code_id = b.COUPON_CODE
         |and b.his_time >= '2018-03-01'
         |and b.his_time < '2018-03-14'
         |where a.his_time = '2018-03-10'
         |and a.fk_coupon_id  in ('1209464','1212154')) x1
         |join dw.pos_fk c
         |on x1.jysbm = c.jysbm
         |and c.his_time >= '2018-03-01'
         |and c.his_time < '2018-03-14'
         |join dw.pos_mx d
         |on  x1.jysbm = d.jysbm
         |and d.his_time >= '2018-03-01'
         |and d.his_time < '2018-03-14'
         |group by x1.fk_coupon_id,
         |c.his_time,
         |x1.jysbm,
         |d.PINM
      """.stripMargin)

    return resultDF
  }

  def columns(spark: SparkSession): Seq[Column] = {
    import org.apache.spark.sql.functions._

    Seq(
      column("fk_coupon_id"),
      column("his_time"),
      column("jysbm"),
      column("PINM"),
      column("90je"),
      column("81je"),
      column("86je"),
      column("qtje")
    )
  }
}