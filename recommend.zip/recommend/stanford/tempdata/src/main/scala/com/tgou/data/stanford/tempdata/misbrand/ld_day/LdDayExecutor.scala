package com.tgou.data.stanford.tempdata.misbrand.ld_day

import com.tgou.data.stanford.tempdata.misbrand.bean.LdDetailDayMarket
import com.tgou.data.stanford.tempdata.misbrand.{Application, Executor}
import org.apache.spark.sql.{SaveMode, SparkSession}
import org.apache.spark.sql.catalyst.ScalaReflection
import org.apache.spark.sql.types.StructType
import org.joda.time.LocalDate

/**
  * Created by 李震 on 2018/5/3.
  */
object LdDayExecutor extends Executor {

  override def execute(spark: SparkSession, appName: String, date: LocalDate): Unit = {
    import spark.implicits._

    val brandBc = spark.sparkContext.broadcast(Application.getBrandMap)

    val daPpDs = Application.getDaPpDataset(spark)

    val ldDetailDayMarketDs = spark.read
      .format("csv")
      .options(Map(
        "delimiter" -> "^",
        "nullValue" -> "\\N",
        "quote" -> ""))
      .schema(ScalaReflection.schemaFor[LdDetailDayMarket].dataType.asInstanceOf[StructType])
      .load(s"/mis_market/sqoop/ld-detail-day-market/${date.toString("yyyy/MM/dd")}/*")
      .as[LdDetailDayMarket]
      .map(i => {
        val brandMap = brandBc.value
        if (brandMap.keySet.contains(i.PPBM)) i.copy(PPBM = brandMap(i.PPBM)) else i
      })

    val r = ldDetailDayMarketDs.join(
        daPpDs,
        ldDetailDayMarketDs.col("PPBM") === daPpDs.col("PPBM") && ldDetailDayMarketDs.col("YT") === daPpDs.col("YT"),
        "left_outer")
      .select(
        ldDetailDayMarketDs.col("ID"),
        ldDetailDayMarketDs.col("STORECODE"),
        ldDetailDayMarketDs.col("YT"),
        ldDetailDayMarketDs.col("YZH"),
        ldDetailDayMarketDs.col("YZM"),
        ldDetailDayMarketDs.col("MQH"),
        ldDetailDayMarketDs.col("MQM"),
        ldDetailDayMarketDs.col("PPBM"),
        daPpDs.col("PPMC"),
        ldDetailDayMarketDs.col("COUPONLDJE"),
        ldDetailDayMarketDs.col("COUPONLDBS"),
        ldDetailDayMarketDs.col("COUPONLDRS"),
        ldDetailDayMarketDs.col("ORDERLDJE"),
        ldDetailDayMarketDs.col("ORDERLDBS"),
        ldDetailDayMarketDs.col("ORDERLDRS"),
        ldDetailDayMarketDs.col("JIESUANMAJYJE"),
        ldDetailDayMarketDs.col("JIESUANMAJYBS"),
        ldDetailDayMarketDs.col("JIESUANMAJYRS"),
        ldDetailDayMarketDs.col("TOTALLDJE"),
        ldDetailDayMarketDs.col("TOTALLDBS"),
        ldDetailDayMarketDs.col("TOTALLDRS"),
        ldDetailDayMarketDs.col("TOTAL_NON_RETURN_JYJE"),
        ldDetailDayMarketDs.col("TOTAL_NON_RETURN_JYBS"),
        ldDetailDayMarketDs.col("TOTAL_NON_RETURN_JYRS"),
        ldDetailDayMarketDs.col("TOTAL_RETURN_JYJE"),
        ldDetailDayMarketDs.col("TOTAL_RETURN_JYBS"),
        ldDetailDayMarketDs.col("TOTAL_RETURN_JYRS"),
        ldDetailDayMarketDs.col("DG_COUPONLDJE"),
        ldDetailDayMarketDs.col("DG_COUPONLDBS"),
        ldDetailDayMarketDs.col("DG_COUPONLDRS"),
        ldDetailDayMarketDs.col("DG_ORDERLDJE"),
        ldDetailDayMarketDs.col("DG_ORDERLDBS"),
        ldDetailDayMarketDs.col("DG_ORDERLDRS"),
        ldDetailDayMarketDs.col("DG_JIESUANMAJYJE"),
        ldDetailDayMarketDs.col("DG_JIESUANMAJYBS"),
        ldDetailDayMarketDs.col("DG_JIESUANMAJYRS"),
        ldDetailDayMarketDs.col("DG_TOTALLDJE"),
        ldDetailDayMarketDs.col("DG_TOTALLDBS"),
        ldDetailDayMarketDs.col("DG_TOTALLDRS"),
        ldDetailDayMarketDs.col("DG_TOTAL_NON_RETURN_JYJE"),
        ldDetailDayMarketDs.col("DG_TOTAL_NON_RETURN_JYBS"),
        ldDetailDayMarketDs.col("DG_TOTAL_NON_RETURN_JYRS"),
        ldDetailDayMarketDs.col("DG_TOTAL_RETURN_JYJE"),
        ldDetailDayMarketDs.col("DG_TOTAL_RETURN_JYBS"),
        ldDetailDayMarketDs.col("DG_TOTAL_RETURN_JYRS"),
        ldDetailDayMarketDs.col("MARKET_TIME"),
        ldDetailDayMarketDs.col("IDENTITY")
      )

    r.write
      .mode(SaveMode.Overwrite)
      .option("delimiter", "^")
      .option("quote", "")
      .option("nullValue", "\\N")
      .csv(s"/tmp/lz/data/${appName}/${date.toString("yyyy/MM/dd")}")

  }

}
