package com.tgou.data.stanford.tempdata.pinpaiertong

import com.tgou.data.stanford.tempdata.core.TempDataBootstrap
import org.apache.spark.sql._
import org.joda.time.LocalDate


/**
  * Created by 李磊 on 2018/1/31.
  * 品牌-儿童统计
  */

object PinPaiErTong {

  def main(args: Array[String]): Unit = {
    TempDataBootstrap(args).bootstrap(execute)
  }

  def execute(spark: SparkSession, appName: String, date: LocalDate): Unit = {

    /**
      * 第一步 获取数据
      * */
    //天狗支付概况
    val PinPaiErTong = getTansDF(spark, date)


    /**
      * 第二步 拼接数据
      * */
    val result = PinPaiErTong

    /**
      * 第三步 保存数据到HDFS上
      * */
  //  result.select(columns(spark): _*).coalesce(2).write.format("csv").option("delimiter", ",").option("nullValue", " ").mode(SaveMode.Overwrite).save(s"/tmp/lilei/PinPaiErTong/2016")
   // result.select(columns(spark): _*).coalesce(2).write.format("csv").option("delimiter", ",").option("nullValue", " ").mode(SaveMode.Overwrite).save(s"/tmp/lilei/PinPaiErTong/2017")
  //  result.select(columns2(spark): _*).coalesce(2).write.format("csv").option("delimiter", ",").option("nullValue", " ").mode(SaveMode.Overwrite).save(s"/tmp/lilei/PinPaiErTong/2016yue")
  //  result.select(columns2(spark): _*).coalesce(2).write.format("csv").option("delimiter", ",").option("nullValue", " ").mode(SaveMode.Overwrite).save(s"/tmp/lilei/PinPaiErTong/2017yue")
   // result.select(columnsS(spark): _*).coalesce(2).write.format("csv").option("delimiter", ",").option("nullValue", " ").mode(SaveMode.Overwrite).save(s"/tmp/lilei/PinPaiErTong/jiamus")
      //result.select(columns(spark): _*).coalesce(2).write.format("csv").option("delimiter", ",").option("nullValue", " ").mode(SaveMode.Overwrite).save(s"/tmp/lilei/PinPaiErTong/jms/2016")
    //result.select(columns(spark): _*).coalesce(2).write.format("csv").option("delimiter", ",").option("nullValue", " ").mode(SaveMode.Overwrite).save(s"/tmp/lilei/PinPaiErTong/jms/2017")
   //   result.select(columns2(spark): _*).coalesce(2).write.format("csv").option("delimiter", ",").option("nullValue", " ").mode(SaveMode.Overwrite).save(s"/tmp/lilei/PinPaiErTong/jms/2016yue")
      result.select(columns2(spark): _*).coalesce(2).write.format("csv").option("delimiter", ",").option("nullValue", " ").mode(SaveMode.Overwrite).save(s"/tmp/lilei/PinPaiErTong/jms/2017yue")
    spark.stop()

  }

  def getTansDF(spark:SparkSession, date: LocalDate): DataFrame = {

//    val pinPaiYouHua = spark.read.format("csv")
//      .option("delimiter", ",")
//      .option("qoute", "")
//      .option("nullValue", "\\N")
//      .load(s"hdfs://nameservice1/tmp/lilei/PinPaiYouHuaN/fl/*")
//
//    val pinPaiYouHuaS = pinPaiYouHua.select("_c0","_c1","_c2","_c3","_c4").toDF("dpbm","dpmc","pinpaim","ppbm","hh")
//
//    pinPaiYouHuaS.createOrReplaceTempView("pinPaiYouHua2_lilei")


    val pinPaiYouHua = spark.read.format("csv")
      .option("delimiter", ",")
      .option("qoute", "")
      .option("nullValue", "\\N")
      .load(s"hdfs://nameservice1/tmp/lilei/PinPaiErTong/jiamus/*")

    val pinPaiYouHuaS = pinPaiYouHua.select("_c0","_c1","_c2","_c3","_c4").toDF("dpbm","dpmc","pinpaim","ppbm","hh")

    pinPaiYouHuaS.createOrReplaceTempView("pinPaiYouHua2_lilei")

    var his_time = "2018-02-01"

    var end = "2018-02-02"

    var etl_time = "2018-02-01 00:00:00"



//    val resultDF = spark.sql(
//      s"""
//         |select xy.dpmc,xy.pinpaim,xy.yezhong,xy.maiqu,
//         |nvl(cast(sum(case when xy.fkje > xy.je then xy.je else xy.fkje end) as decimal(18,2)),0) as jingxiao ,
//         |nvl(cast(sum(xy.je) as decimal(18,2)),0) as shixiao,
//         |count( xy.jysbm) as lks,
//         |count(case when isnull(xy.cid) = false then xy.jysbm end) as bs,
//         |nvl(cast(sum(case when isnull(xy.cid) = false then xy.je end) as decimal(18,2)),0) as je
//         |from (select x1.dpmc,x1.pinpaim,x1.yezhong,x1.maiqu,x2.jysbm,max(x2.cid) as cid,sum(x1.je) as je ,max(x2.jyje) as jyje,max(x3.fkje) as fkje
//         |from (select a.dpmc,a.pinpaim,b.yezhongm as yezhong,b.maiqum as maiqu,b.jysbm,sum(b.je) as je
//         |from pinPaiYouHua2_lilei a
//         |join dw.pos_mx b
//         |on a.dpbm = b.storecode
//         |and a.ppbm = b.ppbm
//         |and a.hh = b.hh
//         |and b.his_time >= '2016-01-01'
//         |and b.his_time < '2017-01-01'
//         |group by a.dpmc,a.pinpaim,b.yezhongm,b.maiqum,b.jysbm) x1
//         |join dw.pos_zz x2
//         |on x1.jysbm = x2.jysbm
//         |and x2.his_time >= '2016-01-01'
//         |and x2.his_time < '2017-01-01'
//         |left join (select
//         | b.jysbm,
//         |  sum(b.fkje) as fkje
//         |from dw.sy_pay a
//         |join dw.pos_fk b
//         |on a.payn = b.fkfsh
//         |and a.storecode = b.storecode
//         |and b.his_time >= '2016-01-01'
//         |and b.his_time < '2017-01-01'
//         |where a.his_time = '2018-01-10'
//         |and a.paylx not in ('B','C','G','N','T','Y','Z','0','1','5','6','7')
//         |group by  b.jysbm) x3
//         |on x1.jysbm = x3.jysbm
//         |group by x1.dpmc,x1.pinpaim,x1.yezhong,x1.maiqu,x2.jysbm) xy
//         |group by xy.dpmc,xy.pinpaim,xy.yezhong,xy.maiqu
//      """.stripMargin)



//    val resultDF = spark.sql(
//      s"""
//         |select xy.dpmc,xy.pinpaim,xy.yezhong,xy.maiqu,
//         |nvl(cast(sum(case when xy.fkje > xy.je then xy.je else xy.fkje end) as decimal(18,2)),0) as jingxiao ,
//         |nvl(cast(sum(xy.je) as decimal(18,2)),0) as shixiao,
//         |count( xy.jysbm) as lks,
//         |count(case when isnull(xy.cid) = false then xy.jysbm end) as bs,
//         |nvl(cast(sum(case when isnull(xy.cid) = false then xy.je end) as decimal(18,2)),0) as je
//         |from (select x1.dpmc,x1.pinpaim,x1.yezhong,x1.maiqu,x2.jysbm,max(x2.cid) as cid,sum(x1.je) as je ,max(x2.jyje) as jyje,max(x3.fkje) as fkje
//         |from (select a.dpmc,a.pinpaim,b.yezhongm as yezhong,b.maiqum as maiqu,b.jysbm,sum(b.je) as je
//         |from pinPaiYouHua2_lilei a
//         |join dw.pos_mx b
//         |on a.dpbm = b.storecode
//         |and a.ppbm = b.ppbm
//         |and a.hh = b.hh
//         |and b.his_time >= '2017-01-01'
//         |and b.his_time < '2018-01-01'
//         |group by a.dpmc,a.pinpaim,b.yezhongm,b.maiqum,b.jysbm) x1
//         |join dw.pos_zz x2
//         |on x1.jysbm = x2.jysbm
//         |and x2.his_time >= '2017-01-01'
//         |and x2.his_time < '2018-01-01'
//         |left join (select
//         | b.jysbm,
//         |  sum(b.fkje) as fkje
//         |from dw.sy_pay a
//         |join dw.pos_fk b
//         |on a.payn = b.fkfsh
//         |and a.storecode = b.storecode
//         |and b.his_time >= '2017-01-01'
//         |and b.his_time < '2018-01-01'
//         |where a.his_time = '2018-01-10'
//         |and a.paylx not in ('B','C','G','N','T','Y','Z','0','1','5','6','7')
//         |group by  b.jysbm) x3
//         |on x1.jysbm = x3.jysbm
//         |group by x1.dpmc,x1.pinpaim,x1.yezhong,x1.maiqu,x2.jysbm) xy
//         |group by xy.dpmc,xy.pinpaim,xy.yezhong,xy.maiqu
//      """.stripMargin)


//    val resultDF = spark.sql(
//      s"""
//         |select xy.yue,xy.dpmc,xy.pinpaim,xy.yezhong,xy.maiqu,
//         |nvl(cast(sum(case when xy.fkje > xy.je then xy.je else xy.fkje end) as decimal(18,2)),0) as jingxiao ,
//         |nvl(cast(sum(xy.je) as decimal(18,2)),0) as shixiao,
//         |count( xy.jysbm) as lks,
//         |count(case when isnull(xy.cid) = false then xy.jysbm end) as bs,
//         |nvl(cast(sum(case when isnull(xy.cid) = false then xy.je end) as decimal(18,2)),0) as je
//         |from (select DATE_FORMAT(x2.his_time,'yyyy/MM') as yue,x1.dpmc,x1.pinpaim,x1.yezhong,x1.maiqu,x2.jysbm,max(x2.cid) as cid,sum(x1.je) as je ,max(x2.jyje) as jyje,max(x3.fkje) as fkje
//         |from (select a.dpmc,a.pinpaim,b.yezhongm as yezhong,b.maiqum as maiqu,b.jysbm,sum(b.je) as je
//         |from pinPaiYouHua2_lilei a
//         |join dw.pos_mx b
//         |on a.dpbm = b.storecode
//         |and a.ppbm = b.ppbm
//         |and a.hh = b.hh
//         |and b.his_time >= '2016-01-01'
//         |and b.his_time < '2017-01-01'
//         |group by a.dpmc,a.pinpaim,b.yezhongm,b.maiqum,b.jysbm) x1
//         |join dw.pos_zz x2
//         |on x1.jysbm = x2.jysbm
//         |and x2.his_time >= '2016-01-01'
//         |and x2.his_time < '2017-01-01'
//         |left join (select
//         | b.jysbm,
//         |  sum(b.fkje) as fkje
//         |from dw.sy_pay a
//         |join dw.pos_fk b
//         |on a.payn = b.fkfsh
//         |and a.storecode = b.storecode
//         |and b.his_time >= '2016-01-01'
//         |and b.his_time < '2017-01-01'
//         |where a.his_time = '2018-01-10'
//         |and a.paylx not in ('B','C','G','N','T','Y','Z','0','1','5','6','7')
//         |group by  b.jysbm) x3
//         |on x1.jysbm = x3.jysbm
//         |group by DATE_FORMAT(x2.his_time,'yyyy/MM'),x1.dpmc,x1.pinpaim,x1.yezhong,x1.maiqu,x2.jysbm) xy
//         |group by xy.yue,xy.dpmc,xy.pinpaim,xy.yezhong,xy.maiqu
//      """.stripMargin)

    val resultDF = spark.sql(
      s"""
         |select xy.yue,xy.dpmc,xy.pinpaim,xy.yezhong,xy.maiqu,
         |nvl(cast(sum(case when xy.fkje > xy.je then xy.je else xy.fkje end) as decimal(18,2)),0) as jingxiao ,
         |nvl(cast(sum(xy.je) as decimal(18,2)),0) as shixiao,
         |count( xy.jysbm) as lks,
         |count(case when isnull(xy.cid) = false then xy.jysbm end) as bs,
         |nvl(cast(sum(case when isnull(xy.cid) = false then xy.je end) as decimal(18,2)),0) as je
         |from (select DATE_FORMAT(x2.his_time,'yyyy/MM') as yue,x1.dpmc,x1.pinpaim,x1.yezhong,x1.maiqu,x2.jysbm,max(x2.cid) as cid,sum(x1.je) as je ,max(x2.jyje) as jyje,max(x3.fkje) as fkje
         |from (select a.dpmc,a.pinpaim,b.yezhongm as yezhong,b.maiqum as maiqu,b.jysbm,sum(b.je) as je
         |from pinPaiYouHua2_lilei a
         |join dw.pos_mx b
         |on a.dpbm = b.storecode
         |and a.ppbm = b.ppbm
         |and a.hh = b.hh
         |and b.his_time >= '2017-01-01'
         |and b.his_time < '2018-01-01'
         |group by a.dpmc,a.pinpaim,b.yezhongm,b.maiqum,b.jysbm) x1
         |join dw.pos_zz x2
         |on x1.jysbm = x2.jysbm
         |and x2.his_time >= '2017-01-01'
         |and x2.his_time < '2018-01-01'
         |left join (select
         | b.jysbm,
         |  sum(b.fkje) as fkje
         |from dw.sy_pay a
         |join dw.pos_fk b
         |on a.payn = b.fkfsh
         |and a.storecode = b.storecode
         |and b.his_time >= '2017-01-01'
         |and b.his_time < '2018-01-01'
         |where a.his_time = '2018-01-10'
         |and a.paylx not in ('B','C','G','N','T','Y','Z','0','1','5','6','7')
         |group by  b.jysbm) x3
         |on x1.jysbm = x3.jysbm
         |group by DATE_FORMAT(x2.his_time,'yyyy/MM'),x1.dpmc,x1.pinpaim,x1.yezhong,x1.maiqu,x2.jysbm) xy
         |group by xy.yue,xy.dpmc,xy.pinpaim,xy.yezhong,xy.maiqu
      """.stripMargin)


//    val ertongpinpai = spark.read.format("csv")
//      .option("delimiter", ",")
//      .option("qoute", "")
//      .option("nullValue", "\\N")
//      .load("hdfs://nameservice1/tmp/lilei/PinPaiErTong/jiamushi.txt")
//
//    val ertongpinpaiS = ertongpinpai.select("_c0","_c1","_c2","_c3").toDF("dpmc","pinpaim","yezhong","maiqu")
//
//
//    ertongpinpaiS.createOrReplaceTempView("jimushi")
//
//    var resultDF = spark.sql(
//      s"""
//         |select a.dpbm,
//         |s.dpmc,
//         |s.pinpaim,
//         |b.ppbm,
//         |b.hh
//         |from jimushi s
//         |join dw.emt_dpxx a
//         |on s.dpmc = a.dpmc
//         |and a.his_time = '2018-01-23'
//         |join (select e.dpbm,e.hh,e.ppmc,e.ppbm,e.hh
//         |from (select s.dpbm,
//         |s.HH,
//         |max(s.etl_time) as etl_time
//         |from dw.DA_STORE_SP s
//         |group by  s.dpbm,s.HH) d
//         |join dw.DA_STORE_SP e
//         |on d.dpbm = e.dpbm
//         |and d.HH = e.HH
//         |and d.etl_time = e.etl_time
//         |) b
//         |on a.dpbm = b.dpbm
//         |and s.pinpaim = b.ppmc
//         |group by  a.dpbm,
//         |s.dpmc,
//         |s.pinpaim,
//         |b.ppbm,
//         |b.hh
//          """.stripMargin)

    return resultDF
  }

  def columnsS(spark: SparkSession): Seq[Column] = {
    import org.apache.spark.sql.functions._

    Seq(
      column("dpbm"),
      column("dpmc"),
      column("pinpaim"),
      column("ppbm"),
      column("hh")
    )
  }

  def columns(spark: SparkSession): Seq[Column] = {
    import org.apache.spark.sql.functions._

    Seq(
      column("dpmc"),
      column("pinpaim"),
      column("yezhong"),
      column("maiqu"),
      column("jingxiao"),
      column("shixiao"),
      column("lks"),
      column("bs"),
      column("je")
    )
  }

  def columns2(spark: SparkSession): Seq[Column] = {
    import org.apache.spark.sql.functions._

    Seq(
      column("yue"),
      column("dpmc"),
      column("pinpaim"),
      column("yezhong"),
      column("maiqu"),
      column("jingxiao"),
      column("shixiao"),
      column("lks"),
      column("bs"),
      column("je")
    )
  }
}