package com.tgou.data.stanford.tempdata.core

import org.apache.spark.sql.SparkSession
import org.joda.time.LocalDate

/**
  * Created by 李磊 on 2018/1/31.
  */
class TempDataBootstrap(args: Array[String]) {

  val appName = args(0)
  val startDate = LocalDate.now().plusDays(args(1).toInt)
  val endDate = if (args.length > 2) LocalDate.now().plusDays(args(2).toInt) else LocalDate.now()

  def bootstrap(execute: (SparkSession, String, LocalDate) => Unit): Unit = {
    // 配置元数据库
    System.setProperty("hive.metastore.uris", "thrift://hnode1:9083")

    val spark = SparkSession.builder()
      .master("yarn")
      .appName(appName)
      .config("spark.storage.memoryFraction","0.3")
      .config("spark.shuffle.memoryFraction","0.4")
      .config("spark.eventLog.enabled", true)
      .config("spark.eventLog.dir", "hdfs://nameservice1/user/spark/applicationHistory")
      .config("spark.yarn.historyServer.address", "http://hnode10:18080")
      .enableHiveSupport()
      .getOrCreate()

    // 日志级别
    spark.sparkContext.setLogLevel("WARN")

    try {
      execute(spark, appName, startDate)
    } catch {
      case e: Exception => throw new RuntimeException(e)
    } finally {
      spark.close()
    }
  }

  def bootstrapHistory(execute: (SparkSession, String, LocalDate, LocalDate) => Unit): Unit = {
    // 配置元数据库
    System.setProperty("hive.metastore.uris", "thrift://hnode1:9083")

    val spark = if (appName.startsWith("test") || appName.endsWith("test")) {
      SparkSession.builder()
        .master("local[2]")
        .appName(appName)
        .enableHiveSupport()
        .getOrCreate()
    } else {
      SparkSession.builder()
        .master("local[2]")
        .appName(appName)
        .config("spark.storage.memoryFraction","0.3")
        .config("spark.shuffle.memoryFraction","0.4")
        .config("spark.eventLog.enabled", true)
        .config("spark.eventLog.dir", "hdfs://nameservice1/user/spark/applicationHistory")
        .config("spark.yarn.historyServer.address", "http://hnode10:18080")
        .enableHiveSupport()
        .getOrCreate()
    }

    // 日志级别
    spark.sparkContext.setLogLevel("WARN")

    try {
      execute(spark, appName, startDate, endDate)
    } catch {
      case e: Exception => throw new RuntimeException(e)
    } finally {
      spark.close()
    }
  }

}

object TempDataBootstrap {

  def apply(args: Array[String]): TempDataBootstrap = new TempDataBootstrap(args)

}
