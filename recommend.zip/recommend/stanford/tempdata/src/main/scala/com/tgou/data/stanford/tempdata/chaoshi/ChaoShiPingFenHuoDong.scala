package com.tgou.data.stanford.tempdata.chaoshi
import com.tgou.data.stanford.tempdata.core.TempDataBootstrap
import org.apache.spark.sql._
import org.joda.time.LocalDate


/**
  * Created by 李磊 on 2018/1/31.
  * 超市-平分卷
  */

object ChaoShiPingFenHuoDong {
  def main(args: Array[String]): Unit = {
    TempDataBootstrap(args).bootstrap(execute)
  }

  def execute(spark: SparkSession, appName: String, date: LocalDate): Unit = {
    /**
      * 第一步 获取数据
      * */

    val result = getTansDF(spark, date)

    /**
      * 第二步 保存数据到HDFS上
      * */
    result.select(columns(spark): _*).coalesce(2).write.format("csv").option("delimiter", ",").option("nullValue", " ").mode(SaveMode.Overwrite).save(s"/tmp/lilei/ChaoShiPingFenHuoDong/$date")
    spark.stop()

  }
  def getTansDF(spark:SparkSession, date: LocalDate): DataFrame = {




    val resultDF = spark.sql(
      s"""
         |select
         |m.cell_phone,s.store_name
         |from dw.pos_zz a
         |join dw.store s
         |on a.STORECODE = s.store_code
         |and  s.his_time= '2018-04-10'
         |and s.yt = '2'
         |and s.state = 'onshelf'
         |and s.area_id = '1'
         |and s.store_name like '大商超市%'
         |join dw.ds_card_bind b
         |on a.CID = b.card_id
         |and b.his_time =  '2018-04-10'
         |join dw.member m
         |on b.member_id = m.member_id
         |and m.his_time =  '2018-04-10'
         |where a.his_time >= '2018-03-28'
         |and  a.his_time < '2018-04-11'
         |and a.JYJE >= 388
         |and isnull(a.CID) = false
         |group by m.cell_phone,s.store_name
      """.stripMargin)

    return resultDF
  }

  def columns(spark: SparkSession): Seq[Column] = {
    import org.apache.spark.sql.functions._

    Seq(
      column("cell_phone"),
      column("store_name")
    )
  }
}