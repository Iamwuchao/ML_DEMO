package com.tgou.data.stanford.tempdata.misbrand.saoma

import com.tgou.data.stanford.tempdata.misbrand.bean.SaomaDetail
import com.tgou.data.stanford.tempdata.misbrand.{Application, Executor}
import org.apache.spark.sql.{SaveMode, SparkSession}
import org.apache.spark.sql.catalyst.ScalaReflection
import org.apache.spark.sql.types.StructType
import org.joda.time.LocalDate

/**
  * Created by 李震 on 2018/5/3.
  */
object SaomaExecutor extends Executor {

  override def execute(spark: SparkSession, appName: String, date: LocalDate): Unit = {
    import spark.implicits._

    val brandBc = spark.sparkContext.broadcast(Application.getBrandMap)

    val daPpDs = Application.getDaPpDataset(spark)

    val saomaDetailDs = spark.read
      .format("csv")
      .options(Map(
        "delimiter" -> "^",
        "nullValue" -> "\\N",
        "quote" -> ""))
      .schema(ScalaReflection.schemaFor[SaomaDetail].dataType.asInstanceOf[StructType])
      .load(s"/mis_market/sqoop/mis-saoma-store-yz-mq-pp-market/${date.toString("yyyy/MM/dd")}/*")
      .as[SaomaDetail]
      .map(i => {
        val brandMap = brandBc.value
        if (brandMap.keySet.contains(i.PPBM)) i.copy(PPBM = brandMap(i.PPBM)) else i
      })

    val r = saomaDetailDs.join(
        daPpDs,
        saomaDetailDs.col("PPBM") === daPpDs.col("PPBM") && saomaDetailDs.col("YT") === daPpDs.col("YT"),
      "left_outer")
      .select(
        saomaDetailDs.col("ID"),
        saomaDetailDs.col("STORECODE"),
        saomaDetailDs.col("YT"),
        saomaDetailDs.col("YEZHONGH"),
        saomaDetailDs.col("YEZHONGM"),
        saomaDetailDs.col("MAIQUH"),
        saomaDetailDs.col("MAIQUM"),
        saomaDetailDs.col("PPBM"),
        daPpDs.col("PPMC"),
        saomaDetailDs.col("SAOMA_JYRS"),
        saomaDetailDs.col("SAOMA_NEW_JYRS"),
        saomaDetailDs.col("SAOMA_JYBS"),
        saomaDetailDs.col("SAOMA_JYJE"),
        saomaDetailDs.col("TOTAL_NON_RETURN_JYBS"),
        saomaDetailDs.col("TOTAL_NON_RETURN_JYJE"),
        saomaDetailDs.col("TOTAL_NON_RETURN_JYRS"),
        saomaDetailDs.col("TOTAL_RETURN_JYBS"),
        saomaDetailDs.col("TOTAL_RETURN_JYJE"),
        saomaDetailDs.col("TOTAL_RETURN_JYRS"),
        saomaDetailDs.col("IDENTITY"),
        saomaDetailDs.col("MARKET_TIME")
      )

    r.write
      .mode(SaveMode.Overwrite)
      .option("delimiter", "^")
      .option("quote", "")
      .option("nullValue", "\\N")
      .csv(s"/tmp/lz/data/${appName}/${date.toString("yyyy/MM/dd")}")
  }

}
