package com.tgou.data.stanford.tempdata.goliang

/**
  * Created by admin on 2018/4/16.
  */
case class PClass(id: Int, name: String)
