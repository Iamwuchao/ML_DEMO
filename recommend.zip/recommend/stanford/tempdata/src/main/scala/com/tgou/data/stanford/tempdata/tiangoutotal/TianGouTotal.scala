package com.tgou.data.stanford.tempdata.tiangoutotal


import com.tgou.data.stanford.tempdata.core.TempDataBootstrap
import org.apache.spark.sql._
import org.apache.spark.sql.types._
import org.joda.time.LocalDate


/**
  * Created by 李磊 on 2018/1/31.
  * 天狗合计
  */

object TianGouTotal {
  def main(args: Array[String]): Unit = {
    TempDataBootstrap(args).bootstrap(execute)
  }

  def execute(spark: SparkSession, appName: String, date: LocalDate): Unit = {
    /**
      * 第一步 获取数据
      **/


      val result = getTansDF(spark, date)
      /**
        * 第二步 保存数据到HDFS上
        **/
      //result.select(columns(spark): _*).coalesce(2).write.format("csv").option("delimiter", ",").option("nullValue", " ").mode(SaveMode.Overwrite).save(s"/tmp/lilei/TianGouTotal/1/$date")
      result.select(columns2(spark): _*).coalesce(2).write.format("csv").option("delimiter", ",").option("nullValue", " ").mode(SaveMode.Overwrite).save(s"/tmp/lilei/TianGouTotal/4/$date")



    spark.stop()

  }

  def getTansDF(spark: SparkSession, date: LocalDate): DataFrame = {

    val deliveryAddress = spark.read.format("csv")
      .option("delimiter", "^")
      .option("qoute", "")
      .option("nullValue", "\\N")
      .load("hdfs://nameservice1/tiangou/tgouorder/delivery_address/*/*/*/*")

    val deliveryAddressS = deliveryAddress.select("_c0", "_c2", "_c3", "_c4", "_c14").toDF("id", "fk_tgou_order_id", "province_id", "province", "modify_time")

    var deliveryAddressMax = deliveryAddressS.groupBy("id").agg(functions.max("modify_time") as "modify_time")

    var deliveryAddressY = deliveryAddressS.join(deliveryAddressMax,
      deliveryAddressS("id") === deliveryAddressMax("id")
        && deliveryAddressS("modify_time") === deliveryAddressMax("modify_time")
      , "inner"
    ).select(
      deliveryAddressS("fk_tgou_order_id"),
      deliveryAddressS("province_id"),
      deliveryAddressS("province")
    )

    var deliveryAddressYY = deliveryAddressY.groupBy("fk_tgou_order_id").agg(functions.max("province_id") as "province_id", functions.max("province") as "province")

    deliveryAddressYY.createOrReplaceTempView("delivery_address_lilei")

    // 订单其他金额（除订单金额外订单金额）
    val oa = StructType(
      StructField("id", StringType, false) ::
        StructField("fk_tgou_order_id", StringType, true) ::
        StructField("name", StringType, true) ::
        StructField("type", StringType, true) ::
        StructField("sub_type", StringType, true) ::
        StructField("biz_id", StringType, true) ::
        StructField("amount", DoubleType, true) ::
        StructField("frozen_amount", DoubleType, true) ::
        StructField("balance", DoubleType, true) ::
        StructField("quantity", LongType, true) ::
        StructField("state", StringType, true) ::
        StructField("pay_method", StringType, true) ::
        StructField("mis_amount_code", StringType, true) ::
        StructField("exchange_rate", StringType, true) ::
        StructField("currency_code", StringType, true) ::
        StructField("create_time", StringType, true) ::
        StructField("modify_time", StringType, true) ::
        StructField("ext", StringType, true) ::
        StructField("version", StringType, true) ::
        StructField("paid_payment_id", StringType, true) ::
        StructField("card_no", StringType, true) ::Nil
    )

    val oaDF = spark.read
      .option("delimiter","^")
      .option("qoute","")
      .option("nullValue","\\N")
      .schema(oa)
      .csv("hdfs://nameservice1/tiangou/tgouorder/order_amount/*/*/*/*")

    oaDF.join(oaDF.groupBy("id").agg("modify_time" -> "max").toDF("id","modify_time"), Seq("id","modify_time"), "inner").distinct().createOrReplaceTempView("order_amount")

    val tiangou_shh_jye = spark.sql(
      s"""
         |select de.province as province_name,sum(nvl(a.product_discount,0))+sum(nvl(b.amount,0)) as je
         |from(
         |  select
         |      b.order_id,
         |      max(b.store_id) as store_id,
         |      nvl(cast(sum(a.product_discount) as decimal(18,2)),0) as product_discount
         |   from dw.order_information  b
         |   join dw.order_product a
         |   on b.order_id  = a.tgou_order_id
         |   and a.his_time = '2017-12-31'
         |   where b.his_time = '2017-12-31'
         |   and b.order_source in ('3', '4')
         |   and b.order_type = '0'
         |   and b.pay_method != '000'
         |  -- and b.pay_method != '010'
         |   and b.create_time >= '2017-01-01'
         |   and b.create_time < '2018-01-01'
         |   group by b.order_id
         |) a
         |join dw.store s
         |on a.store_id = s.id
         |and s.his_time = '2017-12-31'
         |and s.state = 'onshelf'
         |and s.yt = '4'
         |and s.is_international = '0'
         |left join delivery_address_lilei de
         |on a.order_id = de.fk_tgou_order_id
         |left join(
         |   select
         |       oa.fk_tgou_order_id,
         |       nvl(cast(sum(oa.amount) as decimal(18,2)),0) as amount
         |    from order_amount oa
         |    where oa.type in('4','5')
         |    group by oa.fk_tgou_order_id
         |) b
         |on a.order_id = b.fk_tgou_order_id
         |group by de.province
      """.stripMargin)

    val tiangou_std_wuliu_jye = spark.sql(
      s"""
         |select de.province as province_name,sum(nvl(a.product_discount,0))+sum(nvl(b.amount,0)) as je
         |from(
         |   select
         |      b.order_id,
         |      nvl(cast(sum(a.product_discount) as decimal(18,2)),0) as product_discount
         |   from dw.order_information  b
         |   join dw.order_product a
         |   on b.order_id  = a.tgou_order_id
         |   and a.his_time = '2017-12-31'
         |   where b.his_time = '2017-12-31'
         |   and b.order_source in ('1','2')
         |   and b.order_type = '0'
         |  -- and b.pay_method != '010'
         |  and receive_method in ('10')
         |   and b.create_time >= '2017-01-01'
         |   and b.create_time < '2018-01-01'
         |   group by b.order_id
         |) a
         |left join delivery_address_lilei de
         |on a.order_id = de.fk_tgou_order_id
         |left join(
         |    select
         |       oa.fk_tgou_order_id,
         |       nvl(cast(sum(oa.amount) as decimal(18,2)),0) as amount
         |    from order_amount oa
         |    where oa.type in('4','5')
         |    group by oa.fk_tgou_order_id
         |) b
         |on a.order_id = b.fk_tgou_order_id
         |group by de.province
      """.stripMargin)

    val tiangou_std_zhiti_jye = spark.sql(
      s"""
         |select s.province_name , sum(nvl(a.product_discount,0))+sum(nvl(b.amount,0)) as je
         |from(
         |   select
         |      b.order_id,
         |      max(b.store_id) as store_id,
         |      nvl(cast(sum(a.product_discount) as decimal(18,2)),0) as product_discount
         |   from dw.order_information  b
         |   join dw.order_product a
         |   on b.order_id  = a.tgou_order_id
         |   and a.his_time = '2017-12-31'
         |   where b.his_time = '2017-12-31'
         |   and b.order_source in ('1','2')
         |   and b.order_type = '0'
         |  -- and b.pay_method != '010'
         |  and receive_method in ('00','01','02')
         |   and b.create_time >= '2017-01-01'
         |   and b.create_time < '2018-01-01'
         |   group by b.order_id
         |) a
         |left join dw.store s
         |on a.store_id = s.id
         |and s.his_time = '2017-12-31'
         |and s.state = 'onshelf'
         |left join(
         |    select
         |       oa.fk_tgou_order_id,
         |       nvl(cast(sum(oa.amount) as decimal(18,2)),0) as amount
         |    from order_amount oa
         |    where oa.type in('4','5')
         |    group by oa.fk_tgou_order_id
         |) b
         |on a.order_id = b.fk_tgou_order_id
         |group by s.province_name
      """.stripMargin)

    val tiangou_sm_jye = spark.sql(
      s"""
         |select s.province_name , nvl(cast(sum(jyje) as decimal(18,2)),0) as je
         |from dw.pos_zz  a
         |left join dw.store s
         |on a.storecode = s.store_code
         |and s.his_time = '2017-12-31'
         |and s.state = 'onshelf'
         |where a.his_time >= '2017-01-01'
         |and a.his_time < '2018-01-01'
         |and a.thyy in ('03', '04', '05', '06', '07', '09')
         |and tgou_coupon = false
         |and tgou_order = false
         |and jyje > 0
         |group by s.province_name
      """.stripMargin)

    val tiangou_juan_ldjye = spark.sql(
      s"""
         |select s.province_name , nvl(cast(sum(jyje) as decimal(18,2)),0) as je
         |from dw.pos_zz  a
         |left join dw.store s
         |on a.storecode = s.store_code
         |and s.his_time = '2017-12-31'
         |and s.state = 'onshelf'
         |where a.his_time >= '2017-01-01'
         |and a.his_time < '2018-01-01'
         |and tgou_coupon = true
         |and jyje > 0
         |group by s.province_name
      """.stripMargin)

    val result = tiangou_shh_jye.union(tiangou_std_wuliu_jye).union(tiangou_std_zhiti_jye).union(tiangou_sm_jye).union(tiangou_juan_ldjye)

    val resultDF = result.groupBy("province_name").agg(functions.sum("je") as "je")

    //    val resultDF = spark.sql(
//      s"""
//         |select count(distinct member_id) as tiangou_zxrs
//         |from (
//         |    select
//         |        b.member_id
//         |    from dw.order_information  b
//         |    join dw.order_product a
//         |    on b.order_id  = a.tgou_order_id
//         |    and a.his_time = '2017-12-31'
//         |    where b.his_time = '2017-12-31'
//         |    and
//         |    (
//         |     (b.order_source  in ('3', '4')
//         |     and b.order_type = '0'
//         |     and b.pay_method != '000'
//         |     -- and b.pay_method != '010'
//         |     )
//         |     or
//         |     (b.order_source in ('1','2')
//         |     and b.order_type = '0'
//         |     -- and b.pay_method != '010'
//         |     )
//         |   )
//         |  -- and b.pay_time >=
//         |  -- and b.pay_time <
//         |   and b.create_time >= '2017-01-01'
//         |   and b.create_time < '2018-01-01'
//         |union
//         |    select
//         |        b.member_id
//         |    from(
//         |      select
//         |           a.cid
//         |      from dw.pos_zz  a
//         |      where a.his_time >= '2017-01-01'
//         |      and a.his_time < '2018-01-01'
//         |      and a.thyy in ('03', '04', '05', '06', '07', '09')
//         |      and a.tgou_coupon = false
//         |      and a.tgou_order = false
//         |      and a.jyje > 0) a
//         |    join (
//         |        select
//         |            pm.card_id,
//         |            pm.member_id
//         |        from dw.ds_card_bind pm
//         |        where pm.his_time = '2017-12-31'
//         |    ) b
//         |    on a.cid = b.card_id
//         |union
//         |   select
//         |      c.member_id
//         |   from dw.pos_fk f
//         |   left join dw.coupon_code c
//         |   on  c.coupon_code_id = f.coupon_code
//         |   and c.his_time = '2017-12-31'
//         |   inner join dw.pos_zz a
//         |   on a.jysbm=f.jysbm
//         |   and a.jyje>0
//         |   and a.his_time >= '2017-01-01'
//         |   and a.his_time < '2018-01-01'
//         |   where 1=1
//         |   and f.fkfsh in('81','83','86')
//         |   and f.his_time >= '2017-01-01'
//         |   and f.his_time < '2018-01-01'
//         |)
//          """.stripMargin)

    return resultDF
  }

  def columns(spark: SparkSession): Seq[Column] = {
    import org.apache.spark.sql.functions._

    Seq(
      column("tiangou_zxrs")
    )
  }

  def columns2(spark: SparkSession): Seq[Column] = {
    import org.apache.spark.sql.functions._

    Seq(
      column("province_name"),
      column("je")
    )
  }
}