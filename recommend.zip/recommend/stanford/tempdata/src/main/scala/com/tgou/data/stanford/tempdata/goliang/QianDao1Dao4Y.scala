package com.tgou.data.stanford.tempdata.goliang


import com.tgou.data.stanford.tempdata.core.TempDataBootstrap
import org.apache.spark.sql._
import org.joda.time.LocalDate
import org.joda.time.format.{DateTimeFormat}
import com.tgou.data.stanford.tempdata.goliang.PClass


/**
  * Created by 李磊 on 2018/1/31.
  * 狗粮-签到分析1到4月
  */

object QianDao1Dao4Y {
  def main(args: Array[String]): Unit = {
    TempDataBootstrap(args).bootstrap(execute)
  }

  def execute(spark: SparkSession, appName: String, date: LocalDate): Unit = {
    /**
      * 第一步 获取数据
      * */

    val memberSignLogs = spark.read.format("csv")
      .option("delimiter", "^")
      .option("qoute", "")
      .option("nullValue", "\\N")
      .load("hdfs://nameservice1/tiangou/plat/member_sign_logs/*/*/*/*")

    val memberSignLogsS = memberSignLogs.select("_c0","_c1","_c5","_c6").toDF("id","fk_member_id","create_time","modify_time")

    var memberSignLogsMax = memberSignLogsS.groupBy("id").agg(functions.max("modify_time") as "modify_time")

    var memberSignLogsY = memberSignLogsS.join(memberSignLogsMax,
      memberSignLogsS("id") === memberSignLogsMax("id")
        &&  memberSignLogsS("modify_time") === memberSignLogsMax("modify_time")
      ,"inner"
    ).select(
      memberSignLogsS("id") ,
      memberSignLogsS("fk_member_id") ,
      memberSignLogsS("create_time")
    )

    memberSignLogsY.createOrReplaceTempView("member_sign_logs_lilei")

    //var  dateC = LocalDate.parse("2018-01-01", DateTimeFormat.forPattern("yyyy-MM-dd"))
   // var  dateC = LocalDate.parse("2018-01-08", DateTimeFormat.forPattern("yyyy-MM-dd"))
  //  var  dateC = LocalDate.parse("2018-01-15", DateTimeFormat.forPattern("yyyy-MM-dd"))
   // var  dateC = LocalDate.parse("2018-01-22", DateTimeFormat.forPattern("yyyy-MM-dd"))
   //var  dateC = LocalDate.parse("2018-01-29", DateTimeFormat.forPattern("yyyy-MM-dd"))
  //var  dateC = LocalDate.parse("2018-02-05", DateTimeFormat.forPattern("yyyy-MM-dd"))
   // var  dateC = LocalDate.parse("2018-02-12", DateTimeFormat.forPattern("yyyy-MM-dd"))
  // var  dateC = LocalDate.parse("2018-02-19", DateTimeFormat.forPattern("yyyy-MM-dd"))
   // var  dateC = LocalDate.parse("2018-02-26", DateTimeFormat.forPattern("yyyy-MM-dd"))
 // var  dateC = LocalDate.parse("2018-03-05", DateTimeFormat.forPattern("yyyy-MM-dd"))
 //   var  dateC = LocalDate.parse("2018-03-12", DateTimeFormat.forPattern("yyyy-MM-dd"))
//    var  dateC = LocalDate.parse("2018-03-19", DateTimeFormat.forPattern("yyyy-MM-dd"))
 // var  dateC = LocalDate.parse("2018-03-26", DateTimeFormat.forPattern("yyyy-MM-dd"))
    var  dateC = LocalDate.parse("2018-04-02", DateTimeFormat.forPattern("yyyy-MM-dd"))

    val result = getTansDF(spark, dateC)
    var sign_member_count: String = result.select("sign_member_count").collect()(0).getLong(0).toString

//    var flg = 1
//    var dateh = dateC.plusDays(7)
//    var result2 = getTansDF2(spark,dateC, dateh)
//    sign_member_count = sign_member_count.concat(",").concat(result2.select("sign_member_count").collect()(0).getLong(0).toString)
//    for (flg <- 13 to 13 ) {
//
//      dateh = dateh.plusDays(7)
//      result2 = getTansDF2(spark, dateC, dateh)
//      sign_member_count = sign_member_count.concat(",").concat(result2.select("sign_member_count").collect()(0).getLong(0).toString)
//    }


    var list = List(PClass(1,sign_member_count))

    val resultZ = spark.createDataFrame(list)

    /**
      * 第二步 保存数据到HDFS上
      * */
    resultZ.select(columns1(spark): _*).coalesce(2).write.format("csv").option("delimiter", ",").option("nullValue", " ").mode(SaveMode.Overwrite).save(s"/tmp/lilei/QianDao1Dao4Y/1/$date")
    //result2.select(columns(spark): _*).coalesce(2).write.format("csv").option("delimiter", ",").option("nullValue", " ").mode(SaveMode.Overwrite).save(s"/tmp/lilei/QianDao1Dao4Y/1-1/$date")
    spark.stop()

  }
  def getTansDF(spark:SparkSession, date: LocalDate): DataFrame = {



    var  sDateTj = date.toString("yyyy-MM-dd")

    var endDateTj = date.plusDays(7).toString("yyyy-MM-dd")


   // var  sDateTj = "2018-01-01"
   // var endDateTj = "2018-01-08"


    val resultDF = spark.sql(
      s"""
         |
         |select
         |   count(distinct msl.fk_member_id) as sign_member_count
         |from member_sign_logs_lilei msl
         |where msl.create_time >=  '${sDateTj}'
         |and msl.create_time <  '${endDateTj}'
      """.stripMargin)



    return resultDF
  }

  def getTansDF2(spark:SparkSession, date: LocalDate,dateH: LocalDate): DataFrame = {


    var  sDateTj = date.toString("yyyy-MM-dd")

    var endDateTj = date.plusDays(7).toString("yyyy-MM-dd")

    var  sDate = dateH.toString("yyyy-MM-dd")
    var endDate = dateH.plusDays(7).toString("yyyy-MM-dd")





    val resultDF = spark.sql(
      s"""
         |
         |select count(distinct ms.fk_member_id)  as sign_member_count
         |from (select
         | fk_member_id
         |from member_sign_logs_lilei msl
         |where msl.create_time >= '${sDateTj}'
         |and msl.create_time <  '${endDateTj}'
         |group by fk_member_id) zs1
         |join member_sign_logs_lilei ms
         |on zs1.fk_member_id = ms.fk_member_id
         |and  ms.create_time >=  '${sDate}'
         |and ms.create_time < '${endDate}'
      """.stripMargin)

    return resultDF
  }

  def columns1(spark: SparkSession): Seq[Column] = {
    import org.apache.spark.sql.functions._

    Seq(
      column("id"),
      column("name")

    )
  }

  def columns(spark: SparkSession): Seq[Column] = {
    import org.apache.spark.sql.functions._

    Seq(
      column("sign_member_count"),
      column("sign_member_count1"),
      column("sign_member_count2"),
      column("sign_member_count3"),
      column("sign_member_count4"),
      column("sign_member_count5"),
      column("sign_member_count6"),
      column("sign_member_count7"),
      column("sign_member_count8"),
      column("sign_member_count9"),
      column("sign_member_count10"),
      column("sign_member_count11"),
      column("sign_member_count12"),
      column("sign_member_count13")

    )
  }
}