package com.tgou.data.stanford.tempdata.core.utils

import org.apache.hadoop.conf.Configuration
import org.apache.hadoop.fs.{FileSystem, Path}

/**
  * Created by 李磊 on 2018/1/31.
  */
object HDFSUtils {

  def exists(path: String): Boolean = {
    try {
      val fs = FileSystem.get(new Configuration())
      fs.exists(new Path(path))
    } catch {
      case e: Exception => {
        e.printStackTrace()
        false
      }
    }
  }

}