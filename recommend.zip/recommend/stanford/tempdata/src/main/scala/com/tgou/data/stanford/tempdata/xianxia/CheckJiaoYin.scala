package  com.tgou.data.stanford.tempdata.xianxia

import com.tgou.data.stanford.tempdata.core.TempDataBootstrap
import org.apache.spark.sql.{Column, DataFrame, SaveMode, SparkSession}
import org.joda.time.LocalDate

/**
* Created by 李磊 on 2018/03/06.
* 线下交易-检查交易
*/

object CheckJiaoYin {

  def main(args: Array[String]): Unit = {
    TempDataBootstrap(args).bootstrap(execute)
  }

  def execute(spark: SparkSession, appName: String, date: LocalDate): Unit = {
    /**
      * 第一步 获取数据
      * */

    val result = getTansDF(spark, date)

    /**
      * 第二步 保存数据到HDFS上
      * */
    //result.select(columns1(spark): _*).coalesce(5).write.format("csv").option("delimiter", ",").option("nullValue", " ").mode(SaveMode.Overwrite).save(s"/tmp/lilei/CheckJiaoYin/D/1/$date")
    result.select(columns1(spark): _*).coalesce(5).write.format("csv").option("delimiter", ",").option("nullValue", " ").mode(SaveMode.Overwrite).save(s"/tmp/lilei/CheckJiaoYin/S/1/$date")
    //result.select(columns2(spark): _*).coalesce(5).write.format("csv").option("delimiter", ",").option("nullValue", " ").mode(SaveMode.Overwrite).save(s"/tmp/lilei/CheckJiaoYin/D/2/$date")
   // result.select(columns2(spark): _*).coalesce(5).write.format("csv").option("delimiter", ",").option("nullValue", " ").mode(SaveMode.Overwrite).save(s"/tmp/lilei/CheckJiaoYin/S/2/$date")
    //result.select(columns1(spark): _*).coalesce(5).write.format("csv").option("delimiter", ",").option("nullValue", " ").mode(SaveMode.Overwrite).save(s"/tmp/lilei/CheckJiaoYin/D/3/$date")
    //result.select(columns1(spark): _*).coalesce(5).write.format("csv").option("delimiter", ",").option("nullValue", " ").mode(SaveMode.Overwrite).save(s"/tmp/lilei/CheckJiaoYin/S/3/$date")
    spark.stop()

  }

  def getTansDF(spark:SparkSession, date: LocalDate): DataFrame = {

//    val resultDF = spark.sql(
//      s"""
//         |select
//         |s.area_name,
//         |s.store_name,
//         |'超市' as yt,
//         |a.STORECODE,
//         |ds.phone,
//         |c.cardcode,
//         |FROM_UNIXTIME(a.jysj/1000,'yyyy/MM/dd HH:mm:ss') as sj,
//         |a.JYSBM,
//         |'' as ppmc,
//         |a.jyje,
//         |a.SYJH,
//         |a.SYYH
//         |from dw.pos_zz a
//         |join dw.mmc_card c
//         |on a.cid = c.cid
//         |and c.his_time = '2018-02-28'
//         |join dw.store s
//         |on a.storecode = s.store_code
//         |and s.his_time = '2018-02-28'
//         |and s.state = 'onshelf'
//         |and s.yt = '2'
//         |join dw.ds_card_bind ds
//         |on a.cid = card_id
//         |and ds.his_time = '2018-02-28'
//         |where a.his_time >= '2018-01-01'
//         |and a.his_time < '2018-03-01'
//         |and (a.TGOU_COUPON = true
//         |or a.TGOU_ORDER = true
//         |or a.THYY in ('03', '04', '05', '06', '07', '09'))
//         |and a.YT = 'S'
//         |and a.jyje >= 1000000
//      """.stripMargin)

//    val resultDF = spark.sql(
//      s"""
//         |select
//         |s.area_name,
//         |s.store_name,
//         |'百货' as yt,
//         |a.STORECODE,
//         |ds.phone,
//         |c.cardcode,
//         |FROM_UNIXTIME(a.jysj/1000,'yyyy/MM/dd HH:mm:ss') as sj,
//         |a.JYSBM,
//         |b.ppmc,
//         |a.jyje,
//         |a.SYJH,
//         |a.SYYH
//         |from dw.pos_zz a
//         |join dw.pos_mx b
//         |on a.JYSBM = b.JYSBM
//         |and b.his_time >= '2018-01-01'
//         |and b.his_time < '2018-03-01'
//         |join dw.mmc_card c
//         |on a.cid = c.cid
//         |and c.his_time = '2018-02-28'
//         |join dw.store s
//         |on a.storecode = s.store_code
//         |and s.his_time = '2018-02-28'
//         |and s.state = 'onshelf'
//         |and s.yt = '1'
//         |join dw.ds_card_bind ds
//         |on a.cid = card_id
//         |and ds.his_time = '2018-02-28'
//         |where a.his_time >= '2018-01-01'
//         |and a.his_time < '2018-03-01'
//         |and (a.TGOU_COUPON = true
//         |or a.TGOU_ORDER = true
//         |or a.THYY in ('03', '04', '05', '06', '07', '09'))
//         |and a.YT = 'D'
//         |and a.jyje >= 1000000
//      """.stripMargin)

//    val resultDF = spark.sql(
//      s"""
//         |select
//         |s.area_name,
//         |s.store_name,
//         |'超市' as yt,
//         |a.STORECODE,
//         |ds.phone,
//         |c.cardcode,
//         |FROM_UNIXTIME(a.jysj/1000,'yyyy/MM/dd HH:mm:ss') as sj,
//         |a.JYSBM,
//         |'' as ppmc,
//         |xc.fkje,
//         |a.jyje,
//         |a.SYJH,
//         |a.SYYH
//         |from dw.pos_zz a
//         |join dw.pos_mx b
//         |on a.JYSBM = b.JYSBM
//         |and b.his_time >= '2018-01-01'
//         |and b.his_time < '2018-03-01'
//         |join dw.mmc_card c
//         |on a.cid = c.cid
//         |and c.his_time = '2018-02-28'
//         |join dw.store s
//         |on a.storecode = s.store_code
//         |and s.his_time = '2018-02-28'
//         |and s.state = 'onshelf'
//         |and s.yt = '2'
//         |join dw.ds_card_bind ds
//         |on a.cid = card_id
//         |and ds.his_time = '2018-02-28'
//         |join (select skdd.JYSBM,skdd.fkje
//         |from (select a.JYSBM,sk.fkje/a.jyje as lv,sk.fkje
//         |from (select JYSBM,sum(FKJE) as fkje
//         |from dw.pos_fk fk
//         |where fk.his_time >= '2018-01-01'
//         |and fk.his_time < '2018-03-01'
//         |and fk.FKFSH in ('81','83','86')
//         |group by JYSBM) sk
//         |join dw.pos_zz a
//         |on sk.JYSBM = a.JYSBM
//         |and a.his_time >= '2018-01-01'
//         |and a.his_time < '2018-03-01'
//         |and a.YT = 'S') skdd
//         |where skdd.lv >= 0.9) xc
//         |on xc.JYSBM = a.JYSBM
//         |where a.his_time >= '2018-01-01'
//         |and a.his_time < '2018-03-01'
//         |and a.TGOU_COUPON = true
//         |and a.YT = 'S'
//      """.stripMargin)
//
//    val resultDF = spark.sql(
//      s"""
//         |select
//         |s.area_name,
//         |s.store_name,
//         |'百货' as yt,
//         |a.STORECODE,
//         |ds.phone,
//         |c.cardcode,
//         |FROM_UNIXTIME(a.jysj/1000,'yyyy/MM/dd HH:mm:ss') as sj,
//         |a.JYSBM,
//         |b.ppmc,
//         |xc.fkje,
//         |a.jyje,
//         |a.SYJH,
//         |a.SYYH
//         |from dw.pos_zz a
//         |join dw.pos_mx b
//         |on a.JYSBM = b.JYSBM
//         |and b.his_time >= '2018-01-01'
//         |and b.his_time < '2018-03-01'
//         |join dw.mmc_card c
//         |on a.cid = c.cid
//         |and c.his_time = '2018-02-28'
//         |join dw.store s
//         |on a.storecode = s.store_code
//         |and s.his_time = '2018-02-28'
//         |and s.state = 'onshelf'
//         |and s.yt = '1'
//         |join dw.ds_card_bind ds
//         |on a.cid = card_id
//         |and ds.his_time = '2018-02-28'
//         |join (select skdd.JYSBM,skdd.fkje
//         |from (select a.JYSBM,sk.fkje/a.jyje as lv,sk.fkje
//         |from (select JYSBM,sum(FKJE) as fkje
//         |from dw.pos_fk fk
//         |where fk.his_time >= '2018-01-01'
//         |and fk.his_time < '2018-03-01'
//         |and fk.FKFSH in ('81','83','86')
//         |group by JYSBM) sk
//         |join dw.pos_zz a
//         |on sk.JYSBM = a.JYSBM
//         |and a.his_time >= '2018-01-01'
//         |and a.his_time < '2018-03-01'
//         |and a.YT = 'D') skdd
//         |where skdd.lv >= 0.9) xc
//         |on xc.JYSBM = a.JYSBM
//         |where a.his_time >= '2018-01-01'
//         |and a.his_time < '2018-03-01'
//         |and a.TGOU_COUPON = true
//         |and a.YT = 'D'
//      """.stripMargin)


    val resultDF = spark.sql(
      s"""
         |select
         |s.area_name,
         |s.store_name,
         |'超市' as yt,
         |a.STORECODE,
         |ds.phone,
         |c.cardcode,
         |FROM_UNIXTIME(a.jysj/1000,'yyyy/MM/dd HH:mm:ss') as sj,
         |a.JYSBM,
         | '' as ppmc,
         |a.jyje,
         |a.SYJH,
         |a.SYYH
         |from dw.pos_zz a
         |join dw.mmc_card c
         |on a.cid = c.cid
         |and c.his_time = '2018-02-28'
         |join dw.store s
         |on a.storecode = s.store_code
         |and s.his_time = '2018-02-28'
         |and s.state = 'onshelf'
         |and s.yt = '2'
         |join dw.ds_card_bind ds
         |on a.cid = card_id
         |and ds.his_time = '2018-02-28'
         |join (select
         |a.storecode,ds.phone
         |from dw.pos_zz a
         |join dw.ds_card_bind ds
         |on a.cid = card_id
         |and ds.his_time = '2018-02-28'
         |where a.his_time >= '2018-01-01'
         |and a.his_time < '2018-03-01'
         |and (a.TGOU_COUPON = true
         |or a.TGOU_ORDER = true
         |or a.THYY in ('03', '04', '05', '06', '07', '09'))
         |and a.YT = 'S'
         |group by a.storecode,ds.phone
         |having count(a.JYSBM) > 99) xc
         |on xc.phone = ds.phone
         |and xc.storecode = a.storecode
         |where a.his_time >= '2018-01-01'
         |and a.his_time < '2018-03-01'
         |and (a.TGOU_COUPON = true
         |or a.TGOU_ORDER = true
         |or a.THYY in ('03', '04', '05', '06', '07', '09'))
         |and a.YT = 'S'
      """.stripMargin)

//    val resultDF = spark.sql(
//      s"""
//         |select
//         |s.area_name,
//         |s.store_name,
//         |'百货' as yt,
//         |a.STORECODE,
//         |ds.phone,
//         |c.cardcode,
//         |FROM_UNIXTIME(a.jysj/1000,'yyyy/MM/dd HH:mm:ss') as sj,
//         |a.JYSBM,
//         |b.ppmc,
//         |a.jyje,
//         |a.SYJH,
//         |a.SYYH
//         |from dw.pos_zz a
//         |join (select b.JYSBM,max(b.ppmc) as ppmc
//         |from dw.pos_mx b
//         |where b.yt = 'D'
//         |and b.his_time >= '2018-01-01'
//         |and b.his_time < '2018-03-01'
//         |group by b.JYSBM) b
//         |on a.JYSBM = b.JYSBM
//         |join dw.mmc_card c
//         |on a.cid = c.cid
//         |and c.his_time = '2018-02-28'
//         |join dw.store s
//         |on a.storecode = s.store_code
//         |and s.his_time = '2018-02-28'
//         |and s.state = 'onshelf'
//         |and s.yt = '1'
//         |join dw.ds_card_bind ds
//         |on a.cid = card_id
//         |and ds.his_time = '2018-02-28'
//         |join (select
//         |a.storecode,ds.phone
//         |from dw.pos_zz a
//         |join dw.ds_card_bind ds
//         |on a.cid = card_id
//         |and ds.his_time = '2018-02-28'
//         |where a.his_time >= '2018-01-01'
//         |and a.his_time < '2018-03-01'
//         |and (a.TGOU_COUPON = true
//         |or a.TGOU_ORDER = true
//         |or a.THYY in ('03', '04', '05', '06', '07', '09'))
//         |and a.YT = 'D'
//         |group by a.storecode,ds.phone
//         |having count(a.JYSBM) > 99) xc
//         |on xc.phone = ds.phone
//         |and xc.storecode = a.storecode
//         |where a.his_time >= '2018-01-01'
//         |and a.his_time < '2018-03-01'
//         |and (a.TGOU_COUPON = true
//         |or a.TGOU_ORDER = true
//         |or a.THYY in ('03', '04', '05', '06', '07', '09'))
//         |and a.YT = 'D'
//      """.stripMargin)

    return resultDF
  }

  def columns1(spark: SparkSession): Seq[Column] = {
    import org.apache.spark.sql.functions._

    Seq(
      column("area_name"),
      column("store_name"),
      column("yt"),
      column("STORECODE"),
      column("phone"),
      column("cardcode"),
      column("sj"),
      column("JYSBM"),
      column("ppmc"),
      column("jyje"),
      column("SYJH"),
      column("SYYH")
    )
  }

  def columns2(spark: SparkSession): Seq[Column] = {
    import org.apache.spark.sql.functions._

    Seq(
      column("area_name"),
      column("store_name"),
      column("yt"),
      column("STORECODE"),
      column("phone"),
      column("cardcode"),
      column("sj"),
      column("JYSBM"),
      column("ppmc"),
      column("fkje"),
      column("jyje"),
      column("SYJH"),
      column("SYYH")
    )
  }

}