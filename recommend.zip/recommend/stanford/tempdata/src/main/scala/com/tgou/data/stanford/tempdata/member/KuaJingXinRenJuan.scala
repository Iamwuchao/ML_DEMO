package com.tgou.data.stanford.tempdata.member

import com.tgou.data.stanford.tempdata.core.TempDataBootstrap
import org.apache.spark.sql._
import org.joda.time.LocalDate


/**
  * Created by 李磊 on 2018/1/31.
  * 跨境新人卷
  */

object KuaJingXinRenJuan {
  def main(args: Array[String]): Unit = {
    TempDataBootstrap(args).bootstrap(execute)
  }

  def execute(spark: SparkSession, appName: String, date: LocalDate): Unit = {
    /**
      * 第一步 获取数据
      **/

    for( flg <- -19 to -4){

      var dateT = date.plusDays(flg)

      val result = getTansDF(spark, dateT)
      /**
        * 第二步 保存数据到HDFS上
        **/
      result.select(columns(spark): _*).coalesce(2).write.format("csv").option("delimiter", ",").option("nullValue", " ").mode(SaveMode.Overwrite).save(s"/tmp/lilei/KuaJingXinRenJuan/$dateT")

    }

    spark.stop()

  }

  def getTansDF(spark: SparkSession, date: LocalDate): DataFrame = {

    val orderPreferential = spark.read.format("csv")
      .option("delimiter", "^")
      .option("qoute", "")
      .option("nullValue", "\\N")
      .load("hdfs://nameservice1/tiangou/tgouorder/order_preferential/2018/*/*/*")

    val orderPreferentialS = orderPreferential.select("_c0", "_c1", "_c2", "_c4", "_c8").toDF("id", "type", "object_id", "fk_tgou_order_id", "modify_time")

    var orderPreferentialMax = orderPreferentialS.groupBy("id").agg(functions.max("modify_time") as "modify_time")

    var orderPreferentialY = orderPreferentialS.join(orderPreferentialMax,
      orderPreferentialS("id") === orderPreferentialMax("id")
        && orderPreferentialS("modify_time") === orderPreferentialMax("modify_time")
      , "inner"
    ).select(
      orderPreferentialS("object_id"),
      orderPreferentialS("fk_tgou_order_id"),
      orderPreferentialS("type"),
      orderPreferentialS("modify_time")
    )

    var orderPreferentialYY = orderPreferentialY.filter("type = 3").groupBy("fk_tgou_order_id").agg(functions.max("object_id") as "object_id", functions.max("modify_time") as "modify_time")

    orderPreferentialYY.createOrReplaceTempView("order_preferential_lilei")


    var his_time = date.toString("yyyy-MM-dd")

    var end = date.plusDays(1).toString("yyyy-MM-dd")


    val resultDF = spark.sql(
      s"""
         |select
         |count(distinct a.member_id) as rs,
         |count(distinct case when (isnull(b.fk_tgou_order_id) = false or  isnull(b2.fk_tgou_order_id) = false) then a.member_id end) as yongjuanrs,
         |count(distinct case when isnull(b.fk_tgou_order_id) = false  then a.member_id end) as yongjuanxinrs,
         |count(distinct case when isnull(b2.fk_tgou_order_id) = false  then a.member_id end) as yongjuanfxinrs,
         |count(distinct case when isnull(b.fk_tgou_order_id) = true and isnull(b2.fk_tgou_order_id) = true then a.member_id end) as fyongjuanrs,
         |count(distinct case when isnull(b.fk_tgou_order_id) = true and isnull(b2.fk_tgou_order_id) = true  and isnull(c.member_id) = false then a.member_id end) as fyongjuanxinrs,
         |count(distinct case when isnull(b.fk_tgou_order_id) = true and isnull(b2.fk_tgou_order_id) = true  and isnull(c.member_id) = true then a.member_id end) as fyongjuanfxinrs
         |from dw.order_information a
         |join dw.store s
         |on a.store_id = s.id
         |and s.his_time = '${his_time}'
         |and s.yt = '4'
         |and s.is_international = '1'
         |left join (select a.member_id
         |from dw.order_information a
         |join dw.store s
         |on a.store_id = s.id
         |and s.his_time = '${his_time}'
         |and s.yt = '4'
         |and s.is_international = '1'
         |where a.his_time = '${his_time}'
         |and a.pay_time < '${his_time}'
         |and a.pay_method != '010'
         |and a.order_source = '4'
         |group by a.member_id) xx
         |on a.member_id = xx.member_id
         |left join (select b.fk_tgou_order_id
         |from order_preferential_lilei b
         |join dw.coupon_code c
         |on b.object_id = c.coupon_code_id
         |and c.his_time = '${his_time}'
         |and c.fk_coupon_id in ('1186601',
         |'1186600',
         |'1186599',
         |'1186598',
         |'1186597',
         |'1186594',
         |'1186593',
         |'1186592',
         |'1186591',
         |'1186590',
         |'1186588',
         |'1186586',
         |'1186584',
         |'1186583',
         |'1186582',
         |'1186581',
         |'1186576',
         |'1186575',
         |'1186573',
         |'1186572',
         |'1186569',
         |'1186564') ) b
         |on a.order_id = b.fk_tgou_order_id
         |left join (select b.fk_tgou_order_id
         |from order_preferential_lilei b
         |join dw.coupon_code c
         |on b.object_id = c.coupon_code_id
         |and c.his_time = '${his_time}'
         |and c.fk_coupon_id not in ('1186601',
         |'1186600',
         |'1186599',
         |'1186598',
         |'1186597',
         |'1186594',
         |'1186593',
         |'1186592',
         |'1186591',
         |'1186590',
         |'1186588',
         |'1186586',
         |'1186584',
         |'1186583',
         |'1186582',
         |'1186581',
         |'1186576',
         |'1186575',
         |'1186573',
         |'1186572',
         |'1186569',
         |'1186564') )  b2
         |on a.order_id = b2.fk_tgou_order_id
         |left join dw.coupon_code c
         |on a.member_id = c.member_id
         |and c.his_time = '${his_time}'
         |and c.fk_coupon_id  in ('1186601',
         |'1186600',
         |'1186599',
         |'1186598',
         |'1186597',
         |'1186594',
         |'1186593',
         |'1186592',
         |'1186591',
         |'1186590',
         |'1186588',
         |'1186586',
         |'1186584',
         |'1186583',
         |'1186582',
         |'1186581',
         |'1186576',
         |'1186575',
         |'1186573',
         |'1186572',
         |'1186569',
         |'1186564')
         |and c.use_tag = '1'
         |where a.his_time = '${his_time}'
         |and a.pay_time >= '${his_time}'
         |and a.pay_time < '${end}'
         |and a.pay_method != '010'
         |and a.order_source = '4'
         |and isnull(xx.member_id) = true
          """.stripMargin)

    return resultDF
  }

  def columns(spark: SparkSession): Seq[Column] = {
    import org.apache.spark.sql.functions._

    Seq(
      column("rs"),
      column("yongjuanrs"),
      column("yongjuanxinrs"),
      column("yongjuanfxinrs"),
      column("fyongjuanrs"),
      column("fyongjuanxinrs"),
      column("fyongjuanfxinrs")
    )
  }
}