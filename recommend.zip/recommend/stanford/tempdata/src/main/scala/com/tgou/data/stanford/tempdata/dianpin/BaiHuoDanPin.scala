package com.tgou.data.stanford.tempdata.dianpin

import com.tgou.data.stanford.tempdata.core.TempDataBootstrap
import org.apache.spark.sql._
import org.joda.time.LocalDate


/**
  * Created by 李磊 on 2018/1/31.
  * 百货单品-6月以上没有更新
  */


object BaiHuoDanPin {
  def main(args: Array[String]): Unit = {
    TempDataBootstrap(args).bootstrap(execute)
  }

  def execute(spark: SparkSession, appName: String, date: LocalDate): Unit = {
    /**
      * 第一步 获取数据
      * */

    val result = getTansDF(spark, date)

    /**
      * 第二步 保存数据到HDFS上
      * */
    result.select(columns(spark): _*).coalesce(2).write.format("csv").option("delimiter", ",").option("nullValue", " ").mode(SaveMode.Overwrite).save(s"/tmp/lilei/BaiHuoDanPin/$date")
    spark.stop()

  }
  def getTansDF(spark:SparkSession, date: LocalDate): DataFrame = {

    val mallActivityProductFsmLog = spark.read.format("csv")
      .option("delimiter", "^")
      .option("qoute", "")
      .option("nullValue", "\\N")
      .load("hdfs://nameservice1//tiangou/tgou/mall_activity_product_fsm_log/*/*/*/*")

    val mallActivityProductFsmLogS = mallActivityProductFsmLog.select("_c3","_c6").toDF("enter_time","object_id")


    var mallActivityProductFsmLogYY = mallActivityProductFsmLogS.groupBy("object_id").agg(functions.max("enter_time") as "enter_time")

    mallActivityProductFsmLogYY.createOrReplaceTempView("mall_activity_product_fsm_log_lilei")


    val resultDF = spark.sql(
      s"""
         |select
         |       a.listing_id as lid
         |from dw.listing a
         |join mall_activity_product_fsm_log_lilei c
         |on a.listing_id = c.object_id
         |and c.enter_time < '2017-09-28'
         |where a.his_time = '2018-03-27'
         |and a.source = 1
         |and a.state = 'onshelf'
         |and a.type != '4'
      """.stripMargin)

    return resultDF
  }

  def columns(spark: SparkSession): Seq[Column] = {
    import org.apache.spark.sql.functions._

    Seq(
      column("lid")
    )
  }
}