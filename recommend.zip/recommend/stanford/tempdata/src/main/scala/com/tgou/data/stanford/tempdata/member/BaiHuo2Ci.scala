package  com.tgou.data.stanford.tempdata.member

import com.tgou.data.stanford.tempdata.core.TempDataBootstrap
import org.apache.spark.sql.{Column, DataFrame, SaveMode, SparkSession}
import org.joda.time.LocalDate


/**
  * Created by 李磊 on 2018/03/06.
  * 百货物流交易2次以上
  */

object BaiHuo2Ci {
  def main(args: Array[String]): Unit = {
    TempDataBootstrap(args).bootstrap(execute)
  }

  def execute(spark: SparkSession, appName: String, date: LocalDate): Unit = {
    /**
      * 第一步 获取数据
      * */

    val result = getTansDF(spark, date)

    /**
      * 第二步 保存数据到HDFS上
      * */

    result.select(columns(spark): _*).coalesce(2).write.format("csv").option("delimiter", ",").option("nullValue", " ").mode(SaveMode.Overwrite).save(s"/tmp/lilei/BaiHuo2Ci/$date")

    spark.stop()

  }

  def getTansDF(spark:SparkSession, date: LocalDate): DataFrame = {

    val resultDF = spark.sql(
      s"""
         |select  m.cell_phone,
         |o.order_id,
         |o.pay_time,
         |o.total_amount
         |from dw.order_information o
         |join (select a.member_id
         |from dw.order_information a
         |where a.his_time = '2018-03-21'
         |and a.pay_time >= '2017-03-21'
         |and a.pay_time < '2018-03-22'
         |and a.pay_method != '010'
         |and a.order_source = '1'
         |and a.receive_method = '10'
         |group by a.member_id
         |having count(1) > 1) a
         |on o.member_id = a.member_id
         |join (select a.member_id
         |from dw.order_information a
         |where a.his_time = '2018-03-21'
         |and a.pay_time >= '2018-02-21'
         |and a.pay_time < '2018-03-22'
         |and a.pay_method != '010'
         |and a.order_source = '1'
         |group by a.member_id) b
         |on a.member_id = b.member_id
         |join dw.member m
         |on o.member_id = m.member_id
         |and m.his_time = '2018-03-21'
         |where o.his_time = '2018-03-21'
         |and o.pay_time >= '2017-03-21'
         |and o.pay_time < '2018-03-22'
         |and o.pay_method != '010'
         |and o.order_source = '1'
      """.stripMargin)

    return resultDF
  }

  def columns(spark: SparkSession): Seq[Column] = {
    import org.apache.spark.sql.functions._

    Seq(
      column("cell_phone"),
      column("order_id"),
      column("pay_time"),
      column("total_amount")
    )
  }
}