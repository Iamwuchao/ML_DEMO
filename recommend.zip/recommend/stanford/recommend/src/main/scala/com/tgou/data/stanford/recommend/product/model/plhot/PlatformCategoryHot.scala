package com.tgou.data.stanford.recommend.product.model.plhot

import java.time.LocalDate
import java.time.format.DateTimeFormatter

import com.tgou.data.stanford.recommend.RecommendBootstrap
import com.tgou.data.stanford.recommend.utils.{ModelType, PersistUtils, SaveType}
import org.apache.spark.sql.{SaveMode, SparkSession}
import org.apache.spark.rdd.RDD

import scala.collection.mutable.ArrayBuffer
import com.alibaba.fastjson.{JSON, JSONObject}
import com.tgou.data.stanford.core.utils.DateUtils

/**
  * Created by Travis on 27/03/2018.
  */

//case class HotCategoryBean(listing_id:String,second_category:String,score:Double){}
//case class HotCategorySqoopBean(index:Long,rec_id:String,info:String){}

object PlatformCategoryHot {
  def main(args: Array[String]) {
    RecommendBootstrap(args).bootstrap(execute)
  }

  def execute(spark: SparkSession, appName: String, date: LocalDate, args: Array[String]): Unit = {

    val online = !"test".equals(args(2))
    val dateStr = DateUtils.dateFormat(date)

    val TOTAL_HOT_PRODUCT_COUNT = 300
    val CATEGORY_SIZE = 10

    spark.udf.register("genInfo", (second_category:String, score:Double, is_activity_product:String)=>   {
      val json = new JSONObject()
      json.put("second_category", second_category)
      json.put("score", score)
      json.put("is_activity_product", is_activity_product)

      json.toJSONString
    })

    val mergedResultDF = spark.read.parquet(s"/persona/data/user_product_ratings")
    mergedResultDF.createOrReplaceTempView("merged_score")

    //------------------------
    // 1. Fetch hot category products
    //------------------------
    val hotCategorySqlText =
      s"""
         |SELECT
         |  row_number() over (ORDER BY part_index, second_category) as index,
         |  listing_id as rec_id,
         |  info
         |FROM (
         |  SELECT
         |    row_number() over (PARTITION BY a.category2 ORDER BY a.is_activity_product DESC, m.score DESC) as part_index,
         |    m.listing_id,
         |    genInfo(a.category2, m.score, a.is_activity_product) as info,
         |    a.category2 as second_category
         |  FROM (
         |    SELECT
         |        listing_id,
         |        sum(score) AS score
         |    FROM
         |        merged_score
         |    GROUP BY
         |        listing_id
         |  ) m
         |  INNER JOIN persona.listing a
         |    ON m.listing_id = a.listing_id
         |    AND a.listing_state='onshelf'
         |    AND a.listing_id != '9116001'
         |) t
         |WHERE part_index <= $CATEGORY_SIZE
         |LIMIT $TOTAL_HOT_PRODUCT_COUNT
  """.stripMargin

    val hotCategoryDF = spark.sql(hotCategorySqlText)

    PersistUtils.save(spark, hotCategoryDF, ModelType.P_PT_HOT_V1, SaveType.SQOOP_REC, online)

  }
}
