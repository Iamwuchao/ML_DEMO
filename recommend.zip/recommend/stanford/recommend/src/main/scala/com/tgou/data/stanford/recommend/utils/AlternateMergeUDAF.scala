package com.tgou.data.stanford.recommend.utils

import org.apache.spark.sql.Row
import org.apache.spark.sql.expressions.{MutableAggregationBuffer, UserDefinedAggregateFunction}
import org.apache.spark.sql.types._

import scala.collection.mutable.ArrayBuffer

/**
  * 交叉合并
  *
  * 输入是
  * alter_merge(1,"a:1:2,b:1:2,c:1:2,d:1:2")
  * alter_merge(2,"a:2:2,b:2:2,c:2:2,d:2:2")
  * alter_merge(3,"a:3:2,b:3:2,c:3:2,d:3:2")
  *
  * 输出是
  * a:1:2,a:2:2,a:3:2,b:1:2,b:2:2....
  */
class AlternateMergeUDAF extends UserDefinedAggregateFunction{
  override def inputSchema: StructType = StructType(List(StructField("rank",IntegerType),StructField("info", StringType)))

  override def bufferSchema: StructType = StructType(List(StructField("merge", StringType)))

  override def dataType: DataType = StringType

  override def deterministic: Boolean = true

  override def initialize(buffer: MutableAggregationBuffer): Unit = {
    buffer(0) = ""
  }

  override def update(buffer: MutableAggregationBuffer, input: Row): Unit = {
    val input_info = input.getString(1)

    if(input_info!=null && !"".equals(input_info)){
      if("".equals(buffer(0))){
        buffer.update(0,input.getInt(0).toString+"|"+input_info)
      }else{
        buffer.update(0,buffer(0)+"^"+input.getInt(0).toString+"|"+input_info)
      }
    }
  }

  override def merge(buffer1: MutableAggregationBuffer, buffer2: Row): Unit = {
    val b1_info = buffer1(0)
    val b2_info = buffer2(0)
    if(!"".equals(b2_info)){
      if("".equals(b1_info)){
        buffer1.update(0,b2_info)
      }else{
        buffer1.update(0,b1_info+"^"+b2_info)
      }
    }
  }

  override def evaluate(buffer: Row): String = {

    val ab:ArrayBuffer[String] = new ArrayBuffer[String]()

    val sorted = buffer
      .getString(0)
      .split("\\^")
      .map(str=>(str.split("\\|")(0),str.split("\\|")(1)))
      .sortWith((a,b)=>a._1.toDouble<b._1.toDouble)//根据rank进行排序
      .map(t2=>t2._2.split(","))


    var max_size = 0

    for (arr <- sorted) {
      if(arr.size > max_size){
        max_size = arr.size
      }
    }

    //依次遍历每个数组，添加到buffer中
    for(i <- 0.until(max_size)){
      for(arr <- sorted){
        if(arr.size > i){
          ab += arr(i)
        }
      }
    }

    // 仅取top100
    ab.take(100).mkString(",")
  }
}
