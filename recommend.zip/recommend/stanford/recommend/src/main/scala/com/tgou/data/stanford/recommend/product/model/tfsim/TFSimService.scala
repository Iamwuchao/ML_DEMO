package com.tgou.data.stanford.recommend.product.model.tfsim

import java.time.LocalDateTime

import com.tgou.data.stanford.recommend.utils.{SimPartitionUtils, SimilarityUtils}
import org.apache.spark.Partitioner
import org.apache.spark.ml.feature.{HashingTF, Tokenizer}
import org.apache.spark.ml.linalg.Vector
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.{DataFrame, Row, SaveMode, SparkSession}
import org.apache.spark.storage.StorageLevel

import scala.collection.mutable.ArrayBuffer

object TFSimService {
  /**
    * 计算相似度
    * @param spark      spark
    * @param df         df
    * @param paritioner p
    */
  def calculateSim(spark:SparkSession, df:DataFrame, paritioner: Partitioner, thread_hold_score:Double): DataFrame ={
    val pairRDD = df.rdd.groupBy(p=paritioner,f=r=>r.getString(2))
    pairRDD.persist(StorageLevel.MEMORY_AND_DISK_SER_2)

    val result:RDD[Bean] = pairRDD.mapPartitionsWithIndex((index,iterator) => {

      // 在分区内，collect数据进行计算
      val tmp = new ArrayBuffer[Row]()
      iterator.foreach(t2=> tmp ++= t2._2)

      println(index+"当前的元素个数:"+tmp.size)
      println(index+"开始计算..."+LocalDateTime.now())

      val buffer = new ArrayBuffer[Bean]()

      // r的格式为 (商品id,空,空,是否国际,是否入围,业态,店铺)
      tmp.foreach(r => {

        // 挨个商品计算与其他所有商品的相似
        var sims = tmp
          .filter(neighbor => {
            // 过滤 如果是百货仅保留入围品 || 如果是跨境直接保留
            val f = (neighbor.getString(5).equals("1") && neighbor.getString(4).equals("1")) || neighbor.getString(5).equals("4")
            f && neighbor.getLong(0) != r.getLong(0)
          })
          .map(neighbor => {
            val score = SimilarityUtils.jaccardSimilarity(neighbor.getAs[Vector](1),r.getAs[Vector](1))
            //(相似品的id,空,空,是否国际,是否入围,业态,分数,店铺id)
            (neighbor.getLong(0),"","",neighbor.getString(3),neighbor.getString(4).toInt,neighbor.getString(5).toInt,score,neighbor.getString(6))
          })
          .sortWith((a,b) => a._7 > b._7)
          .take(200)

        // 排序,如果当前商品是百货，则门店优先按照
        /*if(r.getString(5).equals("1")){
          // 筛选同门店的商品，按照分值排序
          val first = sims.filter(a => r.getString(6).equals(a._8) && a._7>=thread_hold_score)

          // 筛选非同门店的商品，按照分值排序
          val second = sims.filter(a => !r.getString(6).equals(a._8))

          // 顺序拼接，合并两部分的数据
          val sort_buffer = new ArrayBuffer[(Long,String,String,String,Int,Int,Double,String)]()
          sort_buffer ++= first
          sort_buffer ++= second

          sims = sort_buffer
        }*/

        val data = sims
          .map(neighbor => {
            neighbor._1+":"+neighbor._6+":"+neighbor._7
          })
          .mkString(",")

        // 剔除为空的数据
        if(data.length>0){
          buffer += Bean(r.getLong(0),data)
        }
      })
      println(index+"计算完成..."+LocalDateTime.now())
      buffer.iterator
    })

    val productSimDF = spark.createDataFrame(result)
    productSimDF.persist(StorageLevel.MEMORY_AND_DISK_SER_2)
    productSimDF
  }

  def featureProcess(origin:DataFrame, statistics:DataFrame): DataFrame ={
    val partitions = SimPartitionUtils.generateKeys(statistics,ProductTFSimMain.COLS,ProductTFSimMain.MIN_THREDHOLD)
    val paritioner = new ProductSimPartioner(partitions)

    // 统计词频
    val hashingTF = new HashingTF()
      .setInputCol("words").setOutputCol("features").setNumFeatures(2000).setBinary(true)
    val featurizedData = hashingTF.transform(origin)

    // 筛选字段，按照事先安排的顺序与规则，形成key（这个key很重要，会作为分区的判断标识）
    val df = featurizedData.selectExpr(
      "listing_id",
      "features",
      "concat(fl1,',',fl2,',',fl3,',',fl4) as key",
      "is_international",
      "is_selected",
      "source",
      "store_id"
    )
    df.write.mode(SaveMode.Overwrite).parquet("/tmp/xhl/recommend/tf_idf/data")
    df.persist(StorageLevel.MEMORY_AND_DISK_SER_2)
    df
  }

  /**
    * 创建自定义的分区器
    *
    * @param spark spark
    * @return
    */
  def createPartitioner(spark:SparkSession) ={
    // 统计四级分类个数
    val basicCounts = spark.sql(
      s"""
         |select
         |  fl1,
         |  fl2,
         |  fl3,
         |  fl4,
         |  count(1) as fl4_count
         |from origin
         |group by fl1,fl2,fl3,fl4
       """.stripMargin)
    basicCounts.persist(StorageLevel.MEMORY_AND_DISK_SER_2)
    basicCounts.createOrReplaceTempView("basic_counts")

    val statistics = spark.sql(
      s"""
         |select
         |  concat(bc.fl1,':',f1.fl1_count) as fl1,
         |  concat(bc.fl2,':',f2.fl2_count) as fl2,
         |  concat(bc.fl3,':',f3.fl3_count) as fl3,
         |  concat(bc.fl4,':',bc.fl4_count) as fl4
         |from basic_counts bc
         |left join (
         |  select fl1,fl2,fl3,sum(fl4_count) as fl3_count
         |  from basic_counts
         |  group by fl1,fl2,fl3
         |) f3
         |on bc.fl1 = f3.fl1
         |  and bc.fl2 = f3.fl2
         |  and bc.fl3 = f3.fl3
         |left join (
         |  select fl1,fl2,sum(fl4_count) as fl2_count
         |  from basic_counts
         |  group by fl1,fl2
         |) f2
         |on bc.fl1 = f2.fl1
         |  and bc.fl2 = f2.fl2
         |left join(
         |  select fl1,sum(fl4_count) as fl1_count
         |  from basic_counts
         |  group by fl1
         |) f1
         |on bc.fl1 = f1.fl1
       """.stripMargin)
    statistics.persist(StorageLevel.MEMORY_AND_DISK_SER_2)
    statistics.write.mode(SaveMode.Overwrite).parquet(s"/tmp/xhl/recommend/product/statistics")
    statistics.createOrReplaceTempView("statistics")

    // 创建自定义的分区器，根据设置的分区规则，进行上浮
    val partitions = SimPartitionUtils.generateKeys(statistics,ProductTFSimMain.COLS,ProductTFSimMain.MIN_THREDHOLD)

    // 输出统计信息
    println("***************************partitions**********************")
    for(i <- partitions.indices){
      println(i+":"+partitions(i))
    }
    println("***********************************************************")

    // 创建自定义的分区器
    (new ProductSimPartioner(partitions),statistics)
  }

  /**
    * 通过persona.listing获得相似计算的原始数据
    * todo 增加包邮
    * @param spark spark
    */
  def registerOrigin(spark:SparkSession): DataFrame ={

    // 把需要的文本拼接在一起，进行分词分析
    // 去除数组长度为0的记录
    val origin = spark.sql(
      s"""
         |select * from (
         |select
         |  listing_id,
         |  segment(concat(name,category1,category2,category3,parse(property))) as words,
         |  category1 as fl1,
         |  category2 as fl2,
         |  category3 as fl3,
         |  case when length(category_code)=8 then category_code else -1 end  as fl4,
         |  is_international,
         |  is_selected,
         |  source,
         |  store_id
         |from persona.listing
         |where
         |  (source = 1 and listing_state = 'onshelf' and product_state = 'onshelf')
         |  or
         |  (source = 4 and listing_state = 'onshelf')
         |) t where size(t.words) > 0
       """.stripMargin)

    origin.persist(StorageLevel.MEMORY_AND_DISK_SER_2)
    origin.createOrReplaceTempView("origin")
    origin.write.mode(SaveMode.Overwrite).parquet(s"/tmp/xhl/recommend/product/segment_origin")
    origin
  }

  case class Bean(listing_id:Long,data:String){}
}
