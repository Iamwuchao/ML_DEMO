package com.tgou.data.stanford.recommend.metrics.click

import java.time.LocalDate

import com.tgou.data.stanford.core.utils.DateUtils
import com.tgou.data.stanford.recommend.utils.{ModelType, PersistUtils, SaveType}
import org.apache.spark.sql.{DataFrame, SaveMode, SparkSession}


object Application {

  def execute(spark: SparkSession, appName: String, date: LocalDate, args: Array[String]): DataFrame = {

    val lastDay = DateUtils.dateFormat(date)

    val clickDF = spark.sql(
      s"""
         |select
         |
         |    concat(meta.scene_id,'_',meta.process_id,'_',meta.model_id,'_',$lastDay) as id,
         |    meta.scene_id,
         |    meta.process_id,
         |    meta.model_id,
         |    nvl(t2.count,0) as expose,
         |    nvl(t1.count,0) as click,
         |    '$lastDay' as date,
         |from meta meta
         |left join (
         |    select
         |        scene_id,
         |        process_id,
         |        model_id,
         |        count(1) as count
         |    from scp
         |    group by scene_id, process_id, model_id
         |) t1
         |on meta.scene_id = t1.scene_id and meta.process_id = t1.process_id and meta.model_id = t1.model_id
         |left join (
         |    select
         |        scene_id,
         |        process_id,
         |        model_id,
         |        count(1) as count
         |    from expose
         |    group by scene_id, process_id, model_id
         |) t2
         |on meta.scene_id = t2.scene_id and meta.process_id = t2.process_id and meta.model_id = t2.model_id
       """.stripMargin).coalesce(1)

    clickDF
  }
}
