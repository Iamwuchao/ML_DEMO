package com.tgou.data.stanford.recommend.product.model.tfsim

import org.apache.spark.Partitioner

class ProductSimPartioner(partitions: Array[String]) extends Partitioner{

  override def numPartitions = partitions.length

  override def getPartition(key: Any): Int = {
    val partitionKey = key.toString

    for(i <- partitions.indices){
      if(partitionKey.startsWith(partitions(i))){
        return i
      }
    }

    numPartitions-1
  }
}
