package com.tgou.data.stanford.recommend.product.model.lr

import java.time.LocalDate

import com.tgou.data.stanford.core.utils.DateUtils
import com.tgou.data.stanford.recommend.RecommendBootstrap
import org.apache.spark.ml.classification.LogisticRegression
import org.apache.spark.ml.feature.{OneHotEncoder, RFormula, StringIndexer}
import org.apache.spark.sql.SparkSession

import scala.util.matching.Regex

object LRProductRecModel {
  def main(args: Array[String]): Unit = {
    RecommendBootstrap(args).bootstrap(execute)
  }

  def execute(spark: SparkSession, appName: String, date: LocalDate, args:Array[String]): Unit = {
    val lastday = DateUtils.dateFormat(date)
    val weekday = DateUtils.dateFormat(date.minusDays(7))

    spark.udf.register("validateMemberId",(member_id:String) => {
    val pattern = new Regex("^\\d+$")
      (pattern findAllIn member_id).nonEmpty
    })

    spark.sql(
      s"""
         |SELECT
         |  member_id               AS member_id,
         |  substring(page, 12)     AS listing_id
         |FROM dw.uba_page
         |WHERE page like '10.pd.item-%'
         |AND validateMemberId(member_id) = true
         |AND his_time >= '2018-01-01'
      """.stripMargin).createOrReplaceTempView("x_lr_origin")

    spark.sql(
      s"""
      select member_id,listing_id,count(1) as c from x_lr_origin group by member_id,listing_id
      """).createOrReplaceTempView("x_lr_group")

    val zheng = spark.sql(
      s"""
         |select
         |  member_id,
         |  listing_id,
         |  1 as label
         |from x_lr_group
         |where c>1
       """.stripMargin)

    val fu = spark.sql(
      s"""
         |select
         |  member_id,
         |  listing_id,
         |  0 as label
         |from x_lr_group
         |where c=1
       """.stripMargin).sample(false,0.3)

    val merge = zheng.union(fu)
    merge.createOrReplaceTempView("x_lr_merge")

    val dataset = spark.sql(
      s"""
         |select
         |  x.flag,
         |  m.age_range,
         |  m.sex,
         |  m.birthday,
         |  m.birth_month,
         |  m.birth_season,
         |  m.constellation,
         |  l.price,
         |  l.original_price,
         |  l.store_id,
         |  l.category1,
         |  l.category2,
         |  l.category3,
         |  l.brand_name
         |from x_lr_merge x
         |inner join persona.basic_info m
         |on x.member_id = m.member_id
         |  and m.card is not null
         |left join persona.listing l
         |on x.listing_id = l.listing_id
       """.stripMargin)


    val indexer = new StringIndexer()
      .setInputCol("constellation")
      .setOutputCol("constellationIndex")
      .fit(dataset)
    val indexed = indexer.transform(dataset)

    val encoder = new OneHotEncoder()
      .setInputCol("constellationIndex")
      .setOutputCol("constellationVec")
    val encoded = encoder.transform(indexed)

    val indexer2 = new StringIndexer()
      .setInputCol("brand_name")
      .setOutputCol("brand_nameIndex")
      .fit(dataset)
    val indexed2 = indexer2.transform(encoded)

    val encoder2 = new OneHotEncoder()
      .setInputCol("brand_nameIndex")
      .setOutputCol("brand_nameVec")

    val encoded2 = encoder.transform(indexed2)



    val formula = new RFormula()
      .setFormula("flag ~ age_range + sex + birthday + birth_month + birth_season + constellation + store_id + brand_name")
      .setFeaturesCol("features")
      .setLabelCol("label")

    val output = formula.fit(dataset).transform(dataset)
    output.select("features", "label").show()

    //val training = spark.read.format("libsvm").load("data/mllib/sample_libsvm_data.txt")

    val lr = new LogisticRegression()
      .setMaxIter(10)
      .setRegParam(0.3)
      .setElasticNetParam(0.8)

    // Fit the model
    val lrModel = lr.fit(output)

    // Print the coefficients and intercept for logistic regression
    println(s"Coefficients: ${lrModel.coefficients} Intercept: ${lrModel.intercept}")

    // We can also use the multinomial family for binary classification
//    val mlr = new LogisticRegression()
//      .setMaxIter(10)
//      .setRegParam(0.3)
//      .setElasticNetParam(0.8)
//      .setFamily("binomial")
//
//    val mlrModel = mlr.fit(training)
//
//    // Print the coefficients and intercepts for logistic regression with multinomial family
//    println(s"binomial coefficients: ${mlrModel.coefficientMatrix}")
//    println(s"binomial intercepts: ${mlrModel.interceptVector}")

  }
}
