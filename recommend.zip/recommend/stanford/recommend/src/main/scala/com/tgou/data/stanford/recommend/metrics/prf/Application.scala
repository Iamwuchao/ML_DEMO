package com.tgou.data.stanford.recommend.metrics.prf

import java.time.LocalDate

import com.tgou.data.stanford.core.utils.DateUtils
import com.tgou.data.stanford.recommend.RecommendBootstrap
import org.apache.spark.sql.{DataFrame, SaveMode, SparkSession}
import org.apache.spark.storage.StorageLevel

object Application {

  def main(args: Array[String]): Unit = {
    RecommendBootstrap(args).bootstrap(execute)
  }

  def execute(spark: SparkSession, appName: String, date: LocalDate, args: Array[String]): DataFrame = {
    val spmDF   = process(spark, Array("scene_id", "process_id", "model_id"), date, "spm")
    val spDF   = process(spark, Array("scene_id", "process_id"), date, "sp")
    val smDF   = process(spark, Array("scene_id", "model_id"), date, "sm")
    val sDF   = process(spark, Array("scene_id"), date, "s")
    sDF.union(spmDF).union(spDF).union(smDF).union(sDF).coalesce(1)
  }

  def process(spark:SparkSession, keys:Array[String], date: LocalDate, data_type: String): DataFrame ={
    import spark.implicits._

    val selectKey = s"concat(${keys.mkString(",'_',")})"
    val groupKey  = s"${keys.mkString(",")}"
    val lastDay = DateUtils.dateFormat(date)

    val groupDF = spark.sql(
      s"""
         |select
         |  $selectKey as key,
         |  query_id,
         |  distinct_merge(rec_id) as info
         |from models_rec
         |where query_id != 'any'
         |group by $groupKey, query_id
       """.stripMargin).as[GroupBean]
    groupDF.persist(StorageLevel.MEMORY_AND_DISK_SER_2)
    groupDF.createOrReplaceTempView("group_t")
    groupDF.write.mode(SaveMode.Overwrite).parquet("/tmp/xhl/recommend/metrics/group_t")

    val metricsDF = spark.sql(
      s"""
         |select
         |  '$lastDay' as date,
         |  concat(key,'_', '$lastDay') as id,
         |  key,
         |  '$data_type' as type,
         |  d2decimal(avg(p)) as p,
         |  d2decimal(avg(r)) as r,
         |  d2decimal(2*avg(p)*avg(r)/(avg(p)+avg(r))) as f1
         |from (
         |  -- 按人统计
         |  select
         |    t1.key,
         |    t1.member_id,
         |    t1.m_click/t2.t_click as r,
         |    t1.m_click/t3.r_count as p
         |  from (
         |    -- 统计 推荐 且 点击 的数量
         |    select
         |      $selectKey as key,
         |      member_id,
         |      count(distinct item_id) as m_click
         |    from scp  where model_id is not null
         |    group by $groupKey, member_id
         |  ) t1
         |  left join (
         |    -- 统计 该人 点击的数量
         |    select
         |      member_id,
         |      count(distinct item_id) as t_click
         |    from scp
         |    group by member_id
         |  ) t2 on t1.member_id = t2.member_id
         |  left join merge_t t3
         |  on t1.member_id = t3.query_id and t1.key = t3.key
         |) t4 group by key
       """.stripMargin)

    metricsDF
  }
  case class GroupBean(key:String,query_id:String,info:String){}

}
