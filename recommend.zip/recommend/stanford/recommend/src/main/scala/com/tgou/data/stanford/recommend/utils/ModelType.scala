package com.tgou.data.stanford.recommend.utils

object ModelType extends Enumeration{
  type ModelType = Value

  // 跨境用户-商品推荐
  val P_KJ_ICF_V1   = Value("p_kj_icf_v1")  //跨境物品协同过滤
  val P_KJ_ALS_V1   = Value("p_kj_als_v1")  //跨境矩阵分解
  val P_KJ_CB_V1    = Value("p_kj_cb_v1")   //跨境基于内容
  val P_KJ_T3C_V1   = Value("p_kj_t3c_v1")  //跨境基于偏好分类
  val P_KJ_TB_V1    = Value("p_kj_tb_v1")   //跨境基于偏好品牌
  val P_KJ_HOT_V1   = Value("p_kj_hot_v1")  //跨境热销

  // 平台用户-商品推荐
  val P_PT_FB_V1    = Value("p_pt_fb_v1")   //平台偏好品牌下的爆品推荐
  val P_PT_T3C_V1   = Value("p_pt_t3c_v1")  //平台三级分类偏好推荐
  val P_PT_ICF_V1   = Value("p_pt_icf_v1")  //平台物品协同过滤推荐
  val P_PT_CB_V1    = Value("p_pt_cb_v1")   //平台基于内容推荐
  val P_PT_ALS_V1   = Value("p_pt_als_v1")  //平台矩阵分解推荐
  val P_PT_HOT_V1   = Value("p_pt_hot_v1")  //平台分类下热销

  val P_PT_HOT_V2   = Value("p_pt_hot_v2")  //平台分类分业态热销 限定为推荐池
  val P_PT_CB_V2    = Value("p_pt_cb_v2")   //平台基于内容的推荐 限定为推荐池
  val P_PT_ICF_V2   = Value("p_pt_icf_v2")  //限定为推荐池

  // 平台物品-物品推荐
  val P_PT_FP_V1    = Value("p_pt_fp_v1")   //平台关联
  val P_PT_SIM_V1   = Value("p_pt_sim_v1")  //平台相似
  val P_PT_CBSIM_V1    = Value("p_pt_cbsim_v1") //平台物品相似度，基于内容的相似度
  val P_PT_CBSIM_V2 = Value("p_pt_cbsim_v2")   //平台物品相似度，推荐池商品

  // 平台用户-品牌推荐
  val B_PT_FP_V1    = Value("b_pt_fp_v1")   //平台品牌关联推荐
  val B_PT_SIM_V1   = Value("b_pt_sim_v1")  //平台品牌相似推荐
  val B_PT_FA_V1    = Value("b_pt_fa_v1")   //平台品牌偏好推荐
  val B_PT_HOT_V1   = Value("b_pt_hot_v1")  //平台品牌热销推荐

  // 指标监控信息
  val M_HOME_METRICS = Value("m_home_metrics")  //首页的上面几个统计数据
  val M_HOME_CHARTS = Value("m_home_charts")    //首页图形数据
  val M_HOME_TABLE  = Value("m_home_table")     //首页数据表
  val M_CLICK       = Value("m_click")          //点击指标
  val M_PRF         = Value("m_prf")            //准确度指标
  val M_COUNT       = Value("m_count")          //推荐商品数量
  val M_SALES_SOURCE = Value("m_sales_source")  //业态销售图形
  val M_SALES_FUNNEL = Value("m_sales_funnel")  //漏斗销售图形
}
