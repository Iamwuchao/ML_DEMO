package com.tgou.data.stanford.recommend.utils

import org.apache.spark.sql.{DataFrame, Row, SparkSession}

import scala.collection.mutable.ArrayBuffer

object SimPartitionUtils {

  /**
    * 根据数量向上浮动，形成key
    *
    * @param table  df
    * @param cols   列名，需要按照上浮的原则，从左到右，最右面是第一个比较的：(最上层，第二层，...，最下层)
    * @return 按照字典顺序从长到短排序
    */
  def generateKeys(table:DataFrame,cols:Array[String],threshold:Int = 100):Array[String] ={
    val arr = table.rdd
      .map(r => {
        val vecs = row2Vec(r,cols.reverse)
        // 如果找到合适的范围，则禁用check，直接记录对应的key
        var check = true
        var keys = new ArrayBuffer[String]()

        for(vec <- vecs){
          if(check){
            if(vec._2 > threshold){
              keys += vec._1
              check = false
            }
          }else{
            keys += vec._1
          }
        }
        keys.reverse.mkString(",")
      })
      .distinct
      .collect

    // 按照从长到短排序，比如 a,b,c 排在 a,b前面
    arr.sortWith(_ > _)
  }

  /**
    * 提取对应的序列
    * @param row  row
    * @param cols 列数组
    * @return
    */
  def row2Vec(row:Row, cols:Array[String]): List[(String,Int)] ={
    val buffer = new ArrayBuffer[(String,Int)]()

    for(key <- cols){
      val arr = row.getAs[String](key).toString.split(":")
      buffer += ((arr(0),arr(1).toInt))
    }

    buffer.toList
  }

  def main(args: Array[String]): Unit = {
    var spark = SparkSession
      .builder()
      .master("local")
      .appName("sim-parition-test")
      .getOrCreate()

    spark.sparkContext.setLogLevel("WARN")// 日志级别

    val df = spark.createDataFrame(
      Seq(
        ("a1:1000","a2:200","a3:30","a4:4"),
        ("a1:500","a2:60","a3:9","a4:8"),
        ("a1:5000","a2:600","a3:900","a4:102")
      )).toDF("a","b","c","d")
    val cols = Array("a","b","c","d")
    generateKeys(df,cols).foreach(println(_))

//    val statistics = spark.read.parquet(s"hdfs://172.16.3.2:8020/tmp/xhl/recommend/product/statistics")
//    val partitions = SimPartitionUtils.generateKeys(statistics,cols,MIN_THREDHOLD)
//    println(partitions.size)
  }
}
