package com.tgou.data.stanford.recommend.product.model.brandhot

import java.time.LocalDate

import com.tgou.data.stanford.core.udaf.MergeUDAF
import com.tgou.data.stanford.core.utils.DateUtils
import com.tgou.data.stanford.recommend.RecommendBootstrap
import com.tgou.data.stanford.recommend.utils.{ModelType, PersistUtils, SaveType}
import org.apache.spark.sql.SparkSession

/**
  * 用户偏好品牌推荐
  */
object Application {

  def main(args: Array[String]): Unit = {
    RecommendBootstrap(args).bootstrap(execute)
  }

  def execute(spark: SparkSession, appName: String, date: LocalDate, args: Array[String]): Unit = {
    val isOnline = !"test".equals(args(2))
    val lastday = DateUtils.dateFormat(date)

    // 读取品牌下爆品
    spark.udf.register("merge",new MergeUDAF())

    val brand_hot = spark.sql(
      s"""
         |select
         |    brand_id,
         |    listing_id,
         |    sl,
         |    rank
         |from (
         |    select
         |        brand_id,
         |        listing_id,
         |        sl,
         |        row_number() over (partition by brand_id order by sl desc) as rank
         |    from (
         |        select
         |            l.brand_id,
         |            p.mall_product_id as listing_id,
         |            sum(p.product_quantity) as sl
         |        from dw.order_product p
         |        inner join persona.listing l
         |            on p.mall_product_id = l.listing_id
         |            and l.listing_state = 'onshelf'
         |            and ((l.source = 1 and l.is_selected=1) or l.source=4)
         |        where p.his_time='$lastday'
         |            and p.ship_time is not null
         |            and p.return_time is null
         |            and p.brand_id is not null
         |        group by l.brand_id,p.mall_product_id
         |    ) t1
         |) t2
         |where rank <= 50
       """.stripMargin)
    brand_hot.createOrReplaceTempView("brand_hot")

    // 合并保存结果，正常不会有重复，所以不需要去重
    // 直接基于品牌排名和品牌下的热销排名进行混合，依次取商品
    val favor_brand_hot_seller = spark.sql(
      s"""
         |select
         |    t1.member_id as query_id,
         |    t1.brand_id,
         |    t1.rank as b_rank,
         |    t2.listing_id as rec_id,
         |    t2.rank as l_rank,
         |    (t2.rank-1)*6+t1.rank as index
         |from (
         |    select
         |        member_id,
         |        brand_id,
         |        row_number() over(partition by member_id order by score desc) rank
         |    from persona.ratings
         |) t1
         |inner join brand_hot t2
         |on t1.brand_id=t2.brand_id
         |where t1.rank <=6
       """.stripMargin)

    PersistUtils.save(spark, favor_brand_hot_seller, ModelType.P_PT_FB_V1, SaveType.USER_PRODUCT_REC, isOnline)
  }
}
