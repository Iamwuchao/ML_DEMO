package com.tgou.data.stanford.recommend.nlp

import org.apache.spark.ml.feature.{HashingTF, IDF, Tokenizer}
import org.apache.spark.sql.SparkSession

object TFIDFTest {
  def main(args: Array[String]) {
    val spark = SparkSession
      .builder
      .master("local")
      .appName("TfIdfExample")
      .getOrCreate()

    // $example on$
    val sentenceData = spark.createDataFrame(Seq(
      (0.0, "你好 我 是 小明 啊"),
      (1.0, "我 你好 是 小红"),
      (2.0, "最近 忙 什么 呢")
    )).toDF("label", "sentence")

    val tokenizer = new Tokenizer().setInputCol("sentence").setOutputCol("words")
    val wordsData = tokenizer.transform(sentenceData)

    val hashingTF = new HashingTF()
      .setInputCol("words").setOutputCol("rawFeatures").setNumFeatures(2000)

    val featurizedData = hashingTF.transform(wordsData)

    // alternatively, CountVectorizer can also be used to get term frequency vectors

    val idf = new IDF().setInputCol("rawFeatures").setOutputCol("features")
    val idfModel = idf.fit(featurizedData)

    val rescaledData = idfModel.transform(featurizedData)
    rescaledData.select("label", "features").show()
    val list = rescaledData.select("label", "features").collect()
    // $example off$
    println(list.size)
    spark.stop()
  }
}
