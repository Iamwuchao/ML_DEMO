package com.tgou.data.stanford.recommend.product.model.lr

object FeatureConvert extends Enumeration {
  type FeatureConvert = Value

  val STR_2_ONEHOT, NUM_2_BUCKET, MERGE, AGE, HASHING = Value
}

