package com.tgou.data.stanford.recommend.utils

object SaveType extends Enumeration{
  type SaveType = Value

  val USER_PRODUCT_REC  = Value("user_product_rec")
  val PRODUCT_REC       = Value("product_rec")
  val USER_BRAND_REC    = Value("user_brand_rec")
  val BRAND_REC         = Value("brand_rec")
  val SQOOP_REC         = Value("sqoop_rec")
  val METRICS           = Value("metrics")
  val OTHER             = Value("other")

  private val default = Seq("query_id","rec_id", "index")

  private val checks:Map[SaveType,Seq[String]] = Map(
    SQOOP_REC -> Seq("index","rec_id","info"),
    METRICS   -> Seq(),
    OTHER     -> Seq()
  )

  /**
    * 获取检查列表
    *
    * @param saveType 保存类型
    * @return
    */
  def getAssertList(saveType: SaveType):Seq[String] = {
    checks.getOrElse(saveType, default)
  }
}
