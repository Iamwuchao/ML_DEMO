package com.tgou.data.stanford.recommend.brand.model.fp

import java.time.LocalDate

import com.tgou.data.stanford.core.udaf.MergeUDAF
import com.tgou.data.stanford.core.utils.DateUtils
import com.tgou.data.stanford.recommend.RecommendBootstrap
import com.tgou.data.stanford.recommend.utils.{ModelType, PersistUtils, SaveType}
import org.apache.spark.mllib.fpm.FPGrowth
import org.apache.spark.sql.{SaveMode, SparkSession}
import org.apache.spark.storage.StorageLevel

import scala.collection.mutable
import scala.collection.mutable.ArrayBuffer

object Application {

  def main(args: Array[String]) {
    RecommendBootstrap(args).bootstrap(execute)
  }

  def execute(spark: SparkSession, appName: String, date: LocalDate, args:Array[String]): Unit = {
    import spark.implicits._

    val isOnline = !"test".equals(args(2))
    val lastday = DateUtils.dateFormat(date)
    val halfYear = DateUtils.dateFormat(date.plusDays(-360))

    spark.udf.register("merge",new MergeUDAF())
    spark.udf.register("str2Vec",(line:String)=>Data(line.split(",")))
    spark.udf.register("format",(data: String) => {
      val buffer = ArrayBuffer[(String,Int)]()

      for(line <- data.split(",")){
        val splits = line.split(":")
        buffer += ((splits(0),splits(1).toInt))
      }

      buffer.sortWith((a,b)=>a._2>b._2)
        .take(3)
        .map(t2 => t2._1+":"+t2._2)
        .mkString(",")
    })

    // 获得基础的计算数据
    // fixed_tags第一位为3为试衣秀大赏订单，剔除
    // http://c.51tiangou.com/display/~lidainan/LocalOrderUtils
    val source = spark.sql(
      s"""
         |select
         |  op.brand_id,
         |  oi.order_id,
         |  oi.member_id,
         |  concat(oi.member_id,'_',to_date(op.ship_time)) as validate_id
         |from dw.order_product op
         |inner join dw.order_information oi
         |  on op.tgou_order_id = oi.order_id
         |  and oi.his_time = '$lastday'
         |  and substr(oi.fixed_tags,0,1) != '3'
         |where op.his_time = '$lastday'
         |  and op.brand_id is not null
         |  and op.ship_time is not null
         |  and op.ship_time >= '$halfYear'
         |  and op.return_time is null
       """.stripMargin)
    source.createOrReplaceTempView("source_t")

    // 剔除当天交易订单数在6笔以上的
    val filter = spark.sql(
      s"""
         |select
         |  validate_id
         |from (
         |  select
         |    validate_id,
         |    count(distinct order_id) as count
         |  from source_t
         |  group by validate_id
         |) t
         |where count <= 6
       """.stripMargin)
    filter.createOrReplaceTempView("filter_t")

    // 筛选形成 购物篮数据集
    val shoppingCart = spark.sql(
      s"""
         |select
         |  member_id,
         |  merge(brand_id) as data
         |from (
         |  select
         |    member_id,
         |    brand_id
         |  from (
         |    select
         |      st.brand_id,
         |      st.member_id
         |    from source_t st
         |    inner join filter_t ft
         |      on st.validate_id = ft.validate_id
         |  ) t
         |  group by member_id,brand_id
         |) t1
         |group by member_id
       """.stripMargin)

    val transactions = shoppingCart.map(row => row.getString(1).split(",")).cache()
    transactions.persist(StorageLevel.MEMORY_AND_DISK_SER_2)
    println(s"Number of transactions: ${transactions.count()}")

    val model = new FPGrowth()
      .setMinSupport(0.00001)
      .setNumPartitions(10)
      .run(transactions.toJavaRDD)

    // 统计分析
    val validateRDD = model.freqItemsets.filter(r => r.items.length>1)
    validateRDD.persist(StorageLevel.MEMORY_AND_DISK_SER_2)
    println(s"Number of frequent itemsets: ${validateRDD.count()}")

    val fpDF = validateRDD.flatMap(line => {
      val buffer = mutable.ArrayBuffer[(String,String,Long)]()

      /**
        * (a,b,c),12
        * --->
        * (a,b,12)(a,c,12)(b,a,12)(b,c,12)(c,a,12)(c,b,12)
        */
      val length = line.items.length
      for(i <- 0 until length){
        for(j <- 0 until length){
          if(i!=j){
            buffer += ((line.items(i),line.items(j),line.freq))
          }
        }
      }

      buffer
    }).toDF("brand_id","fp_brand_id","freq")
    fpDF.createOrReplaceTempView("fp_df")
    if(!isOnline){
      fpDF.persist(StorageLevel.MEMORY_AND_DISK_SER)
      fpDF.write.mode(SaveMode.Overwrite).parquet("/tmp/xhl/recommend/updater/brand/fp_df")
    }

    // 计算每个品牌的关联品牌，取top3
    val fp_rec_result = spark.sql(
      s"""
         |select * from (
         |  select
         |    brand_id,
         |    fp_brand_id as rec_brand_id,
         |    freq as score,
         |    rank() over (partition by brand_id order by freq desc) as rank
         |  from (
         |    select
         |      brand_id,
         |      fp_brand_id,
         |      max(freq) as freq
         |    from fp_df
         |    group by brand_id,fp_brand_id
         |  ) t1
         |) t2 where rank <= 3
       """.stripMargin)
    fp_rec_result.createOrReplaceTempView("fp_rec_r")
    if(!isOnline){
      fp_rec_result.persist(StorageLevel.MEMORY_AND_DISK_SER)
      fp_rec_result.write.mode(SaveMode.Overwrite).parquet("/tmp/xhl/recommend/updater/brand/fp_rec_r")
    }

    // 计算用户最喜欢的品牌top6,交叉排序
    val result = spark.sql(
      s"""
         |select
         |    t1.member_id as query_id,
         |    t1.brand_id as favor_brand_id,
         |    t1.rank as favor_brand_rank,
         |    t2.rec_brand_id as rec_id,
         |    t2.rank as fp_rank,
         |    t2.score as score,
         |    (t2.rank-1)*6+t1.rank as index
         |from (
         |    select
         |        member_id,
         |        brand_id,
         |        row_number() over(partition by member_id order by score desc) rank
         |    from persona.ratings
         |) t1
         |inner join fp_rec_r t2
         |on t1.brand_id=t2.brand_id
         |where t1.rank <=6
       """.stripMargin)
    PersistUtils.save(spark, result, ModelType.B_PT_FP_V1, SaveType.USER_BRAND_REC, isOnline)
  }

  case class Data(data:Array[String])
}
