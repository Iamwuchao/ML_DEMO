package com.tgou.data.stanford.recommend.utils

import org.apache.spark.sql.Row
import org.apache.spark.sql.expressions.{MutableAggregationBuffer, UserDefinedAggregateFunction}
import org.apache.spark.sql.types._

/*
 *created by wuchao on 2018/4/19.
 *package_name : com.tgou.data.stanford.recommend.utils
 */
class PeriodUDAF extends UserDefinedAggregateFunction{
  override def inputSchema: StructType = new StructType().add("jysj",LongType)

  override def bufferSchema: StructType = new StructType().add("time_list_str", StringType)


  override def dataType: DataType = LongType

  override def deterministic: Boolean = true

  override def initialize(buffer: MutableAggregationBuffer): Unit = {
    buffer(0) ="";
  }

  override def update(buffer: MutableAggregationBuffer, input: Row): Unit ={
    buffer.update(0,buffer.getString(0)+"#"+input.getLong(0).toString)
  }

  override def merge(buffer1: MutableAggregationBuffer, buffer2: Row): Unit = {
    val value = buffer1.getString(0)+buffer2.getString(0)
    buffer1.update(0,value)
  }

  override def evaluate(buffer: Row): Any ={
    val str_arr = buffer.getString(0).split("#")
    val num_str_arr = str_arr.filter(p => p.trim.length != 0)
    val time_list = num_str_arr.map(time_str=>{
      time_str.toLong
    })
    val sorted_time_list= time_list.sorted
    var pre_time = sorted_time_list(0)
    var sum_times = 0L
    sorted_time_list.foreach(buy_time=>{
      sum_times =sum_times+ buy_time-pre_time
      pre_time = buy_time
    })
    sum_times/(time_list.length*1000*60*60*24)//将毫秒转换为天
  }
}
