package com.tgou.data.stanford.recommend.brand.model

import java.time.LocalDate

import com.tgou.data.stanford.core.udaf.TopFieldByDouble
import com.tgou.data.stanford.recommend.RecommendBootstrap
import org.apache.spark.sql.{SaveMode, SparkSession}
import org.apache.spark.storage.StorageLevel

object UserFavorBrandModel {
  def main(args: Array[String]): Unit = {
    RecommendBootstrap(args).bootstrap(execute)
  }

  def execute(spark: SparkSession, appName: String, date: LocalDate, args:Array[String]): Unit = {
      spark.udf.register("topN",new TopFieldByDouble())

      val result = spark.sql(
        s"""
           |select
           |  member_id,
           |  topN(brand_id,score,6) as line,
           |  '' as time
           |from persona.ratings
           |group by member_id
         """.stripMargin).coalesce(10)

    result.persist(StorageLevel.MEMORY_AND_DISK_2)
    result.write.mode(SaveMode.Overwrite).parquet("/recommend/data/user_favor_brand")
    result.write.mode(SaveMode.Overwrite).option("sep","^").option("nullValue","").csv("/recommend/sqoop/user_favor_brand")
  }
}
