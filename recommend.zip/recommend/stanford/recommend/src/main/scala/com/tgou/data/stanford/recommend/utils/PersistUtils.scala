package com.tgou.data.stanford.recommend.utils

import java.time.LocalDate
import java.time.format.DateTimeFormatter

import com.alibaba.fastjson.JSON
import com.tgou.data.stanford.core.utils.DateUtils
import com.tgou.data.stanford.recommend.utils.ModelType.ModelType
import com.tgou.data.stanford.recommend.utils.SaveType.SaveType
import org.apache.spark.sql.execution.datasources.hbase.HBaseTableCatalog
import org.apache.spark.sql.{DataFrame, SaveMode, SparkSession}
import org.apache.spark.storage.StorageLevel

/**
  * 推荐系统数据持久化工具类
  */
object PersistUtils {

  val PARQUET_PATH  = "/recommend/parquet"
  val SQOOP_PATH    = "/recommend/sqoop"
  val METRICS_PATH  = "/recommend/metrics"

  /**
    * 读取保存的内容
    *
    * @param spark        sparksession
    * @param model_name   模型名字
    * @param online       是否线上环境
    * @return
    */
  def read(spark:SparkSession, model_name:String, online:Boolean = false, localDate:LocalDate = LocalDate.now()): DataFrame ={
    val date = DateUtils.dateFormat(localDate,DateUtils.DATE_PATH_FORMAT)
    val namespace = getNamespace(online)
    spark.read.parquet(s"$PARQUET_PATH/$namespace/$date/$model_name")
  }

  /**
    * 读取基于历史的保存内容，如果没有当天的数据，最多向前查询3天
    *
    * @param spark      spark
    * @param model_name 模型名字
    * @param online     是否在线，默认是测试环境
    * @param date       日期，默认是昨天
    * @return
    */
  def readHistory(spark:SparkSession, model_name:String, online:Boolean = false, date:LocalDate = LocalDate.now().minusDays(1)): DataFrame ={
    val namespace = getNamespace(online)
    var retries = 3
    var parquet = spark.emptyDataFrame
    while(retries > 0){
      try{
        val path = DateUtils.dateFormat(date,DateUtils.DATE_PATH_FORMAT)
        parquet = spark.read.parquet(s"$PARQUET_PATH/$namespace/$path/$model_name")
        retries = 0
      }catch{
        case e: Exception => retries -= 1
      }
    }
    parquet
  }

  /**
    * 保存方法
    *
    * @param spark      spark
    * @param df         df
    * @param model_name 模型名字
    * @param save_type  保存类型
    * @param online     是否线上
    */
  def save(spark:SparkSession, df: DataFrame, model_name: String, save_type:SaveType, online:Boolean = false, localDate:LocalDate = LocalDate.now()):Unit = {
    df.persist(StorageLevel.MEMORY_AND_DISK_SER)

    val date = DateUtils.dateFormat(localDate,DateUtils.DATE_PATH_FORMAT)

    import spark.implicits._

    spark.udf.register("merge", new SortedMergeUDAF())

    // 校验参数
    assert(df, SaveType.getAssertList(save_type))

    // 格式化前缀，如果是测试环境，所有的表
    val namespace = getNamespace(online)

    // 统一保存
    df.write.mode(SaveMode.Overwrite).parquet(s"$PARQUET_PATH/$namespace/$date/$model_name")

    save_type match {
      case SaveType.SQOOP_REC =>
        df.write.mode(SaveMode.Overwrite).option("sep","^").csv(s"$SQOOP_PATH/$namespace/$model_name")
      case SaveType.METRICS =>
        df.write.mode(SaveMode.Overwrite).option("sep","^").csv(s"$METRICS_PATH/$namespace/$date/$model_name")
      case SaveType.OTHER =>
        df.write.mode(SaveMode.Overwrite).parquet(s"$PARQUET_PATH/$namespace/$model_name")
      case _ =>
        val tempDF = df.toJSON
          .map(j => {
            val json = JSON.parseObject(j)
            (json.getString("query_id"),json.getInteger("index"),json.getString("rec_id")+"^"+j)
          })
          .toDF("query_id","index",model_name)

        tempDF.createOrReplaceTempView("temp")

        val mergedDF = spark.sql(s"select query_id, merge(index, $model_name) as $model_name from temp group by query_id")

        saveToHbase(mergedDF, namespace, save_type.toString, "query_id", model_name)
    }

    df.unpersist()
  }

  /**
    * 推荐内容保存
    *
    * @param df         推荐结果dataframe
    * @param model_type 算法模型
    * @param save_type  保存类型
    * @param online     是否上线，注意！不要直接以上线模式部署!!
    */
  def save(spark:SparkSession, df: DataFrame, model_type: ModelType, save_type:SaveType, online:Boolean):Unit = {
    save(spark,df,model_type.toString,save_type,online)
  }

  /**
    * 按照日期保存
    *
    * @param spark      spark
    * @param df         保存的dfString
    * @param model_type 模型
    * @param save_type  保存类型
    * @param online     是否上线
    * @param localDate  日期
    */
  def save(spark:SparkSession, df: DataFrame, model_type: ModelType, save_type:SaveType, online:Boolean, localDate: LocalDate):Unit = {
    save(spark,df,model_type.toString,save_type,online,localDate)
  }

  /**
    * 判断DataFrame格式是否合法
    *
    * @param df     dataFrame
    * @param fields 必要的列
    */
  private def assert(df:DataFrame, fields:Seq[String]): Unit ={
    df.schema
    fields.foreach(field => {

      var flag = false
      df.schema.foreach(sf => {
        if(sf.name.equals(field)){
          flag = true
        }
      })

      if(!flag){
        val df_schema = df.schema.mkString(",")
        val needs = fields.mkString(",")
        throw new RecommendException(s"DF don't have the column: $field, please check your dataframe. Current dataframe's schema: [$df_schema], but needs: [$needs]")
      }
    })
  }

  /**
    * 保存到Hbase
    *
    * @param df         dataFrame
    * @param namespace  命名空间
    * @param table      表名
    * @param rowkey     rowkey
    * @param column     列名
    */
  private def saveToHbase(df: DataFrame, namespace:String, table:String, rowkey:String, column:String): Unit = {

    def catalog = s"""{
                     |"table":{"namespace":"$namespace", "name":"$table"},
                     |"rowkey":"$rowkey",
                     |"columns":{
                     |  "$rowkey":{"cf":"rowkey", "col":"$rowkey", "type":"string"},
                     |  "$column":{"cf":"t",      "col":"$column", "type":"string"}
                     |}
                     |}""".stripMargin

    df.write
      .mode(SaveMode.Overwrite)
      .options(Map(HBaseTableCatalog.tableCatalog -> catalog))
      .format("org.apache.spark.sql.execution.datasources.hbase")
      .save()
  }

  /**
    * 根据是否线上，判断命名空间
    *
    * @param online 是否线上
    * @return
    */
  private def getNamespace(online:Boolean):String = {
    if(online) "rec" else "test_rec"
  }
}
