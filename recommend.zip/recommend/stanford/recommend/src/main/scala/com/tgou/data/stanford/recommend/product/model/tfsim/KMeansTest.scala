package com.tgou.data.stanford.recommend.product.model.tfsim

import java.time.LocalDate

import com.tgou.data.stanford.recommend.RecommendBootstrap
import org.apache.spark.ml.clustering.{BisectingKMeans, KMeans}
import org.apache.spark.ml.feature.{HashingTF, Tokenizer}
import org.apache.spark.sql.SparkSession

object KMeansTest {
  def main(args: Array[String]): Unit = {
    RecommendBootstrap(args).bootstrap(execute)
  }

  def execute(spark: SparkSession, appName: String, date: LocalDate, args:Array[String]): Unit = {
    // 1. 注册方法
    TFSimPreprocess.registerView(spark)

    // 2. 获取源数据
    val origin = TFSimService.registerOrigin(spark)

    val tokenizer = new Tokenizer().setInputCol("desc").setOutputCol("words")
    val wordsData = tokenizer.transform(origin)

    // 统计词频
    val hashingTF = new HashingTF()
      .setInputCol("words")
      .setOutputCol("features")
      .setNumFeatures(2000)
      .setBinary(true)

    val featurizedData = hashingTF.transform(wordsData)

    val bkm = new BisectingKMeans()
      .setK(args(2).toInt)
      .setSeed(1)
      .setMinDivisibleClusterSize(args(3).toDouble)

    val model = bkm.fit(featurizedData)

    // Evaluate clustering.
    val cost = model.computeCost(featurizedData)
    println(s"Within Set Sum of Squared Errors = $cost")

    // Shows the result.
    println("Cluster Centers: ")
    val centers = model.clusterCenters
    //centers.foreach(println)



    model.summary.clusterSizes.foreach(println)
  }
}
