package com.tgou.data.stanford.recommend.brand.model.favor

import java.time.LocalDate

import com.tgou.data.stanford.recommend.RecommendBootstrap
import com.tgou.data.stanford.recommend.utils.{ModelType, PersistUtils, SaveType}
import org.apache.spark.sql.SparkSession

object Application {
  def main(args: Array[String]): Unit = {
    RecommendBootstrap(args).bootstrap(execute)
  }

  def execute(spark: SparkSession, appName: String, date: LocalDate, args: Array[String]): Unit = {
    val isOnline = !"test".equals(args(2))

    val result = spark.sql(
      s"""
         |select
         |  member_id as query_id,
         |  brand_id as rec_id,
         |  row_number() over(partition by member_id order by score desc) index
         |from persona.ratings
       """.stripMargin)

    PersistUtils.save(spark, result, ModelType.B_PT_FA_V1, SaveType.USER_BRAND_REC, isOnline)
  }
}
