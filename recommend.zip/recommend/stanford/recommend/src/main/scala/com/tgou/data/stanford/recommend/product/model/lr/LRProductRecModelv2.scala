package com.tgou.data.stanford.recommend.product.model.lr

import java.time.LocalDate

import com.tgou.data.stanford.recommend.RecommendBootstrap
import org.apache.spark.ml.Pipeline
import org.apache.spark.ml.classification.LogisticRegression
import org.apache.spark.ml.evaluation.BinaryClassificationEvaluator
import org.apache.spark.ml.feature.{ChiSqSelector, PCA, SQLTransformer, VectorAssembler}
import org.apache.spark.ml.tuning.{CrossValidator, ParamGridBuilder}
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.{DataFrame, Row, SparkSession}

object LRProductRecModelv2 {

  def main(args: Array[String]): Unit = {
    RecommendBootstrap(args).bootstrap(execute)
  }

  def execute(spark: SparkSession, appName: String, date: LocalDate, args: Array[String]): Unit = {

    spark.udf.register("toDouble",(str:String)=> str.toDouble)

    val ratings = spark.read.parquet(s"/tmp/xhl/recommend/lr/train_rating_v2")
    ratings.createOrReplaceTempView("x_ratings")

    val memberFeatureDF = spark.read.parquet(s"/tmp/xhl/recommend/lr/basic_feature")
    memberFeatureDF.createOrReplaceTempView("x_member_feature")

    val listingFeatureDf = spark.read.parquet(s"/tmp/xhl/recommend/lr/listing_feature")
    listingFeatureDf.createOrReplaceTempView("x_listing_feature")

    val data = spark.sql(
      s"""
         |select
         |  toDouble(r.label) as label,m.basic_features,l.listing_features
         |from x_ratings r
         |inner join x_member_feature m
         |on r.member_id = m.member_id
         |inner join x_listing_feature l
         |on r.listing_id = l.listing_id
       """.stripMargin)

    val assembler = new VectorAssembler()
      .setInputCols(Array("basic_features", "listing_features"))
      .setOutputCol("features")

    val splits = assembler.transform(data)
      .selectExpr("label", "features as selectedFeatures")
      .randomSplit(Array(0.7, 0.3), seed = 11L)

    val training = splits(0).cache()
    val test = splits(1).cache()

    // 构建transformer以及estimator
    val chiSqSelector = new ChiSqSelector()
      .setNumTopFeatures(200)
      .setFeaturesCol("selectedFeatures")
      .setLabelCol("label")
      .setOutputCol("features")

    val pca = new PCA()
      .setInputCol("selectedFeatures")
      .setOutputCol("features")
      .setK(200)


    val lr = new LogisticRegression().setMaxIter(20)

    // 构建参数
    val paramGrid = new ParamGridBuilder()
        //.addGrid(lr.maxIter,Array())
      .addGrid(lr.regParam, Array(0.1, 0.01))
//      .addGrid(pca.k,Array(100,200,400))
      .addGrid(chiSqSelector.numTopFeatures,Array(100,200,500))
      .build()

    // 构建Pipeline
    val pipeline = new Pipeline().setStages(Array(chiSqSelector, lr))

    // 开启cross训练
    val cv = new CrossValidator()
      .setEstimator(pipeline)
      .setEvaluator(new BinaryClassificationEvaluator)
      .setEstimatorParamMaps(paramGrid)
      .setNumFolds(3)//分成了3份，前两份用于测试集，最后一份用于训练集

    val cvmodel = cv.fit(training)
    cvmodel.write.overwrite().save(s"/tmp/xhl/recommend/lr/model")

    val valuep: RDD[Row] = cvmodel.transform(test).select("label", "prediction").rdd
    val MSE = valuep.map{case Row(label: Double, prediction: Double) =>
      math.pow(label - prediction, 2)}.mean()

    println("training Mean Squared Error = " + MSE)
  }
}
