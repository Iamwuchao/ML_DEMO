package com.tgou.data.stanford.recommend.product.model.brandfp

import java.time.LocalDate

import com.tgou.data.stanford.core.utils.{DateUtils, HBaseQualifier, HBaseUtils}
import com.tgou.data.stanford.recommend.RecommendBootstrap
import com.tgou.data.stanford.recommend.utils.{AlternateMergeUDAF, SortMergeUDAF}
import org.apache.spark.sql.{SaveMode, SparkSession}
import org.apache.spark.storage.StorageLevel

object BrandFPProductRecModel {
  def main(args: Array[String]): Unit = {
    RecommendBootstrap(args).bootstrap(execute)
  }

  def execute(spark: SparkSession, appName: String, date: LocalDate, args:Array[String]): Unit = {
    val lastday = DateUtils.dateFormat(date)

    spark.udf.register("sort_merge",new SortMergeUDAF())
    spark.udf.register("alter_merge", new AlternateMergeUDAF())
    spark.udf.register("str2num",(str:String)=>str.toDouble)

    // 第一步，计算品牌下的top100
    val brandHotRank = spark.sql(
      s"""
         |select
         |    *
         |from (
         |    select
         |        brand_id,
         |        listing_id,
         |        sl,
         |        row_number() over (partition by brand_id order by sl desc) as rank
         |    from (
         |        select
         |            listing_id,
         |            brand_id,
         |            str2num(online_sl) as sl
         |        from persona.listing
         |        where ((source=1 and is_selected=1) or source = 4)
         |            and listing_state = 'onshelf'
         |    ) t1
         |) t2
         |where rank <= 100
       """.stripMargin)

    // 这个表肯定还有其他的使用场景，这里先单独保存
    brandHotRank.persist(StorageLevel.MEMORY_AND_DISK_2)
    brandHotRank.write.mode(SaveMode.Overwrite).parquet("/recommend/data/brand_hot_rank_v2")
    brandHotRank.createOrReplaceTempView("brand_hot_rank_v2")


    // 第二步，读取品牌关联表
    spark.read.parquet("/recommend/data/bh_ar_rec").createOrReplaceTempView("x_ar")
    val brandARDF = spark.sql(
      s"""
         |select
         |    brand_id,
         |    split(ar_brand,':')[0] as ar_brand,
         |    split(ar_brand,':')[1] as ar_support
         |from (
         |  select brand_id,explode(split(data,',')) as ar_brand from x_ar
         |) t
       """.stripMargin)
    brandARDF.persist(StorageLevel.MEMORY_AND_DISK_2)
    brandARDF.write.mode(SaveMode.Overwrite).parquet("/tmp/xhl/recommend/product_fp_rec/brand_ar")
    brandARDF.createOrReplaceTempView("brand_ar")

    // 第三步，计算单品关联品
    val mergeDF = spark.sql(
      s"""
         |select
         |  l.listing_id,
         |  l.brand_id,
         |  ar.ar_brand,
         |  ar.ar_support,
         |  hot.listing_id as rec_listing_id,
         |  hot.sl,
         |  hot.rank
         |from persona.listing l
         |left join brand_ar ar
         |  on l.brand_id = ar.brand_id
         |left join brand_hot_rank_v2 hot
         |  on ar.ar_brand = hot.brand_id
         |where listing_state = 'onshelf'
       """.stripMargin)
    mergeDF.persist(StorageLevel.MEMORY_AND_DISK_2)
    mergeDF.write.mode(SaveMode.Overwrite).parquet("/tmp/xhl/recommend/product_fp_rec/merge_t")
    mergeDF.createOrReplaceTempView("merge_t")

    // 第四步，合并关联品牌下的数据，合并属性
    // 这里需要 剔除关联不到品牌、品牌下没有销售商品的 数据
    val sortDF = spark.sql(
      s"""
         |select
         |  listing_id,
         |  ar_brand,
         |  max(ar_support) as ar_support,
         |  sort_merge(rank,concat(rec_listing_id,':',brand_id,':',ar_brand,':',ar_support,':',sl,':',rank)) as data
         |from merge_t
         |where ar_brand is not null
         |  and rank is not null
         |group by listing_id,ar_brand
       """.stripMargin)
    sortDF.persist(StorageLevel.MEMORY_AND_DISK_2)
    sortDF.write.mode(SaveMode.Overwrite).parquet("/tmp/xhl/recommend/product_fp_rec/sorted_t")
    sortDF.createOrReplaceTempView("sorted_t")

    // 第五步，交叉合并结果数据
    val alterDF = spark.sql(
      s"""
         |select
         |  listing_id,
         |  alter_merge(rank,data) as fp_rec
         |from (
         |  select
         |    listing_id,
         |    data,
         |    row_number() over (partition by listing_id order by ar_support desc) as rank
         |  from sorted_t
         |) t
         |group by listing_id
       """.stripMargin)
    alterDF.persist(StorageLevel.MEMORY_AND_DISK_2)
    alterDF.write.mode(SaveMode.Overwrite).parquet("/tmp/xhl/recommend/product_fp_rec/alter")

    // 第六步，保存数据到hbase
    alterDF.write.mode(SaveMode.Overwrite).parquet("/recommend/data/product_fp")

    // 6. 保存到hbase
    HBaseUtils.save2HBase(
      df              = alterDF,
      cols            = Array((0,"listing_id","string"),(1,"fp_rec","string")),
      table           = "rec:product",
      hBaseQualifier  = HBaseQualifier.product
    )
  }
}
