package com.tgou.data.stanford.recommend.preprocess

import java.time.LocalDate

import com.tgou.data.stanford.core.utils.DateUtils
import com.tgou.data.stanford.recommend.RecommendBootstrap
import com.tgou.data.stanford.recommend.utils.{PersistUtils, SaveType}
import org.apache.spark.sql.{SaveMode, SparkSession}
import java.sql.Date
import java.time.format.DateTimeFormatter

import scala.util.matching.Regex

/**
  * Created by Travis on 27/03/2018.
  */

object UserProductRatings {
  def main(args: Array[String]) {
    RecommendBootstrap(args).bootstrap(execute)
  }

  def execute(spark: SparkSession, appName: String, date: LocalDate, args: Array[String]): Unit = {

    val online = !"test".equals(args(2))

//    val dateTimestamp = new java.util.Date().getTime
//    val format = new java.text.SimpleDateFormat("yyyy-MM-dd")
//
//    val date = format.format(dateTimestamp - 1 * 24 * 60 * 60 * 1000L)
//    val lastMonth = format.format(dateTimestamp - 30 * 24 * 60 * 60 * 1000L)
//    val halfYear = format.format(dateTimestamp - 6 * 30 * 24 * 60 * 60 * 1000L)

    val dateStr = DateUtils.dateFormat(date)
    val lastMonthStr = DateUtils.dateFormat(date.minusMonths(1))
    val halfYearStr = DateUtils.dateFormat(date.minusMonths(6))

    registerUDF(spark)

    //------------------------
    // 1. order score
    //------------------------
    val orderSqlText =
      s"""
        |select
        |  o.member_id         as member_id,
        |  op.mall_product_id  as listing_id,
        |  clipNormalize(sum(timeAttenuation(calOrderScore(op.create_time,op.pay_time,op.ship_time,op.return_time,op.cancel_time),op.etl_time,100,1.5,10,0.5)),-2,20) as score
        |from dw.order_product op
        |inner join dw.order_information o
        |  on op.tgou_order_id = o.order_id
        |  and o.his_time = '$dateStr'
        |  and o.etl_time >= '$halfYearStr'
        |inner join dw.listing l
        |  on op.mall_product_id = l.listing_id
        |  AND l.state='onshelf'
        |  and l.his_time='$dateStr'
        |where
        |  (op.product_source = 1 or op.product_source = 3 or op.product_source = 4)
        |  and op.his_time='$dateStr'
        |group by o.member_id,op.mall_product_id
      """.stripMargin

    val orderDF = spark.sql(orderSqlText)
    orderDF.createOrReplaceTempView("norm_order")

    if(!online) {
      orderDF.write.mode(SaveMode.Overwrite).format("csv").option("delimiter", "^").option("nullValue", " ").save("/tmp/zhuweicheng/recommend/rating/norm_order.csv")
    }

    //------------------------
    // 2. pv score
    //------------------------
    val pvSqlText =
      s"""
        |SELECT *
        |FROM
        |  (
        |  SELECT
        |    member_id,
        |    substring(page, 12) AS listing_id,
        |    etl_time
        |  FROM dw.uba_page a
        |  WHERE page like '10.pd.item-%'
        |    AND stay_time >= 5
        |    AND his_time >= '$lastMonthStr'
        |   ) s
        |WHERE member_id IS NOT NULL AND member_id != '' AND listing_id IS NOT NULL AND listing_id != ''
        """.stripMargin
    val pvDF = spark.sql(pvSqlText)
    pvDF.createOrReplaceTempView("pageview")

    val pvListingText =
      s"""
        |SELECT
        |  p.member_id,
        |  p.listing_id,
        |  clipNormalize(sum(timeAttenuation(1,p.etl_time,7.0,1.5,2.0,0.5)), 2, 8) as score
        |FROM pageview p
        |INNER JOIN dw.listing l
        |  ON p.listing_id = l.listing_id
        |  AND (l.source = '1' or l.source = '3' or l.source='4')
        |  AND l.state='onshelf'
        |  AND l.his_time = '$dateStr'
        |GROUP BY p.member_id, p.listing_id
      """.stripMargin
    val pvListingDF = spark.sql(pvListingText)
    pvListingDF.createOrReplaceTempView("norm_pv")
    if(!online) {
      pvListingDF.write.mode(SaveMode.Overwrite).format("csv").option("delimiter", "^").option("nullValue", " ").save("/tmp/zhuweicheng/recommend/rating/norm_pv.csv")
    }

    //------------------------
    // 3. search score
    //------------------------
    val searchText =
      s"""
        |SELECT
        |  t.member_id,
        |  t.listing_id,
        |  clipNormalize(sum(timeAttenuation(2,etl_time,7,1.5,2,0.5)),2,8) AS score
        |FROM (
        |   SELECT
        |     up.member_id               AS member_id,
        |     substring(up.page, 12)     AS listing_id,
        |     up.etl_time                AS etl_time
        |   FROM dw.uba_page up
        |   INNER JOIN dw.listing l
        |     ON substring(up.page, 12) = l.listing_id
        |     AND (l.source = '1' or l.source = '3' or l.source='4')
        |     AND l.state='onshelf'
        |     AND l.his_time='$dateStr'
        |   WHERE up.page like '10.pd.item-%'
        |     AND (up.scp like '07.searchsp.%' OR up.scp like '07.searchresult.%' OR up.scp like '07.searchovse.%' OR up.scp like '07.searchstore.%' OR up.scp like '07.search.%' OR up.scp like '07.class.%' OR up.scp like '07.dsrlt.%' OR up.scp like '07.asrlt.%' OR up.scp like '07.ddsearch.%')
        |     AND validateMemberId(member_id) = true
        |     AND up.his_time >= '$lastMonthStr'
        |     AND up.member_id IS NOT NULL
        |     AND up.member_id != ""
        |) t
        |GROUP BY t.member_id,t.listing_id
      """.stripMargin
    val searchDF = spark.sql(searchText)
    searchDF.createOrReplaceTempView("norm_search")
    if(!online) {
      searchDF.write.mode(SaveMode.Overwrite).format("csv").option("delimiter", "^").option("nullValue", " ").save("/tmp/zhuweicheng/recommend/rating/norm_search.csv")
    }

    //------------------------
    // 4. merge all
    //------------------------

    val mergeSqlText =
      s"""
        |SELECT
        |  t.member_id,
        |  t.listing_id,
        |  clipNormalize(sum(t.score), 0, 10.0) as score
        |FROM (
        |    SELECT member_id,listing_id, 3*score as score FROM norm_order
        |    UNION ALL
        |    SELECT member_id,listing_id, 3*score as score FROM norm_pv
        |    UNION ALL
        |    SELECT member_id,listing_id, 4*score as score FROM norm_search
        |  ) t
        |WHERE t.listing_id != '9116001'
        |  and isNumber(t.listing_id) = 1
        |GROUP BY t.member_id,t.listing_id
      """.stripMargin

    val mergedResultDF = spark.sql(mergeSqlText)

    PersistUtils.save(spark, mergedResultDF, "user_product_ratings", SaveType.OTHER, online)

//    mergedResultDF.write.mode(SaveMode.Overwrite).format("csv").option("delimiter", "^").option("nullValue", " ").save("/tmp/zhuweicheng/recommend/rating/merged_score.csv")

  }

  //------------------------
  // register user defined function
  //------------------------
  def registerUDF(spark: SparkSession): Unit = {
    def dayWeight(x:Double,alpha:Double,beta:Double,lambda:Double,sigma:Double) = {
      sigma + (beta / (1 + Math.pow(Math.E, (-x - alpha) / lambda)))
    }

    def clipNormalize(score:Double,min:Double,max:Double) : Double = {
      // We user same algorithm as minMaxScalar, but with extra params to avoid data shuffle
      // $$ Rescaled(e_i) = \frac{e_i - E_{min}}{E_{max} - E_{min}} * (max - min) + min $$
      val minOut:Double = 0.1
      val maxOut:Double = 1.0
      (math.min(math.max(score, min), max) - min) / (max - min) * (maxOut - minOut) + minOut
    }

    spark.udf.register("clipNormalize", clipNormalize _)

    spark.udf.register("timeAttenuation",(score: Double,sinkDate:Date,alpha:Double,beta:Double,lambda:Double,sigma:Double) => {
      try{
        // val format = new java.text.SimpleDateFormat("yyyy-MM-dd")
        // val sinkDate = format.parse(dateStr)
        val elapsedTime = (new java.util.Date().getTime - sinkDate.getTime) / (1000.0 * 60 * 60 * 24)

        score * dayWeight(elapsedTime,alpha, beta, lambda, sigma)
      } catch {
        case e: Exception => println("exception caught: " + e)
          0
      }
    })

    spark.udf.register("calOrderScore", (create_time:String, pay_time:String, ship_time:String, return_time:String, cancel_time:String)=> {
      var score:Double = 0

      if(cancel_time != null) {
        score = 2
      }
      else if(return_time != null) {
        score = -4
      }
      else if(ship_time != null) {
        score = 5
      }
      else if(pay_time != null) {
        score = 4
      }
      else {
        score = 3
      }

      score
    })

    spark.udf.register("validateMemberId",(member_id:String) => {//
    val pattern = new Regex("^\\d+$")
      (pattern findAllIn member_id).length > 0
    })

    spark.udf.register("isNumber",(str:String) => {
      try{
        str.toLong
        1
      }catch{
        case e:Exception => 0
      }
    })

  }
}
