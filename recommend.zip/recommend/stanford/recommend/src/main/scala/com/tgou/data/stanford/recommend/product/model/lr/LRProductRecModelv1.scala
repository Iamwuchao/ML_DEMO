package com.tgou.data.stanford.recommend.product.model.lr

import org.apache.spark.ml.{Pipeline, PipelineModel}
import org.apache.spark.ml.classification.{BinaryLogisticRegressionSummary, LogisticRegression}
import org.apache.spark.ml.evaluation.BinaryClassificationEvaluator
import org.apache.spark.ml.feature._
import org.apache.spark.ml.tuning.{CrossValidator, ParamGridBuilder}
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.{DataFrame, Row, SparkSession}

object LRProductRecModelv1 {
  def main(args: Array[String]): Unit = {
    val spark = SparkSession.builder()
      .config("spark.memory.fraction",0.8)
      .config("spark.memory.storageFraction",0.3)
      .appName("lr-test")
      .config("hive.metastore.uris","thrift://172.16.3.2:9083")
      .master("local")
      .getOrCreate()

    spark.sparkContext.setLogLevel("WARN")// 日志级别
    spark.udf.register("toNum",(num:String) => num.toDouble)

    var dataset = spark.read.parquet("hdfs://172.16.3.2:8020/tmp/xhl/recommend/lr/data")

    dataset = dataset.filter("price is not null")
      .selectExpr("toNum(flag) as label","age_range","sex","toNum(price) as price","brand_name")

    dataset = featureString2Vec(dataset, "age_range")
    dataset = featureString2Vec(dataset, "sex")
    dataset = featureString2Vec(dataset, "brand_name")
    dataset = featureNumber2Vec(dataset, "price")

    val assembler = new VectorAssembler()
      .setInputCols(Array("age_range_vec", "sex_vec", "brand_name_vec","price_vec"))
      .setOutputCol("features")


    dataset = assembler.transform(dataset)
    dataset.show()

    //dataset.select("label","")

    dataset = dataset.sample(false,0.4)
    val splitdata = dataset.randomSplit(Array(0.7, 0.3), seed = 11L)
    val training = splitdata(0).cache()
    val test = splitdata(1)

//    val age_range_indexer = new StringIndexer().setInputCol(s"age_range").setOutputCol(s"age_range_index")
//    val age_range_encoder = new OneHotEncoder().setInputCol(s"age_range_index").setOutputCol(s"age_range_vec")
//
//    val sex_indexer = new StringIndexer().setInputCol(s"sex").setOutputCol(s"sex_index")
//    val sex_encoder = new OneHotEncoder().setInputCol(s"sex_index").setOutputCol(s"sex_vec")
//
//    val brand_name_indexer = new StringIndexer().setInputCol(s"brand_name").setOutputCol(s"brand_name_index").setHandleInvalid("keep")
//    val brand_name_encoder = new OneHotEncoder().setInputCol(s"brand_name_index").setOutputCol(s"brand_name_vec")
//
//    val price_indexer = new StringIndexer().setInputCol(s"price").setOutputCol(s"price_index")
//    val price_encoder = new OneHotEncoder().setInputCol(s"price_index").setOutputCol(s"price_vec")
//
//    val price_discretizer = new QuantileDiscretizer()
//      .setInputCol(s"price")
//      .setOutputCol(s"price_vec")
//      .setNumBuckets(10)



    //    val pca = new PCA()
//      .setInputCol("features")
//      .setOutputCol("pcaFeatures")
//      .setK(2000)


    val lr = new LogisticRegression()
      .setMaxIter(10)
//      .setRegParam(0.3)
//      .setElasticNetParam(0.8)

    val pipeline = new Pipeline().setStages(Array(
//      age_range_indexer,
//      age_range_encoder,
//      sex_indexer,
//      sex_encoder,
//      brand_name_indexer,
//      brand_name_encoder,
//      price_discretizer,
//      assembler,/*pca, */
      lr))

    val paramGrid = new ParamGridBuilder()
      .addGrid(lr.regParam, Array(0.1, 0.01))
      .build()

    val model: PipelineModel = pipeline.fit(training)

    val cv = new CrossValidator()
      .setEstimator(pipeline)
      .setEvaluator(new BinaryClassificationEvaluator)
      .setEstimatorParamMaps(paramGrid)
      .setNumFolds(3)//分成了3份，前两份用于测试集，最后一份用于训练集

    val cvmodel = cv.fit(training)


    val raw: DataFrame = test.select("label", "features")
    cvmodel.transform(raw).show(false)
    val valuep: RDD[Row] = cvmodel.transform(raw).select("label", "prediction").rdd
    val MSE = valuep.map{case Row(label: Double, prediction: Double) =>
      math.pow(label - prediction, 2)}.mean()

    println("training Mean Squared Error = " + MSE)


  }

  def featureNumber2Vec(dataset:DataFrame,col:String):DataFrame = {
    val discretizer = new QuantileDiscretizer()
      .setInputCol(s"$col")
      .setOutputCol(s"${col}_vec")
      .setNumBuckets(10)

    discretizer.fit(dataset).transform(dataset)
  }

  def featureString2Vec(dataset:DataFrame,col:String):DataFrame = {
    val indexer = new StringIndexer()
      .setInputCol(s"$col")
      .setOutputCol(s"${col}_index")
      .fit(dataset)

    var d = indexer.transform(dataset)

    val encoder = new OneHotEncoder()
      .setInputCol(s"${col}_index")
      .setOutputCol(s"${col}_vec")

    encoder.transform(d)
  }
}
