package com.tgou.data.stanford.recommend.utils

import org.apache.spark.sql.Row
import org.apache.spark.sql.expressions.{MutableAggregationBuffer, UserDefinedAggregateFunction}
import org.apache.spark.sql.types.{DataType, DoubleType, StringType, StructType}

/*
 *created by wuchao on 2018/3/29.
 *package_name : com.tgou.data.stanford.recommend.utils
 */
class UserFavorTopKUDAF extends UserDefinedAggregateFunction{
  override def inputSchema: StructType = new StructType().add("item_id",StringType).add("score",DoubleType)

  override def bufferSchema: StructType = new StructType().add("item_list",StringType)

  override def dataType: DataType = StringType

  override def deterministic: Boolean = ???

  override def initialize(buffer: MutableAggregationBuffer): Unit = ???

  override def update(buffer: MutableAggregationBuffer, input: Row): Unit = ???

  override def merge(buffer1: MutableAggregationBuffer, buffer2: Row): Unit = ???

  override def evaluate(buffer: Row): Any = ???
}
