package com.tgou.data.stanford.recommend.brand.model

import java.time.LocalDate

import com.tgou.data.stanford.core.udaf.MergeUDAF
import com.tgou.data.stanford.recommend.RecommendBootstrap
import com.tgou.data.stanford.recommend.utils.FeatureUtils
import org.apache.spark.ml.feature.{MinHashLSH, RFormula}
import org.apache.spark.ml.linalg.{Vector, Vectors}
import org.apache.spark.sql.{SaveMode, SparkSession}
import org.apache.spark.storage.StorageLevel

import scala.collection.mutable.ArrayBuffer

/**
  * a.从品牌画像中选取性别/年龄段/价格段/风格/档次特征值，利用杰卡德算法，计算相似度最高的3个品牌（每个品牌3个相似品牌）
  * b.从用户画像里，选取人最喜欢的6个品牌，与相似品牌匹配，计算人最喜欢的6个品牌相似的6*3个品牌，偏好分值*相似度，得出用户品牌推荐列表以及最终评分
  */
object BHCBRecModel {

  def main(args: Array[String]): Unit = {
    RecommendBootstrap(args).bootstrap(execute)
  }

  def execute(spark: SparkSession, appName: String, date: LocalDate, args:Array[String]): Unit = {

    // 注册方法
    spark.udf.register("change",(vec:Vector)=>FeatureUtils.expandSparseVector(vec))
    spark.udf.register("default",(size:Int)=>Vectors.sparse(size,Seq()))
    spark.udf.register("merge",new MergeUDAF())
    spark.udf.register("format",(brand_id: String, data: String) => {
      val buffer = ArrayBuffer[(String,Double)]()

      for(line <- data.split(",")){
        val splits = line.split(":")
        buffer += ((splits(0),splits(1).toDouble))
      }

      buffer.sortWith((a,b)=>a._2>b._2)
        .filter(!_._1.equals(brand_id))
        .take(3)
        .map(t2 => t2._1+":"+t2._2)
        .mkString(",")
    })

    // 选取性别/年龄段/价格段/风格/档次特征值
    val brand = spark.sql(
      s"""
         |select
         |  brand_id        as brand_id,
         |  max(level)      as level,
         |  max(sex)        as sex,
         |  max(age_range)  as age_range,
         |  max(style)      as style
         |from persona.brand
         |where brand.sex is not null
         |  and brand.age_range is not null
         |  and brand.style is not null
         |group by brand_id
       """.stripMargin)
    brand.persist(StorageLevel.MEMORY_AND_DISK_2)

    // 针对字段进行OneHot编码，null值为全零; 全零的转为 Vectors.spark(max+1,Seq((max,1.0)))
    //    val levelDF     = FeatureUtils.oneHotWithNull(spark, brand, "brand_id", "level",     "level_vec")
    //    val sexDF       = FeatureUtils.oneHotWithNull(spark, brand, "brand_id", "sex",       "sex_vec")
    //    val ageRangeDF  = FeatureUtils.oneHotWithNull(spark, brand, "brand_id", "age_range", "age_range_vec")
    //    val styleDF     = FeatureUtils.oneHotWithNull(spark, brand, "brand_id", "style",     "style_vec")
    //
    //    levelDF.createOrReplaceTempView("level_t")
    //    sexDF.createOrReplaceTempView("sex_t")
    //    ageRangeDF.createOrReplaceTempView("age_range_t")
    //    styleDF.createOrReplaceTempView("style_t")
    //
    //    val unionDF = spark.sql(
    //      s"""
    //         |select
    //         |  t1.brand_id       as brand_id,
    //         |  t1.level_vec      as level,
    //         |  t2.sex_vec        as sex,
    //         |  t3.age_range_vec  as age_range,
    //         |  t4.style_vec      as style,
    //         |  1 as tag
    //         |from level_t t1
    //         |left join sex_t t2
    //         |  on t1.brand_id = t2.brand_id
    //         |left join age_range_t t3
    //         |  on t1.brand_id = t3.brand_id
    //         |left join style_t t4
    //         |  on t1.brand_id = t4.brand_id
    //       """.stripMargin)
    //    unionDF.persist(StorageLevel.MEMORY_AND_DISK_2)

    val formula = new RFormula()
      .setFormula("tag ~ level + sex + age_range + style")
      .setFeaturesCol("features")

    val output = formula.fit(brand).transform(brand)

    val df = output.select("brand_id","features")
    df.persist(StorageLevel.MEMORY_AND_DISK_2)

    val mh = new MinHashLSH()
      .setNumHashTables(5)
      .setInputCol("features")

    val model = mh.fit(df)

    // 计算物品相似度
    val lshDf = model.approxSimilarityJoin(df, df, 1.0).toDF("source","target","score")

    lshDf.persist(StorageLevel.MEMORY_AND_DISK_2)
    lshDf.write.mode(SaveMode.Overwrite).parquet("/recommend/data/lsh")
    lshDf.createOrReplaceTempView("lsh")
    lshDf.show()

    // 结果格式化
    val format = spark.sql(
      s"""
         |select
         |  source.brand_id as brand_id,
         |  target.brand_id as sim_id,
         |  1-score         as score
         |from lsh
       """.stripMargin)

    format.persist(StorageLevel.MEMORY_AND_DISK_2)
    format.write.mode(SaveMode.Overwrite).parquet("/recommend/data/lsh_format")
    format.createOrReplaceTempView("lsh_format")
    format.show()

    // 合并保存
    val result = spark.sql(
      s"""
         |select
         |  brand_id,
         |  format(brand_id,merge(sim_info)) as data,
         |  '' as time
         |from (
         |  select
         |    brand_id as brand_id,
         |    concat(sim_id,':',score) as sim_info,
         |    rank() over (partition by brand_id order by score desc) as rank
         |  from lsh_format
         |) t
         |where rank <= 3
         |group by brand_id
       """.stripMargin).coalesce(10)

    result.persist(StorageLevel.MEMORY_AND_DISK_2)
    result.write.mode(SaveMode.Overwrite).parquet("/recommend/data/bh_cb_rec")
    result.write.mode(SaveMode.Overwrite).option("sep","^").option("nullValue","").csv("/recommend/sqoop/bh_cb_rec")
    result.show()
  }
}
