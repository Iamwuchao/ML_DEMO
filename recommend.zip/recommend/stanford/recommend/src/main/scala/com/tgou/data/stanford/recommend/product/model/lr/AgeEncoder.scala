package com.tgou.data.stanford.recommend.product.model.lr

import org.apache.spark.ml.Transformer
import org.apache.spark.ml.attribute.NominalAttribute
import org.apache.spark.ml.linalg.Vectors
import org.apache.spark.ml.param.{Param, ParamMap}
import org.apache.spark.ml.util.Identifiable
import org.apache.spark.sql.functions.{col, udf}
import org.apache.spark.sql.types.{StructType, _}
import org.apache.spark.sql.{DataFrame, Dataset}

import scala.collection.mutable.ArrayBuffer

class AgeEncoder extends Transformer{

  var outputCol = "outputCol"
  var inputCol = "inputCol"

  def setInputCol(value: String): this.type = {
    inputCol = value
    this
  }
  def setOutputCol(value: String): this.type = {
    outputCol = value
    this
  }

  override def transform(dataset: Dataset[_]): DataFrame = {
    val inputColName = inputCol
    val outputColName = outputCol

    // [40-45)
    val encode = udf { label: String =>
      var min = 0
      var max = 100

      label match {
        case "[60,up)" =>
          min =60
        case "15以下" =>
          max = 14
        case _ =>
          min = label.split("-")(0).split("\\[")(1).toInt
          max = label.split("-")(1).split("\\)")(0).toInt
      }

      val indices = new ArrayBuffer[Int]()
      val values  = new ArrayBuffer[Double]()

      for( index <- min.until(max)){
        indices += index
        values  += 1.0
      }
      Vectors.sparse(100, indices.toArray, values.toArray)
    }

    dataset.select(col("*"), encode(col(inputColName).cast(StringType)).as(outputColName))
  }

  override def copy(extra: ParamMap): AgeEncoder = defaultCopy(extra)

  override def transformSchema(schema: StructType): StructType = {
    val inputFields = schema.fields
    val attr = NominalAttribute.defaultAttr.withName(outputCol)
    val outputFields =  inputFields :+ attr.toStructField()
    StructType(outputFields)
  }

  override val uid = Identifiable.randomUID("ageExcutor")
}
