package com.tgou.data.stanford.recommend.utils

import org.apache.spark.sql.Row
import org.apache.spark.sql.expressions.{MutableAggregationBuffer, UserDefinedAggregateFunction}
import org.apache.spark.sql.types._

/*
 *created by wuchao on 2018/3/28.
 *package_name : com.tgou.data.stanford.recommend.utils
 * 这个就是ICF自己使用的
 * 把 商品id+评分,拼接成[ (item_id,score),(item_id,score) ]
 */
class ICFMergeUDAF extends UserDefinedAggregateFunction{

  override def inputSchema: StructType = new StructType().add("item_id",LongType)
    .add("score",FloatType)



  override def bufferSchema: StructType = new StructType().add("merge_item_list",StringType)


  override def dataType: DataType = StringType

  override def deterministic: Boolean = true

  override def initialize(buffer: MutableAggregationBuffer): Unit = {
    buffer(0)=""
  }

  override def update(buffer: MutableAggregationBuffer, input: Row): Unit = {
    buffer(0) = input.getAs[Long](0).toString+":"+input.getAs[Float](1).toString+ ","+ buffer.getAs[String](0)
  }

  override def merge(buffer1: MutableAggregationBuffer, buffer2: Row): Unit = {
    buffer1(0) = buffer1.getAs[String](0)+","+buffer2.getAs[String](0)
  }

  override def evaluate(buffer: Row): Any = {
    buffer(0).toString
  }
}
