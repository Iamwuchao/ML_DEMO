package com.tgou.data.stanford.recommend.product.model.lr

import org.apache.spark.ml.Pipeline
import org.apache.spark.ml.feature.{OneHotEncoder, VectorAssembler}
import org.apache.spark.sql.SparkSession

object AgeExcutorTest {
  def main(args: Array[String]): Unit = {
    val spark = SparkSession.builder().appName("age-excutor").master("local").getOrCreate()
    val df = spark.createDataFrame(Seq((1,"[30-40)"),(3,"[30-40)"),(2,"[30-40)"))).toDF("id","age")


//    val encoder = new OneHotEncoder().setInputCol("age").setOutputCol("age_out")
//    encoder.transform(df).show(false)
//    val excutor = new AgeEncoder().setInputCol("age").setOutputCol("age_vec")
//    excutor.transform(df).show(false)
    val encoder = new AgeEncoder().setInputCol("age").setOutputCol("age_vec")
    val vector = new VectorAssembler().setInputCols(Array("age_vec","age_vec")).setOutputCol("basic_features")
    val pipeline = new Pipeline().setStages(Array(encoder,vector))
    val basicFeatureDF = pipeline.fit(df).transform(df)
    basicFeatureDF.show(false)
  }
}
