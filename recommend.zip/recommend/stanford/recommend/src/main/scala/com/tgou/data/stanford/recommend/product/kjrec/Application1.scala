package com.tgou.data.stanford.recommend.product.kjrec

import org.apache.hadoop.hbase.client.{ConnectionFactory, Put}
import org.apache.hadoop.hbase.util.Bytes
import org.apache.hadoop.hbase.{HBaseConfiguration, TableName}
import org.apache.spark.sql.{DataFrame, SparkSession}

object Application1 {
  def main(args: Array[String]): Unit = {
    val spark = SparkSession.builder().master("local").appName("normal").getOrCreate()
    spark.sparkContext.setLogLevel("warn")

    val data = (0 to 10).map { i => (i, "extra")}
    val df:DataFrame = spark.createDataFrame(data)



    df.foreachPartition(records => {

      val config = HBaseConfiguration.create
      config.set("hbase.zookeeper.property.clientPort", "2181")
      config.set("hbase.zookeeper.quorum", "hnode2,hnode4,hnode5")
      val connection = ConnectionFactory.createConnection(config)

      val table = connection.getTable(TableName.valueOf("rec:user_rec"))//获取表连接


      val list = new java.util.ArrayList[Put]

      for(i <- 0 until 10){
        val put = new Put(Bytes.toBytes(i.toString))
        put.addColumn(Bytes.toBytes("t"), Bytes.toBytes("aaaa"), Bytes.toBytes("1111"))
        list.add(put)
      }


      table.put(list)
      table.close()//分区数据写入HBase后关闭连接
    })
  }
}
