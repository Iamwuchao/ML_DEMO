package com.tgou.data.stanford.recommend.product.model.plcb

/*
 *created by wuchao on 2018/4/8.
 *package_name : com.tgou.data.stanford.recommend.product.model.plcb
 */
case  class CBBean(listing_id:String,price_id:Double,category_id:String,brand_id:String) {
}
