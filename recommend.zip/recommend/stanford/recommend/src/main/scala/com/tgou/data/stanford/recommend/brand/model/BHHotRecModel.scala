package com.tgou.data.stanford.recommend.brand.model

import java.time.LocalDate

import com.tgou.data.stanford.core.utils.DateUtils
import com.tgou.data.stanford.recommend.RecommendBootstrap
import org.apache.spark.sql.{SaveMode, SparkSession}
import org.apache.spark.storage.StorageLevel

/**
  * 推荐逻辑：
  * 天狗各业态下，
  * 近7天单品销量（订单时间为核销时间）排行最高的品牌，
  * 每个业态计算出30个品牌
  */
object BHHotRecModel {

  def main(args: Array[String]): Unit = {
    RecommendBootstrap(args).bootstrap(execute)
  }

  def execute(spark: SparkSession, appName: String, date: LocalDate, args:Array[String]): Unit = {

    val lastday = DateUtils.dateFormat(date)
    val lastWeek = DateUtils.dateFormat(date.plusDays(-7))

    val result = spark.sql(
      s"""
         |select
         |  concat(source,'_',rank) as id,
         |  source,
         |  brand_id,
         |  floor(total) as total,
         |  rank,
         |  '' as time
         |from (
         |  select
         |    source,
         |    brand_id,
         |    total,
         |    row_number() over (partition by source order by total desc) as rank
         |  from (
         |    select
         |      source,
         |      brand_id,
         |      sum(sl) as total
         |    from (
         |      select
         |        brand_id          as brand_id,
         |        product_quantity  as sl,
         |        product_source    as source
         |    from dw.order_product
         |    where his_time = '$lastday'
         |      and ship_time is not null
         |      and ship_time > '$lastWeek'
         |      and product_source in (1,4)
         |    ) t
         |    where brand_id != '16142'
         |    group by source,brand_id
         |  ) t1
         |) t2
         |where rank <= 30
       """.stripMargin).coalesce(1)

    result.persist(StorageLevel.MEMORY_AND_DISK_2)
    result.write.mode(SaveMode.Overwrite).parquet("/recommend/data/bh_hot_rec")
    result.write.mode(SaveMode.Overwrite).option("sep","^").option("nullValue","").csv("/recommend/sqoop/bh_hot_rec")
  }
}
