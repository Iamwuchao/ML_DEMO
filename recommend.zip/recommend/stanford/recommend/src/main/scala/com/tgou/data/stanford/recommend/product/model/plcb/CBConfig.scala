package com.tgou.data.stanford.recommend.product.model.plcb

/*
 *created by wuchao on 2018/4/8.
 *package_name : com.tgou.data.stanford.recommend.product.model.plcb
 */
object CBConfig {
 val listing_info_path = "/persona/data/listing"
 val maxSimilaritiesPerItem = 30  //一个物品最多找几个相似品
  val userFavorItems = 3
}
