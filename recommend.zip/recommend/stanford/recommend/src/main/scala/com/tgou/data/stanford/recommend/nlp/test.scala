package com.tgou.data.stanford.recommend.nlp

import org.apache.spark.ml.linalg.{BLAS, Vector, Vectors}

object test {

  val test123: String => String = {
    key: String => {
      key+"hello"
    }
  }

  def main(args: Array[String]): Unit = {
    println(test123("123"))
  }
}
