package com.tgou.data.stanford.recommend.product.model.als

import java.time.LocalDate

import com.tgou.data.stanford.recommend.RecommendBootstrap
import org.apache.spark.ml.evaluation.RegressionEvaluator
import org.apache.spark.ml.recommendation.ALS
import org.apache.spark.sql.{SaveMode, SparkSession}

object ALSModel {

  def main(args: Array[String]): Unit = {
    RecommendBootstrap(args).bootstrap(execute)
  }

  def execute(spark: SparkSession, appName: String, date: LocalDate, args:Array[String]): Unit = {

    spark.udf.register("str2long",(s:String)=>s.toLong)

    val ratings = spark.sql(
      s"""
         |select
         |  str2long(member_id) as member_id,
         |  str2long(listing_id) as listing_id,
         |  score
         |from persona.product_ratings
         |""".stripMargin)
    val Array(training, test) = ratings.randomSplit(Array(0.8, 0.2))
    ratings.toJavaRDD

    // Build the recommendation model using ALS on the training data
    val als = new ALS()
      .setMaxIter(5)
      .setRegParam(0.01)
      .setUserCol("member_id")
      .setItemCol("listing_id")
      .setRatingCol("score")
    val model = als.fit(training)

    // Evaluate the model by computing the RMSE on the test data
    // Note we set cold start strategy to 'drop' to ensure we don't get NaN evaluation metrics
    model.setColdStartStrategy("drop")
    val predictions = model.transform(test)

    val evaluator = new RegressionEvaluator()
      .setMetricName("rmse")
      .setLabelCol("score")
      .setPredictionCol("prediction")
    val rmse = evaluator.evaluate(predictions)
    println(s"Root-mean-square error = $rmse")

    // Generate top 10 movie recommendations for each user
    val userRecs = model.recommendForAllUsers(100)
    userRecs.write.mode(SaveMode.Overwrite).parquet("/recommend/data/als_rec")
    // Generate top 10 user recommendations for each movie
//    val movieRecs = model.recommendForAllItems(10)
//    movieRecs.show()
  }
}
