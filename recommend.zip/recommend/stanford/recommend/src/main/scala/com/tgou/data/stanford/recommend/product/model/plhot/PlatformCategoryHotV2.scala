package com.tgou.data.stanford.recommend.product.model.plhot

import java.time.LocalDate

import com.alibaba.fastjson.JSONObject
import com.tgou.data.stanford.core.utils.DateUtils
import com.tgou.data.stanford.recommend.RecommendBootstrap
import com.tgou.data.stanford.recommend.utils.{ModelType, PersistUtils, SaveType}
import org.apache.spark.sql.SparkSession

/*
 *created by wuchao on 2018/5/10.
 *package_name : com.tgou.data.stanford.recommend.product.model.plhot
 */
object PlatformCategoryHotV2 {
  def main(args: Array[String]) {
    RecommendBootstrap(args).bootstrap(execute)
  }

  def execute(spark: SparkSession, appName: String, date: LocalDate, args: Array[String]): Unit = {

    val online = !"test".equals(args(2))
    val dateStr = DateUtils.dateFormat(date)

    val TOTAL_HOT_PRODUCT_COUNT = 300
    val CATEGORY_SIZE = 10

    spark.udf.register("genInfo", (second_category:String, score:Double, is_activity_product:String)=>   {
      val json = new JSONObject()
      json.put("second_category", second_category)
      json.put("score", score)
      json.put("is_activity_product", is_activity_product)
      json.toJSONString
    })

    val mergedResultDF = spark.read.parquet(s"/persona/data/user_product_ratings")
    mergedResultDF.createOrReplaceTempView("merged_score")

    //------------------------
    // 1. Fetch hot category products  限定业态和推荐池商品
    //------------------------
    val hotCategorySqlText =
    s"""
       |SELECT
       |  row_number() over (ORDER BY part_index, second_category) as index,
       |  listing_id as rec_id,
       |  info
       |FROM (
       |  SELECT
       |    row_number() over (PARTITION BY a.category2,a.source ORDER BY a.is_activity_product DESC, m.score DESC) as part_index,
       |    m.listing_id,
       |    genInfo(a.category2, m.score, a.is_activity_product) as info,
       |    a.category2 as second_category
       |  FROM (
       |    SELECT
       |        listing_id,
       |        sum(score) AS score
       |    FROM
       |        merged_score
       |    GROUP BY
       |        listing_id
       |  ) m
       |  INNER JOIN persona.recommend_pool_test a
       |    ON m.listing_id = a.listing_id
       |    AND a.listing_state='onshelf'
       |    AND a.listing_id != '9116001'
       |    AND a.source!='3'
       |    AND a.is_recommended = '1'
       |) t
       |WHERE part_index <= $CATEGORY_SIZE
       |LIMIT $TOTAL_HOT_PRODUCT_COUNT
  """.stripMargin

    val hotCategoryDF = spark.sql(hotCategorySqlText)

    PersistUtils.save(spark, hotCategoryDF, ModelType.P_PT_HOT_V2, SaveType.SQOOP_REC, online)

  }
}
