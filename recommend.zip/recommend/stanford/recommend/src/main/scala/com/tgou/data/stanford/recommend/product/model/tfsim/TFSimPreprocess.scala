package com.tgou.data.stanford.recommend.product.model.tfsim

import com.hankcs.hanlp.dictionary.CustomDictionary
import com.hankcs.hanlp.seg.common.Term
import com.hankcs.hanlp.tokenizer.NotionalTokenizer
import com.tgou.data.stanford.recommend.utils.{MergeUDAF, MongoManager}
import org.apache.commons.lang3.StringUtils
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.sql.SparkSession

import scala.collection.mutable.ArrayBuffer

object TFSimPreprocess {

  /**
    * 注册udf方法
    * @param spark spark
    */
  def registerView(spark:SparkSession): Unit ={

    // 读取mongodb中的词库
    val col = MongoManager.getDB().getCollection("nerword")
    val result = col.find()
    val iter = result.iterator()
    val seg_tokens:ArrayBuffer[String] = new ArrayBuffer[String]()
    while(iter.hasNext){
      val document = iter.next()

      for(s <- Seq("word","similar_word1","similar_word2","similar_word3","similar_word4","similar_word5")){
        if(document.get(s)!=null && StringUtils.isNotBlank(document.get(s).toString)) {
          seg_tokens += document.get(s).toString
        }
      }
    }

    // 广播词典
    val segBroadCast:Broadcast[Seq[String]] = spark.sparkContext.broadcast(seg_tokens)

    // 基于HanLP进行分词，参考https://github.com/hankcs/HanLP
    spark.udf.register("segment",(sent:String) => {
      //todo 这里以后可以考虑只设置成单例，只添加一次词典
      segBroadCast.value.foreach(s => CustomDictionary.add(s))
      NotionalTokenizer.segment(sent).toArray().map(t => t.asInstanceOf[Term].word)
    })

    spark.udf.register("merge",new MergeUDAF())

    // 解析描述性属性
    spark.udf.register("parse",(line: String) => {
      val result = if(StringUtils.isNotBlank(line)){
        try{
          line.split("^").map(l=>l.split(":")(1)).mkString(" ")
        }catch{
          case ex:ArrayIndexOutOfBoundsException =>
            println("解析出错:"+line)
            ""
        }
      }else{
        ""
      }
      result
    })
  }
}
