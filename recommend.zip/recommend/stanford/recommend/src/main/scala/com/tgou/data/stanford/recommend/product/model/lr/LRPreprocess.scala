package com.tgou.data.stanford.recommend.product.model.lr

import java.time.LocalDate
import java.time.format.DateTimeFormatter

import com.hankcs.hanlp.dictionary.CustomDictionary
import com.hankcs.hanlp.seg.common.Term
import com.hankcs.hanlp.tokenizer.NotionalTokenizer
import com.tgou.data.stanford.core.utils.DateUtils
import com.tgou.data.stanford.recommend.RecommendBootstrap
import com.tgou.data.stanford.recommend.utils.MongoManager
import org.apache.commons.lang3.StringUtils
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.ml._
import org.apache.spark.ml.feature._
import org.apache.spark.sql.{SaveMode, SparkSession}
import org.apache.spark.storage.StorageLevel

import scala.collection.mutable
import scala.collection.mutable.ArrayBuffer
import scala.util.matching.Regex

object LRPreprocess {

  def main(args: Array[String]): Unit = {
    RecommendBootstrap(args).bootstrap(execute)
  }

  def execute(spark: SparkSession, appName: String, date: LocalDate, args: Array[String]): Unit = {

    val col = MongoManager.getDB().getCollection("nerword")
    val result = col.find()
    val iter = result.iterator()
    val seg_tokens:ArrayBuffer[String] = new ArrayBuffer[String]()
    while(iter.hasNext){
      val document = iter.next()

      for(s <- Seq("word","similar_word1","similar_word2","similar_word3","similar_word4","similar_word5")){
        if(document.get(s)!=null && StringUtils.isNotBlank(document.get(s).toString)) {
          seg_tokens += document.get(s).toString
        }
      }
    }

    // 广播词典
    val segBroadCast:Broadcast[Seq[String]] = spark.sparkContext.broadcast(seg_tokens)

    // 基于HanLP进行分词，参考https://github.com/hankcs/HanLP
    spark.udf.register("segment",(sent:String) => {
      //todo 这里以后可以考虑只设置成单例，只添加一次词典
      segBroadCast.value.foreach(s => CustomDictionary.add(s))
      NotionalTokenizer.segment(sent).toArray().map(t => t.asInstanceOf[Term].word)
    })

    spark.udf.register("str2num",(str:String) => str.toDouble)

    spark.udf.register("validateMemberId",(member_id:String) => {
      val pattern = new Regex("^\\d+$")
      (pattern findAllIn member_id).nonEmpty
    })

    // 用户表形成特征

    // basic_info: age_range(特殊处理), sex（onehot）, birth_month(onehot), birth_season（onehot）, constellation（onehot）

    val basicInfoDF = spark.read.parquet(s"/persona/data/basic_info").filter("age_range is not null")

    val basicStages = generateStages(Seq(
      (FeatureConvert.AGE,          "age_range",    ""),
      (FeatureConvert.STR_2_ONEHOT, "sex",          ""),
      (FeatureConvert.STR_2_ONEHOT, "birth_month",  ""),
      (FeatureConvert.STR_2_ONEHOT, "birth_season", ""),
      (FeatureConvert.STR_2_ONEHOT, "constellation",""),
      (FeatureConvert.MERGE, "age_range_vec,sex_vec,birth_month_vec,birth_season_vec,constellation_vec","basic_features")
    ))

    val basicPipeline = new Pipeline().setStages(basicStages)
    val basicFeatureDF = basicPipeline.fit(basicInfoDF).transform(basicInfoDF)

    basicFeatureDF.persist(StorageLevel.MEMORY_AND_DISK_SER)
    basicFeatureDF.write.mode(SaveMode.Overwrite).parquet(s"/tmp/xhl/recommend/lr/basic_feature")
    basicFeatureDF.show(false)

    // favor_info: top1、top2、top3、top4、top5、top6（onehot就行了）、level（分类标签）
    val favorInfoDF = spark.read.parquet(s"/persona/data/favor_info").filter("level is not null")

    val favorStages = generateStages(Seq(
      (FeatureConvert.STR_2_ONEHOT, "top1", ""),
      (FeatureConvert.STR_2_ONEHOT, "top2", ""),
      (FeatureConvert.STR_2_ONEHOT, "top3", ""),
      (FeatureConvert.STR_2_ONEHOT, "top4", ""),
      (FeatureConvert.STR_2_ONEHOT, "top5", ""),
      (FeatureConvert.STR_2_ONEHOT, "top6", ""),
      (FeatureConvert.STR_2_ONEHOT, "level", ""),
      (FeatureConvert.MERGE, "top1_vec,top2_vec,top3_vec,top4_vec,top5_vec,top6_vec,level_vec","favor_features")
    ))

    val favorPipline = new Pipeline().setStages(favorStages)
    val favorFeatureDF = favorPipline.fit(favorInfoDF).transform(favorInfoDF)

    favorFeatureDF.persist(StorageLevel.MEMORY_AND_DISK_SER)
    favorFeatureDF.write.mode(SaveMode.Overwrite).parquet(s"/tmp/xhl/recommend/lr/favor_feature")
    favorFeatureDF.show(false)

    // trans_info: is_promotion（分类标签）, d_flh1, s_flh1, d_flh2, s_flh2, d_flh3, s_flh3（转对应的分类名字）,trans_je, trans_days（分桶中位数）
    val transInfoDF = spark.read.parquet(s"/persona/data/trans_info")
      .filter("is_promotion is not null")
      .selectExpr("member_id","is_promotion","str2num(nvl(trans_je,0)) as trans_je", "str2num(nvl(trans_days,0)) as trans_days")

    val transStages = generateStages(Seq(
      (FeatureConvert.STR_2_ONEHOT, "is_promotion", ""),
//      (FeatureConvert.STR_2_ONEHOT, "d_flh1", ""),
//      (FeatureConvert.STR_2_ONEHOT, "s_flh1", ""),
//      (FeatureConvert.STR_2_ONEHOT, "d_flh2", ""),
//      (FeatureConvert.STR_2_ONEHOT, "s_flh2", ""),
//      (FeatureConvert.STR_2_ONEHOT, "d_flh3", ""),
//      (FeatureConvert.STR_2_ONEHOT, "s_flh3", ""),
      (FeatureConvert.NUM_2_BUCKET, "trans_je", "10"),
      (FeatureConvert.NUM_2_BUCKET, "trans_days", "10"),
      (FeatureConvert.MERGE, "is_promotion_vec,trans_je_vec,trans_days_vec","trans_features")
    ))

    val transPipline = new Pipeline().setStages(transStages)
    val transFeatureDF = transPipline.fit(transInfoDF).transform(transInfoDF)

    transFeatureDF.persist(StorageLevel.MEMORY_AND_DISK_SER)
    transFeatureDF.write.mode(SaveMode.Overwrite).parquet(s"/tmp/xhl/recommend/lr/trans_feature")
    transFeatureDF.show(false)

    // 物品表形成特征

    // listing: name（文本）,  ,property（文本）,
    // source（分类标签），is_international （分类标签）,is_selected, category1 category2 category3（转对应的文字）
    // store_name（文本）, counter_name（文本）, sold_area_name（文本）, sold_type_name（文本）,brand_name（文本）
    // origin_price, price,(分桶)，online_je, online_sl, total_je, total_sl

    val listingDF = spark.read.parquet(s"/persona/data/listing")
        .filter("listing_state = 'onshelf'")
        .selectExpr("listing_id",
        "segment(concat(name,nvl(property,''))) as words",
        "source","is_international","is_selected","category1","category2","category3",
        "store_name", "brand_name",
          //"counter_name","sold_area_name","sold_type_name",
        "str2num(original_price) as original_price",
        "str2num(price) as price",
        "str2num(online_je) as online_je",
        "str2num(online_sl) as online_sl",
        "str2num(total_je) as total_je",
        "str2num(total_sl) as total_sl"
      )

    val listingStages = generateStages(Seq(
      (FeatureConvert.HASHING,      "words",            ""),
      (FeatureConvert.STR_2_ONEHOT, "source",           ""),
      (FeatureConvert.STR_2_ONEHOT, "is_international", ""),
      (FeatureConvert.STR_2_ONEHOT, "is_selected",      ""),
      (FeatureConvert.STR_2_ONEHOT, "category1",        ""),
      (FeatureConvert.STR_2_ONEHOT, "category2",        ""),
      (FeatureConvert.STR_2_ONEHOT, "category3",        ""),
      (FeatureConvert.STR_2_ONEHOT, "store_name",       ""),
//      (FeatureConvert.STR_2_ONEHOT, "counter_name",     ""),
//      (FeatureConvert.STR_2_ONEHOT, "sold_area_name",   ""),
//      (FeatureConvert.STR_2_ONEHOT, "sold_type_name",   ""),
      (FeatureConvert.STR_2_ONEHOT, "brand_name",       ""),
      (FeatureConvert.NUM_2_BUCKET, "original_price",   "10"),
      (FeatureConvert.NUM_2_BUCKET, "price",            "10"),
      (FeatureConvert.NUM_2_BUCKET, "online_je",        "10"),
      (FeatureConvert.NUM_2_BUCKET, "online_sl",        "10"),
      (FeatureConvert.NUM_2_BUCKET, "total_je",         "10"),
      (FeatureConvert.NUM_2_BUCKET, "total_sl",         "10"),
      (FeatureConvert.MERGE, "words_vec,source_vec,is_international_vec,is_selected_vec,category1_vec,category2_vec,category3_vec,store_name_vec,brand_name_vec,original_price_vec,price_vec,online_je_vec,online_sl_vec,total_je_vec,total_sl_vec","listing_features")
    ))

    val listingPipline = new Pipeline().setStages(listingStages)
    val listingFeatureDF = listingPipline.fit(listingDF).transform(listingDF)

    listingFeatureDF.persist(StorageLevel.MEMORY_AND_DISK_SER)
    listingFeatureDF.write.mode(SaveMode.Overwrite).parquet(s"/tmp/xhl/recommend/lr/listing_feature")
    listingFeatureDF.show(false)
  }

  def generateStages(settings:Seq[(FeatureConvert.Value,String,String)]):Array[PipelineStage] = {
    val stages = new ArrayBuffer[PipelineStage]()

    for(t2 <- settings){
      t2._1 match {
        case FeatureConvert.STR_2_ONEHOT =>

          stages += new StringIndexer().setInputCol(s"${t2._2}").setOutputCol(s"${t2._2}_index").setHandleInvalid("skip")
          stages += new OneHotEncoder().setInputCol(s"${t2._2}_index").setOutputCol(s"${t2._2}_vec")

        case FeatureConvert.NUM_2_BUCKET =>

          stages += new QuantileDiscretizer().setInputCol(s"${t2._2}").setOutputCol(s"${t2._2}_vec").setNumBuckets(t2._3.toInt)

        case FeatureConvert.MERGE =>

          stages += new VectorAssembler().setInputCols(t2._2.split(",")).setOutputCol(t2._3)

        case FeatureConvert.AGE =>

          stages += new AgeEncoder().setInputCol(s"${t2._2}").setOutputCol(s"${t2._2}_vec")

        case FeatureConvert.HASHING =>

          stages += new HashingTF().setInputCol(s"${t2._2}").setOutputCol(s"${t2._2}_vec").setNumFeatures(2000).setBinary(true)

      }
    }

    stages.toArray
  }
}
