package com.tgou.data.stanford.recommend.utils

import java.util
import java.util.{Locale, ResourceBundle}

import com.mongodb.client.MongoDatabase
import com.mongodb.{MongoClient, MongoClientOptions, MongoCredential, ServerAddress}

/**
  * MongoDb连接池
  *
  * 参考：http://blog.csdn.net/u013320750/article/details/50504562
  *
  * @author xingoo
  */
object MongoManager {

  val mongo = new MongoManager()

  def getDB() : MongoDatabase = {
    mongo.getMongoDatabase
  }
}

class MongoManager private {

  private var mg:MongoClient = null
  private var mongoDatabase: MongoDatabase = null

  // 连接池配置
  val options: MongoClientOptions = MongoClientOptions.builder
    .connectionsPerHost(50)// 链接池数量
    .maxWaitTime(300000)// 最大等待时间
    .socketTimeout(100000)// scoket超时时间
    .maxConnectionLifeTime(150000)// 设置连接池最长生命时间
    .connectTimeout(25000)// 连接超时时间
    .build

  // 身份验证信息
  val credential:MongoCredential = MongoCredential
    .createCredential("biteam","sklearn", "BD13lomy".toCharArray)

  // 创建连接
  this.mg = new MongoClient(new ServerAddress("58.87.88.189",27017),credential,options)

  // 创建database
  this.mongoDatabase = this.mg.getDatabase("sklearn")

  def getMongoDatabase: MongoDatabase = mongoDatabase
}
