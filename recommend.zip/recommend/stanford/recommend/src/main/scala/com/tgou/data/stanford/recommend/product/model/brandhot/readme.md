# 第二版：新版品牌下热销

改造存储到HBase

# 第一版：品牌下的热销品排行

## PRD描述

**算法** 从用户画像里，选取人最喜欢的6个品牌，再计算该品牌下的50个爆品（单品核销订单数倒序），若百货单品，限制单品状态为入围

[confluence地址<--点击这里](http://c.51tiangou.com/pages/viewpage.action?pageId=15213149)

## 算法流程

### 读取所有的order_product以及order_information表

order_product 使用下面的信息：
- brand_id          品牌id
- product_id        营销品id
- product_quantity  数量
- return_time       退货时间
- ship_time         核销时间
- tgou_order_id     订单id

listing 使用下面的信息
- listing_id        营销品id
- state             状态

> **note** 暂时没有考虑去除电子小票订单

### 统计品牌下的商品销售数量
```sql
select
    brand_id,
    product_id,
    sl,
    rank
from (
    select
        brand_id,
        product_id,
        sl,
        row_number() over (partition by brand_id order by sl desc) as rank
    from (
        select
            p.brand_id,
            p.product_id,
            sum(p.product_quantity) as sl
        from dw.order_product p
        inner join dw.listing l
            on p.product_id = l.listing_id
            and l.his_time = '2017-11-22'
            and l.state = 'onshelf'
        where p.his_time='2017-11-22' 
            and p.ship_time is not null 
            and p.return_time is null
        group by p.brand_id,p.product_id
    ) t1
) t2
where rank <= 50
```

### 保存到数据库

保存每个品牌下的爆品

### 