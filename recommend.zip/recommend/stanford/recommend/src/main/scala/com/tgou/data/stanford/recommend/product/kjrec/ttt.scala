package com.tgou.data.stanford.recommend.product.kjrec

import org.apache.spark.launcher.SparkLauncher

object ttt {
  def main(args: Array[String]): Unit = {
    val handler = new SparkLauncher()
      .setSparkHome("/Users/xingoo/IdeaProjects/stanford/recommend/target/")
      .setAppName("test-spark-launcher")
      .setConf("spark.executor.memory","1G")
      .setConf("spark.executo.-cores","1")
      .setConf("spark.driver.memory","1G")
      .addJar("/Users/xingoo/IdeaProjects/stanford/recommend/target/recommend.jar")
      .setMainClass("com.tgou.data.stanford.recommend.product.kjrec.Application2")
      .startApplication()
  }
}
