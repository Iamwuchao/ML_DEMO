package com.tgou.data.stanford.recommend.product.model.icf

import java.time.LocalDate

import com.tgou.data.stanford.recommend.RecommendBootstrap
import com.tgou.data.stanford.recommend.utils._
import org.apache.spark.sql.SparkSession

import scala.collection.mutable


/*
 *created by wuchao on 2018/3/26.
 *package_name : com.tgou.data.stanford.recommend.product.model.icf
 * 计算方法参考：https://www.jianshu.com/p/ae1fe36fdb90
 */
//case class UserItemV2(member_id:String,item_score:String)

object ICFV2 {

  def main(args: Array[String]): Unit = {
    RecommendBootstrap(args).bootstrap(execute)
  }

  def execute(spark: SparkSession, appName: String, date: LocalDate, args:Array[String]): Unit = {

    import spark.implicits._

    spark.udf.register("ICFMergeUDAF",new ICFMergeUDAF())
    spark.udf.register("SecondNorm",new SecondNormUDAF())
    val onLine = "online".equals(args(2))
    val ratingMartix  = spark.read.parquet(s"/persona/data/user_product_ratings")
    ratingMartix.createOrReplaceTempView("rmdf_temp")

    //限制为推荐池中的商品
    val recommend_pool = spark.sql(
      """
        |select member_id,a.listing_id,score
        |from rmdf_temp a inner join
        |(select listing_id from persona.recommend_pool_test where is_recommended='1') b
        | on a.listing_id = b.listing_id
      """.stripMargin)
    recommend_pool.cache()
    recommend_pool.createOrReplaceTempView("rmdf")

    //获取合法商品的列表,一个物品至少要被多少人评价过才行
    val legal_item_user_df = spark.sql(
      s"""
         |select a.listing_id from
         | (select listing_id,count(distinct member_id) user_count from rmdf group by listing_id) a where a.user_count>${ICFConfig.minVisitedPerItem}
      """.stripMargin)
    legal_item_user_df.createOrReplaceTempView("legal_item_user_df")

    //物品总评分,内容为 listing_id ,评分的二范数SN
    val item_user_SN = spark.sql(
      """
        |select a.listing_id,SecondNorm(score) as secondNorm from legal_item_user_df a left outer join rmdf b on a.listing_id = b.listing_id
        | group by a.listing_id
      """.stripMargin).rdd
      .map(row=>{
        (row.getString(0),row.getDouble(1))
      }).collectAsMap()
    val item_user_SN_bd = spark.sparkContext.broadcast(item_user_SN)

    //合法的用户商品矩阵，筛掉评价商品过多，过少的用户
    val legal_user_item_df = spark.sql(
      s"""
         | select a.member_id from
         |  (select member_id,count(distinct listing_id) item_count from rmdf group by member_id) a
         |  where a.item_count>=${ICFConfig.minPrefsPerUser} and a.item_count<=${ICFConfig.maxPrefsPerUser}
      """.stripMargin)
    legal_user_item_df.createOrReplaceTempView("legal_user_item_df")

    //用户和物品的矩阵，内容为member_id：[ (listing_id,score)……]
    val user_items_df = spark.sql(
      """
        |select c.member_id,ICFMergeUDAF(c.listing_id,c.score) item_score from
        | ( select a.member_id,b.listing_id,b.score from legal_user_item_df a
        | left outer join rmdf b on a.member_id = b.member_id) c
        |group by c.member_id
      """.stripMargin).as[UserItem]

    val item_similar_df = user_items_df.rdd.map(userItem=>{
      val item_score_str = userItem.item_score
      //将String还原为list,list的格式为
      val item_score_str_list = item_score_str.split(",").filter(str=>str.length>1)

      //还原为（listing_id,score）
      val item_score_list = new Array[Tuple2[String,Double]](item_score_str_list.length);
      var i=0
      for(item_score_str <- item_score_str_list){
        val item_score = item_score_str.split(":")
        val listing_id = item_score(0)
        val score = item_score(1).toDouble
        item_score_list(i) = (listing_id,score)
        i+=1
      }

      //记录两个物品的评分的乘积，既有itemi * itemj 也有itemj*itemi
      val item_similar_map =  new mutable.HashMap[String,Double]()
      for(i<-0 until item_score_list.length){
        val item1 = item_score_list(i)
        for(j<-i+1 until item_score_list.length){
          val item2 = item_score_list(j)
          if(item1._1!=item2._1){
            var item1_sn = item_user_SN_bd.value.get(item1._1).getOrElse(1.0)
            var item2_sn = item_user_SN_bd.value.get(item2._1).getOrElse(1.0)
            item_similar_map.put(item1._1+","+item2._1,item1._2 * item2._2 /
              (item1_sn* item2_sn))
            item_similar_map.put(item2._1+","+item1._1,item2._2 * item1._2 /
              (item1_sn* item2_sn))
          }
        }
      }
      item_similar_map
    }).flatMap(item_scoreMap=> item_scoreMap.toList)
      //计算itemi 与itemj的相似度
      .reduceByKey((score1,score2)=>score1+score2)
      //转换之后的内容是 listing_id ,listing_id,score)
      .map(row=>{
      val itemstr = row._1
      val itemArr = itemstr.split(",")
      (itemArr(0),itemArr(1),row._2)
    }).toDF("origin_listing_id","listing_id","score")
    item_similar_df.createOrReplaceTempView("item_similary_df")

    //计算物品 最相似的 topk 个品
    val item_similary_topk_df = spark.sql(
      s"""
         |select origin_listing_id,listing_id,score from
         | (select *,row_number() OVER (partition by origin_listing_id order by score DESC ) rank from item_similary_df) tmp
         | where rank<=${ICFConfig.maxSimilaritiesPerItem} and score>=${ICFConfig.min_similary}
      """.stripMargin)
    item_similary_topk_df.createOrReplaceTempView("item_similary_topk")
    //item_similary_topk_df.write.mode(SaveMode.Overwrite).parquet("/tmp/wuchao/icf/item_similary_topk_df")


    //计算用户最喜欢的三个商品
    val user_favorite_items_df = spark.sql(
      s"""
         |select member_id,listing_id as origin_listing_id,score from
         |(select *,row_number() OVER (partition by member_id order by score  DESC) rank from rmdf ) tmp
         | where rank<=${ICFConfig.maxPrefsPerUserForRec}
       """.stripMargin)
    user_favorite_items_df.createOrReplaceTempView("user_favorite_items")
    //user_favorite_items_df.write.mode(SaveMode.Overwrite).parquet("/tmp/wuchao/icf/user_favorite_items_df")

    val result_user_recommend_df = spark.sql(
      s"""
         |select tmp.member_id query_id,tmp.origin_listing_id,tmp.listing_id rec_id,tmp.similarity,
         |row_number() OVER (partition by member_id order by similarity DESC) index from
         | ( select a.member_id,a.origin_listing_id,b.listing_id,(a.score*b.score) as similarity from
         | user_favorite_items a left outer join item_similary_topk b on a.origin_listing_id = b.origin_listing_id) tmp
         |  where similarity is not null and similarity>0
      """.stripMargin)

    result_user_recommend_df.createOrReplaceTempView("result_user_recommend")


    //result_user_recommend_df.write.mode(SaveMode.Overwrite).parquet("/tmp/wuchao/icf/result_user_recommend")
    PersistUtils.save(spark, result_user_recommend_df,ModelType.P_PT_ICF_V2, SaveType.USER_PRODUCT_REC,onLine)
    ratingMartix.unpersist()
  }
}
