package com.tgou.data.stanford.recommend.nlp

import org.apache.spark.sql.SparkSession

object EDTest {
  def main(args: Array[String]): Unit = {
    import org.apache.spark.ml.feature.BucketedRandomProjectionLSH
    import org.apache.spark.ml.linalg.Vectors
    val spark = SparkSession
      .builder
      .master("local")
      .appName("TfIdfExample")
      .getOrCreate()
    spark.sparkContext.setLogLevel("warn")

    val dfA = spark.createDataFrame(Seq(
      (0, Vectors.dense(1.0, 1.0, 1.0)),
      (2, Vectors.dense(1.0, -1.0, 1.0)),
      (3, Vectors.dense(-1.0, 1.0, 1.0))
    )).toDF("id", "keys")
    val dfB = spark.createDataFrame(Seq(
      (0, Vectors.dense(1.0, 1.0)),
      (2, Vectors.dense(1.0, -1.0)),
      (3, Vectors.dense(-1.0, 1.0))
    )).toDF("id", "keys")

    val brp = new BucketedRandomProjectionLSH()
      .setBucketLength(100.0)
      .setNumHashTables(100)
      .setInputCol("keys")
      .setOutputCol("values")

    var model = brp.fit(dfA)
    model.approxSimilarityJoin(dfA,dfA,10).show()
    model = brp.fit(dfB)
    model.approxSimilarityJoin(dfB,dfB,10).show()
    model.approxNearestNeighbors(dfB,dfB.first().get(1).asInstanceOf[org.apache.spark.ml.linalg.Vector],2).show()
  }
}
