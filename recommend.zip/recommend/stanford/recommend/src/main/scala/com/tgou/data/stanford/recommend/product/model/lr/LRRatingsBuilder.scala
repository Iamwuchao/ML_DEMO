package com.tgou.data.stanford.recommend.product.model.lr

import java.time.LocalDate

import com.tgou.data.stanford.core.utils.DateUtils
import com.tgou.data.stanford.recommend.RecommendBootstrap
import com.tgou.data.stanford.recommend.utils.MergeUDAF
import org.apache.spark.sql.{SaveMode, SparkSession}
import org.apache.spark.storage.StorageLevel

import scala.collection.mutable
import scala.collection.mutable.ArrayBuffer
import scala.util.matching.Regex

object LRRatingsBuilder {
  def main(args: Array[String]): Unit = {
    RecommendBootstrap(args).bootstrap(execute)
  }

  def execute(spark: SparkSession, appName: String, date: LocalDate, args: Array[String]): Unit = {

    // 数据合并
    spark.udf.register("merge",new MergeUDAF())

    // 随机采样，以保证分类下数据均衡
    spark.udf.register("sample",(line:String,len:Int) => {

      val buffer = new ArrayBuffer[SampleBean]()
      line.split(",").foreach(l => {
        buffer += SampleBean(l.split(":")(0),l.split(":")(1))
      })

      while(buffer.size > len){
        val index = new java.util.Random().nextInt(buffer.size)
        buffer.remove(index)
      }

      buffer
    })

    spark.udf.register("validateMemberId",(member_id:String) => {
      val pattern = new Regex("^\\d+$")
      (pattern findAllIn member_id).nonEmpty
    })


    // 读取最近一周的数据
    val week = DateUtils.dateFormat(date.minusDays(7))

    val x_originalDF = spark.sql(
      s"""
         |select t.member_id,t.listing_id
         |from (
         |select
         |  member_id,
         |  listing_id,
         |  count(1) as count
         |from (
         |  SELECT
         |    member_id               AS member_id,
         |    substring(page, 12)     AS listing_id
         |  FROM dw.uba_page
         |  WHERE page like '10.pd.item-%'
         |    AND validateMemberId(member_id) = true
         |    AND his_time >= '$week'
         |) t1
         |group by member_id,listing_id
         |) t
         |inner join persona.listing l
         |  on t.listing_id = l.listing_id
         |  and ((l.source=1 and l.is_selected=1) or l.source=4)
         |where count > 1
      """.stripMargin)

    x_originalDF.persist(StorageLevel.MEMORY_AND_DISK_SER)
    x_originalDF.write.mode(SaveMode.Overwrite).parquet(s"/tmp/xhl/recommend/lr/x_rating_origin")
    x_originalDF.createOrReplaceTempView("x_rating_origin")

    // 水平抽样 正样本
    val x_zhengSamplesDF = spark.sql(
      s"""
         |select
         |  sample.member_id as member_id,
         |  sample.listing_id as listing_id,
         |  category3
         |from (
         |select
         |  category3,
         |  explode(sample) as sample
         |from (
         |select
         |  category3,
         |  sample(merge(concat(member_id,':',listing_id)),300) as sample
         |from (
         |  select
         |    x.member_id,
         |    x.listing_id,
         |    l.category3
         |  from x_rating_origin x
         |  left join persona.listing l
         |  on x.listing_id = l.listing_id
         |) t
         |group by category3
         |) t1
         |) t2
       """.stripMargin)

    x_zhengSamplesDF.persist(StorageLevel.MEMORY_AND_DISK_SER)
    x_zhengSamplesDF.write.mode(SaveMode.Overwrite).parquet(s"/tmp/xhl/recommend/lr/x_zheng_samples")
    x_zhengSamplesDF.createOrReplaceTempView("x_zheng_samples")

    // 构建 负样本

    // 获取全部的member_id和listing_id，随机给每个用户分配20个商品

    val xm = spark.sql("select distinct member_id from x_rating_origin")
    val xl = spark.sql("select distinct listing_id from x_rating_origin")

    val broadcast_listing = spark.sparkContext.broadcast(xl.collect().map(r=>r.getString(0)))
    spark.udf.register("sample_join",()=>{
      val bl = broadcast_listing.value
      var set = mutable.Set[String]()
      while(set.size < 20){
        var index = new java.util.Random().nextInt(bl.length)
        set += bl(index)
      }
      set.toArray
    })

    val join = xm.selectExpr("member_id","explode(sample_join()) as listing_id")

    // 剔除正样本数据
    val x_fuOriginDF = join.except(x_zhengSamplesDF.select("member_id","listing_id"))

    x_fuOriginDF.persist(StorageLevel.MEMORY_AND_DISK_SER)
    x_fuOriginDF.write.mode(SaveMode.Overwrite).parquet(s"/tmp/xhl/recommend/lr/x_fu_origin")
    x_fuOriginDF.show(false)

    // 基于采样，使正负样本均衡
    val x_fuSamplesDF = x_fuOriginDF.sample(withReplacement = false,x_zhengSamplesDF.count().toDouble/x_fuOriginDF.count().toDouble)
    x_fuSamplesDF.persist(StorageLevel.MEMORY_AND_DISK_SER)
    x_fuSamplesDF.write.mode(SaveMode.Overwrite).parquet(s"/tmp/xhl/recommend/lr/x_fu_samples")
    x_fuSamplesDF.show(false)

    // 合并结果
    val ratingsDF = x_zhengSamplesDF.selectExpr("member_id","listing_id","1 as label")
      .union(x_fuSamplesDF.selectExpr("member_id","listing_id","0 as label"))

    ratingsDF.persist(StorageLevel.MEMORY_AND_DISK_SER)
    ratingsDF.write.mode(SaveMode.Overwrite).parquet(s"/tmp/xhl/recommend/lr/ratings")
    ratingsDF.show(false)

    println(s"总体正样本个数${x_originalDF.count()}, 正样本个数${x_zhengSamplesDF.count()}，总体负样本个数${x_fuOriginDF.count()}，负样本个数${x_fuSamplesDF}")
  }
}
case class SampleBean(member_id:String,listing_id:String){}
