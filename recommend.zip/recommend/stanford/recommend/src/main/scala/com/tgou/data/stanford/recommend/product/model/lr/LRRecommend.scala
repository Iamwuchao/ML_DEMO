package com.tgou.data.stanford.recommend.product.model.lr

import java.time.LocalDate

import com.tgou.data.stanford.recommend.RecommendBootstrap
import org.apache.spark.ml.tuning.CrossValidatorModel
import org.apache.spark.sql.SparkSession

object LRRecommend {
  def main(args: Array[String]): Unit = {
    RecommendBootstrap(args).bootstrap(execute)
  }

  def execute(spark: SparkSession, appName: String, date: LocalDate, args: Array[String]): Unit = {

    CrossValidatorModel.load("/tmp/xhl/recommend/lr/model")

    val t1 = spark.createDataFrame(Seq())
    val t2 = spark.createDataFrame(Seq())

    t1.except(t2)

  }
}
