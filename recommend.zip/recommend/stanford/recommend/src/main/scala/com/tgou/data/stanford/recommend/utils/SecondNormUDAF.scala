package com.tgou.data.stanford.recommend.utils

import org.apache.spark.sql.Row
import org.apache.spark.sql.expressions.{MutableAggregationBuffer, UserDefinedAggregateFunction}
import org.apache.spark.sql.types.{DataType, DoubleType, StructType}
import scala.math._

/*
 *created by wuchao on 2018/3/27.
 *package_name : com.tgou.data.stanford.recommend.utils
 * 计算二范数，感觉spark sql应该有啊，但是没找到就自己写了一个
 */
class SecondNormUDAF extends UserDefinedAggregateFunction{
  override def inputSchema: StructType =new StructType().add("score",DoubleType)

  override def bufferSchema: StructType = new StructType().add("secondNorm",DoubleType)

  override def dataType: DataType = DoubleType

  override def deterministic: Boolean = true

  override def initialize(buffer: MutableAggregationBuffer): Unit = {
    buffer(0)=0.0
  }

  override def update(buffer: MutableAggregationBuffer, input: Row): Unit = {
    val score = input.getAs[Double](0)
    buffer(0)= buffer.getAs[Double](0) + score*score
  }

  override def merge(buffer1: MutableAggregationBuffer, buffer2: Row): Unit = {
    buffer1(0) = buffer1.getAs[Double](0) + buffer2.getAs[Double](0)
  }

  override def evaluate(buffer: Row): Any ={
    val result = buffer.getAs[Double](0)
    sqrt(result)
  }
}
