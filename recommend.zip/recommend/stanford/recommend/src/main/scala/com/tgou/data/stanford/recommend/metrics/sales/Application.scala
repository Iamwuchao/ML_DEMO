package com.tgou.data.stanford.recommend.metrics.sales

import java.time.LocalDate

import com.tgou.data.stanford.core.utils.DateUtils
import org.apache.spark.sql.{DataFrame, SparkSession}

object Application {

  /**
    * 计算漏斗部分数据，形成 场景-流程-创建订单数-支付订单数
    *
    * @param spark
    * @param appName
    * @param date
    * @param args
    * @return
    */
  def funnelSalesChart(spark: SparkSession, appName: String, date: LocalDate, args: Array[String]): DataFrame = {
    val lastDay = DateUtils.dateFormat(date)

    spark.sql(
      s"""
         |select
         |  concat(t1.scene_id, '_', t1.process_id, '_', '$lastDay') as id
         |  t1.scene_id,
         |  t1.process_id,
         |  t2.count as create_bs,
         |  t3.count as pay_bs,
         |  '$lastDay' as date
         |from (
         |  select
         |    scene_id,
         |    process_id
         |  from meta
         |  group by scene_id, process_id
         |) t1
         |left join (
         |  -- 统计创建订单数量
         |  select
         |    scene_id,
         |    process_id,
         |    count(distinct order_id) as count
         |  from ordeItem
         |  where order_create_time >= '$lastDay 00:00:00' and order_create_time <= '$lastDay 23:59:59'
         |    and scene_id is not null
         |  group by scene_id, process_id
         |) t2 on t1.scene_id = t2.scene_id and t1.process_id = t2.process_id
         |left join (
         |  -- 统计支付订单数量
         |  select
         |    scene_id,
         |    process_id,
         |    count(distinct order_id) as count
         |  from ordeItem
         |  where order_pay_time >= '$lastDay 00:00:00' and order_pay_time <= '$lastDay 23:59:59'
         |    and scene_id is not null
         |  group by scene_id, process_id
         |) t3 on t1.scene_id = t3.scene_id and t1.process_id = t3.process_id
       """.stripMargin)

  }

  /**
    * 饼图数据，形成 场景-业态-支付笔数-支付金额
    *
    * @param spark
    * @param appName
    * @param date
    * @param args
    * @return
    */
  def sourceSalesChart(spark: SparkSession, appName: String, date: LocalDate, args: Array[String]): DataFrame = {
    val lastDay = DateUtils.dateFormat(date)

    spark.sql(
      s"""
         |select
         |  concat(scene_id,'_',source,'_','$lastDay') as id,
         |  scene_id,
         |  source,
         |  count(1) as pay_bs,
         |  sum(amount) as pay_je,
         |  '$lastDay' as date
         |from (
         |  select
         |    scene_id,
         |    sourcem
         |    order_id,
         |    max(order_actual_sales_amount) as amount
         |  from orderItem
         |  where order_pay_time >= '$lastDay 00:00:00' and order_pay_time <= '$lastDay 23:59:59'
         |    and scene_id is not null
         |  group by scene_id, source, order_id
         |) t
         |group by scene_id, source
       """.stripMargin)
  }
}
