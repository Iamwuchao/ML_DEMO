package com.tgou.data.stanford.recommend.utils

import breeze.numerics.sqrt
import org.apache.spark.mllib.linalg.{Vector, Vectors}
import org.jblas.DoubleMatrix

/**
  * Created by Administrator on 2017/5/22.
  */
object SimilarityUtils {

  /**
    * 夹角余弦
    */
  def cosineSimilarity(vec1: DoubleMatrix,vec2: DoubleMatrix): Double = {
    vec1.dot(vec2) / (vec1.norm2() * vec2.norm2())
  }

  def cosineSimilarity1(vec1: Vector,vec2: Vector): Double = {
    val norm1 = Vectors.norm(vec1,2)
    val norm2 = Vectors.norm(vec2,2)
    val dm1 = new DoubleMatrix(vec1.toDense.toArray)
    val dm2 = new DoubleMatrix(vec2.toDense.toArray)
    dm1.dot(dm2) / (norm1 * norm2)
  }

  /**
    * 欧式距离
    */
  def euclideanDistanceSimilarity(vec1: Vector,vec2: Vector): Double = {
    val dist = sqrt(Vectors.sqdist(vec1,vec2))
    val sim = 1 / (1+dist)
    sim
  }

  /**
    * Jaccard相似度
    */
  def jaccardSimilarity(vec1: Vector,vec2: Vector): Double = {
    val norm1 = Vectors.norm(vec1,1)
    val norm2 = Vectors.norm(vec2,1)
    val dm1 = new DoubleMatrix(vec1.toDense.toArray)
    val dm2 = new DoubleMatrix(vec2.toDense.toArray)
    val dot = dm1.dot(dm2)
    dot / (norm1+norm2-dot)
  }

  def jaccardSimilarity(vec1: org.apache.spark.ml.linalg.Vector,vec2: org.apache.spark.ml.linalg.Vector): Double = {
    val norm1 = org.apache.spark.ml.linalg.Vectors.norm(vec1,1)
    val norm2 = org.apache.spark.ml.linalg.Vectors.norm(vec2,1)
    val dm1 = new DoubleMatrix(vec1.toDense.toArray)
    val dm2 = new DoubleMatrix(vec2.toDense.toArray)
    val dot = dm1.dot(dm2)
    dot / (norm1+norm2-dot)
  }

  def main(args: Array[String]) {
    val vv1 = Vectors.dense(Array[Double](0,1,1,0))
    val vv2 = Vectors.dense(Array[Double](1,0,1,1))
    println(jaccardSimilarity(vv1,vv2))
  }

}
