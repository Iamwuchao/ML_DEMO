package com.tgou.data.stanford.recommend.utils

/**
  * recommend exception
  *
  * @param message  msg
  * @param cause    cause
  */
class RecommendException(message: String, cause: Throwable)
  extends Exception(message, cause) {

  def this(message: String) = this(message, null)

}


