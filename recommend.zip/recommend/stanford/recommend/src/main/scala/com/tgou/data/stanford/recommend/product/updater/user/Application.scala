package com.tgou.data.stanford.recommend.product.updater.user

import java.time.LocalDate

import com.tgou.data.stanford.recommend.RecommendBootstrap
import com.tgou.data.stanford.recommend.utils.{ModelType, PersistUtils, SaveType}
import org.apache.spark.sql.SparkSession

import scala.collection.mutable.ArrayBuffer

/**
  * 跨境几个推荐模型
  */
object Application {
  def main(args: Array[String]): Unit = {
    RecommendBootstrap(args).bootstrap(execute)
  }

  def execute(spark: SparkSession, appName: String, date: LocalDate, args: Array[String]): Unit = {
    val isOnline = !"test".equals(args(2))

    val cb = spark.read.parquet("/ml/kj_recommend/a/cb_user_recommend_result")
      .selectExpr("member_id as query_id","origin_listing_id","listing_id as rec_id","similarity","index")

    val als = spark.read.parquet("/ml/kj_recommend/a/als_user_recommend_result")

    val icf = spark.read.parquet("/ml/kj_recommend/a/icf_user_recommend_result")
      .selectExpr("member_id as query_id","origin_listing_id","listing_id as rec_id","similarity","index")

    val tb = spark.read.parquet("/ml/kj_recommend/a/cb_tag_brand_user_recommend_result")
      .selectExpr("member_id as query_id","brand_id","listing_id as rec_id","index")

    val t3c = spark.read.parquet("/ml/kj_recommend/a/cb_tag_thrid_category_user_recommend_result")
      .selectExpr("member_id as query_id","listing_id as rec_id","index","third_category")

    import spark.implicits._

    val saveALS = als.selectExpr("userId as member_id","recommendProductIds").flatMap(r => {
      val member_id = r.getLong(0).toString
      val recs = r.getString(1).split(",")
      val buffer:ArrayBuffer[(String,String,Int)] = new ArrayBuffer[(String,String,Int)]()
      for(i <- recs.indices){
        buffer += ((member_id, recs(i), i))
      }
      buffer
    }).toDF("query_id","rec_id","index")

    PersistUtils.save(spark, cb, ModelType.P_KJ_CB_V1, SaveType.USER_PRODUCT_REC, isOnline)

    PersistUtils.save(spark, saveALS, ModelType.P_KJ_ALS_V1, SaveType.USER_PRODUCT_REC, isOnline)

    PersistUtils.save(spark, icf, ModelType.P_KJ_ICF_V1, SaveType.USER_PRODUCT_REC, isOnline)

    PersistUtils.save(spark, tb, ModelType.P_KJ_TB_V1, SaveType.USER_PRODUCT_REC, isOnline)

    PersistUtils.save(spark, t3c, ModelType.P_KJ_T3C_V1, SaveType.USER_PRODUCT_REC, isOnline)
  }
}
