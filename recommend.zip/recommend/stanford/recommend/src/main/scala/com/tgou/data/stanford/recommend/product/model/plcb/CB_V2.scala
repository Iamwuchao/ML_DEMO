package com.tgou.data.stanford.recommend.product.model.plcb

import java.time.LocalDate

import com.alibaba.fastjson.JSONObject
import com.tgou.data.stanford.recommend.RecommendBootstrap
import com.tgou.data.stanford.recommend.utils.{ModelType, PersistUtils, SaveType}
import org.apache.spark.ml.feature.QuantileDiscretizer
import org.apache.spark.sql.SparkSession

/*
 *created by wuchao on 2018/4/3.
 *package_name : com.tgou.data.stanford.recommend.product.model.plcb
 */

object CBV2 {

  def main(args: Array[String]): Unit = {
    RecommendBootstrap(args).bootstrap(execute)
  }

  def categoryProcess(category3:String,category4:String):String={
    if(category4 ==null ||category4==""){
      return category3
    }
    else{
      return category4
    }
  }

  def strToNum(price:Double):Double={
    price.toDouble
  }

  //拼接两个字段
  def spliceField(filed1:String,filed2:String):String={
    filed1+"#"+filed2
  }

  def spliceStrDouble(filed1:String,filed2:Double):String={
    filed1+"#"+filed2.toInt.toString
  }

  def myJaccard(price_id1:String,price_id2:String,category_id1: String,category_id2: String,
                brand_id1:String,brand_id2:String):Double={
    val set1 = Set("p"+price_id1,"c"+category_id1,"b"+brand_id1)
    val set2 = Set("p"+price_id2,"c"+category_id2,"b"+brand_id2)
    val set3 = set1&set2
    val set4 = set1 | set2
    set3.size*1.0/set4.size*1.0
  }

  def jaccardJson(jaccard:Double):String={
    val json = new JSONObject()
    json.put("jaccard",jaccard)
    json.toJSONString
  }

  def execute(spark: SparkSession, appName: String, date: LocalDate, args:Array[String]): Unit = {

    import spark.implicits._
    spark.udf.register("categoryProcess",categoryProcess _)
    spark.udf.register("spliceField",spliceField _)
    spark.udf.register("strToNum",strToNum _)
    spark.udf.register("spliceStrDouble",spliceStrDouble _)
    spark.udf.register("myJaccard",myJaccard _)
    spark.udf.register("jaccardJson",jaccardJson _)

    val onLine = "online".equals(args(2))
    val listing_df = spark.read.parquet(CBConfig.listing_info_path)
    listing_df.createOrReplaceTempView("listing")

    //获取推荐池商品的列表
    val rec_list_info_df = spark.sql(
      """
        |select listing_id,strToNum(sale_price) price,categoryProcess(category3,category4) category_id,brand_id
        |from  persona.recommend_pool_test where listing_state='onshelf' and is_recommended='1' and (source='1' or source='4' or source='3') and listing_id!='9116001'
      """.stripMargin)
    rec_list_info_df.createOrReplaceTempView("rec_list_info_df")
    //rec_list_info_df.write.mode(SaveMode.Overwrite).parquet("/tmp/wuchao/cb/rec_list_info_df")

    //划分价格区间
    //将价格划分为20个区间，每个区间的数量尽可能相等
    val discretizer = new QuantileDiscretizer()
      .setInputCol("price")
      .setOutputCol("price_id")
      .setNumBuckets(20)

    val item_info_processed_df = discretizer.fit(rec_list_info_df).transform(rec_list_info_df).as[CBBean]


    item_info_processed_df.createOrReplaceTempView("item_info_processed_df")
    item_info_processed_df.cache()

    /*
      获取杰卡德相似度大于等于0.5 的商品信息，也就是说 （品类，价格），（品类，品牌），（品牌，价格）这三个字段中有俩相等
     */
    val tem_item_info_df = spark.sql(
      """
        |select listing_id,spliceStrDouble(category_id,price_id) cp,spliceField(category_id,brand_id) cb,spliceStrDouble(brand_id,price_id) bp
        |from item_info_processed_df where category_id is not null and brand_id is not null
      """.stripMargin)
    tem_item_info_df.createOrReplaceTempView("tem_item_info_df")
    tem_item_info_df.cache()

    //(品类，价格)
    val cp_df = spark.sql(
      """
        |select spliceField(a.listing_id,b.listing_id) item_pair
        |from tem_item_info_df a left outer join tem_item_info_df b on a.cp = b.cp
        |where a.listing_id != b.listing_id
      """.stripMargin).as[ItemPair]

    //(品类，品牌)
    val cb_df = spark.sql(
      """
        |select spliceField(a.listing_id,b.listing_id) item_pair
        |from tem_item_info_df a left outer join tem_item_info_df b on a.cb = b.cb
        |where a.listing_id != b.listing_id
      """.stripMargin).as[ItemPair]

    //(品牌，价格)
    val bp_df = spark.sql(
      """
        |select spliceField(a.listing_id,b.listing_id) item_pair
        |from tem_item_info_df a left outer join tem_item_info_df b on a.bp = b.bp
        |where a.listing_id != b.listing_id
      """.stripMargin).as[ItemPair]

    val cp_cd = cp_df.union(cb_df)
    val cp_cd_bp = cp_cd.union(bp_df)
    cp_cd_bp.createOrReplaceTempView("cp_cd_bp")
    val distinct_cp_cb_bp = spark.sql(
      """
        |select distinct item_pair from cp_cd_bp
      """.stripMargin).as[ItemPair]
    val item_pair_df = distinct_cp_cb_bp.map(itemPair=>{
      val strArr = itemPair.item_pair.split("#")
      (strArr(0),strArr(1))
    }).toDF("listing_id1","listing_id2")
    item_pair_df.createOrReplaceTempView("item_pair_df")
    //item_pair_df.write.mode(SaveMode.Overwrite).parquet("/tmp/wuchao/cb/item_pair_df")


    tem_item_info_df.unpersist()

    //获取listing_id1 的 价格，品牌，类别
    val list_id1_info_df = spark.sql(
      """
        |select listing_id1,listing_id2,category_id category_id1,price_id price_id1,brand_id brand_id1
        |from item_pair_df a left outer join item_info_processed_df b on a.listing_id1 = b.listing_id
      """.stripMargin)
    list_id1_info_df.createOrReplaceTempView("list_id1_info_df")

    val list_id2_info_df = spark.sql(
      """
        |select listing_id1,listing_id2,category_id1,price_id1,brand_id1,category_id category_id2,
        |price_id price_id2,brand_id brand_id2
        |from list_id1_info_df a left outer join item_info_processed_df b on a.listing_id2 = b.listing_id
      """.stripMargin)
    list_id2_info_df.createOrReplaceTempView("list_id2_info")
    val listing_jaccard_df = spark.sql(
      """
        |select listing_id1,listing_id2,
        |myJaccard(price_id1,price_id2,category_id1,category_id2,brand_id1,brand_id2) as jaccard
        |from list_id2_info
      """.stripMargin)
    listing_jaccard_df.createOrReplaceTempView("listing_jaccard")
    //listing_jaccard_df.write.mode(SaveMode.Overwrite).parquet("/tmp/wuchao/cb/listing_jaccard_df")

    item_info_processed_df.unpersist()

    //选出每个物品最相似的30个物品
    val cb_similarity_df = spark.sql(
      s"""
         |select listing_id1,listing_id2,jaccard,rank_j
         |from (select *,row_number() OVER (partition by listing_id1 order by jaccard DESC ) rank_j from listing_jaccard) tmp
         |where tmp.rank_j<=${CBConfig.maxSimilaritiesPerItem}
      """.stripMargin)
    cb_similarity_df.createOrReplaceTempView("cb_similarity_topk")
    cb_similarity_df.cache()

    //转换一下，info需要是json的
    val cbsim_df = spark.sql(
      """
        |select listing_id1 query_id,listing_id2 rec_id,rank_j index from cb_similarity_topk
      """.stripMargin)
    PersistUtils.save(spark,cbsim_df,ModelType.P_PT_CBSIM_V2,SaveType.PRODUCT_REC,onLine)

    //读取用户评分矩阵
    val ratingMartix  = spark.read.parquet(s"/persona/data/user_product_ratings")
    ratingMartix.createOrReplaceTempView("user_product_ratings")
    //选出用户最喜欢的三个商品
    val user_favorite_items_df = spark.sql(
      s"""
         |select member_id,listing_id as origin_listing_id,score from
         |(select *,row_number() OVER (partition by member_id order by score  DESC) rank from user_product_ratings ) tmp
         | where rank<=${CBConfig.userFavorItems}
       """.stripMargin)
    user_favorite_items_df.createOrReplaceTempView("user_favorite_items")
    //user_favorite_items_df.write.mode(SaveMode.Overwrite).parquet("/tmp/wuchao/cb/user_favorite_items_df")

    //根据用户评分计算用户推荐商品的评分
    val user_rec_item_rating_df = spark.sql(
      """
        |select * from
        |(select member_id,origin_listing_id,listing_id2 rec_id,(score*jaccard) rating from
        |user_favorite_items a left outer join cb_similarity_topk b on a.origin_listing_id = b.listing_id1) tmp
        |where tmp.origin_listing_id!=tmp.rec_id
      """.stripMargin)
    user_rec_item_rating_df.createOrReplaceTempView("user_rec_item_rating")

    //对用户评分进行排序
    val user_rec_item_sort_df = spark.sql(
      """
        |select member_id query_id,origin_listing_id,rec_id,rating similarity,
        |row_number() OVER(partition by member_id order by rating DESC) index
        |from user_rec_item_rating
      """.stripMargin)
    PersistUtils.save(spark, user_rec_item_sort_df,ModelType.P_PT_CB_V2,SaveType.USER_PRODUCT_REC,onLine)
  }
}
