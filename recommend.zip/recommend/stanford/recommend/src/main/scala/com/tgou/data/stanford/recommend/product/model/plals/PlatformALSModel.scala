package com.tgou.data.stanford.recommend.product.model.plals

import java.time.LocalDate

import com.tgou.data.stanford.recommend.RecommendBootstrap
import com.tgou.data.stanford.recommend.utils.{PersistUtils, SaveType, ModelType}
import org.apache.spark.ml.evaluation.RegressionEvaluator
import org.apache.spark.ml.recommendation.ALS
import org.apache.spark.sql.{SaveMode, SparkSession, Row}

import scala.collection.mutable.ArrayBuffer

/**
  * Created by Travis on 29/03/2018.
  */
object PlatformALSModel {

  def main(args: Array[String]): Unit = {
    RecommendBootstrap(args).bootstrap(execute)
  }

  def execute(spark: SparkSession, appName: String, date: LocalDate, args:Array[String]): Unit = {

    import spark.implicits._

    val online = !"test".equals(args(2))
    val namespace = if(online) "rec" else "test_rec"
    val model_name = "user_product_ratings"

    val mergedResultDF = spark.read.parquet(s"/persona/data/user_product_ratings")
    mergedResultDF.createOrReplaceTempView("merged_score")

    spark.udf.register("str2long",(s:String)=>s.toLong)

    val ratings = spark.sql(
      s"""
         |select
         |  str2long(member_id) as member_id,
         |  str2long(listing_id) as listing_id,
         |  score
         |from merged_score
         |""".stripMargin)
    val Array(training, test) = ratings.randomSplit(Array(0.8, 0.2))

    // Build the recommendation model using ALS on the training data
    val als = new ALS()
        .setMaxIter(5)
        .setRegParam(0.01)
        .setUserCol("member_id")
        .setItemCol("listing_id")
        .setRatingCol("score")
        .setImplicitPrefs(true)
        .setAlpha(0.01)
    val model = als.fit(training)

    // Evaluate the model by computing the RMSE on the test data
    // Note we set cold start strategy to 'drop' to ensure we don't get NaN evaluation metrics
    model.setColdStartStrategy("drop")
    val predictions = model.transform(test)

    val evaluator = new RegressionEvaluator()
        .setMetricName("rmse")
        .setLabelCol("score")
        .setPredictionCol("prediction")
    val rmse = evaluator.evaluate(predictions)
    println(s"Root-mean-square error = $rmse")

    // Generate top 10 movie recommendations for each user
    val userRecs = model.recommendForAllUsers(100)

    val saveALS = userRecs.flatMap(r => {
      val member_id = r.getInt(0).toString
      val recs: Seq[Row] = r.getSeq(1)
      val buffer:ArrayBuffer[(String,String,Int)] = new ArrayBuffer[(String,String,Int)]()
      for(i <- recs.indices){
        buffer += ((member_id, recs(i).getInt(0).toString, i))
      }
      buffer
    }).toDF("query_id","rec_id","index")

    PersistUtils.save(spark, saveALS, ModelType.P_PT_ALS_V1, SaveType.USER_PRODUCT_REC, online)

  }
}
