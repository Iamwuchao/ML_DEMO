package com.tgou.data.stanford.recommend.metrics

import java.time.LocalDate
import java.util.Properties

import com.tgou.data.stanford.core.utils.DateUtils
import com.tgou.data.stanford.recommend.RecommendBootstrap
import com.tgou.data.stanford.recommend.utils.udaf.DistinctMergeUDAF
import com.tgou.data.stanford.recommend.utils.{ModelType, PersistUtils, SaveType}
import com.tgou.traceInfo.OriginGenerator
import org.apache.spark.sql.types.{StringType, StructField, StructType}
import org.apache.spark.sql.{DataFrame, SaveMode, SparkSession}
import org.apache.spark.storage.StorageLevel

/**
  * 算法文档：http://c.51tiangou.com/pages/viewpage.action?pageId=16799565
  * 需求文档：http://c.51tiangou.com/pages/viewpage.action?pageId=16795366
  *
  * @author xinghailong
  */
object Application {
  def main(args: Array[String]): Unit = {
    RecommendBootstrap(args).bootstrap(execute)
  }

  def execute(spark: SparkSession, appName: String, date: LocalDate, args: Array[String]): Unit = {

    val lastDay = DateUtils.dateFormat(date)
    val isOnline = "online".equals(args(2))
    val path = DateUtils.dateFormat(date, DateUtils.DATE_PATH_FORMAT)
    val url = args(3)
    val connectionProperties = new Properties()
    connectionProperties.put("user", args(4))
    connectionProperties.put("password", args(5))

    // 1. 注册udf
    spark.udf.register("parse",(traceId:String)=> {
      // 解析traceId,并转成scala的Map
      var map:scala.collection.mutable.Map[String,String] = scala.collection.mutable.Map()
      try{
        val json = OriginGenerator.getOriginJsonObject(traceId)
        val iter = json.keySet().iterator()
        while(iter.hasNext){
          val key = iter.next()
          map.put(key,json.getString(key))
        }
      }catch{
        case e: Exception =>
      }
      map
    })
    spark.udf.register("str_length",(s:String)=> s.split(",").count(s => !"".equals(s)))
    spark.udf.register("distinct_merge",new DistinctMergeUDAF())
    spark.udf.register("d2decimal",(d:Double)=>BigDecimal.valueOf(d))

    // 2. 形成临时数据
    val scp = preprocess(spark, s"/tiangou/scp/$path/*/")
    scp.persist(StorageLevel.MEMORY_AND_DISK_SER_2)
    scp.write.mode(SaveMode.Overwrite).parquet("/tmp/xhl/recommend/metrics/scp")
    scp.createOrReplaceTempView("scp")

    val expose = preprocess(spark, s"/tiangou/expose/$path/*/")
    expose.persist(StorageLevel.MEMORY_AND_DISK_SER_2)
    expose.write.mode(SaveMode.Overwrite).parquet("/tmp/xhl/recommend/metrics/expose")
    expose.createOrReplaceTempView("expose")

    //读取订单相关数据，形成订单相关的临时数据
    val orderItem = preprocessOrder(spark, date)
    orderItem.persist(StorageLevel.MEMORY_AND_DISK_SER_2)
    orderItem.write.mode(SaveMode.Overwrite).parquet("/tmp/xhl/recommend/metrics/orderItem")
    orderItem.createOrReplaceTempView("orderItem")

    // 读取mysql查询模型信息
    spark.read.jdbc(url,"model",connectionProperties).createOrReplaceTempView("model")
    spark.read.jdbc(url,"model_to_process",connectionProperties).createOrReplaceTempView("model_to_process")
    spark.read.jdbc(url,"process",connectionProperties).createOrReplaceTempView("process")
    spark.read.jdbc(url,"scene",connectionProperties).createOrReplaceTempView("scene")

    // 形成原始数据表
    val meta = metaTable(spark)
    meta.persist(StorageLevel.MEMORY_AND_DISK_SER_2)
    meta.write.mode(SaveMode.Overwrite).parquet("/tmp/xhl/recommend/metrics/meta")
    meta.createOrReplaceTempView("meta")

    // 获得模型推荐的内容信息
    val modelsRecDF = modelRecData(spark)
    modelsRecDF.persist(StorageLevel.MEMORY_AND_DISK_SER_2)
    modelsRecDF.write.mode(SaveMode.Overwrite).parquet("/tmp/xhl/recommend/metrics/modes_rec")
    modelsRecDF.createOrReplaceTempView("models_rec")

    // 3. 计算首页信息
    // WARN:由于涉及跨场景的订单去重，因此数据不可复用，需要单独计算
    val homeMetricsDF = home.Application.homeMetrics(spark, appName, date, args)
    PersistUtils.save(spark, homeMetricsDF, ModelType.M_HOME_METRICS, SaveType.METRICS, isOnline, date)

    // 4. 计算首页图形信息
    // WARN:由于图形涉及业态信息，因此数据不可复用，需要单独计算
    val homeChartsDF = home.Application.homeCharts(spark, appName, date, args)
    PersistUtils.save(spark, homeChartsDF, ModelType.M_HOME_CHARTS, SaveType.METRICS, isOnline, date)

    // 5. 计算首页下面的表格数据
    val homeTableDF = home.Application.homeTable(spark, appName, date, args)
    PersistUtils.save(spark, homeTableDF, ModelType.M_HOME_TABLE, SaveType.METRICS, isOnline, date)

    // 6. 计算点击和曝光
    val clickDF = click.Application.execute(spark, appName, date, args)
    PersistUtils.save(spark, clickDF, ModelType.M_CLICK, SaveType.METRICS, isOnline, date)

    // 7. 计算准确率、召回率、F1
    val prfDF   = prf.Application.execute(spark, appName, date, args)
    PersistUtils.save(spark, prfDF, ModelType.M_PRF, SaveType.METRICS, isOnline, date)

    // 8. 计算业态饼图
    val sourceSalesCharts = sales.Application.sourceSalesChart(spark, appName, date, args)
    PersistUtils.save(spark, sourceSalesCharts, ModelType.M_SALES_SOURCE, SaveType.METRICS, isOnline, date)

    // 9. 计算漏斗订单相关部分数据
    val funnelSalesCharts = sales.Application.funnelSalesChart(spark, appName, date, args)
    PersistUtils.save(spark, funnelSalesCharts, ModelType.M_SALES_FUNNEL, SaveType.METRICS, isOnline, date)
  }

  /**
    * 注册场景元数据表
    *
    * @param spark spark
    * @return
    */
  def metaTable(spark:SparkSession):DataFrame  = {
    spark.sql(
      s"""
         |select
         |    s.id as scene_id,
         |    s.name as scene_name,
         |    p.id as process_id,
         |    p.name as process_name,
         |    m.id as model_id,
         |    m.name as model_name,
         |    m.location,
         |    m.param_type,
         |    m.col
         |from scene s
         |inner join process p
         |    on s.id = p.scene_id
         |inner join model m
         |    on p.standby = m.id
         |where  s.state = 'online'
         |union all
         |select
         |    s.id as scene_id,
         |    s.name as scene_name,
         |    p.id as process_id,
         |    p.name as process_name,
         |    m.id as model_id,
         |    m.name as model_name,
         |    m.location,
         |    m.param_type,
         |    m.col
         |from scene s
         |inner join process p
         |    on s.id = p.scene_id
         |inner join model_to_process mtp
         |    on p.id = mtp.process_id
         |left join model m
         |    on mtp.model_id = m.id
         |where  s.state = 'online'
       """.stripMargin)
  }

  def preprocessOrder(spark: SparkSession, date: LocalDate): DataFrame = {
    val lastday = DateUtils.dateFormat(date)

    spark.sql(
      s"""
         |select
         |    order_item_id,
         |    order_id,
         |    order_actual_sales_amount,
         |    order_create_time,
         |    order_pay_time,
         |    source,
         |    trace['scene_id'] as scene_id,
         |    trace['process_id'] as process_id,
         |    trace['model_id'] as model_id
         |from (
         |    select
         |        order_item_id,
         |        order_id,
         |        order_actual_sales_amount,
         |        order_create_time,
         |        order_pay_time,
         |        source,
         |        parse(trace_id) as trace
         |    from zhangshaorui.order_item_fact
         |) t
         |where trace['scene'] is not null
         |  and (order_create_time > '$lastday 00:00:00' or order_pay_time > '$lastday 00:00:00')
       """.stripMargin)
  }

  /**
    * 数据预处理，member_id补全
    *
    * @param spark spark
    * @param path path
    * @return
    */
  def preprocess(spark:SparkSession, path:String):DataFrame = {

    import spark.implicits._

    val origin = spark.read.json(path)
    origin.createOrReplaceTempView("temp")

    // 格式化数据
    val formatedDF = spark.sql(
      s"""
         |select
         |    trace['scene_id']   as scene_id,
         |    trace['process_id'] as process_id,
         |    trace['model_id']   as model_id,
         |    case when bk_id is null then trace['rec_id'] else bk_id end as item_id,
         |    member_id,
         |    uuid,
         |    unix_timestamp(time) as time
         |from (
         |    -- 如果bk不存在，也可以从trace_id中解析
         |    select
         |        case when bk like '%-%' then split(bk,'-')[1] else null end as bk_id,
         |        mi as member_id,
         |        uuid,
         |        parse(traceId) as trace,
         |        time
         |    from temp
         |) t1
         |where bk_id is not null or trace['rec_id'] is not null
       """.stripMargin)

    // 补全member_id, 此处排序可以参考：com.tgou.data.stanford.recommend.metrics.SortedTest
    val result = formatedDF
      .toDF("scene_id","process_id","model_id","item_id","member_id","uuid","time")
      .as[Metrics]
      .groupByKey(m=>m.uuid)
      .flatMapGroups((key:String,values:Iterator[Metrics])=>{
        // 按照时间逆序排序
        val sorted = values.toList.sortWith((a,b)=>a.time > b.time)//根据rank进行排序
        var member_id = sorted.head.member_id

        // member_id 补全
        sorted.foreach(m => {
          // 如果member_id为空，则进行补全
          if(m.member_id == null || "".equals(m.member_id)){
            m.member_id = member_id
          }else{
            member_id = m.member_id
          }
        })

        sorted
      }
      )

    result.toDF()
  }

  // WARN: member_id需要补全，需要定义为var类型
  case class Metrics(scene_id:String,process_id:String,model_id:String,
                     item_id:String,var member_id:String,uuid:String,
                     time:Long)

  /**
    * 读取所有模型对应的推荐内容
    *
    * @param spark spark
    * @return
    */
  def modelRecData(spark:SparkSession):DataFrame = {
    import spark.implicits._

    val validMembersDF = spark.sql(s"select distinct member_id as query_id from scp")

    // 获得model member_id rec_id等信息
    val structTypes = StructType(Seq(
      StructField("model",    StringType),
      StructField("query_id", StringType),
      StructField("rec_id",   StringType)
    ))

    // 获得模型的名字
    val models = spark.sql(s"select col,max(param_type) as param_type from meta group by col")
      .map(r=>(r.getString(0),r.getInt(1)))
      .collectAsList()

    var unionDF = spark.createDataFrame(spark.emptyDataFrame.toJavaRDD, structTypes)

    val iter = models.iterator()
    // 遍历模型进行join
    while(iter.hasNext){
      val model = iter.next()
      //这里测试环境的数据没有意义，直接读取线上数据即可
      var modelDF = PersistUtils.readHistory(spark,model._1,true)
      if (modelDF.count() > 0){
        model._2 match {
          case 0  => // 用户推品模式
            // 普通模型直接过滤非当天有效的数据，union在一起
            modelDF =  modelDF
              .join(validMembersDF,Seq("query_id","query_id"),"inner")
              .selectExpr(s"'${model._1}' as model","query_id","rec_id")

          case _  => // 品推品模式 或者 候补集模式

            //按照热销的模式计算，笛卡尔积
            modelDF =  modelDF
              .select("rec_id")
              .distinct
              .selectExpr(s"'${model._1}' as model","'any' as query_id","rec_id")

        }
        unionDF = unionDF.union(modelDF)
      }
    }

    unionDF.persist(StorageLevel.MEMORY_AND_DISK_SER_2)
    unionDF.createOrReplaceTempView("union_t")

    val totalDF = spark.sql(
      s"""
         |select
         |  scene_id,process_id,model_id,u.query_id,u.rec_id
         |from meta m left join union_t u on m.col = u.model
       """.stripMargin)
    totalDF
  }

}

