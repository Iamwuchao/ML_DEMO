package com.tgou.data.stanford.recommend.product.model.lr

import java.time.LocalDate
import java.time.format.DateTimeFormatter

import com.tgou.data.stanford.core.utils.DateUtils
import com.tgou.data.stanford.recommend.RecommendBootstrap
import org.apache.spark.sql.{DataFrame, SaveMode, SparkSession}
import org.apache.spark.storage.StorageLevel

import scala.collection.mutable.ArrayBuffer
import scala.util.matching.Regex

object LRRatingsBuilderv2 {

  def main(args: Array[String]): Unit = {
    RecommendBootstrap(args).bootstrap(execute)
  }

  def execute(spark: SparkSession, appName: String, date: LocalDate, args: Array[String]): Unit = {

    spark.udf.register("validateMemberId",(member_id:String) => {
      val pattern = new Regex("^\\d+$")
      (pattern findAllIn member_id).nonEmpty
    })

    val exposeTrain = exposeRead(spark,date.minusDays(7),date.minusDays(1))
      .persist(StorageLevel.MEMORY_AND_DISK_SER_2)
    val exposeTest  = exposeRead(spark,date,date)
      .persist(StorageLevel.MEMORY_AND_DISK_SER_2)

    val accessTrain = accessRead(spark,DateUtils.dateFormat(date.minusDays(7)),DateUtils.dateFormat(date.minusDays(1)))
      .persist(StorageLevel.MEMORY_AND_DISK_SER_2)
    val accessTest  = accessRead(spark,DateUtils.dateFormat(date),DateUtils.dateFormat(date))
      .persist(StorageLevel.MEMORY_AND_DISK_SER_2)

    val train = accessTrain.selectExpr("member_id","listing_id","1 as label").union(
      exposeTrain.sample(false,accessTrain.count().toDouble/exposeTrain.count().toDouble)
        .selectExpr("member_id","listing_id","0 as lable")
    )

    train.write.mode(SaveMode.Overwrite).parquet(s"/tmp/xhl/recommend/lr/train_rating_v2")

    val test = accessTest.selectExpr("member_id","listing_id","1 as label").union(
      exposeTest.sample(false,accessTest.count().toDouble/exposeTest.count().toDouble)
        .selectExpr("member_id","listing_id","0 as lable")
    )

    test.write.mode(SaveMode.Overwrite).parquet(s"/tmp/xhl/recommend/lr/test_rating_v2")
  }

  /**
    * 根据时间范围读取点击日志
    *
    * @param spark  spark
    * @param begin  开始时间
    * @param end    结束时间
    * @return
    */
  def accessRead(spark:SparkSession, begin:String, end:String): DataFrame = {
    // read dataframe
    val access = spark.sql(
      s"""
         |select
         |  member_id,
         |  listing_id
         |from (
         |  SELECT
         |    member_id               AS member_id,
         |    substring(page, 12)     AS listing_id
         |  FROM dw.uba_page
         |  WHERE page like '10.pd.item-%'
         |    AND validateMemberId(member_id) = true
         |    AND his_time >= '$begin'
         |    AND his_time <= '$end'
         |) t1
         |group by member_id,listing_id
      """.stripMargin)

    // filter
    listingFilter(spark, access)
  }

  /**
    * 根据时间范围读取曝光日志
    *
    * @param spark  spark
    * @param from   开始时间
    * @param end    结束时间
    * @return
    */
  def exposeRead(spark:SparkSession, from:LocalDate, end:LocalDate):DataFrame = {
    var current = from
    var buffer = new ArrayBuffer[DataFrame]()

    // read dataframe
    while(current.isBefore(end.plusDays(1))){
      val path = current.format(DateTimeFormatter.ofPattern("yyyy/MM/dd"))
      println(path)
      buffer += spark.read.json(s"/tiangou/expose/$path/*")
      current = current.plusDays(1)
    }

    // merge dataframe
    var first = buffer.head
    for(i <- 1.until(buffer.length)){
      first = first.union(buffer(i))
    }

    // distinct
    val df = first.filter("mi is not null and mi <> '' and bk is not null and bk <>''")
      .selectExpr("mi as member_id","split(bk,'-')[1] as listing_id")
      .groupBy("member_id","listing_id")
      .count()

    // filter
    listingFilter(spark, df)
  }

  /**
    * 过滤商品状态
    *
    * @param spark      spark
    * @param dataFrame  dataframe
    * @return
    */
  def listingFilter(spark:SparkSession, dataFrame:DataFrame):DataFrame = {

    val listing = spark.sql(
      s"""
         |select
         |  listing_id, source, is_selected
         |from persona.listing
         |where (source=1 and is_selected=1) or source=4
         |""".stripMargin)

    dataFrame.join(listing,Seq("listing_id"),"inner").selectExpr("member_id","listing_id")
  }
}
