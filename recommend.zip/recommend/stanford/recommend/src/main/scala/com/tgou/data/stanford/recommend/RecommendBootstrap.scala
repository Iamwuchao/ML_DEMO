package com.tgou.data.stanford.recommend

import java.time.LocalDate

import org.apache.spark.sql.SparkSession

class RecommendBootstrap(args: Array[String]) {



  def bootstrap(execute: (SparkSession, String, LocalDate, Array[String]) => Unit): Unit = {

    var builder = SparkSession.builder()

    var appName = "local-without-name"
    var date = LocalDate.now().plusDays(-1)

    if(args == null || args.length == 0){
      builder = builder.master("local")
    }else{
      appName = args(0)
      date = LocalDate.now().plusDays(args(1).toInt)
      builder = builder.enableHiveSupport()
    }

    val spark = builder
      .appName(appName)
      .config("hive.metastore.uris","thrift://hnode1:9083")
      .getOrCreate()

    spark.sparkContext.setLogLevel("WARN")// 日志级别

    try {
      execute(spark, appName, date, args)
    } catch {
      case e: Exception => throw new RuntimeException(e)
    } finally {
      spark.close()
    }
  }
}

object RecommendBootstrap {

  def apply(args: Array[String]): RecommendBootstrap = new RecommendBootstrap(args)

}
