package com.tgou.data.stanford.recommend.product.model.icf

/*
 *created by wuchao on 2018/3/26.
 *package_name : com.tgou.data.stanford.recommend.utils
 * 主要用于存储一些配置信息
 */
object ICFConfig {
 val numRecommendations = 100
 val minVisitedPerItem = 1
 val maxPrefsPerUser = 200
 val minPrefsPerUser = 2
 val maxSimilaritiesPerItem = 30  //一个物品最多找几个相似品
 val maxPrefsPerUserForRec = 3  //给用户推荐 他最喜欢的三个商品的相似品
 val min_similary = 0.1f

}
