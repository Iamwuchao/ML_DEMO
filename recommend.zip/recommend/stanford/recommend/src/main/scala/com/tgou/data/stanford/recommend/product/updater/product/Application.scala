package com.tgou.data.stanford.recommend.product.updater.product

import java.time.LocalDate

import com.alibaba.fastjson.JSON
import com.tgou.data.stanford.recommend.RecommendBootstrap
import com.tgou.data.stanford.recommend.utils.{ModelType, PersistUtils, SaveType}
import org.apache.spark.sql.SparkSession

import scala.collection.mutable.ArrayBuffer

/**
  * 平台相似品和关联品
  */
object Application {
  def main(args: Array[String]): Unit = {
    RecommendBootstrap(args).bootstrap(execute)
  }

  def execute(spark: SparkSession, appName: String, date: LocalDate, args: Array[String]): Unit = {

    val isOnline = !"test".equals(args(2))

    val sim = spark.read.parquet("/recommend/data/product_sim")
    val fp  = spark.read.parquet("/recommend/data/product_fp")

    import spark.implicits._

    // 保存cb
    val simDF = sim.toJSON.flatMap(j => {
      val json = JSON.parseObject(j)
      val data = json.getString("data")
      val recs = data.split(",")
      val listing_id = json.getString("listing_id")

      val buffer:ArrayBuffer[(String,String,Int,String,String)] = new ArrayBuffer[(String,String,Int,String,String)]()
      for(i <- recs.indices){
        val arr = recs(i).split(":")
        buffer += ((listing_id,arr(0),i,arr(1),arr(2)))
      }

      buffer
    }).toDF("query_id","rec_id","index","yt","similarity")

    PersistUtils.save(spark,  simDF, ModelType.P_PT_SIM_V1, SaveType.PRODUCT_REC, isOnline)

    // 保存icf
    val fpDF = fp.toJSON.flatMap(j => {
      val json = JSON.parseObject(j)
      val data = json.getString("fp_rec")
      val recs = data.split(",")
      val listing_id = json.getString("listing_id")

      val buffer:ArrayBuffer[(String,String,Int,String,String,String,String,String)] = new ArrayBuffer[(String,String,Int,String,String,String,String,String)]()
      for(i <- recs.indices){
        val arr = recs(i).split(":")
        buffer += ((listing_id,arr(0),i,arr(1),arr(2),arr(3),arr(4),arr(5)))
      }

      buffer
    }).toDF("query_id","rec_id","index","b_id","ar_b","sp","sl","rank")

    PersistUtils.save(spark,  fpDF, ModelType.P_PT_FP_V1, SaveType.PRODUCT_REC, isOnline)
  }
}
