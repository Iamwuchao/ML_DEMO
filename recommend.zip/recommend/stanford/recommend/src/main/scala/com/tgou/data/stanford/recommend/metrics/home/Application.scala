package com.tgou.data.stanford.recommend.metrics.home

import java.time.LocalDate

import com.tgou.data.stanford.core.utils.DateUtils
import org.apache.spark.sql.{DataFrame, SparkSession}

object Application {

  /**
    * 日期-场景-曝光量-点击量-创建订单数-支付笔数-支付金额-点击转化-支付转化
    *
    * @param spark
    * @param appName
    * @param date
    * @param args
    * @return
    */
  def homeTable(spark: SparkSession, appName: String, date: LocalDate, args: Array[String]): DataFrame = {
    val lastDay = DateUtils.dateFormat(date)

    spark.sql(
      s"""
         |select
         |  concat(scene_id,'_','$lastDay') as id,
         |  t1.scene_id,
         |  nvl(t4.count, 0) as create_bs,
         |  nvl(t5.count, 0) as pay_bs,
         |  nvl(t5.amount, 0) as pay_je,
         |  nvl(t7.count, 0) as item_ks,
         |  '$lastDay' as date,
         |from (
         |  select scene_id from meta group by scene_id
         |) t1
         |left join (
         |  -- 统计场景创建订单相关信息
         |  select
         |    scene_id,
         |    count(distinct order_id) as count
         |  from orderItem
         |  where scene_id is not null and order_create_time >= '$lastDay 00:00:00' and order_create_time <= '$lastDay 23:59:59'
         |  group by scene_id
         |) t4 on t1.scene_id = t4.scene_id
         |left join (
         |  -- 统计场景支付订单相关信息
         |  select
         |    scene_id,
         |    count(1) as count,
         |    sum(amount) as amount
         |  from (
         |    select
         |      scene_id,
         |      order_id,
         |      max(order_actual_sales_amount) as amount
         |    from orderItem
         |    where scene_id is not null and order_pay_time >= '$lastDay 00:00:00' and order_pay_time <= '$lastDay 23:59:59'
         |    group by scene_id, order_id
         |  ) t6
         |  group by scene_id
         |) t5 on t1.scene_id = t5.scene_id
         |left join (
         |  select
         |    scene_id,
         |    count(distinct rec_id) as count,
         |  from models_rec
         |  group by scene_id
         |) t7 on t1.scene_id = t7.scene_id
       """.stripMargin)
  }

  /**
    * 日期-业态-支付笔数
    *
    * @param spark
    * @param appName
    * @param date
    * @param args
    * @return
    */
  def homeCharts(spark: SparkSession, appName: String, date: LocalDate, args: Array[String]): DataFrame = {
    val lastDay = DateUtils.dateFormat(date)
    spark.sql(
      s"""
         |select
         |  concat(source,_,'$lastDay') as id,
         |  source,
         |  count(distinct order_id) as pay_bs,
         |  '$lastDay' as date,
         |from orderItem
         |where order_pay_time >= '$lastDay 00:00:00' and order_pay_time <= '$lastDay 23:59:59'
         |group by source
       """.stripMargin)
  }

  /**
    * 日期-支付金额-支付笔数
    *
    * @param spark
    * @param appName
    * @param date
    * @param args
    * @return
    */
  def homeMetrics(spark: SparkSession, appName: String, date: LocalDate, args: Array[String]): DataFrame = {
    val lastDay = DateUtils.dateFormat(date)

    val totalRow = spark.sql(
      s"""
         |select
         |  count(1) as order_count,
         |  sum(amount) as order_amount
         |from (
         |  select
         |    order_id,
         |    max(order_actual_sales_amount) as amount
         |  from (
         |    select
         |      order_id,
         |      order_actual_sales_amount
         |    from orderItem
         |    where order_pay_time >= '$lastDay 00:00:00' and order_pay_time <= '$lastDay 23:59:59'
         |  ) t1
         |  group by order_id
         |) t2
       """.stripMargin)
      .head()
    val order_count = totalRow.get(0)
    val order_amount = totalRow.get(1)

    val homeMetricsDF = spark.createDataFrame(Seq((lastDay, order_amount, order_count, lastDay))).toDF("id", "pay_je","pay_bs","date")
    homeMetricsDF
  }
}
