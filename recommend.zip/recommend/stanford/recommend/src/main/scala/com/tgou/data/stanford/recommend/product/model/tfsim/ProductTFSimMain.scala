package com.tgou.data.stanford.recommend.product.model.tfsim

import java.time.LocalDate

import com.tgou.data.stanford.core.utils.{DateUtils, HBaseQualifier, HBaseUtils}
import com.tgou.data.stanford.recommend.RecommendBootstrap
import org.apache.spark.sql.{SaveMode, SparkSession}

object ProductTFSimMain {

  val MIN_THREDHOLD = 500
  val MAX_THREDHOLD = 10000
  val COLS = Array("fl1","fl2","fl3","fl4")

  def main(args: Array[String]): Unit = {
    RecommendBootstrap(args).bootstrap(execute)
  }

  def execute(spark: SparkSession, appName: String, date: LocalDate, args:Array[String]): Unit = {

    val lastday = DateUtils.dateFormat(date)

    // 1. 注册方法
    TFSimPreprocess.registerView(spark)

    // 2. 获取源数据
    val origin = TFSimService.registerOrigin(spark)

    // 3. 创建自定义分区器
    val (partitioner,statistics) = TFSimService.createPartitioner(spark)

    // 4. 特征处理
    val df = TFSimService.featureProcess(origin,statistics)

    // 5. 计算相似度, 增加门店的分数阈值
    val merged = TFSimService.calculateSim(spark,df,partitioner,args(2).toDouble)

    // 6. 保存到hdfs
    merged.write.mode(SaveMode.Overwrite).parquet("/recommend/data/product_sim")

    // 6. 保存到hbase
    HBaseUtils.save2HBase(
      df              = merged,
      cols            = Array((0,"listing_id","string"),(1,"data","string")),
      table           = "rec:product",
      hBaseQualifier  = HBaseQualifier.product
    )

  }
}
