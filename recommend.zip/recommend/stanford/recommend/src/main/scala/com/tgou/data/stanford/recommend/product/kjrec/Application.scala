package com.tgou.data.stanford.recommend.product.kjrec

import java.time.LocalDate

import com.alibaba.fastjson.JSON
import com.tgou.data.stanford.recommend.RecommendBootstrap
import com.tgou.data.stanford.recommend.utils.MergeUDAF
import org.apache.spark.sql.execution.datasources.hbase.HBaseTableCatalog
import org.apache.spark.sql.{DataFrame, SaveMode, SparkSession}
import org.apache.spark.storage.StorageLevel

object Application {
  def main(args: Array[String]): Unit = {
    RecommendBootstrap(args).bootstrap(execute)
  }

  def execute(spark: SparkSession, appName: String, date: LocalDate, args: Array[String]): Unit = {

    spark.udf.register("merge", new MergeUDAF("|"))
    spark.sparkContext.setLogLevel("info")

    val cb = spark.read.parquet("/ml/kj_recommend/a/cb_user_recommend_result")
    val als = spark.read.parquet("/ml/kj_recommend/a/als_user_recommend_result")
    val icf = spark.read.parquet("/ml/kj_recommend/a/icf_user_recommend_result")
    val tb = spark.read.parquet("/ml/kj_recommend/a/cb_tag_brand_user_recommend_result")
    val t3c = spark.read.parquet("/ml/kj_recommend/a/cb_tag_thrid_category_user_recommend_result")

    import spark.implicits._

    // 保存cb
    cb.toJSON.map(j => {
      val json = JSON.parseObject(j)
      (json.getString("member_id"),json.getString("listing_id")+"^"+j)
    }).toDF("member_id","cb").createOrReplaceTempView("cb")

    val cbDF = spark.sql(s"select member_id, merge(cb) as cb from cb group by member_id")
    saveToHbase(cbDF, "member_id", "cb")

    // 保存als
    val alsDF = als.toJSON.map(j => {
      val json = JSON.parseObject(j)
      (json.getString("userId"),json.getString("recommendProductIds").replaceAll(",","|"))
    }).toDF("member_id","als")

    saveToHbase(alsDF, "member_id", "als")

    // 保存icf
    icf.toJSON.map(j => {
      val json = JSON.parseObject(j)
      (json.getString("member_id"),json.getString("listing_id")+"^"+j)
    }).toDF("member_id", "icf").createOrReplaceTempView("icf")

    val icfDF = spark.sql(s"select member_id, merge(icf) as icf from icf group by member_id")
    saveToHbase(icfDF, "member_id", "icf")

    // 保存tb
    tb.toJSON.map(j => {
      val json = JSON.parseObject(j)
      (json.getString("member_id"),json.getString("listing_id")+"^"+j)
    }).toDF("member_id", "tb").createOrReplaceTempView("tb")

    val tbDF = spark.sql(s"select member_id, merge(tb) as tb from tb group by member_id")
    saveToHbase(tbDF, "member_id", "tb")

    // 保存t3c
    t3c.toJSON.map(j => {
      val json = JSON.parseObject(j)
      (json.getString("member_id"),json.getString("listing_id")+"^"+j)
    }).toDF("member_id", "t3c").createOrReplaceTempView("t3c")

    val t3cDF = spark.sql(s"select member_id, merge(t3c) as t3c from t3c group by member_id")
    saveToHbase(t3cDF, "member_id", "t3c")
  }

  def saveToHbase(df: DataFrame, rowkey:String, column:String): Unit = {

    def catalog = s"""{
                       |"table":{"namespace":"rec", "name":"user_rec"},
                       |"rowkey":"$rowkey",
                       |"columns":{
                       |  "$rowkey":{"cf":"rowkey", "col":"$rowkey", "type":"string"},
                       |  "$column":{"cf":"t",      "col":"$column", "type":"string"}
                       |}
                       |}""".stripMargin

    df.write
      .mode(SaveMode.Overwrite)
      .options(Map(HBaseTableCatalog.tableCatalog -> catalog))
      .format("org.apache.spark.sql.execution.datasources.hbase")
      .save()
  }
}
