package com.tgou.data.stanford.recommend.brand.dcounter

import java.time.format.DateTimeFormatter
import java.time.{LocalDate, LocalDateTime}

import com.tgou.data.stanford.recommend.RecommendBootstrap
import org.apache.spark.sql.{SaveMode, SparkSession}

object UserBrandRecMain {

  def main(args: Array[String]): Unit = {
    RecommendBootstrap(args).bootstrap(execute)
  }

  def execute(spark: SparkSession, appName: String, date: LocalDate, args:Array[String]): Unit = {

    // 合并代码
    spark.udf.register("merge",(top1:String,
                                top2:String,
                                top3:String,
                                top4:String,
                                top5:String,
                                top6:String)=>{
      var data:String = top1
      for( top <- List(top2,top3,top4,top5,top6)){
        if(top != null)
          data += ","+top
      }
      data
    })

    // 刷新用户品牌偏好表
    spark.sql(s"refresh table persona.favor_info")
    val current = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"))

    // 直接请求数据并合并内容
    val result = spark.sql(
      s"""
         |select
         |  member_id,
         |  nvl(merge(top1,top2,top3,top4,top5,top6),'') as data,
         |  '' as time
         |from persona.favor_info
       """.stripMargin)

    result.write.mode(SaveMode.Overwrite).option("sep","^").option("nullValue","").csv("/recommend/sqoop/user_brand_rec")
  }
}
