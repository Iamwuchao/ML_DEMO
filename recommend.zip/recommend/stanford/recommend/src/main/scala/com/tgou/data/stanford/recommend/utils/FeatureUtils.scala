package com.tgou.data.stanford.recommend.utils

import org.apache.spark.ml.feature.{OneHotEncoder, StringIndexer}
import org.apache.spark.ml.linalg.{SparseVector, Vector, Vectors}
import org.apache.spark.sql.{DataFrame, SparkSession}

import scala.collection.mutable.ArrayBuffer

object FeatureUtils {

  /**
    * 增加Vector的维度，如传入的是：<br>
    * Vectors.sparse(3,Seq((1,1.0),(2,1.0))) 变成： Vectors.sparse(4,Seq((1,1.0),(2,1.0)))<br>
    * Vectors.sparse(3,Seq()) 变成：Vectors.sparse(4,Seq((3,1.0)))<br>
    * @param source 想要增加维度的Vector
    * @return
    */
  def expandSparseVector(source: Vector, size: Int=1):Vector = {
    if(source == null) return null

    //创建临时ArrayBuffer，用于存储原来的SparseVector
    val temp = new ArrayBuffer[(Int,Double)]()
    val sourceSize = source.size

    source.foreachActive((i,d) => temp.+=:(i,d))

    // 这里做了两件事情：
    // 第一件：对Vector的长度+1
    // 第二件：把原来全零的向量，末尾加1
    Vectors.sparse(sourceSize+size,if(temp.isEmpty) Seq((sourceSize,1.0)) else temp)
  }

  /**
    * 用于对包含的Null的字段进行OneHot编码，并需要保证编码后能应用于杰卡德算法
    *
    * <strong>注意：</strong>
    * 1 确保使用前注册change,default方法！<br>
    * 2 确保主键不要重复，不然最后合并的时候会重复<br>
    *
    * @param spark        SparkSession
    * @param source       来源DF
    * @param primaryField DataFrame的主键
    * @param sourceField  想要OneHot转码的字段
    * @param targetField  转码后的字段
    * @return
    */
  def oneHotWithNull(spark: SparkSession,
                     source: DataFrame,
                     primaryField: String,
                     sourceField: String,
                     targetField: String
                    ):DataFrame = {

    val fieldNotNullDF = source.filter(s"$sourceField is not null")

    val sourceFieldIndex = sourceField+"Index"
    val sourceFieldVec = sourceField+"Vec"

    val indexer = new StringIndexer()
      .setInputCol(sourceField)
      .setOutputCol(sourceFieldIndex)
      .fit(fieldNotNullDF)
    val indexed = indexer.transform(fieldNotNullDF)

    val encoder = new OneHotEncoder()
      .setInputCol(sourceFieldIndex)
      .setOutputCol(sourceFieldVec)

    val encoded = encoder.transform(indexed)

    // 获得当前Vector的Size大小
    val size = encoded.take(1).head.getAs[SparseVector](sourceFieldVec).size

    val fieldNullDF = source.filter(s"$sourceField is null")
      .selectExpr(primaryField,sourceField,s"null as $sourceFieldIndex",s"default(${size+1}) as $targetField")

    val target = fieldNullDF.union(encoded.selectExpr(primaryField,sourceField,sourceFieldIndex,s"change($sourceFieldVec) as $targetField"))

    target
  }
}
