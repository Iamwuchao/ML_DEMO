package com.tgou.data.stanford.recommend.product.updater.kjhot

import java.time.LocalDate

import com.alibaba.fastjson.JSON
import com.tgou.data.stanford.recommend.RecommendBootstrap
import com.tgou.data.stanford.recommend.utils.{ModelType, PersistUtils, SaveType}
import org.apache.spark.sql.SparkSession

/**
  * 跨境旧版热销品
  */
object Application {
  def main(args: Array[String]): Unit = {
    RecommendBootstrap(args).bootstrap(execute)
  }

  def execute(spark: SparkSession, appName: String, date: LocalDate, args: Array[String]): Unit = {

    val isOnline = !"test".equals(args(2))

    import spark.implicits._

    val x_nr_hot = spark.read.parquet("/ml/kj_recommend/a/hot_product_result")
    x_nr_hot.createOrReplaceTempView("x_nr_hot")

    val hot = spark.sql(s"select row_number() over ( order by sl desc) as index, listing_id as rec_id, sl from x_nr_hot ")

    val formatHotDF = hot.toJSON
      .map(json => {
        val jo = JSON.parseObject(json)
        (jo.getString("index"),jo.getString("rec_id"),json)
      })
      .toDF("index","rec_id","info")

    PersistUtils.save(spark, formatHotDF, ModelType.P_KJ_HOT_V1, SaveType.SQOOP_REC,isOnline)
  }
}
