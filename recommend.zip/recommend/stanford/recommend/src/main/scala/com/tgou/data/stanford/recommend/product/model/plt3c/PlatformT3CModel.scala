package com.tgou.data.stanford.recommend.product.model.plt3c

import java.time.LocalDate
import java.time.format.DateTimeFormatter

import com.alibaba.fastjson.JSONObject
import com.tgou.data.stanford.core.utils.DateUtils
import com.tgou.data.stanford.recommend.RecommendBootstrap
import com.tgou.data.stanford.recommend.utils.{ModelType, PersistUtils, SaveType}
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

import scala.collection.mutable.ArrayBuffer

//case class HotCategoryBean(listing_id:String,third_category:String,score:Double){}
//case class HotCategoryLiteBean(listing_id:String,score:Double){}
//case class HotCategorySqoopBean(index:Long,rec_id:String,info:String){}

/**
  * Created by Travis on 30/03/2018.
  */
object PlatformT3CModel {
  def main(args: Array[String]) {
    RecommendBootstrap(args).bootstrap(execute)
  }

  def execute(spark: SparkSession, appName: String, date: LocalDate, args: Array[String]): Unit = {

    val online = !"test".equals(args(2))
    val dateStr = DateUtils.dateFormat(date)

//    val TOTAL_HOT_PRODUCT_COUNT = 100
    val CATEGORY_SIZE = 30

    spark.udf.register("genInfo", (third_category:String, score:Double, is_activity_product:String)=>   {
      val json = new JSONObject()
      json.put("third_category", third_category)
      json.put("score", score)
      json.put("is_activity_product", is_activity_product)

      json.toJSONString
    })

    val mergedResultDF = spark.read.parquet(s"/persona/data/user_product_ratings")
    mergedResultDF.createOrReplaceTempView("merged_score")

    //------------------------
    // 1. Fetch hot t3c products
    //------------------------
    val hotT3CPhase1SqlText =
      s"""
         |SELECT
         |  *
         |FROM (
         |  SELECT
         |    row_number() over (PARTITION BY a.category3 ORDER BY a.is_activity_product DESC, m.score DESC) as hot_index,
         |    m.listing_id,
         |    genInfo(a.category3, m.score, a.is_activity_product),
         |    a.category3 as third_category
         |  FROM (
         |    SELECT
         |        listing_id,
         |        sum(score) AS score
         |    FROM
         |        merged_score
         |    GROUP BY
         |        listing_id
         |  ) m
         |  INNER JOIN persona.listing a
         |    ON m.listing_id = a.listing_id
         |    AND a.listing_state='onshelf'
         |    AND a.listing_id != '9116001'
         |) t
         |WHERE hot_index <= $CATEGORY_SIZE
         |ORDER BY hot_index
  """.stripMargin

    val hotT3CPhase1DF = spark.sql(hotT3CPhase1SqlText)
    hotT3CPhase1DF.createOrReplaceTempView("hot_t3c_phase1")

    //------------------------
    // 2. Join user profile table
    //------------------------

    val userFavorCategoryDF =  spark.read.format("parquet").load("/persona/data/user_favor_category")
    userFavorCategoryDF.createOrReplaceTempView("user_favor_category")

    val hotT3CSqlText =
      s"""
        |SELECT
        |  member_id as query_id,
        |  listing_id as rec_id,
        |  row_number() over (PARTITION BY member_id ORDER BY hot_index, category_index) as index
        |FROM  (
        |  SELECT
        |    u.member_id,
        |    u.category_id AS third_category,
        |    u.index AS category_index,
        |    t.listing_id,
        |    t.hot_index
        |  FROM user_favor_category u
        |  INNER JOIN hot_t3c_phase1 t
        |    ON u.category_id = t.third_category
        |  ) t
      """.stripMargin

    val hotT3CDF = spark.sql(hotT3CSqlText)

    PersistUtils.save(spark, hotT3CDF, ModelType.P_PT_T3C_V1, SaveType.USER_PRODUCT_REC, online)

  }
}
