package nlp;

import java.time.LocalDate;

public class LocalDateTest {
    public static void main(String[] args) {
        LocalDate localDate = LocalDate.now().minusDays(2);
        System.out.println(localDate.plusDays(-360));
    }
}
