package nlp;

import com.hankcs.hanlp.HanLP;
import com.hankcs.hanlp.dictionary.CustomDictionary;
import com.hankcs.hanlp.dictionary.stopword.CoreStopWordDictionary;
import com.hankcs.hanlp.seg.common.Term;
import com.hankcs.hanlp.tokenizer.BasicTokenizer;
import com.hankcs.hanlp.tokenizer.NotionalTokenizer;

import java.util.Arrays;
import java.util.List;

public class HanNLPTest {
    public static void main(String[] args) {
        CustomDictionary.add("居民rrr");
        String text = "小区居民有的反对喂养流浪猫，而有的居民rrr却赞成喂养这些小宝贝";
        // 可以动态修改停用词词典
        CoreStopWordDictionary.add("居民");
        System.out.println(NotionalTokenizer.segment(text));
        CoreStopWordDictionary.remove("居民");
        System.out.println(NotionalTokenizer.segment(text));
        // 可以对任意分词器的结果执行过滤
        List<Term> termList = BasicTokenizer.segment(text);
        System.out.println(termList);
        CoreStopWordDictionary.apply(termList);
        System.out.println(termList);


        CustomDictionary.add("HanLP汉语");
        CustomDictionary.add("HanLP汉语");
        CustomDictionary.add("HanLP汉语");
        CustomDictionary.add("HanLP汉语");
       //CoreStopWordDictionary.add("");
        CoreStopWordDictionary.add(" ");
        CoreStopWordDictionary.add("+");
        CoreStopWordDictionary.add("，");
        CoreStopWordDictionary.add("海");

        System.out.println(HanLP.segment("你好，欢迎使用 HanLP汉语处理包！邢海龙"));
        System.out.println(HanLP.newSegment().seg("你好，欢迎使用HanLP汉语处理包！"));
    }
}
