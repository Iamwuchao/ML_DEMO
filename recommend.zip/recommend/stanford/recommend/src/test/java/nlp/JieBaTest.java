package nlp;

import com.huaban.analysis.jieba.JiebaSegmenter;
import com.huaban.analysis.jieba.WordDictionary;
import scala.collection.mutable.ArrayBuffer;

import java.nio.file.Paths;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class JieBaTest {
    public static void main(String[] args) {
        WordDictionary wordDictionary = WordDictionary.getInstance();
        wordDictionary.init(Paths.get("recommend/src/test/java/nlp"));
        JiebaSegmenter segmenter = new JiebaSegmenter();

        System.out.println(segmenter.sentenceProcess("ALT冬装新款夹克40850111"));
        System.out.println(segmenter.sentenceProcess("七匹狼毛衫111350201859"));
        System.out.println(segmenter.sentenceProcess("乐町大衣C1AA43019"));
        System.out.println(segmenter.sentenceProcess("亨奴亨奴小衫14041"));
        System.out.println(segmenter.sentenceProcess("依思Q休闲短靴14186309hello`baby"));
        System.out.println(segmenter.sentenceProcess("3d床垫3d打印机耗材3g无线路由器"));

        LocalDate local = LocalDate.now();
        local.minusDays(1);
        local.format(DateTimeFormatter.ofPattern("yyyy-MM-dd"));
    }
}
