import org.apache.spark.ml.linalg.{Matrix, Vectors}
import org.apache.spark.ml.stat.Correlation
import org.apache.spark.sql.{Row, SparkSession}

/**
  * 皮尔森与斯皮尔曼相关系数
  * https://www.cnblogs.com/zhangchaoyang/articles/2631907.html
  * 官网源码
  * https://github.com/apache/spark/blob/master/examples/src/main/scala/org/apache/spark/examples/ml/CorrelationExample.scala
  */
object CorrTest {
  def main(args: Array[String]): Unit = {
    val spark = SparkSession
      .builder
      .appName("CorrelationExample")
      .master("local[*]")
      .getOrCreate()

    spark.sparkContext.setLogLevel("WARN")

    import spark.implicits._

//    // $example on$
//    val data = Seq(
//      Vectors.sparse(4, Seq((0, 1.0), (3, -2.0))),
//      Vectors.dense(4.0, 5.0, 0.0, 3.0),
//      Vectors.dense(6.0, 7.0, 0.0, 8.0),
//      Vectors.sparse(4, Seq((0, 9.0), (3, 1.0)))
//    )
//
//    val df = data.map(Tuple1.apply).toDF("features")
//    val Row(coeff1: Matrix) = Correlation.corr(df, "features").head
//    println("Pearson correlation matrix:\n" + coeff1.toString)
//
//    val Row(coeff2: Matrix) = Correlation.corr(df, "features", "spearman").head
//    println("Spearman correlation matrix:\n" + coeff2.toString)
//    // $example off$

    val x_df = spark.createDataFrame(Seq((1,"a",3),(2,"b",4),(3,"a",5),(4,"a",1),(5,"b",2)))
    x_df
      .map(r=>{
        (r.getInt(0),r.getString(1),r.getInt(2))
      }).collect()
      .sortWith((a,b) => {
        if(a._2 == b._2){
          // 默认按照分值排序
          a._3 > b._3
        }else{
          // 业态数量小的排在前面，即优先选择百货的商品
          true
        }
      }).foreach(println(_))

    spark.stop()
  }

}
