import org.apache.spark.sql.{DataFrame, SparkSession}

object TestSort1 {
  def main(args: Array[String]): Unit = {

    var spark = SparkSession
      .builder()
      .master("local")
      .appName("sort-main")
      .getOrCreate()
    spark.sparkContext.setLogLevel("WARN")// 日志级别

    //import spark.implicits._

    Seq((1,"a",3),(2,"b",4),(3,"a",5),(4,"a",1),(5,"b",2))
      .sortWith((a,b) => {
        if(a._2.equals(b._2)){
          // 默认按照分值排序
          a._3 > b._3
        }else{
          // 业态数量小的排在前面，即优先选择百货的商品
          a._3 > b._3
        }
      }).foreach(println(_))

  }

  case class Bean(a:Int, b:String, c:Int){}
}
