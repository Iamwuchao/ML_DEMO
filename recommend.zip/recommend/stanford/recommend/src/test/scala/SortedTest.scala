package com.tgou.data.stanford.recommend.metrics

import org.apache.spark.sql.SparkSession

object SortedTest {
  def main(args: Array[String]): Unit = {
    val spark = SparkSession.builder().master("local").appName("ttt").getOrCreate()
    import spark.implicits._
    spark.createDataFrame(Seq(
      ("","1","2018-04-06 09:30:07"),
      ("","1","2018-04-06 09:31:07"),
      ("3","1","2018-04-06 09:33:07"),
      ("3","1","2018-04-06 09:34:07"),
      ("","2","2018-04-06 09:30:07"),
      ("4","2","2018-04-06 09:31:07"),
      ("","2","2018-04-06 09:32:07"),
      ("5","2","2018-04-06 09:33:07"),
      ("5","2","2018-04-06 09:34:07")))
      .toDF("m","u","time")
      .selectExpr("m","u","time","unix_timestamp(time) as timestamp")
      .as[Metrics]
      .groupByKey(m=>m.u)
      .flatMapGroups((k:String,values:Iterator[Metrics])=>{
        val sorted = values.toList.sortWith((a,b)=>a.time > b.time)//根据rank进行排序
        var member_id = sorted.head.m

        // member_id 补全
        sorted.foreach(m => {
          if(m.m == ""){
            m.m = member_id
          }else{
            member_id = m.m
          }
        })


        println(sorted)
        sorted
      }).show(false)

  }

  case class Metrics(var m:String,u:String,time:String,timestamp:Long){}
}
