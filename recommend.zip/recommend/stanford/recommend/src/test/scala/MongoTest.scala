import com.hankcs.hanlp.dictionary.CustomDictionary
import com.hankcs.hanlp.seg.common.Term
import com.hankcs.hanlp.tokenizer.NotionalTokenizer
import com.tgou.data.stanford.recommend.utils.MongoManager
import org.apache.commons.lang3.StringUtils

import scala.collection.mutable.ArrayBuffer

object MongoTest {
  def main(args: Array[String]): Unit = {
//    val col = MongoManager.getDB().getCollection("nerword")
//    val result = col.find()
//    val iter = result.iterator()
//    while(iter.hasNext){
//      val document = iter.next()
//
//      print(document.get("word"))
//      println(document.get("similar_word1"))
//    }
//    println(result)


    val col = MongoManager.getDB().getCollection("nerword")
    val result = col.find()
    val iter = result.iterator()
    val seg_tokens:ArrayBuffer[String] = new ArrayBuffer[String]()
    while(iter.hasNext){
      val document = iter.next()

      for(s <- Seq("word","similar_word1","similar_word2","similar_word3","similar_word4","similar_word5")){
        if(document.get(s)!=null && StringUtils.isNotBlank(document.get(s).toString)) {
          seg_tokens += document.get(s).toString
        }
      }
    }

    seg_tokens.foreach(s => CustomDictionary.add(s))
    println(NotionalTokenizer.segment("毛毛虫鞋和135胶片单反3ds游戏软件"))


  }
}
