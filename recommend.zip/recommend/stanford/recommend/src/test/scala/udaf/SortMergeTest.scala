package udaf

import com.tgou.data.stanford.recommend.utils.{AlternateMergeUDAF, SortMergeUDAF}
import org.apache.spark.sql.SparkSession

object SortMergeTest {
  def main(args: Array[String]): Unit = {
    val spark = SparkSession
      .builder
      .appName("CorrelationExample")
      .master("local[*]")
      .getOrCreate()

    spark.sparkContext.setLogLevel("WARN")

    import spark.implicits._


    spark.createDataFrame(Seq(
      ("a",1,"101:101"),
      ("a",5,"501:501"),
      ("a",2,"201:201"),
      ("a",4,"401:401"),
      ("a",3,"301:301"),
      ("b",5,"501:501"),
      ("b",2,"201:201")
    )).toDF("id","rank","info").createOrReplaceTempView("x_test")

    spark.udf.register("sort_merge", new SortMergeUDAF())

    spark.sql(
      s"""
         |select
         |   id,
         |   sort_merge(rank,info) as data
         |from x_test
         |group by id
       """.stripMargin).show(false)
  }
}
