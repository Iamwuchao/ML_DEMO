package udaf

import com.tgou.data.stanford.recommend.utils.AlternateMergeUDAF
import org.apache.spark.sql.SparkSession

object AlterMergeTest {
  def main(args: Array[String]): Unit = {
    val spark = SparkSession
      .builder
      .appName("CorrelationExample")
      .master("local[*]")
      .getOrCreate()

    spark.sparkContext.setLogLevel("WARN")

    import spark.implicits._



    spark.createDataFrame(Seq(
      ("a",1,"101:101,102:102,103:103,104:004"),
      ("a",2,"201:201"),
      ("a",3,"301:301,302:302"),
      ("a",4,"401:401,402:402,403:403"),
      ("a",5,"501:501"),
      ("b",2,"201:201,202:202"),
      ("b",5,"501:501,502:502")
    )).toDF("id","rank","info").createOrReplaceTempView("x_test")

    spark.udf.register("alter_merge", new AlternateMergeUDAF())

    spark.sql(
      s"""
         |select
         |   id,
         |   alter_merge(rank,info) as data
         |from x_test
         |group by id
       """.stripMargin).show(false)
  }
}
