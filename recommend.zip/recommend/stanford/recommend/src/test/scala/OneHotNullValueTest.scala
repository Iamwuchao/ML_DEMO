import org.apache.spark.ml.feature.RFormula
import org.apache.spark.ml.linalg.{Vector, Vectors}
import org.apache.spark.sql.SparkSession


object OneHotNullValueTest {
  def main(args: Array[String]): Unit = {

    /**
      * String => StringIndex => OneHotEncoder
      */

    var spark = SparkSession
      .builder()
      .master("local")
      .appName("Jaccard-main")
      .getOrCreate()
    spark.sparkContext.setLogLevel("WARN")// 日志级别

    val dataset = spark.createDataFrame(Seq(
      (7, Vectors.sparse(3,Seq((0,1.0))), "c", 1.0),
      (8, Vectors.sparse(3,Seq((1,1.0))), "c", 0.0),
      (9, Vectors.sparse(3,Seq((2,1.0))), "d", 0.0),
      (9, Vectors.sparse(3,Seq((2,1.0))), "a", 0.0),
      (9, Vectors.sparse(3,Seq()), "d", 0.0)
    )).toDF("id", "country", "hour", "clicked")

    val formula = new RFormula()
      .setFormula("clicked ~ country + hour")
      .setFeaturesCol("features")

    val output = formula.fit(dataset).transform(dataset)
    output.select("features").show()
    output.write.option("header","true").csv("xxx")

//    spark.udf.register("change",(vec:Vector)=>FeatureUtils.expandSparseVector(vec))
//    spark.udf.register("default",(size:Int)=>Vectors.sparse(size,Seq()))
//
//    val df = spark.createDataFrame(Seq(
//      (0, "a",3),
//      (1, "b",3),
//      (2, "c",3),
//      (3, "a",3),
//      (4, "a",3),
//      (5, "c",3),
//      (6,null,3)
//    )).toDF("id", "category","other")
//    df.createOrReplaceTempView("df")
//
//    FeatureUtils.oneHotWithNull(spark,df,"id","category","vec").show()

    spark.close()
  }

  case class Bean(id:Any,vec:Vector)
}
