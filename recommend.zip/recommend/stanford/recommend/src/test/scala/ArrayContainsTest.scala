import java.util.Locale

import scala.collection.mutable.ArrayBuffer

object ArrayContainsTest {
  def main(args: Array[String]): Unit = {
    val buffer:ArrayBuffer[(String,Integer)] = new ArrayBuffer[(String,Integer)]()
    buffer += (("",1))

  }
}
