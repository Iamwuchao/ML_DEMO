import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.functions.col

object AggregateTest {
  def main(args: Array[String]): Unit = {
    val spark = SparkSession.builder().appName("test").master("local[*]").getOrCreate()
    spark.sparkContext.setLogLevel("WARN")

//    val z =spark.createDataFrame(Seq((1,1),(2,1),(4,1),(5,1),(8,1),(9,1))).repartition(3)
//    println(z.rdd.map(r=>r.getInt(0)).aggregate(3)(seq,comb))
//    println(z.rdd.map(r=>r.getInt(0)).treeAggregate(3)(seq,comb))

    val df = spark.createDataFrame(Seq((1,1),(1,1),(1,1),(2,1),(4,1),(5,1),(8,1),(9,1))).toDF("a","b")
    df.select(col("a").as("aa"),col("b")).groupBy("aa","b").count().show()
  }

  def seq(a:Int,b:Int):Int={
    println("seq:"+a+":"+b)
    math.min(a,b)
  }

  def comb(a:Int,b:Int):Int={
    println("comb:"+a+":"+b)
    a+b
  }

}
