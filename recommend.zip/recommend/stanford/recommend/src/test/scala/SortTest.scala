import scala.collection.mutable.ArrayBuffer

object SortTest {
  def main(args: Array[String]): Unit = {
    val list = ArrayBuffer(
      SortBean("001",20,30),
      SortBean("002",21,40),
      SortBean("003",20,50),
      SortBean("004",21,60),
      SortBean("005",20,70)
    )

    val newlist = list.sortWith((a,b)=>{
      if(a.age == b.age){
        a.money.compareTo(b.money)>0
      }else{
        a.age.compareTo(b.age)>0
      }
    })

    list.foreach(println(_))
    println("*************")
    newlist.foreach(println(_))
  }
}
case class SortBean(id:String,age:Int,money:Int){
}
